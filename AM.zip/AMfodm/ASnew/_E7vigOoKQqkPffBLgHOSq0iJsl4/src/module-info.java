/**
 * 
 */
/**
 * 
 */
module _E7vigOoKQqkPffBLgHOSq0iJsl4 {
	requires JEntispace; 
	requires java.logging;
	requires java.desktop;
	requires _TZ34ntGtza4ryheSV3Xo_JOLOIU;

}