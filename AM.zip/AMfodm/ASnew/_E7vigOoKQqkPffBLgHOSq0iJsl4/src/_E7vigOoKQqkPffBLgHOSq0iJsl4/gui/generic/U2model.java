package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic;

import java.util.Hashtable;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.M2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V4;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

public class U2model {
	public static final String MOTOR="motor";
	public static final String OPTION="option";
	public static final String GIVEN="given";
	public static final String ESTIMATED="estimated";
	//state
	double i2x=0;
	double i2y=0;
	double isx=0;
	double isy=0;
	double fx=0;
	double fy=0;
	//outputs
	double wr=0;
	double m=0;
	//inputs
	double usx=0;
	double usy=0;
	double clock=Double.MIN_VALUE;
	double mc=0;
	//parameters
	double ls=0;
	double rs=0;
	double l2=0;
	double r2=0;
	double lm=0;
	double j=0;
	int pol=1; 

public U2model(Entigrator entigrator,String locator$) {
  try {
	  String motor$=Locator.getProperty(locator$, MOTOR);
	  Sack motor=entigrator.getEntityAtLabel(motor$);
	  String option$=Locator.getProperty(locator$, OPTION);
	  double w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
     rs=0;
     if(GIVEN.equals(option$))
	   try{rs=Double.parseDouble(motor.getElementItemAt("zgvn", "rs"));}catch(Exception ee) {}
     if(ESTIMATED.equals(option$))
  	   try{rs=Double.parseDouble(motor.getElementItemAt("zpar", "rs"));}catch(Exception ee) {}
	 r2=0;
	 if(GIVEN.equals(option$))
		 try{r2=Double.parseDouble(motor.getElementItemAt("zgvn", "r2"));}catch(Exception ee) {}
	 if(ESTIMATED.equals(option$))
	  	   try{r2=Double.parseDouble(motor.getElementItemAt("zpar", "r2"));}catch(Exception ee) {}
	 ls=0;
	 if(GIVEN.equals(option$))
	 try{
		double xs=Double.parseDouble(motor.getElementItemAt("zgvn", "xs"));
		ls=xs/w0;
	 }catch(Exception ee) {}
	 if(ESTIMATED.equals(option$))
		 try{
			double xs=Double.parseDouble(motor.getElementItemAt("zpar", "xs"));
				ls=xs/w0;
			 }catch(Exception ee) {}
	 
	 l2=0;
	 if(GIVEN.equals(option$))
	 try{
		double x2=Double.parseDouble(motor.getElementItemAt("zgvn", "x2"));
		l2=x2/w0;
	 }catch(Exception ee) {}
	 if(ESTIMATED.equals(option$))
		 try{
			double xs=Double.parseDouble(motor.getElementItemAt("zpar", "x2"));
			l2=xs/w0;
		 }catch(Exception ee) {}
	 
	 lm=0;
	 if(GIVEN.equals(option$))
	 try{
			double xm=Double.parseDouble(motor.getElementItemAt("zgvn", "xm"));
			lm=xm/w0;
		 }catch(Exception ee) {}
	 if(ESTIMATED.equals(option$))
		 try{
			double xm=Double.parseDouble(motor.getElementItemAt("zpar", "xm"));
				lm=xm/w0;
			 }catch(Exception ee) {}
	
	j=Double.MIN_VALUE;
		try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
		pol=1; 
		try{pol=Integer.parseInt(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
	    clock=ls/(rs*100);
  }catch(Exception e) {
	  System.out.println("U2model:"+e.toString());
  }
}
public void reset() {
	i2x=0;
	i2y=0;
	isx=0;
	isy=0;
	fx=0;
	fy=0;
	wr=0;
	//EduHandler.printHashtableDouble("U2model:reset:outs", getOuts());
}
public void stride(Hashtable<String,Double>ins) {
	try {
	//	EduHandler.printHashtableDouble("U2model:stride:ins", ins);
		mc=0;
		try{ mc=ins.get("mc");}catch(Exception ee) {}
	//	System.out.println("U2model:stride:ls="+ls+" rs=="+rs+" l2="+l2+" r2="+r2+" lm="+lm+" j="+j+" pol="+pol+" mc="+mc);
		clock=0.01*ls/rs;
		try {clock=ins.get("clock");}catch(Exception ee) {}
		usx=0;
		try {usx=ins.get("usx");}catch(Exception ee) {}
		usy=0;
		try {usy=ins.get("usy");}catch(Exception ee) {}
	//	System.out.println("U2model:stride:clock="+clock+" usx="+usx+" usy="+usy+" mc="+mc);
		V2 i2= new  V2 (i2x,i2y);
		V2 fl=new V2(fx,fy);  
		V4 s= new V4(fl,i2);
		M2 ll=new M2(1+ls/lm,-ls,1,l2);
		M2 rr=new M2(-rs/lm,rs,0,-r2);
		M2 ee=new M2(0,0,1,l2);
		M2 lli=ll.inverse();
		
		//System.out.println("U2model:stride:m="+m+" i2n="+i2.norm()+" fn="+fl.norm()+" a="+i2.angle(fl));
		M2 t1=lli.multiplication(rr);
		V4 s1=t1.product(s);		
		M2 t2=lli.multiplication(ee);
		V4 s2=t2.product(s.componentRotation().product(wr));
		V2 us= new  V2 (usx,usy);
		V4 u=new V4(us,new V2(0,0));
		V4 s3=lli.product(u);
		V4 ds= s1.add(s2).add(s3);
		V4 sn=s.add(ds.product(clock));   
	  	fl=sn.v1;
		i2=sn.v2;
		V2 im=fl.product(1/lm);
		V2 is=im.product(1).add(i2.product(-1));
		m=1.5*pol*fl.crossProduct(i2); 
		i2x=i2.x;
		i2y=i2.y;
		isx=is.x;
		isy=is.y;
		fx=fl.x;
		fy=fl.y;
		double dwr=pol*(m-mc)*clock/j;
		wr=wr+dwr;
		//System.out.println("U2model:stride: wr="+wr);
	}catch(Exception e) {
		  System.out.println("U2model:stride"+e.toString());
	  }
}
public Hashtable <String,Double> getOuts(){
	Hashtable <String,Double> outs=new Hashtable <String,Double>();
	outs.put("i2x", i2x);
	outs.put("i2y", i2y);
	outs.put("isx", isx);
	outs.put("isy", isy);
	outs.put("fx", fx);
	outs.put("fy", fy);
	outs.put("wr", wr);
	outs.put("m", m);
	//System.out.println("U2model:getOuts:usx="+usx+" usy="+usy);
	//EduHandler.printHashtableDouble("U2model:outs", outs);
	return outs;
}
public Hashtable<String, Double> getSettings() {
	Hashtable<String, Double> settings=new Hashtable<String, Double>();
	settings.put("ls",ls);
	settings.put("rs",rs);
	settings.put("l2",l2);
	settings.put("r2",r2);
	settings.put("lm",lm);
	settings.put("j",j);
	settings.put("pol",(double)pol);
	return settings;
}
public void putSettings(Hashtable<String, Double> settings) {
	try {
	try {ls=settings.get("ls");}catch(Exception ee) {}
	try {rs=settings.get("rs");}catch(Exception ee) {}
	try {l2=settings.get("l2");}catch(Exception ee) {}
	try {r2=settings.get("r2");}catch(Exception ee) {}
	try {lm=settings.get("lm");}catch(Exception ee) {}
	try {j=settings.get("j");}catch(Exception ee) {}
	try{pol=(int)settings.get("pol").intValue();}catch(Exception ee) {}
	try{clock=settings.get("clock").intValue();}catch(Exception ee) {}
	}catch(Exception e) {
		System.out.println("u2model:putSettings:"+e.toString());
	}
}
public double getClock() {
	double clock=Double.MIN_VALUE;
	try {clock=	0.01*(ls+l2)/(rs+r2);}catch(Exception ee) {}
	return clock;
}
public void setClock(double clock) {
	this.clock=clock;
}
}
