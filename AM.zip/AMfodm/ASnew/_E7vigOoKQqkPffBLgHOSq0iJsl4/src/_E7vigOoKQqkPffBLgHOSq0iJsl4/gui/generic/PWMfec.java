package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic;

import java.util.Hashtable;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.M2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V4;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

public class PWMfec {
	public static final String MOTOR="motor";
	public static final String OPTION="option";
	public static final String GIVEN="given";
	public static final String ESTIMATED="estimated";
	public static final String FLUX="FLUX";
	public static final String EMF="EMF";
	public static final String ORIENTATION="orientation";
	
	public static final int F0=0;//magnetizing
	public static final int F1=1;//flux error
	public static final int F2=2;//flux stable
	public static final int W0=0;//speed tuning
	public static final int W1=1;//speed error
	public static final int W2=2;//speed stable
	public static final int W3=3;//hight speed 
	public static final int E0=0;//normal flux
	public static final int E1=1;//week flux
	double ux=0;
	double uy=0;
	double uxf=0;
	double uyf=0;
	

	//input
	double Ud=0;
	double preferredClock=Double.MIN_VALUE;
	//state
			double irefx=0;
			double irefy=0;
			double i2x=0;
			double i2y=0;
			double isx=0;
			double isy=0;
			double fx=0;
			double fy=0;
			double fox=0;
			double foy=0;
			double pa=0;
		//	double idf=0;
		//	double iqf=0;
			double fg=0;
			double es=0;
			double iqf=0;
			double idf=0;
	//outputs
			double wr=0;
			double m=0;
			int k=0;
	//secondary outputs
			double isa=0;
			double isb=0;
			double isc=0;
			double ismod=0;
			double fmod=0;
	//inputs
			double clock=Double.MIN_VALUE;
			double mc=0;
			double w=0;
	//parameters
		//object
			double ls=0;
			double rs=0;
			double l2=0;
			double r2=0;
			double lm=0;
			double j=0;
			int pol=1; 
			double isd=0;
			double w0=0;
			double fnom=0;
			double enom=0;
			double idnom=0;
	//regulator
	  //settings
	   double Kid=0;
	   double Tiq=0;
	   double Kiq=0;
	   double Krs=0;
	   String orientation=FLUX;
	   //secondary parameters
	   double Imax=0;
	   double Fmin=0; 
	// variables
	   double iqi=0;
	   double mf=0;
	   double ms=0;
	   double wef=0;
	   double fce=0;
	   public PWMfec(Entigrator entigrator,String locator$) {
			  reset(entigrator,locator$);
			}
	   public void reset(Entigrator entigrator,String locator$) {
			//System.out.println("PWMfec:reset:0:locator="+locator$);
	  ux=0;
	  uy=0;
	  uxf=0;
	  uyf=0;
	  i2x=0;
	  i2y=0;
	  isx=0;
	  isy=0;
	  fx=0;
	  fy=0;
	  wr=0;
	  iqi=0;
	  fox=0;
	  foy=0;
	  pa=0;
	  mf=0;
	  wef=0;
	  fce=0;
	  try {
	  String motor$=Locator.getProperty(locator$, MOTOR);
	  Sack motor=entigrator.getEntityAtLabel(motor$);
	  if(motor==null) {
		  System.out.println("PWMfec:reset:cannot get motor="+motor$+" in locator="+locator$);
					  return;
	  }
	  String fec$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	  Sack  fec=entigrator.getEntityAtLabel(fec$);
	  String option$=Locator.getProperty(locator$, OPTION);
	  w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
	     rs=0;
	  if(GIVEN.equals(option$))
		  try{rs=Double.parseDouble(motor.getElementItemAt("zgvn", "rs"));}catch(Exception ee) {}
	  if(ESTIMATED.equals(option$))
		  try{rs=Double.parseDouble(motor.getElementItemAt("zpar", "rs"));}catch(Exception ee) {}
	  r2=0;
	  if(GIVEN.equals(option$))
		 try{r2=Double.parseDouble(motor.getElementItemAt("zgvn", "r2"));}catch(Exception ee) {}
	  if(ESTIMATED.equals(option$))
		 try{r2=Double.parseDouble(motor.getElementItemAt("zpar", "r2"));}catch(Exception ee) {}
	  ls=0;
	  if(GIVEN.equals(option$))
		 try{
			double xs=Double.parseDouble(motor.getElementItemAt("zgvn", "xs"));
			ls=xs/w0;
		 }catch(Exception ee) {}
	  if(ESTIMATED.equals(option$))
		 try{
			double xs=Double.parseDouble(motor.getElementItemAt("zpar", "xs"));
			ls=xs/w0;
		 }catch(Exception ee) {}
	  l2=0;
	  if(GIVEN.equals(option$))
		 try{
			double x2=Double.parseDouble(motor.getElementItemAt("zgvn", "x2"));
			l2=x2/w0;
		}catch(Exception ee) {}
	  if(ESTIMATED.equals(option$))
		 try{
			double xs=Double.parseDouble(motor.getElementItemAt("zpar", "x2"));
			l2=xs/w0;
		 }catch(Exception ee) {}
			 lm=0;
	   if(GIVEN.equals(option$))
		   try{
			   double xm=Double.parseDouble(motor.getElementItemAt("zgvn", "xm"));
				lm=xm/w0;
			}catch(Exception ee) {}
		if(ESTIMATED.equals(option$))
			try{
				double xm=Double.parseDouble(motor.getElementItemAt("zpar", "xm"));
				lm=xm/w0;
			}catch(Exception ee) {}
		j=Double.MIN_VALUE;
			try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
		pol=1; 
			try{pol=Integer.parseInt(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
		isd=0;
			try{isd=Double.parseDouble(motor.getElementItemAt("nvar","isd" ));} catch(NumberFormatException nfe){ isd=0; }
		double mn=0;
			try{mn=Double.parseDouble(motor.getElementItemAt("nvar","mn" ));} catch(NumberFormatException nfe){ mn=0; }
		double cos=0;	
			try{cos=Double.parseDouble(motor.getElementItemAt("nvar","cos" ));} catch(NumberFormatException nfe){ cos=0; }
	    orientation=FLUX;
	    if(EMF.equals(fec.getElementItemAt("pwmfec","orientation" )))
	    	orientation=EMF;	
		System.out.println("PWMfec:reset:0:isd="+isd+" mn="+mn+" cos="+cos+" orientation="+orientation);	
		clock=ls/(rs*1000);
		Ud=0;
		try{Ud=Double.parseDouble(fec.getElementItemAt("pwmfec","Ud" ));} catch(NumberFormatException nfe){ Ud=0; }
		Kid=0;
		try{Kid=Double.parseDouble(fec.getElementItemAt("pwmfec","Kid" ));} catch(NumberFormatException nfe){ Kid=0; }
		Krs=1;
		try{Krs=Double.parseDouble(fec.getElementItemAt("pwmfec","Krs" ));} catch(NumberFormatException nfe){ Krs=1; }
		
		
		Tiq=0;
		try{Tiq=Double.parseDouble(fec.getElementItemAt("pwmfec","Tiq" ));} catch(NumberFormatException nfe){ Tiq=0; }
		Kiq=0;
		try{Kiq=Double.parseDouble(fec.getElementItemAt("pwmfec","Kiq" ));} catch(NumberFormatException nfe){ Kiq=0; }
		//current limit
		
		/*
		double Kilim=10;
		//
		Imax=Kilim*1.41*Kid*isd*Math.sqrt(1-cos*cos)/1.5;
		*/
		Imax=2*1.41*isd;
		fnom=1.41*Ud/w0;
		enom=0.8*1.41*Ud;
		idnom=isd*1.41*Math.sqrt(1-cos*cos);
		iqf=0;
		idf=0;
		System.out.println("PWMfec:reset:ls="+ls+" rs="+rs+" l2="+l2+" r2="+r2+" lm="+lm+" j="+j+" pol="+pol+" isd="+isd+" Imax="+Imax+" Kid="+Kid+" Kiq="+Kiq+" Tiq="+Tiq+" orientation="+orientation+" w0="+w0+" fnom="+fnom+"  enom="+enom+" idnom="+idnom);
			  }catch(Exception e) {
				  System.out.println("PWMfec:reset:"+e.toString());
			  }
		}
	   public String[] listOuts() {
			return new String[] {"ux","uy","uxf","uyf","i2x","i2y","isx","isy","fx","fy","wr","m","isa","isb","isc","isx","isy","ismod","fmod","f2","irefx","irefy","fox","foy","pa","es"};
		}	   
	   public Hashtable <String,Double> getOuts(){
			Hashtable <String,Double> outs=new Hashtable <String,Double>();
			outs.put("ux", ux);
			outs.put("uy", uy);
			outs.put("uxf", uxf);
			outs.put("uyf", uyf);
			outs.put("i2x", i2x);
			outs.put("i2y", i2y);
			outs.put("isx", isx);
			outs.put("isy", isy);
			outs.put("fx", fx);
			outs.put("fy", fy);
			outs.put("wr", wr);
			outs.put("m", m);
			outs.put("isa", isa);
			outs.put("isb", isb);
			outs.put("isc", isc);
			outs.put("isx", isx);
			outs.put("isy", isy);
			outs.put("ismod", ismod);
			outs.put("fmod", fmod);
			outs.put("irefx", irefx);
			outs.put("irefy", irefy);
			outs.put("fox", fox);
			outs.put("foy", foy);
			outs.put("pa", pa);
			outs.put("es", es);
			//System.out.println("VFsupply:getOuts:ux="+ux+" uy="+uy);
			//EduHandler.printHashtableDouble("VFsupply:outs", outs);
			return outs;
		}			
	   public void putSettings(Hashtable<String, Double> settings) {
			EduHandler.printHashtableDouble("PWMfec:settings", settings);
			
			try {
				try {Ud=settings.get("Ud");}catch(Exception ee) {}
				try {ls=settings.get("ls");}catch(Exception ee) {}
				try {rs=settings.get("rs");}catch(Exception ee) {}
				try {l2=settings.get("l2");}catch(Exception ee) {}
				try {r2=settings.get("r2");}catch(Exception ee) {}
				try {lm=settings.get("lm");}catch(Exception ee) {}
				try {j=settings.get("j");}catch(Exception ee) {}
				try{pol=(int)settings.get("pol").intValue();}catch(Exception ee) {}
				try{clock=settings.get("clock").intValue();}catch(Exception ee) {}
				try{Tiq=settings.get("Tiq");}catch(Exception ee) {}
				try{Kiq=settings.get("Kiq");}catch(Exception ee) {}
				try{Kid=settings.get("Kid");}catch(Exception ee) {}
				try{Ud=settings.get("Ud");}catch(Exception ee) {}
				}catch(Exception e) {
					System.out.println("PWMfec:putSettings:"+e.toString());
				}
			
		}
	   public String[] listIns() {
			return new String[] {"W","Mc"};
		}
		private static V2 getVk(int k ){
			 double a=- Math.PI/6 +k*Math.PI/3;
			 double cos=Math.cos(a);
			 double sin=Math.sin(a);
			 return new V2(cos,sin);
		}
		private static int bestK (V2 v) {
			double worth=0;
			double best=0;
			V2 vk;
			int k=-1;
			for(int n=0;n<6;n++) {
				vk=getVk(n);
				worth=v.dotProduct(vk);
				if(worth>best) {
					best=worth;
					k=n;
				}
			}
			return k;
		}
		private V2 getIdq() {
			try {
				double id=0;
				double iq=0;
				double dw=(w-wr);
				double we=0.2;
				
				// speed
				if(Math.abs(dw)>we) 
				{
					iq=iqf+0.1*dw*Imax; 
					//wef=0;
			//		 System.out.println("PWMfec:getIdq:speed error:  iq="+iq+"  id="+id+" fg="+fg+ " dw="+dw);
				}
				else {
					iq=iqf+0.1*(dw+wef)*Imax; ;
//					 System.out.println("PWMfec:getIdq:speed stable:  iqf="+iqf+"  id="+id+" fg="+fg);
				}
				if(iq>Imax)
					iq=Imax;
				if(iq<-Imax)
					iq=-Imax;
				double frmod=0;
				//flux
				if(FLUX.equals(orientation)) {
					fg=0.5*fnom+0.01*Math.abs(mf);
					frmod=fmod;
				} else {
			    	   V2 fo=new V2(fox,foy);
			    	   frmod=fo.norm()+fce;
			    	   fg=1*fnom+0.01*Math.abs(mf);
			    	  
				}	   
				//fg=0.5*fnom+0.01*Math.abs(mf);
				double df=fg-frmod;
				double dfa=Math.abs(df);
				if(dfa>0.1) 
				
				{
				if (dfa<0.1) {
					id=idf+df;
				}else {	
				   // id=idf;
				   if(df>0)
					id=Imax;
				   else
					   id=-Imax;  
				}
			   if(id>Imax)
			    	id=Imax;
				}else 
					id=idf;
			 if(frmod<0.5*fnom)
					   id=Imax;
				//week
				if(Math.abs(es)>enom) 
					id=-Imax;
				mf=mf+(ms-mf)*clock/0.1;
				iqf=iqf+(iq-iqf)*clock/0.1;
				idf=idf+(id-idf)*clock/0.1;
				if(idf>isd)
					idf=isd;
				if(idf<-isd)
					idf=-isd;
				wef=wef+(dw-wef)*clock/0.1;
				if(wef>0.2)
					wef=0.2;
				if(wef<-0.2)
					wef=-0.2;
				double fcmod=idf*lm;
				fce=fce+((fcmod-frmod)*10-fce)*clock/0.2;
				fce=0; 
				System.out.println("PWMfec:getIdq:fmod="+fmod+" frmod="+frmod+" fg="+fg+"  wef="+wef);
				return new V2(id,iq);
			}catch(Exception e) {
				System.out.println("PWMfec:getIdq2:"+e.toString());	
			}
			return null;
		}

public void stride(Hashtable<String,Double>ins) {
			try {
				double clock=preferredClock;
				try { clock=ins.get("clock");}catch(Exception e) {}
				//System.out.println("PWMfoc:stride:orientaion="+orientation);
				w=0;
				try {w=ins.get("w");}catch(Exception ee) {}
				//control
//				double time=0;
//				try{ time=ins.get("time");}catch(Exception e) {}
				///regulator
		
	          V2 fl=new V2(fx,fy);
	          V2 fo=new V2(fox,foy);
	          //flux regulator
	      /*
	      if(FLUX.equals(orientation))
	          fmod=fl.norm();
	       else
	    	   fmod=fo.norm();
	    	   */
	       V2 idq=getIdq();
	         V2 isref=null;
	         if(FLUX.equals(orientation))
        	     isref=idq.translate(fl);
	         else
	        	 isref=idq.translate(fo);
	         irefx=isref.x; 
	         irefy=isref.y;
	         
	             double idifx=(irefx-isx);
	            double idify=(irefy-isy);
	       
	            V2 idif=new V2(idifx,idify);
	            		k=bestK(idif);
	            V2 vk=getVk(k);
	            V2 us=vk.product(2.34*Ud);
	            double usx=us.x;
	            double usy=us.y;
	            
				 //motor
					mc=0;
					try{ mc=ins.get("mc");}catch(Exception ee) {}
				//	System.out.println("U2model:stride:ls="+ls+" rs=="+rs+" l2="+l2+" r2="+r2+" lm="+lm+" j="+j+" pol="+pol+" mc="+mc);
					clock=0.01*ls/rs;
					try {clock=ins.get("clock");}catch(Exception ee) {}
					V2 i2= new  V2 (i2x,i2y);
					//V2 fl=new V2(fx,fy);  
					V4 s= new V4(fl,i2);
					M2 ll=new M2(1+ls/lm,-ls,1,l2);
					M2 rr=new M2(-rs/lm,rs,0,-r2);
					M2 ee=new M2(0,0,1,l2);
					M2 lli=ll.inverse();
					
					//System.out.println("U2model:stride:m="+m+" i2n="+i2.norm()+" fn="+fl.norm()+" a="+i2.angle(fl));
					M2 t1=lli.multiplication(rr);
					V4 s1=t1.product(s);		
					M2 t2=lli.multiplication(ee);
					V4 s2=t2.product(s.componentRotation().product(wr));
					//V2 us= new  V2 (ux,uy);
					V4 u=new V4(us,new V2(0,0));
					V4 s3=lli.product(u);
					V4 ds= s1.add(s2).add(s3);
					V4 sn=s.add(ds.product(clock));   
				  	fl=sn.v1;
					i2=sn.v2;
					V2 im=fl.product(1/lm);
					V2 is=im.product(1).add(i2.product(-1));
					m=1.5*pol*fl.crossProduct(i2); 
					if(FLUX.equals(orientation))
						ms=1.5*pol*fl.crossProduct(is); 
			         else
			        	 ms=1.5*pol*fo.crossProduct(is); 
			 
					i2x=i2.x;
					i2y=i2.y;
					isx=is.x;
					isy=is.y;
					fx=fl.x;
					fy=fl.y;
					double dwr=pol*(m-mc)*clock/j;
					wr=wr+dwr;
					isa=isx;
					isb=-0.5*isx+0.866*isy;
					isc=-0.5*isx-0.866*isy;
					ismod=Math.sqrt(isx*isx+isy*isy)/Math.sqrt(2);
					fmod=Math.sqrt(fx*fx+fy*fy);
							//observer
				    es=fmod*wr;
				    fox=fox+clock*(usx-isx*Krs*rs);
				    foy=foy+clock*(usy-isy*Krs*rs);
				    
				    pa=pa+clock*(us.x*isx+us.y*isy-pa)/0.02;
				  //  System.out.println("PWMfec:stride:es="+es);
				   // System.out.println("PWMfoc:stride:fox="+fox+" foy="+foy);
			}catch(Exception e) {
				System.out.println("PWMfec:stride"+e.toString());
			}
		}
	
}
