package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic;

import java.util.Hashtable;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.M2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V4;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

public class PWMfoc {
	public static final String MOTOR="motor";
	public static final String OPTION="option";
	public static final String GIVEN="given";
	public static final String ESTIMATED="estimated";
	
	
	double ux=0;
	double uy=0;
	double uxf=0;
	double uyf=0;
	double uA2=0;
	double uB2=0;
	double uC2=0;
	
	double uA2g=0;
	double uB2g=0;
	double uC2g=0;
	
	double uA2o=0;
	double uB2o=0;
	double uC2o=0;
	double uA2k=0;
	 double uB2k=0;
	 double uC2k=0;
	
	
	//input
	double Ua=0;
	double Uam=0;
	double f0=0;
	double Ucm=0;
	//secondary parameters 
	double T=Double.MIN_VALUE;
	double T0=0;
	double T1=0;
	double T2=0;
	double T3=0;
	double T4=0;
	double T5=0;
	double Tr=0;
	double Ku=0;
	double Udm=0;
	double ud=0;
	double preferredClock=Double.MIN_VALUE;
	double TT=Double.MIN_VALUE;
	double delay=0.0001;
	double tau=0;
//	double Tc=0;
//	double Kc=0;
	//U2model
	
	//state
		double irefx=0;
		double irefy=0;
		double angle=0;
		double i2x=0;
		double i2y=0;
		double isx=0;
		double isy=0;
		double fx=0;
		double fy=0;
	//	observer
		double angle0=0;
		double w0=0;
		double im0=0;
		//outputs
		double wr=0;
		double m=0;
		int k=0;
		
		///secondary outputs
		double isa=0;
		double isb=0;
		double isc=0;
		double ismod=0;
		double fmod=0;
		//inputs
		double usx=0;
		double usy=0;
		double clock=Double.MIN_VALUE;
		double mc=0;
		//parameters
		double ls=0;
		double rs=0;
		double l2=0;
		double r2=0;
		double lm=0;
		double j=0;
		int pol=1; 
		
		double kw=1/(2*Math.PI);
		double f2=0;
	    double mf=0;
	    double iqi=0;
	    double thx=0;
	    double thy=0;
	    
	    double wslip=0;
	public PWMfoc(Entigrator entigrator,String locator$) {
		  reset(entigrator,locator$);
		}
	public void reset(Entigrator entigrator,String locator$) {
		System.out.println("PWMVFdrive:reset:0:locator="+locator$);
		angle=0;
	  ux=0;
	  uy=0;
	  uxf=0;
	  uyf=0;
	  uA2o=0;
	  uB2o=0;
	  uC2o=0;
	  TT=0.001;
	  i2x=0;
		i2y=0;
		isx=0;
		isy=0;
		fx=0;
		fy=0;
		wr=0;
		f2=0;
		mf=0;
		iqi=0;
	//observer
		angle0=0;
		w0=0;
		im0=0;
		thx=0;
		thy=0;
		wslip=0;
		 try {
			  String motor$=Locator.getProperty(locator$, MOTOR);
			  Sack motor=entigrator.getEntityAtLabel(motor$);
			  if(motor==null) {
				  System.out.println("PWMVFdrive:reset:cannot get motor="+motor$+" in locator="+locator$);
				  return;
			  }
			  String option$=Locator.getProperty(locator$, OPTION);
			  double w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
		     rs=0;
		     if(GIVEN.equals(option$))
			   try{rs=Double.parseDouble(motor.getElementItemAt("zgvn", "rs"));}catch(Exception ee) {}
		     if(ESTIMATED.equals(option$))
		  	   try{rs=Double.parseDouble(motor.getElementItemAt("zpar", "rs"));}catch(Exception ee) {}
			 r2=0;
			 if(GIVEN.equals(option$))
				 try{r2=Double.parseDouble(motor.getElementItemAt("zgvn", "r2"));}catch(Exception ee) {}
			 if(ESTIMATED.equals(option$))
			  	   try{r2=Double.parseDouble(motor.getElementItemAt("zpar", "r2"));}catch(Exception ee) {}
			 ls=0;
			 if(GIVEN.equals(option$))
			 try{
				double xs=Double.parseDouble(motor.getElementItemAt("zgvn", "xs"));
				ls=xs/w0;
			 }catch(Exception ee) {}
			 if(ESTIMATED.equals(option$))
				 try{
					double xs=Double.parseDouble(motor.getElementItemAt("zpar", "xs"));
						ls=xs/w0;
					 }catch(Exception ee) {}
			 
			 l2=0;
			 if(GIVEN.equals(option$))
			 try{
				double x2=Double.parseDouble(motor.getElementItemAt("zgvn", "x2"));
				l2=x2/w0;
			 }catch(Exception ee) {}
			 if(ESTIMATED.equals(option$))
				 try{
					double xs=Double.parseDouble(motor.getElementItemAt("zpar", "x2"));
					l2=xs/w0;
				 }catch(Exception ee) {}
			 
			 lm=0;
			 if(GIVEN.equals(option$))
			 try{
					double xm=Double.parseDouble(motor.getElementItemAt("zgvn", "xm"));
					lm=xm/w0;
				 }catch(Exception ee) {}
			 if(ESTIMATED.equals(option$))
				 try{
					double xm=Double.parseDouble(motor.getElementItemAt("zpar", "xm"));
						lm=xm/w0;
					 }catch(Exception ee) {}
			
			j=Double.MIN_VALUE;
				try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
				pol=1; 
				try{pol=Integer.parseInt(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
			
				clock=ls/(rs*100);
				//System.out.println("PWMVFdrive:reset:lm="+lm);    
				//control
				System.out.println("PWMVFdrive:reset:1:rs="+rs+" ls="+ls+" r2="+r2+" lm="+lm+" j="+j+" pol="+pol);	
		  }catch(Exception e) {
			  System.out.println("PWMVFdrive:reset:"+e.toString());
		  }
	}
	public Hashtable <String,Double> getOuts(){
		Hashtable <String,Double> outs=new Hashtable <String,Double>();
		outs.put("ux", ux);
		outs.put("uy", uy);
		outs.put("uxf", uxf);
		outs.put("uyf", uyf);
		outs.put("uA2", uA2);
		outs.put("uB2", uB2);
		outs.put("uC2", uC2);
		outs.put("uA2o", uA2o);
		outs.put("uB2o", uB2o);
		outs.put("uC2o", uC2o);
		outs.put("i2x", i2x);
		outs.put("i2y", i2y);
		outs.put("isx", isx);
		outs.put("isy", isy);
		outs.put("fx", fx);
		outs.put("fy", fy);
		outs.put("wr", wr);
		outs.put("m", m);
		outs.put("isa", isa);
		outs.put("isb", isb);
		outs.put("isc", isc);
		outs.put("isx", isx);
		outs.put("isy", isy);
		outs.put("ismod", ismod);
		outs.put("fmod", fmod);
		outs.put("f2", f2);
		outs.put("irefx", irefx);
		outs.put("irefy", irefy);
		outs.put("mf", mf);
		outs.put("angle0",angle0);
		outs.put("im0",im0);
		outs.put("w0",w0);
		outs.put("thx",thx);
		outs.put("thy",thy);
		//System.out.println("VFsupply:getOuts:ux="+ux+" uy="+uy);
		//EduHandler.printHashtableDouble("VFsupply:outs", outs);
		return outs;
	}
	public void putSettings(Hashtable<String, Double> settings) {
		EduHandler.printHashtableDouble("PWMVFcontrol:settings", settings);
		Ua=settings.get("Ua");
		f0=settings.get("f0");
		
		Ucm=settings.get("Ucm");
		Uam=Ua*Math.sqrt(2);
		T=1/(f0+Double.MIN_VALUE);
		TT=T/10;
		T0=(double)T/12;
		T1=(double)T/4;
		T2=(double)T/4+(double)T/6;
		T3=(double)T/12+(double)T/2;
		T4=(double)3*T/4;
		T5=(double)3*T/4+(double)T/6;
		preferredClock=T/1000;
		Tr=1/(6*f0);
		Udm=2.34*Ua;
		Ku=Udm/Ucm;
		try {
			try {ls=settings.get("ls");}catch(Exception ee) {}
			try {rs=settings.get("rs");}catch(Exception ee) {}
			try {l2=settings.get("l2");}catch(Exception ee) {}
			try {r2=settings.get("r2");}catch(Exception ee) {}
			try {lm=settings.get("lm");}catch(Exception ee) {}
			try {j=settings.get("j");}catch(Exception ee) {}
			try{pol=(int)settings.get("pol").intValue();}catch(Exception ee) {}
			try{clock=settings.get("clock").intValue();}catch(Exception ee) {}
			}catch(Exception e) {
				System.out.println("pwmvfdrive:putSettings:"+e.toString());
			}
		
	}
	public String[] listIns() {
		return new String[] {"W","Mc"};
	}
	
	public String[] listOuts() {
		return new String[] {"ux","uy","uA2","uB2","uC2","uA2o","uB2o","uC2o","uxf","uyf","i2x","i2y","isx","isy","fx","fy","wr","m","isa","isb","isc","isx","isy","ismod","fmod","f2","irefx","irefy","mf","angle0","im0","w0","thx","thy"};
	}
	private static V2 getVk(int k ){
		 double a=- Math.PI/6 +k*Math.PI/3;
		 double cos=Math.cos(a);
		 double sin=Math.sin(a);
		 return new V2(cos,sin);
	}
	private static int bestK (V2 v) {
		double worth=0;
		double best=0;
		V2 vk;
		int k=-1;
		for(int n=0;n<6;n++) {
			vk=getVk(n);
			worth=v.dotProduct(vk);
			if(worth>best) {
				best=worth;
				k=n;
			}
		}
		return k;
	}
	
	public void stride(Hashtable<String,Double>ins) {
		try {
			double clock=preferredClock;
			try { clock=ins.get("clock");}catch(Exception e) {}
			double w=0;
			try {w=ins.get("w");}catch(Exception ee) {}
			//control

			double time=0;
			try{ time=ins.get("time");}catch(Exception e) {}
			
			ud=0;
			int cnt=(int)(time/T);
			double tk=time-cnt*T;
			double  alphaA=(tk*2*Math.PI)/(T+Double.MIN_VALUE);
			
			double uA=Uam*Math.sin(alphaA);
			double uB=Uam*Math.sin(alphaA-2.0943);
			double uC=Uam*Math.sin(alphaA-4.1885);
			if(tk>=0&&tk<T0) {
				ud=uC-uB;
				//System.out.println("VFsupply:stride:0  uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T0&&tk<T1) {
				
				ud= uA-uB;
				//System.out.println("VFsupply:stride:1 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			   }
			if(tk>=T1&&tk<T2) {
				ud= uA-uC;
				//System.out.println("VFsupply:stride:2 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T2&&tk<T3) {
				
				 ud=uB-uC;
				 //System.out.println("VFsupply:stride:3 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T3&&tk<T4) {
				
				ud=uB-uA;
				//System.out.println("VFsupply:stride:4 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T4&&tk<T5) {
				ud=uC-uA;
				//System.out.println("VFsupply:stride:5 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T5&&tk<T) {
				ud=uC-uB;
				//System.out.println("VFsupply:stride:6 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
		//	System.out.println("VFsupply:stride:ud="+ud);
			/////////////////////////////
			double id=5;
           
			///regulator
		   double dw=w-wr;	
		   /*
		   if(dw>25)
			   dw=25;
		   if(dw<-25)
			   dw=-25;
			   */
		   id=id+0.06*dw;
		   
		   double Ts=0.2;
		   double Kp=0.015/Ts;
		   double Ki=0.0577/Math.sqrt(Ts);
           //iqi=iqi+0.4*clock*dw;
		   iqi=iqi+Ki*clock*dw;
          // iqi=0;
           //double iqp=0.25*dw;
		   double iqp=Kp*dw;
            double iq=iqi+iqp;
            V2 fl=new V2(fx,fy);
           /*
            if(fl.norm()<0.9)
            iq=0;
            else
            */
            //	iq=iqp;
            	
            V2 ifoc=new V2(id,iq);
           
           // V2 iref=ifoc.translate(fl);
           
         // irefx=iref.x;
         // irefy=iref.y;
            double ilimit=20;
            if(iq>ilimit)
         	   iq=ilimit;
            if(iq<-ilimit)
         	   iq=-ilimit;
           double isref=Math.sqrt(iq*iq+id*id);
           irefx=isref*Math.cos(angle0);
           irefy=isref*Math.sin(angle0);
           //
           /*
           double ilimit=20;
           if(irefx>ilimit)
        	   irefx=ilimit;
           if(irefx<-ilimit)
        	   irefx=-ilimit;
           if(irefy>ilimit)
        	   irefy=ilimit;
           if(irefy<-ilimit)
        	   irefy=-ilimit;
           */
           //
            double idifx=(irefx-isx);
            double idify=(irefy-isy);
         
            V2 idif=new V2(idifx,idify);
            double idnorm=idif.norm();
           // System.out.println("PWMfoc:stride:irefx="+irefx+" irefy="+irefy+"  idnorm="+idnorm+" K="+k+" w="+w); 
            //if(idnorm>1) {
            		k=bestK(idif);
           // }
            
            V2 vk=getVk(k);
            V2 us=vk.product(ud);
            usx=us.x;
            usy=us.y;
            
			 //motor
//				EduHandler.printHashtableDouble("U2model:stride:ins", ins);
				mc=0;
				try{ mc=ins.get("mc");}catch(Exception ee) {}
			//	System.out.println("U2model:stride:ls="+ls+" rs=="+rs+" l2="+l2+" r2="+r2+" lm="+lm+" j="+j+" pol="+pol+" mc="+mc);
				clock=0.01*ls/rs;
				try {clock=ins.get("clock");}catch(Exception ee) {}
				V2 i2= new  V2 (i2x,i2y);
				//V2 fl=new V2(fx,fy);  
				V4 s= new V4(fl,i2);
				M2 ll=new M2(1+ls/lm,-ls,1,l2);
				M2 rr=new M2(-rs/lm,rs,0,-r2);
				M2 ee=new M2(0,0,1,l2);
				M2 lli=ll.inverse();
				
				//System.out.println("U2model:stride:m="+m+" i2n="+i2.norm()+" fn="+fl.norm()+" a="+i2.angle(fl));
				M2 t1=lli.multiplication(rr);
				V4 s1=t1.product(s);		
				M2 t2=lli.multiplication(ee);
				V4 s2=t2.product(s.componentRotation().product(wr));
				//V2 us= new  V2 (ux,uy);
				V4 u=new V4(us,new V2(0,0));
				V4 s3=lli.product(u);
				V4 ds= s1.add(s2).add(s3);
				V4 sn=s.add(ds.product(clock));   
			  	fl=sn.v1;
				i2=sn.v2;
				V2 im=fl.product(1/lm);
				V2 is=im.product(1).add(i2.product(-1));
				m=1.5*pol*fl.crossProduct(i2); 
				i2x=i2.x;
				i2y=i2.y;
				isx=is.x;
				isy=is.y;
				fx=fl.x;
				fy=fl.y;
				//
				//double id=is.dotProduct(fl)/fl.norm();
				//double iq=is.crossProduct(fl)/fl.norm();
				
				
				double dwr=pol*(m-mc)*clock/j;
				wr=wr+dwr;
				System.out.println("PWMfoc:stride: id="+id+" iq="+iq+"  m="+mf+"  dw="+dw+" wr="+wr);
				//System.out.println("PWMfoc:stride: id="+id+" iq="+iq+" s="+slip+"  m="+m+"  dw="+dw);
				////debug
				//wr=0;
				///
				isa=isx;
				isb=-0.5*isx+0.866*isy;
				isc=-0.5*isx-0.866*isy;
				ismod=Math.sqrt(isx*isx+isy*isy)/Math.sqrt(2);
				fmod=Math.sqrt(fx*fx+fy*fy);
				mf=mf+(m-mf)*clock/0.01;
				//observer
				
				
				//double dim0=(r2/l2)*(id-im0);
				//im0=im0+dim0*clock;
				/*
				double wslip0=(iq/id)*12;
				wslip=wslip+(wslip0-wslip)*clock*0.001;
				w0=wr+wslip;
				*/
				//double ddw=2*dw;
				/*
				if(ddw>2)
					ddw=2;
				if(ddw<-2)
					ddw=-2;
					*/
				//ddw=0;
				wslip=(iq/id)*12;
				
				//w0=wr+(iq/id)*12;
				w0=wr+wslip;
				if(wslip>20)
					wslip=20;
				if(wslip<-20)
					wslip=-20;
				angle0=angle0+w0*clock;
				//V2 theta=new V2(Math.cos(angle0),Math.sin(angle0));
				thx=Math.cos(angle0);
				thy=Math.sin(angle0);
			 System.out.println("PWMfoc:stride:w0="+w0+"  angle0="+angle0+" im0="+im0+"  thx="+thx+" thy="+thy);
		}catch(Exception e) {
			System.out.println("PWMVFdrive:stride"+e.toString());
		}
	}
	
}
