package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic;

import java.util.Hashtable;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.Z;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

public class Zmodel {
	public static final String MOTOR="motor";
	public static final String OPTION="option";
	public static final String FREQUENCY="frequency";
	public static final String VOLTAGE="voltage";
	public static final String GIVEN="given";
	public static final String ESTIMATED="estimated";
	//state
	
	//outputs
	double wr=0;
	double m=0;
	double isd=0;
	//inputs
	double f=0;
	double usd=0;
	double clock=Double.MIN_VALUE;
	double mc=0;
	//parameters
	double ls=0;
	double rs=0;
	double l2=0;
	double r2=0;
	double lm=0;
	double j=0;
	int pol=1;
	//second pars
	double w0=0;	
	double xm=0;
	double xs=0;
	double x2=0;

public Zmodel(Entigrator entigrator,String locator$) {
  try {
	  String motor$=Locator.getProperty(locator$, MOTOR);
	  Sack motor=entigrator.getEntityAtLabel(motor$);
	  String option$=Locator.getProperty(locator$, OPTION);
	 // double w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
	  f=0;
	  try{f=Double.parseDouble(Locator.getProperty(locator$, FREQUENCY));}catch(Exception ee) {}
	  w0=2*Math.PI*f;
	  usd=0;
	  try{usd=Double.parseDouble(Locator.getProperty(locator$, VOLTAGE));}catch(Exception ee) {}
      rs=0;
     if(GIVEN.equals(option$))
	   try{rs=Double.parseDouble(motor.getElementItemAt("zgvn", "rs"));}catch(Exception ee) {}
     if(ESTIMATED.equals(option$))
  	   try{rs=Double.parseDouble(motor.getElementItemAt("zpar", "rs"));}catch(Exception ee) {}
	 r2=0;
	 if(GIVEN.equals(option$))
		 try{r2=Double.parseDouble(motor.getElementItemAt("zgvn", "r2"));}catch(Exception ee) {}
	 if(ESTIMATED.equals(option$))
	  	   try{r2=Double.parseDouble(motor.getElementItemAt("zpar", "r2"));}catch(Exception ee) {}
	 ls=0;
	 if(GIVEN.equals(option$))
	 try{
		double xs=Double.parseDouble(motor.getElementItemAt("zgvn", "xs"));
		ls=xs/w0;
	 }catch(Exception ee) {}
	 if(ESTIMATED.equals(option$))
		 try{
			double xs=Double.parseDouble(motor.getElementItemAt("zpar", "xs"));
				ls=xs/w0;
			 }catch(Exception ee) {}
	 
	 l2=0;
	 if(GIVEN.equals(option$))
	 try{
		double x2=Double.parseDouble(motor.getElementItemAt("zgvn", "x2"));
		l2=x2/w0;
	 }catch(Exception ee) {}
	 if(ESTIMATED.equals(option$))
		 try{
			double x2=Double.parseDouble(motor.getElementItemAt("zpar", "x2"));
			l2=x2/w0;
		 }catch(Exception ee) {}
	 
	 lm=0;
	 if(GIVEN.equals(option$))
	 try{
			double xm=Double.parseDouble(motor.getElementItemAt("zgvn", "xm"));
			lm=xm/w0;
		 }catch(Exception ee) {}
	 if(ESTIMATED.equals(option$))
		 try{
			double xm=Double.parseDouble(motor.getElementItemAt("zpar", "xm"));
				lm=xm/w0;
			 }catch(Exception ee) {}
	
	j=Double.MIN_VALUE;
		try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
	pol=1; 
		try{pol=Integer.parseInt(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
		
		
	    clock=ls/(rs*100);
	    System.out.println("Zmodel:rs="+rs+" ls="+ls+" l2="+l2+" r2="+r2+" lm="+lm+" pol="+pol+" j="+j+" usd="+usd+" f="+f);	    
  }catch(Exception e) {
	  System.out.println("Zmodel:"+e.toString());
  }
}
public void reset() {
	wr=0;
	w0=2*Math.PI*f;
	xm=w0*lm;
	xs=w0*ls;
	x2=w0*l2;
	//EduHandler.printHashtableDouble("Zmodel:reset:outs", getOuts());
}
public void stride(Hashtable<String,Double>ins) {
	try {
		//EduHandler.printHashtableDouble("ZModel:stride:ins", ins);
		//System.out.println("Zmodel:rs="+rs+" ls="+ls+" l2="+l2+" r2="+r2+" lm="+lm+" pol="+pol+" j="+j+" usd="+usd+" f="+f+" xs="+xs+" x2="+x2+" xm="+xm);	    
		Z zm=new Z(0,xm);
		Z zs=new Z(rs,xs);
		double s=(w0-wr)/w0;
		Z zr=new Z(r2/s,x2);
		Z z1=zm.inverse().product(zr).add(new Z(1,0));
		Z z0=z1.product(zs).add(zr).inverse().product(-1);
		
		V2 us= new V2(Math.sqrt(2)*usd,0);
		V2 i2=z0.product(us); 
		double i2a=i2.norm();
		V2 is=z1.product(i2).product(-1);
		V2 im=is.add(i2);
		mc=0;
		try{mc=ins.get("mc");}catch(Exception ee) {}
		try{clock=ins.get("clock");}catch(Exception ee) {}
		//System.out.println("Zmodel:mc="+mc);
		m=(1.5*pol*xm/(w0))*i2.rotProduct(im);
		double isa=is.norm();
//		double cos = i2a/isa; //a2
		isd=isa/Math.sqrt(2);//a0
	//	System.out.println("MotorHandler:z_makeState:isd="+isd);	
		double pl= 3*(i2a*i2a*r2+isa*isa*rs);
		double pow= m*w0/pol;
//		double eta=pow/(pow+pl);
		double dwr=pol*(m-mc)*clock/j;
		wr=wr+dwr;
	}catch(Exception e) {
		System.out.println("Zmodel:stride:"+e.toString());
	}

}
public Hashtable <String,Double> getOuts(){
	
	Hashtable <String,Double> outs=new Hashtable <String,Double>();
	outs.put("wr", wr);
	outs.put("m", m);
	outs.put("isd", isd);
	//System.out.println("U2model:getOuts:usx="+usx+" usy="+usy);
	//EduHandler.printHashtableDouble("U2model:outs", outs);
	return outs;
}
public Hashtable<String, Double> getSettings() {
	Hashtable<String, Double> settings=new Hashtable<String, Double>();
	settings.put("ls",ls);
	settings.put("rs",rs);
	settings.put("l2",l2);
	settings.put("r2",r2);
	settings.put("lm",lm);
	settings.put("j",j);
	settings.put("pol",(double)pol);
	return settings;
}
public void putSettings(Hashtable<String, Double> settings) {
	try {
	try {ls=settings.get("ls");}catch(Exception ee) {}
	try {rs=settings.get("rs");}catch(Exception ee) {}
	try {l2=settings.get("l2");}catch(Exception ee) {}
	try {r2=settings.get("r2");}catch(Exception ee) {}
	try {lm=settings.get("lm");}catch(Exception ee) {}
	try {j=settings.get("j");}catch(Exception ee) {}
	try{pol=(int)settings.get("pol").intValue();}catch(Exception ee) {}
	try{clock=settings.get("clock").intValue();}catch(Exception ee) {}
	}catch(Exception e) {
		System.out.println("Zmodel:putSettings:"+e.toString());
	}
}
public double getClock() {
	double clock=Double.MIN_VALUE;
	try {clock=	0.01*(ls+l2)/(rs+r2);}catch(Exception ee) {}
	return clock;
}
public void setClock(double clock) {
	this.clock=clock;
}
}
