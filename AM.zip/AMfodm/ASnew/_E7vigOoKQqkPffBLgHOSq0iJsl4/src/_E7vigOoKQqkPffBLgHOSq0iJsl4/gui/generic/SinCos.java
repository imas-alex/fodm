package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;

public class SinCos {
	double um=0;
	double w0=0;
	public SinCos(double um,double f) {
		this.um=um;
		w0=2*Math.PI*f;
		System.out.println("SinCos:w0="+w0);
	}
	public V2 get(double time) {
		try {
			double angle=w0*time;
			double cos=Math.cos(angle);
			double sin=Math.sin(angle);
			double usx=um*cos;
			double usy=um*sin;
			return new V2(usx,usy);
			}catch(Exception e) {
				System.out.println("SinCos:get:"+e.toString());
			}
			return null;
	}
}


