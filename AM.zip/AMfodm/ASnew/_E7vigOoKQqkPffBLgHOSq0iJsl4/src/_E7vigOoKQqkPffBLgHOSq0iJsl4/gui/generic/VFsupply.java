package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic;

import java.util.Hashtable;
public class VFsupply {
	double angle=0;
	double ux=0;
	double uy=0;
	//
	double Ua=0;
	double Uam=0;
	double f0=0;
	double Ucm=0;
	//secondary parameters 
	double T=Double.MIN_VALUE;
	double T0=0;
	double T1=0;
	double T2=0;
	double T3=0;
	double T4=0;
	double T5=0;
	double Tr=0;
	double Ku=0;
	double Udm=0;
	//global variable
	double time=0;
	//internal variable
	double uA=0;
	double uB=0;
	double uC=0;
	double uaa=0;
	double ubb=0;
	double ucc=0;
	double ud=0;
	double preferredClock=Double.MIN_VALUE;
	public VFsupply() {
		reset();
	}
	public void reset() {
	  angle=0;
	  ux=0;
	  uy=0;
	}
	public void stride(Hashtable<String,Double>ins) {
		try {
			//
			double uc=0;
			try { uc=ins.get("Uc");}catch(Exception e) {}
			double uin=uc/Ucm;
			if(uin>1)
				uin=1;
			if(uin<-1)
				uin=-1;
			double time=0;
			try{ time=ins.get("time");}catch(Exception e) {}
			ud=0;
			int cnt=(int)(time/T);
			double tk=time-cnt*T;
			double dAlpha=(1-uin)*Math.PI/2;
			double  alphaA=(tk*2*Math.PI)/(T+Double.MIN_VALUE);
			
			uA=Uam*Math.sin(alphaA-dAlpha);
			uB=Uam*Math.sin(alphaA-2.0943-dAlpha);
			uC=Uam*Math.sin(alphaA-4.1885-dAlpha);
			double aa=alphaA;
			uaa=Uam*Math.sin(aa);
			ubb=Uam*Math.sin(aa-2.0943);
			ucc=Uam*Math.sin(aa-4.1885);
			if(tk>=0&&tk<T0) {
				ud=uC-uB;
				//System.out.println("VFsupply:stride:0  uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T0&&tk<T1) {
				
				ud= uA-uB;
				//System.out.println("VFsupply:stride:1 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			   }
			if(tk>=T1&&tk<T2) {
				ud= uA-uC;
				//System.out.println("VFsupply:stride:2 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T2&&tk<T3) {
				
				 ud=uB-uC;
				 //System.out.println("VFsupply:stride:3 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T3&&tk<T4) {
				
				ud=uB-uA;
				//System.out.println("VFsupply:stride:4 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T4&&tk<T5) {
				ud=uC-uA;
				//System.out.println("VFsupply:stride:5 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			if(tk>=T5&&tk<T) {
				ud=uC-uB;
				//System.out.println("VFsupply:stride:6 uC="+uC+"  uB="+uB+"  Ua="+uA+" ud="+ud+"  tk="+tk);
			}
			double f=0;
			try {f=ins.get("f");}catch(Exception ee) {}
			double T2=1/f;
			double cnt2=(int)(time/T2);
			double tk2=time-cnt2*T2;
			double a=(tk2/T2)*2*Math.PI;
			
			//System.out.println("VFsupply:stride:a="+a+" a0="+0+" a1="+Math.PI/6+" a2="+Math.PI/2+" a3="+5*Math.PI/6+" a4="+7*Math.PI/6+" a5="+3*Math.PI/2+" a6="+11*Math.PI/6+" a7="+2*Math.PI);
			if(a>(0)&&(a<=Math.PI/6)){
				ux=ud*Math.sqrt(3)/2;
				uy=ud*0.5;
				//System.out.println("VFsupply:stride:a="+a+"  sector=0");
			}
			if(a>Math.PI/6&&(a<Math.PI/2)){
				
				ux=0;
				uy=ud;
				//System.out.println("VFsupply:stride:a="+a+"  sector=1"+"  amin="+Math.PI/2+" amax=" +Math.PI/2);
			}	
			if(a>=Math.PI/2&&(a<5*Math.PI/6)){
				ux=-ud*Math.sqrt(3)/2;
				uy=0.5*ud;
				//System.out.println("VFsupply:stride:a="+a+"  sector=2"+"   amin="+Math.PI/2+" amax=" +5*Math.PI/12);
			}	
			if( a >5*Math.PI/6&&(a<=7*Math.PI/6)){
				ux=-ud*Math.sqrt(3)/2;
				uy=-0.5*ud;
				//System.out.println("VFsupply:stride:a="+a+"  sector=3"+"   amin="+5*Math.PI/12+" amax=" +7*Math.PI/12);
			}
			if( a >7*Math.PI/6&&(a<=3*Math.PI/2)){
				ux=0;
				uy=-ud;
				//System.out.println("VFsupply:stride:a="+a+"  sector=4"+"   amin="+7*Math.PI/2+" amax=" +3*Math.PI/4);
			}
			if( a >3*Math.PI/2&&(a<=11*Math.PI/6)){
				ux=ud*Math.sqrt(3)/2;
				uy=-0.5*ud;
				//System.out.println("VFsupply:stride:a="+a+"  sector=5"+"  sector=4"+"   amin="+3*Math.PI/4+" amax=" +11*Math.PI/12);
			}
			if( a >11*Math.PI/6&&(a<=2*Math.PI)){
				ux=ud*Math.sqrt(3)/2;
				uy=-0.5*ud;
				//System.out.println("VFsupply:stride:a="+a+"  sector=5"+"  sector=4"+"   amin="+3*Math.PI/4+" amax=" +11*Math.PI/12);
			}
		}catch(Exception e) {
			System.out.println("VFsupply:stride"+e.toString());
		}
	}
	public Hashtable <String,Double> getOuts(){
		Hashtable <String,Double> outs=new Hashtable <String,Double>();
		outs.put("ux", ux);
		outs.put("uy", uy);
		outs.put("ud",ud);
		outs.put("uaa",uaa);
		outs.put("ubb",ubb);
		outs.put("ucc",ucc);
		outs.put("uA",uA);
		outs.put("uB",uB);
		outs.put("uC",uC);
		
		//System.out.println("VFsupply:getOuts:ux="+ux+" uy="+uy);
		//EduHandler.printHashtableDouble("VFsupply:outs", outs);
		return outs;
	}
	public void putSettings(Hashtable<String, Double> settings) {
		Ua=settings.get("Ua");
		f0=settings.get("f0");
		Ucm=settings.get("Ucm");
		Uam=Ua*Math.sqrt(2);
		T=1/(f0+Double.MIN_VALUE);
		T0=(double)T/12;
		T1=(double)T/4;
		T2=(double)T/4+(double)T/6;
		T3=(double)T/12+(double)T/2;
		T4=(double)3*T/4;
		T5=(double)3*T/4+(double)T/6;
		preferredClock=T/1000;
		Tr=1/(6*f0);
		Udm=2.34*Ua;
		Ku=Udm/Ucm;
		
	}
	public String[] listIns() {
		return new String[] {"uc","f"};
	}
	public String[] listOuts() {
		return new String[] {"ux","uy","ud","uaa","ubb","ucc","uA","uB","uC"};
	}
}
