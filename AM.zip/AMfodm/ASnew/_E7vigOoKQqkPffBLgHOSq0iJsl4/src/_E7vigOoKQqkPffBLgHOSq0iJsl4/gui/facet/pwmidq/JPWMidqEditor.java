package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmidq;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;

import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JGuiEditor;

import java.awt.GridBagLayout;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.amsupply.JAMsupplyEditor;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class JPWMidqEditor extends JGuiEditor{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_oehxl1vaORZEYAHOG_Swy_S6oXr24";
	JTextField txtUd;
	JTextField txtKid;
	JTextField txtW;
	JTextField txtM;
	JTextField txtTr;
	JTextField txtKr;
	JComboBox <String>cbxMotor;
	JComboBox <String>cbxTest;
	boolean block=false;
	Sack entity;
	public JPWMidqEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0,0,1};
		gridBagLayout.rowHeights = new int[]{0,0,0,0,0,1};
		gridBagLayout.columnWeights = new double[]{0.0,0.0,1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0,0.0,0.0,Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblUd = new JLabel("Ud");
		GridBagConstraints gbc_lblUd = new GridBagConstraints();
		gbc_lblUd.anchor = GridBagConstraints.LINE_START;
		gbc_lblUd.insets = new Insets(5, 5, 5, 5);
		gbc_lblUd.gridx = 0;
		gbc_lblUd.gridy = 0;
		add(lblUd, gbc_lblUd);
		
		txtUd = new JTextField();
		txtUd.setColumns(10);
		txtUd.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String ud$=txtUd.getText();
		    	if(!entity.existsElement("pwmidq"))
		    		entity.createElement("pwmidq");
	    		entity.putElementItem("pwmidq", new Core(null,"Ud",ud$));	
				 console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtUd = new GridBagConstraints();
		gbc_txtUd.insets = new Insets(5, 5, 5, 5);
		gbc_txtUd.gridx = 1;
		gbc_txtUd.gridy = 0;
		gbc_txtUd.anchor = GridBagConstraints.LINE_START;
		add(txtUd, gbc_txtUd);
		
		JLabel lblKid = new JLabel("Kid");
		GridBagConstraints gbc_lblKid = new GridBagConstraints();
		gbc_lblKid.anchor = GridBagConstraints.LINE_START;
		gbc_lblKid.insets = new Insets(0, 5, 5, 5);
		gbc_lblKid.gridx = 0;
		gbc_lblKid.gridy = 1;
		add(lblKid, gbc_lblKid);
		
		txtKid = new JTextField();
		txtKid.setColumns(10);
		txtKid.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String kid$=txtKid.getText();
		    	if(!entity.existsElement("pwmidq"))
		    		entity.createElement("pwmidq");
	    		entity.putElementItem("pwmidq", new Core(null,"Kid",kid$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtKid = new GridBagConstraints();
		gbc_txtKid.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF0.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtKid.gridx = 1;
		gbc_txtKid.gridy = 1;
		gbc_txtKid.anchor = GridBagConstraints.LINE_START;
		add(txtKid, gbc_txtKid);
		
		JLabel  lblW = new JLabel("W");
		GridBagConstraints gbc_lblW = new GridBagConstraints();
		gbc_lblW.insets = new Insets(0, 5, 5, 5);
		gbc_lblW.anchor=GridBagConstraints.LINE_START;
		gbc_lblW.gridx = 0;
		gbc_lblW.gridy = 2;
		add(lblW, gbc_lblW);
		
		txtW = new JTextField();
		txtW.setColumns(10);
		
		GridBagConstraints gbc_txtW = new GridBagConstraints();
		gbc_txtW.insets = new Insets(0, 5, 5, 5);
		gbc_txtW.gridx = 1;
		gbc_txtW.gridy = 2;
		gbc_txtW.anchor = GridBagConstraints.LINE_START;
		add(txtW, gbc_txtW);
		txtW.addCaretListener(new CaretListener() {
				@Override
				public void caretUpdate(CaretEvent e) {
					String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    	String w$=txtW.getText();
			    	if(!entity.existsElement("pwmidq"))
			    		entity.createElement("pwmidq");
		    		entity.putElementItem("pwmidq", new Core(null,"W",w$));	
					console.getEntigrator().putEntity(entity);
					 }
		      });
		
		JLabel lblM = new JLabel("M");
		GridBagConstraints gbc_lblM = new GridBagConstraints();
		gbc_lblM.anchor = GridBagConstraints.LINE_START;
		gbc_lblM.insets = new Insets(0, 5, 5, 5);
		gbc_lblM.gridx = 0;
		gbc_lblM.gridy = 3;
		add(lblM, gbc_lblM);
		
		txtM = new JTextField();
		txtM.setColumns(10);
		txtM.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String m$=txtM.getText();
		    	if(!entity.existsElement("pwmidq"))
		    		entity.createElement("pwmidq");
	    		entity.putElementItem("pwmidq", new Core(null,"M",m$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtM = new GridBagConstraints();
		gbc_txtM.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtM.gridx = 1;
		gbc_txtM.gridy = 3;
		gbc_txtM.anchor = GridBagConstraints.LINE_START;
		add(txtM, gbc_txtM);
		
		JLabel lblKr = new JLabel("Kr");
		GridBagConstraints gbc_lblKr = new GridBagConstraints();
		gbc_lblKr.anchor = GridBagConstraints.LINE_START;
		gbc_lblKr.insets = new Insets(0, 5, 5, 5);
		gbc_lblKr.gridx = 0;
		gbc_lblKr.gridy = 4;
		add(lblKr, gbc_lblKr);
		
		txtKr = new JTextField();
		txtKr.setColumns(10);
		txtKr.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String kr$=txtKr.getText();
		    	if(!entity.existsElement("pwmidq"))
		    		entity.createElement("pwmidq");
	    		entity.putElementItem("pwmidq", new Core(null,"Kr",kr$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtKr = new GridBagConstraints();
		gbc_txtKr.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtKr.gridx = 1;
		gbc_txtKr.gridy = 4;
		gbc_txtKr.anchor = GridBagConstraints.LINE_START;
		add(txtKr, gbc_txtKr);
		
		JLabel lblTr = new JLabel("Tr");
		GridBagConstraints gbc_lblTr = new GridBagConstraints();
		gbc_lblTr.anchor = GridBagConstraints.LINE_START;
		gbc_lblTr.insets = new Insets(0, 5, 5, 5);
		gbc_lblTr.gridx = 0;
		gbc_lblTr.gridy = 5;
		add(lblTr, gbc_lblTr);
		
		txtTr = new JTextField();
		txtTr.setColumns(10);
		txtTr.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String tr$=txtTr.getText();
		    	if(!entity.existsElement("pwmidq"))
		    		entity.createElement("pwmidq");
	    		entity.putElementItem("pwmidq", new Core(null,"Tr",tr$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtTr = new GridBagConstraints();
		gbc_txtTr.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtTr.gridx = 1;
		gbc_txtTr.gridy = 5;
		gbc_txtTr.anchor = GridBagConstraints.LINE_START;
		add(txtTr, gbc_txtTr);
		
		
		JLabel lblAM = new JLabel("Motor");
		lblAM.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String motor$=(String)cbxMotor.getSelectedItem();
					 Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
		              if(motor==null) {
		            	  System.out.println("JPWMidqEditor:cannot find entity="+motor$);
		            	  return;
		              }
		              String servicesLocator$=JEntityFacetList.classLocator();
		              servicesLocator$=Locator.append(servicesLocator$, Entigrator.ENTITY_LABEL, motor$);
		              JEntityFacetList entityFacetList=new JEntityFacetList(console,servicesLocator$);
					  JDisplay display=new JDisplay(console);
					  display.putContext(entityFacetList);
					  display.setLocationRelativeTo(JPWMidqEditor.this);
					  display.setVisible(true);
					  display.pack();
					  display.revalidate();
					  display.repaint();
					}catch(Exception ee) {
						System.out.println("JPWMidqEditor:motor click:"+ee.toString());
					}
					
			}
		});
		GridBagConstraints gbc_lblAM = new GridBagConstraints();
		gbc_lblAM.anchor = GridBagConstraints.LINE_START;
		gbc_lblAM.insets = new Insets(0, 5, 5, 5);
		gbc_lblAM.gridx = 0;
		gbc_lblAM.gridy = 6;
		add(lblAM, gbc_lblAM);
		
		cbxMotor=new JComboBox();
		cbxMotor.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				saveValues();
			}
		});
		GridBagConstraints gbc_cbxAM = new GridBagConstraints();
		gbc_cbxAM.insets = new Insets(0, 5, 5, 5);
		gbc_cbxAM.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxAM.gridx = 1;
		gbc_cbxAM.gridy = 6;
		add(cbxMotor, gbc_cbxAM);
		
		JLabel lblTest = new JLabel("Test");
		GridBagConstraints gbc_lblTest = new GridBagConstraints();
		gbc_lblTest.insets = new Insets(5, 5, 5, 5);
		gbc_lblTest.gridx = 0;
		gbc_lblTest.gridy =7;
		add(lblTest, gbc_lblTest);
		
		cbxTest = new JComboBox<String>();
		cbxTest.setModel(new DefaultComboBoxModel(new String[] {"given", "estimated"}));
		cbxTest.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				 saveValues();
			}
		});
		GridBagConstraints gbc_cbxTest = new GridBagConstraints();
		gbc_cbxTest.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxTest.gridx = 1;
		gbc_cbxTest.gridy = 7;
		gbc_cbxTest.insets = new Insets(5, 5, 5, 0);
		add(cbxTest, gbc_cbxTest);
		
		
		JPanel placebo=new JPanel();
		GridBagConstraints gbc_P = new GridBagConstraints();
		gbc_P.fill=GridBagConstraints.BOTH;
		gbc_P.gridx = 0;
		gbc_P.gridy = 8;
		add(placebo, gbc_P);
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
    	
		entity=console.getEntigrator().getEntityAtLabel(entity$);
    	initContext();
    	//System.out.println("JVFsupplyEditor:Uc="+uc$+" f0="+f0$+" Uc="+uc$+" f="+f$);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,"pwmidq");
		locator.put(FacetHandler.FACET_TYPE,"pwmidq");
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMidqMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(JContext.CONTEXT_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmidq.JPWMidqEditor");
		return Locator.toString(locator);
	}
	
	@Override
	public String reply(JMainConsole console, String locator$) {
		return locator$;
	}
	private void initContext() {
		try {
			block=true;
			String[] sa=console.getEntigrator().listEntities("motor",Locator.LOCATOR_TRUE);
			DefaultComboBoxModel <String>model=new DefaultComboBoxModel<String>();
			ArrayList<String>sl=new ArrayList<String>();
			String label$;
			if(sa!=null) {
				for(String s:sa) {
					label$=console.getEntigrator().getLabel(s);
					if(label$!=null)
						sl.add(label$);
				}
			sa=new String[sl.size()];
			sl.toArray(sa);
			Arrays.sort(sa);
			model=new DefaultComboBoxModel<String>(sa);
			}
			cbxMotor.setModel(model);
			String motor$=entity.getElementItemAt("pwmidq", "motor");
			if(motor$!=null)
				selectCombo(cbxMotor,motor$);
			else {
				cbxMotor.setSelectedIndex(0);
			}
			String test$=entity.getElementItemAt("pwmidq", "test");
			if(test$!=null)
				selectCombo(cbxTest,test$);
			//entity.printElement("pwmidqcontrol");
	    	String ua$=entity.getElementItemAt("pwmidq", "Ud");
	    	txtUd.setText(ua$);
	    	String kid$=entity.getElementItemAt("pwmidq", "Kid");
	    	txtKid.setText(kid$);
	    	String w$=entity.getElementItemAt("pwmidq", "W");
	    	txtW.setText(w$);
	    	String m$=entity.getElementItemAt("pwmidq", "M");
	    	txtM.setText(m$);
	    	String tr$=entity.getElementItemAt("pwmidq", "Tr");
	    	txtTr.setText(tr$);
	    	String kr$=entity.getElementItemAt("pwmidq", "Kr");
	    	txtKr.setText(kr$);
	    	block=false;
		}catch(Exception e) {
			System.out.println("JPWMidqEditor:initContext:"+e.toString());
		}
	}
	private void saveValues() {
		try {
			if(!entity.existsElement("pwmidq"))
				entity.createElement("pwmidq");
			String val$=(String)cbxMotor.getSelectedItem();
			entity.putElementItem("pwmidq", new Core(null,"motor",val$));
			val$=(String)cbxTest.getSelectedItem();
			entity.putElementItem("pwmidq", new Core(null,"test",val$));
			val$=txtKid.getText();
			entity.putElementItem("pwmidq", new Core(null,"Kid",val$));
			val$=txtUd.getText();
			entity.putElementItem("pwmidq", new Core(null,"Ud",val$));
			val$=txtM.getText();
			entity.putElementItem("pwmidq", new Core(null,"M",val$));
			val$=txtW.getText();
			entity.putElementItem("pwmidq", new Core("","W",val$));
			val$=txtTr.getText();
			entity.putElementItem("pwmidq", new Core("","Tco",val$));
			console.getEntigrator().putEntity(entity);
		}catch(Exception e) {
			System.out.println("JPWMidqEditor:saveValues:"+e.toString());
		}
	}
}
