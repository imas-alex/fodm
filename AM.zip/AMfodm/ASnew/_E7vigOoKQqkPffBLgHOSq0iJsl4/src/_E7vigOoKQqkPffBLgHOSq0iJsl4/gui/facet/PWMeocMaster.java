package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet;

import java.util.Properties;

import javax.swing.JPopupMenu;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMeocHandler;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmeoc.JPWMeocEditor;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;

public class PWMeocMaster extends FacetMaster{
	public static final String KEY="_8ggKt5KjICKiwDB20L4yKvvt8jA";
	public PWMeocMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMeocMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMeocHandler");
	    locator.put(HANDLER_KEY,"_H2Yjz08_SVC9SaD_SAYA3WsSSQAN0");
	    locator.put(Locator.LOCATOR_TITLE,"PWMeoc");
	    locator.put(MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "pwmeoc.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_TYPE,"pwmeochandler");
	    return Locator.toString(locator);
	    
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		//String display$=Locator.getProperty(handlerLocator$, JContext.DISPLAY);
		String itemLocator$=JItemPanel.classLocator();
		String controllerLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, controllerLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= PWMeocHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		//System.out.println("VectorMaster:getFacetHandler:locator="+locator$);
		return new PWMeocHandler(console.getEntigrator(),handlerLocator$); 
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return "PWMeocHandler";
	}
	@Override
	public String getType() {
		return "pwmeochandler";
	}
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String parent$=Locator.getProperty(locator$, JContext.PARENT);
			String pwmeocEditor$=JPWMeocEditor.classLocator();
			pwmeocEditor$=Locator.merge(pwmeocEditor$,locator$);
			pwmeocEditor$=Locator.append(pwmeocEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			if(parent$!=null)
				pwmeocEditor$=Locator.append(pwmeocEditor$,JContext.PARENT,parent$);
			JPWMeocEditor pwmeocEditor=new JPWMeocEditor(console,pwmeocEditor$);
			//System.out.println("VectorMaster:entityFacetsItemOnClick:2");
			console.replaceContext(context,(JContext)pwmeocEditor);
		}catch(Exception e) {
			System.out.println("PWMeocMaster:entityFacetsItemOnClick:"+e.toString());	
		}
		
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",PWMeocHandler.KEY,PWMeocHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("PWMeocMaster:putToSession:"+e.toString());
	    }
	}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
		
	}

	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		try { 
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		System.out.println("PWMeocMaster:createEntity:label"+entityLabel$);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		System.out.println("PWMeocMaster:createEntity:entity="+entity.getProperty("label"));
		entity.putElementItem("facet", new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",getType(),classLocator()));
		entity.putAttribute(new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4","icon","pwmeoc.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty( "operator","true", entity.getKey());
		return entity;
		}catch(Exception e) {
	    	System.out.println("PWMeocMaster:createEntity:"+e.toString());
	    	return null;
	    }
	}
}
