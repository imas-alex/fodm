package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet;

import java.util.Properties;

import javax.swing.JPopupMenu;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMVFdriveHandler;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmvfdrive.JPWMVFdriveEditor;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;

public class PWMVFdriveMaster extends FacetMaster{
	public static final String KEY="_LAQ1u0WlKcTugGlOUqzYVpmZrco";
	public PWMVFdriveMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMVFdriveMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMVFdriveHandler");
	    locator.put(HANDLER_KEY,"_5ZTQcM_zAjSObea5Qx5_SeoOl8KI");
	    locator.put(Locator.LOCATOR_TITLE,"PWMVFdrive");
	    locator.put(MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "pwmvfdrive.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_TYPE,"pwmvfdrivehandler");
	    return Locator.toString(locator);
	    
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String display$=Locator.getProperty(handlerLocator$, JContext.DISPLAY);
		String itemLocator$=JItemPanel.classLocator();
		String controllerLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, controllerLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= PWMVFdriveHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		//System.out.println("VectorMaster:getFacetHandler:locator="+locator$);
		return new PWMVFdriveHandler(console.getEntigrator(),handlerLocator$); 
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return "PWMVFdriveHandler";
	}
	@Override
	public String getType() {
		return "pwmvfdrivehandler";
	}
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String parent$=Locator.getProperty(locator$, JContext.PARENT);
			String pwmvfdriveEditor$=JPWMVFdriveEditor.classLocator();
			pwmvfdriveEditor$=Locator.merge(pwmvfdriveEditor$,locator$);
			pwmvfdriveEditor$=Locator.append(pwmvfdriveEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			if(parent$!=null)
				pwmvfdriveEditor$=Locator.append(pwmvfdriveEditor$,JContext.PARENT,parent$);
			JPWMVFdriveEditor pwmvfdriveEditor=new JPWMVFdriveEditor(console,pwmvfdriveEditor$);
			//System.out.println("VectorMaster:entityFacetsItemOnClick:2");
			console.replaceContext(context,(JContext)pwmvfdriveEditor);
		}catch(Exception e) {
			System.out.println("PWMVFdriveMaster:entityFacetsItemOnClick:"+e.toString());	
		}
		
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",PWMVFdriveHandler.KEY,PWMVFdriveHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("PWMVFdriveMaster:putToSession:"+e.toString());
	    }
	}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
		
	}

	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity.putElementItem("facet", new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",getType(),classLocator()));
		entity.putAttribute(new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4","icon","pwmvfdrive.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty( "operator","true", entity.getKey());
		return entity;
	}
}
