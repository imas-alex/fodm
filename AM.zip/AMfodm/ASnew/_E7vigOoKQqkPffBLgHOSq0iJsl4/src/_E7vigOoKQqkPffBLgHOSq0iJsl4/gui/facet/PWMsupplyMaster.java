package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet;

import java.util.Properties;

import javax.swing.JPopupMenu;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMsupplyHandler;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VFsupplyHandler;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmsupply.JPWMsupplyEditor;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.vfsupply.JVFsupplyEditor;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.facet.FacetMaster.JAllFacetsItem;
import gdt.gui.facet.FacetMaster.JEntityFacetsItem;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;

public class PWMsupplyMaster extends FacetMaster{
	public static final String KEY="_lzMR65jEA84YuPUZrfe4tbLQIsg";
	public PWMsupplyMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMsupplyMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMsupplyHandler");
	    locator.put(HANDLER_KEY,"_yiTQ8xCaankf3v70xDZWOGK9fxM");
	    locator.put(Locator.LOCATOR_TITLE,"PWMsupply");
	    locator.put(MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "pwmsupply.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_TYPE,"pwmsupply");
	    return Locator.toString(locator);
	    
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String display$=Locator.getProperty(handlerLocator$, JContext.DISPLAY);
		String itemLocator$=JItemPanel.classLocator();
		String controllerLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, controllerLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= PWMsupplyHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		//System.out.println("VectorMaster:getFacetHandler:locator="+locator$);
		return new PWMsupplyHandler(console.getEntigrator(),handlerLocator$); 
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return "PWMsupply";
	}
	@Override
	public String getType() {
		return "pwmsupply";
	}
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			//System.out.println("PWMsupplyMaster:entityFacetsItemOnClick:alocator$="+alocator$);
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String parent$=Locator.getProperty(locator$, JContext.PARENT);
			String pwmsupplyEditor$=JPWMsupplyEditor.classLocator();
			pwmsupplyEditor$=Locator.merge(pwmsupplyEditor$,locator$);
			pwmsupplyEditor$=Locator.append(pwmsupplyEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			if(parent$!=null)
				pwmsupplyEditor$=Locator.append(pwmsupplyEditor$,JContext.PARENT,parent$);
			JPWMsupplyEditor pwmsupplyEditor=new JPWMsupplyEditor(console,pwmsupplyEditor$);
			//System.out.println("PWMsupplyMaster:entityFacetsItemOnClick:");
			console.replaceContext(context,(JContext)pwmsupplyEditor);
		}catch(Exception e) {
			System.out.println("PWMsupplyMaster:entityFacetsItemOnClick:"+e.toString());	
		}
		
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",PWMsupplyHandler.KEY,PWMsupplyHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("PWMsupplyMaster:putToSession:"+e.toString());
	    }
	}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
		
	}

	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity.putElementItem("facet", new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",getType(),classLocator()));
		entity.putAttribute(new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4","icon","pwmsupply.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty( "operator","true", entity.getKey());
		return entity;
	}
}
