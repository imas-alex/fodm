package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmfec;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;

import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JGuiEditor;

import java.awt.GridBagLayout;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;


import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class JPWMfecEditor extends JGuiEditor{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_oehxl1vaORZEYAHOG_Swy_S6oXr24";
	JTextField txtUd;
	JTextField txtKid;
	JTextField txtW;
	JTextField txtM;
	JTextField txtKiq;
	JTextField txtTiq;
	JTextField txtKrs;
	JComboBox <String>cbxOrient;
	JComboBox <String>cbxMotor;
	JComboBox <String>cbxTest;
	boolean block=false;
	Sack entity;
	public JPWMfecEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0,0,1};
		gridBagLayout.rowHeights = new int[]{0,0,0,0,0,1};
		gridBagLayout.columnWeights = new double[]{0.0,0.0,1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblUd = new JLabel("Ud");
		GridBagConstraints gbc_lblUd = new GridBagConstraints();
		gbc_lblUd.anchor = GridBagConstraints.LINE_START;
		gbc_lblUd.insets = new Insets(5, 5, 5, 5);
		gbc_lblUd.gridx = 0;
		gbc_lblUd.gridy = 0;
		add(lblUd, gbc_lblUd);
		
		txtUd = new JTextField();
		txtUd.setColumns(10);
		txtUd.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String ud$=txtUd.getText();
		    	if(!entity.existsElement("pwmfec"))
		    		entity.createElement("pwmfec");
	    		entity.putElementItem("pwmfec", new Core(null,"Ud",ud$));	
				 console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtUd = new GridBagConstraints();
		gbc_txtUd.insets = new Insets(5, 5, 5, 5);
		gbc_txtUd.gridx = 1;
		gbc_txtUd.gridy = 0;
		gbc_txtUd.anchor = GridBagConstraints.LINE_START;
		add(txtUd, gbc_txtUd);
		
		JLabel lblKid = new JLabel("Kid");
		GridBagConstraints gbc_lblKid = new GridBagConstraints();
		gbc_lblKid.anchor = GridBagConstraints.LINE_START;
		gbc_lblKid.insets = new Insets(0, 5, 5, 5);
		gbc_lblKid.gridx = 0;
		gbc_lblKid.gridy = 1;
		add(lblKid, gbc_lblKid);
		
		txtKid = new JTextField();
		txtKid.setColumns(10);
		txtKid.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String kid$=txtKid.getText();
		    	if(!entity.existsElement("pwmfec"))
		    		entity.createElement("pwmfec");
	    		entity.putElementItem("pwmfec", new Core(null,"Kid",kid$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtKid = new GridBagConstraints();
		gbc_txtKid.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF0.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtKid.gridx = 1;
		gbc_txtKid.gridy = 1;
		gbc_txtKid.anchor = GridBagConstraints.LINE_START;
		add(txtKid, gbc_txtKid);
		
		JLabel  lblW = new JLabel("W");
		GridBagConstraints gbc_lblW = new GridBagConstraints();
		gbc_lblW.insets = new Insets(0, 5, 5, 5);
		gbc_lblW.anchor=GridBagConstraints.LINE_START;
		gbc_lblW.gridx = 0;
		gbc_lblW.gridy = 2;
		add(lblW, gbc_lblW);
		
		txtW = new JTextField();
		txtW.setColumns(10);
		
		GridBagConstraints gbc_txtW = new GridBagConstraints();
		gbc_txtW.insets = new Insets(0, 5, 5, 5);
		gbc_txtW.gridx = 1;
		gbc_txtW.gridy = 2;
		gbc_txtW.anchor = GridBagConstraints.LINE_START;
		add(txtW, gbc_txtW);
		txtW.addCaretListener(new CaretListener() {
				@Override
				public void caretUpdate(CaretEvent e) {
					String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    	String w$=txtW.getText();
			    	if(!entity.existsElement("pwmfec"))
			    		entity.createElement("pwmfec");
		    		entity.putElementItem("pwmfec", new Core(null,"W",w$));	
					console.getEntigrator().putEntity(entity);
					 }
		      });
		
		JLabel lblM = new JLabel("M");
		GridBagConstraints gbc_lblM = new GridBagConstraints();
		gbc_lblM.anchor = GridBagConstraints.LINE_START;
		gbc_lblM.insets = new Insets(0, 5, 5, 5);
		gbc_lblM.gridx = 0;
		gbc_lblM.gridy = 3;
		add(lblM, gbc_lblM);
		
		txtM = new JTextField();
		txtM.setColumns(10);
		txtM.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String m$=txtM.getText();
		    	if(!entity.existsElement("pwmfec"))
		    		entity.createElement("pwmfec");
	    		entity.putElementItem("pwmfec", new Core(null,"M",m$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtM = new GridBagConstraints();
		gbc_txtM.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtM.gridx = 1;
		gbc_txtM.gridy = 3;
		gbc_txtM.anchor = GridBagConstraints.LINE_START;
		add(txtM, gbc_txtM);
		
		JLabel lblKiq = new JLabel("Kiq");
		GridBagConstraints gbc_lblKiq = new GridBagConstraints();
		gbc_lblKiq.anchor = GridBagConstraints.LINE_START;
		gbc_lblKiq.insets = new Insets(0, 5, 5, 5);
		gbc_lblKiq.gridx = 0;
		gbc_lblKiq.gridy = 4;
		add(lblKiq, gbc_lblKiq);
		
		txtKiq = new JTextField();
		txtKiq.setColumns(10);
		txtKiq.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String kiq$=txtKiq.getText();
		    	if(!entity.existsElement("pwmfec"))
		    		entity.createElement("pwmfec");
	    		entity.putElementItem("pwmfec", new Core(null,"Kiq",kiq$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		
		GridBagConstraints gbc_txtKiq = new GridBagConstraints();
		gbc_txtKiq.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtKiq.gridx = 1;
		gbc_txtKiq.gridy = 4;
		gbc_txtKiq.anchor = GridBagConstraints.LINE_START;
		add(txtKiq, gbc_txtKiq);
		
		JLabel lblTiq = new JLabel("Tiq");
		GridBagConstraints gbc_lblTiq = new GridBagConstraints();
		gbc_lblTiq.anchor = GridBagConstraints.LINE_START;
		gbc_lblTiq.insets = new Insets(0, 5, 5, 5);
		gbc_lblTiq.gridx = 0;
		gbc_lblTiq.gridy = 5;
		add(lblTiq, gbc_lblTiq);
		
		txtTiq = new JTextField();
		txtTiq.setColumns(10);
		txtTiq.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String tiq$=txtTiq.getText();
		    	if(!entity.existsElement("pwmfec"))
		    		entity.createElement("pwmfec");
	    		entity.putElementItem("pwmfec", new Core(null,"Tiq",tiq$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtTiq = new GridBagConstraints();
		gbc_txtTiq.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtTiq.gridx = 1;
		gbc_txtTiq.gridy = 5;
		gbc_txtTiq.anchor = GridBagConstraints.LINE_START;
		add(txtTiq, gbc_txtTiq);
		
		//
		JLabel lblKrs = new JLabel("Krs");
		GridBagConstraints gbc_lblKrs = new GridBagConstraints();
		gbc_lblKrs.anchor = GridBagConstraints.LINE_START;
		gbc_lblKrs.insets = new Insets(0, 5, 5, 5);
		gbc_lblKrs.gridx = 0;
		gbc_lblKrs.gridy = 6;
		add(lblKrs, gbc_lblKrs);
		
		txtKrs = new JTextField();
		txtKrs.setColumns(10);
		txtKrs.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String krs$=txtKrs.getText();
		    	if(!entity.existsElement("pwmfec"))
		    		entity.createElement("pwmfec");
	    		entity.putElementItem("pwmfec", new Core(null,"Krs",krs$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtKrs = new GridBagConstraints();
		gbc_txtKrs.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtKrs.gridx = 1;
		gbc_txtKrs.gridy = 6;
		gbc_txtKrs.anchor = GridBagConstraints.LINE_START;
		add(txtKrs, gbc_txtKrs);
		//
		JLabel lblOrient = new JLabel("Orientation");
		
		GridBagConstraints gbc_lblOrient = new GridBagConstraints();
		gbc_lblOrient.anchor = GridBagConstraints.LINE_START;
		gbc_lblOrient.insets = new Insets(0, 5, 5, 5);
		gbc_lblOrient.gridx = 0;
		gbc_lblOrient.gridy = 7;
		add(lblOrient, gbc_lblOrient);
		
		cbxOrient=new JComboBox();
		cbxOrient.setModel(new DefaultComboBoxModel(new String[] {"FLUX", "EMF"}));
		cbxOrient.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				saveValues();
			}
		});
		GridBagConstraints gbc_cbxOrient = new GridBagConstraints();
		gbc_cbxOrient.insets = new Insets(0, 5, 5, 5);
		gbc_cbxOrient.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxOrient.gridx = 1;
		gbc_cbxOrient.gridy = 7;
		add(cbxOrient, gbc_cbxOrient);
		
		
		
		JLabel lblAM = new JLabel("Motor");
		lblAM.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String motor$=(String)cbxMotor.getSelectedItem();
					 Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
		              if(motor==null) {
		            	  System.out.println("JPWMeocEditor:cannot find entity="+motor$);
		            	  return;
		              }
		              String servicesLocator$=JEntityFacetList.classLocator();
		              servicesLocator$=Locator.append(servicesLocator$, Entigrator.ENTITY_LABEL, motor$);
		              JEntityFacetList entityFacetList=new JEntityFacetList(console,servicesLocator$);
					  JDisplay display=new JDisplay(console);
					  display.putContext(entityFacetList);
					  display.setLocationRelativeTo(JPWMfecEditor.this);
					  display.setVisible(true);
					  display.pack();
					  display.revalidate();
					  display.repaint();
					}catch(Exception ee) {
						System.out.println("JPWMeocEditor:motor click:"+ee.toString());
					}
					
			}
		});
		GridBagConstraints gbc_lblAM = new GridBagConstraints();
		gbc_lblAM.anchor = GridBagConstraints.LINE_START;
		gbc_lblAM.insets = new Insets(0, 5, 5, 5);
		gbc_lblAM.gridx = 0;
		gbc_lblAM.gridy = 8;
		add(lblAM, gbc_lblAM);
		
		cbxMotor=new JComboBox();
		cbxMotor.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				saveValues();
			}
		});
		GridBagConstraints gbc_cbxAM = new GridBagConstraints();
		gbc_cbxAM.insets = new Insets(0, 5, 5, 5);
		gbc_cbxAM.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxAM.gridx = 1;
		gbc_cbxAM.gridy = 8;
		add(cbxMotor, gbc_cbxAM);
		
		JLabel lblTest = new JLabel("Test");
		GridBagConstraints gbc_lblTest = new GridBagConstraints();
		gbc_lblTest.insets = new Insets(5, 5, 5, 5);
		gbc_lblTest.anchor = GridBagConstraints.LINE_START;
		gbc_lblTest.gridx = 0;
		gbc_lblTest.gridy = 9;
		add(lblTest, gbc_lblTest);
		
		cbxTest = new JComboBox<String>();
		cbxTest.setModel(new DefaultComboBoxModel(new String[] {"given", "estimated"}));
		cbxTest.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				 saveValues();
			}
		});
		GridBagConstraints gbc_cbxTest = new GridBagConstraints();
		gbc_cbxTest.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxTest.gridx = 1;
		gbc_cbxTest.gridy = 9;
		gbc_cbxTest.insets = new Insets(5, 5, 5, 0);
		add(cbxTest, gbc_cbxTest);
		
		
		JPanel placebo=new JPanel();
		GridBagConstraints gbc_P = new GridBagConstraints();
		gbc_P.fill=GridBagConstraints.BOTH;
		gbc_P.gridx = 0;
		gbc_P.gridy = 10;
		add(placebo, gbc_P);
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
    	
		entity=console.getEntigrator().getEntityAtLabel(entity$);
    	initContext();
    	//System.out.println("JVFsupplyEditor:Uc="+uc$+" f0="+f0$+" Uc="+uc$+" f="+f$);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,"pwmfec");
		locator.put(FacetHandler.FACET_TYPE,"pwmfec");
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMidqMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(JContext.CONTEXT_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmfec.JPWMfecEditor");
		return Locator.toString(locator);
	}
	
	@Override
	public String reply(JMainConsole console, String locator$) {
		return locator$;
	}
	private void initContext() {
		try {
			block=true;
			String[] sa=console.getEntigrator().listEntities("motor",Locator.LOCATOR_TRUE);
			DefaultComboBoxModel <String>model=new DefaultComboBoxModel<String>();
			ArrayList<String>sl=new ArrayList<String>();
			String label$;
			if(sa!=null) {
				for(String s:sa) {
					label$=console.getEntigrator().getLabel(s);
					if(label$!=null)
						sl.add(label$);
				}
			sa=new String[sl.size()];
			sl.toArray(sa);
			Arrays.sort(sa);
			model=new DefaultComboBoxModel<String>(sa);
			}
			cbxMotor.setModel(model);
			String motor$=entity.getElementItemAt("pwmfec", "motor");
			if(motor$!=null)
				selectCombo(cbxMotor,motor$);
			else {
				cbxMotor.setSelectedIndex(0);
			}
			String test$=entity.getElementItemAt("pwmfec", "test");
			if(test$!=null)
				selectCombo(cbxTest,test$);
			String orient$=entity.getElementItemAt("pwmfec", "orientation");
			if(orient$!=null)
				selectCombo(cbxOrient,orient$);
		
	    	String ua$=entity.getElementItemAt("pwmfec", "Ud");
	    	txtUd.setText(ua$);
	    	String kid$=entity.getElementItemAt("pwmfec", "Kid");
	    	txtKid.setText(kid$);
	    	String w$=entity.getElementItemAt("pwmfec", "W");
	    	txtW.setText(w$);
	    	String m$=entity.getElementItemAt("pwmfec", "M");
	    	txtM.setText(m$);
	    	String tiq$=entity.getElementItemAt("pwmfec", "Tiq");
	    	txtTiq.setText(tiq$);
	    	String kiq$=entity.getElementItemAt("pwmfec", "Kiq");
	    	txtKiq.setText(kiq$);
	    	String krs$=entity.getElementItemAt("pwmfec", "Krs");
	    	txtKrs.setText(krs$);
	    	block=false;
		}catch(Exception e) {
			System.out.println("JPWMfecEditor:initContext:"+e.toString());
		}
	}
	private void saveValues() {
		try {
			if(!entity.existsElement("pwmfec"))
				entity.createElement("pwmfec");
			String val$=(String)cbxMotor.getSelectedItem();
			entity.putElementItem("pwmfec", new Core(null,"motor",val$));
			val$=(String)cbxTest.getSelectedItem();
			entity.putElementItem("pwmfec", new Core(null,"test",val$));
			val$=(String)cbxOrient.getSelectedItem();
			entity.putElementItem("pwmfec", new Core(null,"orientation",val$));
			val$=txtKid.getText();
			entity.putElementItem("pwmfec", new Core(null,"Kid",val$));
			val$=txtUd.getText();
			entity.putElementItem("pwmfec", new Core(null,"Ud",val$));
			val$=txtM.getText();
			entity.putElementItem("pwmfec", new Core(null,"M",val$));
			val$=txtW.getText();
			entity.putElementItem("pwmfec", new Core("","W",val$));
			val$=txtTiq.getText();
			entity.putElementItem("pwmfec", new Core("","Tiq",val$));
			val$=txtKiq.getText();
			entity.putElementItem("pwmfec", new Core("","Kiq",val$));
			val$=txtKrs.getText();
			entity.putElementItem("pwmfec", new Core("","Krs",val$));
			console.getEntigrator().putEntity(entity);
		}catch(Exception e) {
			System.out.println("JPWMfecEditor:saveValues:"+e.toString());
		}
	}
}
