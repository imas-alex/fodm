package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Properties;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;


import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.motor.JMotorEditor;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;

public class MotorMaster extends FacetMaster{
	public static final String KEY="_09sWHMDw7XIJrTDGRFFTvwbd1SA";
	public static final String NAME="Motor";
	public MotorMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MotorMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return NAME;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.MotorMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler");
	    locator.put(HANDLER_KEY,"_9KrEWOlwlMKHHXLfLg_cTZ22Iyc");
	    locator.put(Locator.LOCATOR_TITLE,"Motor");
	    locator.put(MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "motor.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_TYPE,MotorHandler.MOTOR_FACET_TYPE);
	    return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		//System.out.println("MotorMaster:getJEntityFacetsItem:locator="+handlerLocator$);
		/*
		 * 	String itemLocator$=JItemPanel.classLocator();
		String applianceLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, applianceLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
	
		 */
		
		String entity$=Locator.getProperty(handlerLocator$, Entigrator.ENTITY_LABEL);
		String itemLocator$=JItemPanel.classLocator();
		String masterLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, masterLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		//itemLocator$=Locator.append(itemLocator$,JContext.PARENT, context.getInstance());
		//SessionHandler.putLocator(console.getEntigrator(), context.getLocator());
		//System.out.println("MotorMaster:getJEntityFacetsItem:item locator="+itemLocator$);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= MotorHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new MotorHandler(console.getEntigrator(),handlerLocator$); 
	}

	

	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			System.out.println("MotorMaster:entityFacetsItemOnClick:entity locator="+locator$);
			String motorEditor$=JMotorEditor.classLocator();
			motorEditor$=Locator.merge(motorEditor$,alocator$);
			motorEditor$=Locator.append(motorEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			motorEditor$=Locator.append(motorEditor$,JContext.PARENT, context.getInstance());
			SessionHandler.putLocator(console.getEntigrator(), context.getLocator());
			JMotorEditor motorEditor=new JMotorEditor(console,motorEditor$);
			console.replaceContext(context,(JContext)motorEditor);
		}catch(Exception e) {
			System.out.println("ApplianceMaster:entityFacetsItemOnClick:"+e.toString());	
		}
		
	}

	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		final String itemLocator$=alocator$;
		JPopupMenu popup=new JPopupMenu();
		JMenuItem newItem=new JMenuItem("New motor");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("MotorMaster:allFacetsItemPopup:new entity:locator="+itemLocator$);
				popup.setVisible(false);
				String textEditor$=JTextEditor.classLocator();
				textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New motor");
				String facetList$=JEntityFacetList.classLocator();
				facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
				facetList$=Locator.append(facetList$,MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.MotorMaster");
				facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
				SessionHandler.putLocator(console.getEntigrator(),facetList$);
				textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
				JTextEditor textEditor=new JTextEditor(console,textEditor$);
				console.replaceContext(context,textEditor);
			}
		} );
		popup.add(newItem);
		return popup;
	}

	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getType() {
		return "motor";
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",getType(),classLocator()));
		entity.putAttribute(new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4","icon","motor.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty("operator", "true", entity.getKey());
		//createSource( entigrator,entityLabel$);
		return entity;
	}
	private void createSource(Entigrator entigrator, String entityLabel$){
		try{
//			System.out.println("JProcedurePanel:createSource.procedure key="+procedureKey$);
			String entityKey$=entigrator.getKey(entityLabel$);
			File sourceHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src");
			if(!sourceHome.exists())
				sourceHome.mkdirs();
			File binHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin");
			if(!binHome.exists())
				binHome.mkdirs();
			File procedureJava=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src/"+entityKey$+".java");
			if(!procedureJava.exists())
				procedureJava.createNewFile();
			 FileOutputStream fos = new FileOutputStream(procedureJava, false);
			 Writer writer = new OutputStreamWriter(fos, "UTF-8");
				writer.write("import java.util.Hashtable;\n");
				writer.write("import gdt.base.store.Sack;\n");
				writer.write("import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;\n");
				writer.write("public class " +entityKey$+"  implements SegueController {\n");
				writer.write("private final static String ENTITY_KEY=\""+entityKey$+"\";\n");
				writer.write("@Override\n");
				writer.write("public void reset() {}\n");
				writer.write("@Override\n");
				writer.write("public Hashtable<String, Double> getSettings()  {return null;}\n");
				writer.write("@Override\n");
				writer.write("public Hashtable<String, Double> getSettings(Sack entity)   {return null;}\n");
				writer.write("@Override\n");
				writer.write("public void putSettings(Hashtable<String, Double> set)  {}\n");
				writer.write("@Override\n");
				writer.write("public String[] listInputs(){return null;}\n");
				writer.write("@Override\n");
				writer.write("public String[] listOutputs(){return null;}\n"); 
				writer.write("@Override\n");
				writer.write("public Hashtable<String, Double> transition(Hashtable<String, Double> ins){return null;}\n"); 
				writer.write("}\n");
			 writer.close();   
		}catch(Exception e){
			System.out.println("EduMaster:createSource:"+e.toString());
		}
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",MotorHandler.KEY,MotorHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("MotorMaster:addToSession:"+e.toString());
	    }
}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 	
		
	}
}
