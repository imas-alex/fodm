package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmvfcontrol;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;

import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;

import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;

import java.awt.GridBagLayout;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

public class JPWMVFcontrolEditor extends JGuiEditor{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_oehxl1vaORZEYAHOG_Swy_S6oXr24";
	JTextField txtUa;
	JTextField txtF0;
	JTextField txtW;
	JTextField txtM;
	JTextField txtTc;
	JTextField txtKc;
	JTextField txtKfv;
	JComboBox <String>cbxMotor;
	JComboBox <String>cbxTest;
	boolean block=false;
	Sack entity;
	public JPWMVFcontrolEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0,0,1};
		gridBagLayout.rowHeights = new int[]{0,0,0,0,0,1};
		gridBagLayout.columnWeights = new double[]{0.0,0.0,1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblUa = new JLabel("Ua");
		GridBagConstraints gbc_lblUa = new GridBagConstraints();
		gbc_lblUa.anchor = GridBagConstraints.LINE_START;
		gbc_lblUa.insets = new Insets(5, 5, 5, 5);
		gbc_lblUa.gridx = 0;
		gbc_lblUa.gridy = 0;
		add(lblUa, gbc_lblUa);
		
		txtUa = new JTextField();
		txtUa.setColumns(10);
		txtUa.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String ua$=txtUa.getText();
		    	if(!entity.existsElement("pwmvfcontrol"))
		    		entity.createElement("pwmvfcontrol");
	    		entity.putElementItem("pwmvfcontrol", new Core(null,"Ua",ua$));	
				 console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtUa = new GridBagConstraints();
		gbc_txtUa.insets = new Insets(5, 5, 5, 5);
		gbc_txtUa.gridx = 1;
		gbc_txtUa.gridy = 0;
		gbc_txtUa.anchor = GridBagConstraints.LINE_START;
		add(txtUa, gbc_txtUa);
		
		JLabel lblF0 = new JLabel("f0");
		GridBagConstraints gbc_lblF0 = new GridBagConstraints();
		gbc_lblF0.anchor = GridBagConstraints.LINE_START;
		gbc_lblF0.insets = new Insets(0, 5, 5, 5);
		gbc_lblF0.gridx = 0;
		gbc_lblF0.gridy = 1;
		add(lblF0, gbc_lblF0);
		
		txtF0 = new JTextField();
		txtF0.setColumns(10);
		txtF0.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String f0$=txtF0.getText();
		    	if(!entity.existsElement("pwmvfcontrol"))
		    		entity.createElement("pwmvfcontrol");
	    		entity.putElementItem("pwmvfcontrol", new Core(null,"f0",f0$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtF0 = new GridBagConstraints();
		gbc_txtF0.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF0.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtF0.gridx = 1;
		gbc_txtF0.gridy = 1;
		gbc_txtF0.anchor = GridBagConstraints.LINE_START;
		add(txtF0, gbc_txtF0);
		
		JLabel  lblKfv = new JLabel("Kfv");
		GridBagConstraints gbc_lblKfv = new GridBagConstraints();
		gbc_lblKfv.insets = new Insets(0, 5, 5, 5);
		gbc_lblKfv.anchor=GridBagConstraints.LINE_START;
		gbc_lblKfv.gridx = 0;
		gbc_lblKfv.gridy = 2;
		add(lblKfv, gbc_lblKfv);
		
		txtKfv = new JTextField();
		txtKfv.setText("1");
		txtKfv.setColumns(10);
		GridBagConstraints gbc_txtKfv = new GridBagConstraints();
		gbc_txtKfv.anchor=GridBagConstraints.LINE_START;
		gbc_txtKfv.insets = new Insets(0, 5, 5, 5);
		gbc_txtKfv.gridx = 1;
		gbc_txtKfv.gridy = 2;
		add(txtKfv, gbc_txtKfv);
		txtKfv.addCaretListener(new CaretListener() {
				@Override
				public void caretUpdate(CaretEvent e) {
					String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    	String kfv$=txtKfv.getText();
			    	if(!entity.existsElement("pwmvfcontrol"))
			    		entity.createElement("pwmsupply");
		    		entity.putElementItem("pwmvfcontrol", new Core(null,"Kfv",kfv$));	
					console.getEntigrator().putEntity(entity);
					 }
		      });
		
		
		
		
		JLabel  lblW = new JLabel("W");
		GridBagConstraints gbc_lblW = new GridBagConstraints();
		gbc_lblW.insets = new Insets(0, 5, 5, 5);
		gbc_lblW.anchor=GridBagConstraints.LINE_START;
		gbc_lblW.gridx = 0;
		gbc_lblW.gridy = 3;
		add(lblW, gbc_lblW);
		
		txtW = new JTextField();
		txtW.setColumns(10);
		
		GridBagConstraints gbc_txtW = new GridBagConstraints();
		gbc_txtW.insets = new Insets(0, 5, 5, 5);
		gbc_txtW.gridx = 1;
		gbc_txtW.gridy = 3;
		gbc_txtW.anchor = GridBagConstraints.LINE_START;
		add(txtW, gbc_txtW);
		txtW.addCaretListener(new CaretListener() {
				@Override
				public void caretUpdate(CaretEvent e) {
					String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    	String w$=txtW.getText();
			    	if(!entity.existsElement("pwmvfcontrol"))
			    		entity.createElement("pwmvfcontrol");
		    		entity.putElementItem("pwmvfcontrol", new Core(null,"W",w$));	
					console.getEntigrator().putEntity(entity);
					 }
		      });
		
		JLabel lblM = new JLabel("M");
		GridBagConstraints gbc_lblM = new GridBagConstraints();
		gbc_lblM.anchor = GridBagConstraints.LINE_START;
		gbc_lblM.insets = new Insets(0, 5, 5, 5);
		gbc_lblM.gridx = 0;
		gbc_lblM.gridy = 4;
		add(lblM, gbc_lblM);
		
		txtM = new JTextField();
		txtM.setColumns(10);
		txtM.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String m$=txtM.getText();
		    	if(!entity.existsElement("pwmvfcontrol"))
		    		entity.createElement("pwmvfcontrol");
	    		entity.putElementItem("pwmvfcontrol", new Core(null,"M",m$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtM = new GridBagConstraints();
		gbc_txtM.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtM.gridx = 1;
		gbc_txtM.gridy = 4;
		gbc_txtM.anchor = GridBagConstraints.LINE_START;
		add(txtM, gbc_txtM);
		
		JLabel lblTc = new JLabel("Tc");
		GridBagConstraints gbc_lblTc = new GridBagConstraints();
		gbc_lblTc.anchor = GridBagConstraints.LINE_START;
		gbc_lblTc.insets = new Insets(0, 5, 5, 5);
		gbc_lblTc.gridx = 0;
		gbc_lblTc.gridy = 5;
		add(lblTc, gbc_lblTc);
		
		txtTc = new JTextField();
		txtTc.setColumns(10);
		txtTc.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String tc$=txtTc.getText();
		    	if(!entity.existsElement("pwmvfcontrol"))
		    		entity.createElement("pwmvfcontrol");
	    		entity.putElementItem("pwmvfcontrol", new Core(null,"Tc",tc$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtTc = new GridBagConstraints();
		gbc_txtTc.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtTc.gridx = 1;
		gbc_txtTc.gridy = 5;
		gbc_txtTc.anchor = GridBagConstraints.LINE_START;
		add(txtTc, gbc_txtTc);
		
		JLabel lblKc = new JLabel("Kc");
		GridBagConstraints gbc_lblKc = new GridBagConstraints();
		gbc_lblKc.anchor = GridBagConstraints.LINE_START;
		gbc_lblKc.insets = new Insets(0, 5, 5, 5);
		gbc_lblKc.gridx = 0;
		gbc_lblKc.gridy = 6;
		add(lblKc, gbc_lblKc);
		
		txtKc = new JTextField();
		txtKc.setColumns(10);
		txtKc.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String kc$=txtKc.getText();
		    	if(!entity.existsElement("pwmvfcontrol"))
		    		entity.createElement("pwmvfcontrol");
	    		entity.putElementItem("pwmvfcontrol", new Core(null,"Kc",kc$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtKc = new GridBagConstraints();
		gbc_txtTc.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtKc.gridx = 1;
		gbc_txtKc.gridy = 6;
		gbc_txtKc.anchor = GridBagConstraints.LINE_START;
		add(txtKc, gbc_txtKc);
		
		JLabel lblAM = new JLabel("Motor");
		GridBagConstraints gbc_lblAM = new GridBagConstraints();
		gbc_lblAM.anchor = GridBagConstraints.LINE_START;
		gbc_lblAM.insets = new Insets(0, 5, 5, 5);
		gbc_lblAM.gridx = 0;
		gbc_lblAM.gridy = 7;
		add(lblAM, gbc_lblAM);
		
		cbxMotor=new JComboBox();
		cbxMotor.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				saveValues();
			}
		});
		GridBagConstraints gbc_cbxAM = new GridBagConstraints();
		gbc_cbxAM.insets = new Insets(0, 5, 5, 5);
		gbc_cbxAM.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxAM.gridx = 1;
		gbc_cbxAM.gridy = 7;
		add(cbxMotor, gbc_cbxAM);
		
		JLabel lblTest = new JLabel("Test");
		GridBagConstraints gbc_lblTest = new GridBagConstraints();
		gbc_lblTest.insets = new Insets(5, 5, 5, 5);
		gbc_lblTest.gridx = 0;
		gbc_lblTest.gridy =8;
		add(lblTest, gbc_lblTest);
		
		cbxTest = new JComboBox<String>();
		cbxTest.setModel(new DefaultComboBoxModel(new String[] {"given", "estimated"}));
		cbxTest.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				 saveValues();
			}
		});
		GridBagConstraints gbc_cbxTest = new GridBagConstraints();
		gbc_cbxTest.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxTest.gridx = 1;
		gbc_cbxTest.gridy = 8;
		gbc_cbxTest.insets = new Insets(5, 5, 5, 0);
		add(cbxTest, gbc_cbxTest);
		
		JPanel placebo=new JPanel();
		GridBagConstraints gbc_P = new GridBagConstraints();
		gbc_P.fill=GridBagConstraints.BOTH;
		gbc_P.gridx = 0;
		gbc_P.gridy = 9;
		add(placebo, gbc_P);
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
    	
		entity=console.getEntigrator().getEntityAtLabel(entity$);
    	initContext();
    	//System.out.println("JVFsupplyEditor:Uc="+uc$+" f0="+f0$+" Uc="+uc$+" f="+f$);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,"pwmvfcontrol");
		locator.put(FacetHandler.FACET_TYPE,"pwmvfcontrol");
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMVFcontrolMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(JContext.CONTEXT_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmvfcontrol.JPWMVFcontrolEditor");
		return Locator.toString(locator);
	}
	
	@Override
	public String reply(JMainConsole console, String locator$) {
		return locator$;
	}
	private void initContext() {
		try {
			block=true;
			String[] sa=console.getEntigrator().listEntities("motor",Locator.LOCATOR_TRUE);
			DefaultComboBoxModel <String>model=new DefaultComboBoxModel<String>();
			ArrayList<String>sl=new ArrayList<String>();
			String label$;
			if(sa!=null) {
				for(String s:sa) {
					label$=console.getEntigrator().getLabel(s);
					if(label$!=null)
						sl.add(label$);
				}
			sa=new String[sl.size()];
			sl.toArray(sa);
			Arrays.sort(sa);
			model=new DefaultComboBoxModel<String>(sa);
			}
			cbxMotor.setModel(model);
			String motor$=entity.getElementItemAt("pwmvfcontrol", "motor");
			if(motor$!=null)
				selectCombo(cbxMotor,motor$);
			else {
				cbxMotor.setSelectedIndex(0);
			}
			String test$=entity.getElementItemAt("pwmvfcontrol", "test");
			if(test$!=null)
				selectCombo(cbxTest,test$);
			entity.printElement("pwmvfcontrol");
	    	String ua$=entity.getElementItemAt("pwmvfcontrol", "Ua");
	    	txtUa.setText(ua$);
	    	String f0$=entity.getElementItemAt("pwmvfcontrol", "f0");
	    	txtF0.setText(f0$);
	    	String kfv$=entity.getElementItemAt("pwmvfcontrol", "Kfv");
	    	txtKfv.setText(kfv$);
	    	String w$=entity.getElementItemAt("pwmvfcontrol", "W");
	    	txtW.setText(w$);
	    	String m$=entity.getElementItemAt("pwmvfcontrol", "M");
	    	txtM.setText(m$);
	    	String tc$=entity.getElementItemAt("pwmvfcontrol", "Tc");
	    	txtTc.setText(tc$);
	    	String kc$=entity.getElementItemAt("pwmvfcontrol", "Kc");
	    	txtKc.setText(kc$);
			block=false;
		}catch(Exception e) {
			System.out.println("JPWMVFcontrolEditor:initContext:"+e.toString());
		}
	}
	private void saveValues() {
		try {
			if(!entity.existsElement("pwmvfcontrol"))
				entity.createElement("pwmvfcontrol");
			String val$=(String)cbxMotor.getSelectedItem();
			entity.putElementItem("pwmvfcontrol", new Core(null,"motor",val$));
			val$=(String)cbxTest.getSelectedItem();
			entity.putElementItem("pwmvfcontrol", new Core(null,"test",val$));
			val$=txtF0.getText();
			entity.putElementItem("pwmvfcontrol", new Core(null,"f0",val$));
			val$=txtUa.getText();
			entity.putElementItem("pwmvfcontrol", new Core(null,"Ua",val$));
			val$=txtM.getText();
			entity.putElementItem("pwmvfcontrol", new Core(null,"M",val$));
			val$=txtW.getText();
			entity.putElementItem("pwmvfcontrol", new Core("","W",val$));
			console.getEntigrator().putEntity(entity);
		}catch(Exception e) {
			System.out.println("JPWMVFcontrolEditor:saveValues:"+e.toString());
		}
	}
}
