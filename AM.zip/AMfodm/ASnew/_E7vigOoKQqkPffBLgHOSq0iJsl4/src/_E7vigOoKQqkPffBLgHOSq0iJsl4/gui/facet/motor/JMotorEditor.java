package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.motor;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.FileTool;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;

import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Properties;

import javax.swing.border.TitledBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.JPlotPanel;

import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import java.awt.Component;

public class JMotorEditor extends JGuiEditor{
	public static final String ACTION_NEW_ENTITY="action new entity";
	public static final String ACTION_DISPLAY_ENTITY="action display entity";
	public static final String MOTOR_FACET_TYPE="motor";
	public static final String MOTOR_FACET_NAME="Motor";
	public static final String MOTOR_MASTER_CLASS="_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.JMotorMaster";
	public static final String KEY="_jDkrGwF2bbIGziylU40Az5aA0BQ";
	//private JTextField textField;
	JTextField txtPower;
	JTextField txtFreq;
	JTextField txtVoltage;
	JTextField txtSlip;
	JTextField txtEfficiency;
	JTextField txtCos;
	JTextField txtMaxTorq; 
	JTextField txtStartTorq;
	JTextField txtStartCurrent;
	JTextField txtInertia;
	JTextField txtRs;
	JTextField txtXs;
	JTextField txtRr;
	JTextField txtXr;
	JTextField txtXm;
	
	//
	JTextField txtIs;
	JTextField txtIso;
	JTextField txtMn;
	JTextField txtMmax;
	JTextField txtNnom;
	JTextField txtRsG;
	JTextField txtXsG;
	JTextField txtRrG;
	JTextField txtXrG;
	JTextField txtXmG;

	JTextField txtPole;
	JTextField txtLim;
	JTextField txtErr;
	JTextArea  txaReport;
	JButton run;
	JPanel iterator;
	PrintStream reportStream;
	protected JMenu operatorMenu;
	Sack entity;
	public JMotorEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		entity=console.getEntigrator().getEntityAtLabel(entity$);
		//System.out.println("JMotorEditor:BEGIN");
		//entity.print();
		JScrollPane scrollPane=new JScrollPane();
		add(scrollPane);
		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		JTabbedPane parametersPane = new JTabbedPane(JTabbedPane.TOP);
		//add(parametersPane);
		scrollPane.setViewportView(parametersPane);
		JPanel parameters = new JPanel();
		parametersPane.addTab("Parameters", null, parameters, null);
		parameters.setLayout(new BoxLayout(parameters, BoxLayout.Y_AXIS));
		JPanel primary = new JPanel();
		primary.setBorder(new TitledBorder(null, "Primary", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		parameters.add(primary);
		primary.setLayout(new BoxLayout(primary, BoxLayout.X_AXIS));
		JPanel reference = new JPanel();
		reference.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		reference.setAlignmentX(Component.RIGHT_ALIGNMENT);
		reference.setBorder(new TitledBorder(null, "Reference", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		primary.add(reference);
		//
		GridBagLayout gbl_reference = new GridBagLayout();
		gbl_reference.columnWidths = new int[]{0,0,1};
		gbl_reference.rowHeights = new int[]{0,0,0,0,0,0,0,0,0,0,0,1};
		gbl_reference.columnWeights = new double[]{0.0,0.0,1.0};
		gbl_reference.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0,0.0, 0.0,0.0,0.0,0.0,Double.MIN_VALUE};
		reference.setLayout(gbl_reference);

		JPanel calculated = new JPanel();
		calculated.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		calculated.setAlignmentX(Component.RIGHT_ALIGNMENT);
		calculated.setBorder(new TitledBorder(null, "Calculated", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		primary.add(calculated);
		GridBagLayout gbl_calculated = new GridBagLayout();
		gbl_calculated.columnWidths = new int[]{0,0,1};
		gbl_calculated.rowHeights = new int[]{0,0,0,0,0,0, 0,0,1};
		gbl_calculated.columnWeights = new double[]{0.0,0.0,1.0};
		gbl_calculated.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0, 0.0,Double.MIN_VALUE};
		calculated.setLayout(gbl_calculated);
		
		JPanel secondary=new JPanel();
		secondary.setBorder(new TitledBorder(null, "Secondary", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		parameters.add(secondary);
		secondary.setLayout(new BoxLayout(secondary, BoxLayout.X_AXIS));
		
		JPanel given = new JPanel();
		given.setAlignmentX(Component.LEFT_ALIGNMENT);
		given.setAlignmentY(Component.TOP_ALIGNMENT);
		given.setBorder(new TitledBorder(null, "Given", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		secondary.add(given);
		GridBagLayout gbl_given = new GridBagLayout();
		gbl_given.columnWidths = new int[]{0,0,1};
		gbl_given.rowHeights = new int[] {0,0,0,0,0,0,0,1};
		gbl_given.columnWeights = new double[]{0.0,0.0,1.0};
		gbl_given.rowWeights = new double[]{ 0.0, 0.0,0.0,0.0,0.0,0.0,Double.MIN_VALUE};
		given.setLayout(gbl_given);
		//
		JPanel estimated = new JPanel();
		estimated.setAlignmentY(Component.TOP_ALIGNMENT);
		estimated.setAlignmentX(Component.LEFT_ALIGNMENT);
		estimated.setBorder(new TitledBorder(null, "Estimated", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		secondary.add(estimated);
		GridBagLayout gbl_estimated = new GridBagLayout();
		gbl_estimated.columnWidths = new int[]{0,0,1};
		gbl_estimated.rowHeights = new int[]{0,0,0,0,0,0,0,1};
		gbl_estimated.columnWeights = new double[]{0.0,0.0,1.0};
		gbl_estimated.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0,Double.MIN_VALUE};
		estimated.setLayout(gbl_estimated);
	
	//reference	
		 
		JLabel lblPower = new JLabel("Power*");
		GridBagConstraints gbc_lblPower = new GridBagConstraints();
		gbc_lblPower.gridx=0;
		gbc_lblPower.gridy=0;
		gbc_lblPower.anchor = GridBagConstraints.LINE_START;
		gbc_lblPower.weightx = 0.1;
		reference.add(lblPower, gbc_lblPower);

		txtPower = new JTextField();
		txtPower.setText("0");
		txtPower.setColumns(10);
		txtPower.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"P",txtPower.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		GridBagConstraints gbc_txtPower = new GridBagConstraints();
		gbc_txtPower.gridx=1;
		gbc_txtPower.gridy=0;
		gbc_txtPower.anchor = GridBagConstraints.LINE_START;
		gbc_txtPower.weightx = 0.9;
		reference.add( txtPower, gbc_txtPower);
		
		JLabel lblFreq = new JLabel("Frequency*");
		GridBagConstraints gbc_lblFreq = new GridBagConstraints();
		gbc_lblFreq.gridx=0;
		gbc_lblFreq.gridy=1;
		gbc_lblFreq.anchor = GridBagConstraints.LINE_START;
		reference.add(lblFreq, gbc_lblFreq);
		
		txtFreq = new JTextField();
		txtFreq.setText("0");
		txtFreq.setColumns(10);
		txtFreq.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"f",txtFreq.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		GridBagConstraints gbc_txtFreq = new GridBagConstraints();
		gbc_txtFreq.gridx=1;
		gbc_txtFreq.gridy=1;
		gbc_txtFreq.anchor = GridBagConstraints.LINE_START;
		reference.add( txtFreq, gbc_txtFreq);
		
		
		JLabel lblVoltage = new JLabel("Voltage*");
		GridBagConstraints gbc_lblVoltage = new GridBagConstraints();
		gbc_lblVoltage.gridx = 0;
		gbc_lblVoltage.gridy = 2;
		gbc_lblVoltage.anchor = GridBagConstraints.LINE_START;
		reference.add(lblVoltage, gbc_lblVoltage);

		txtVoltage = new JTextField();
		txtVoltage.setText("0");
		txtVoltage.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"Us",txtVoltage.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtVoltage.setColumns(10);
		GridBagConstraints gbc_txtVoltage = new GridBagConstraints();
		gbc_txtVoltage.gridx = 1;
		gbc_txtVoltage.gridy = 2;
		gbc_txtVoltage.anchor = GridBagConstraints.LINE_START;
		reference.add( txtVoltage, gbc_txtVoltage);
		
		JLabel lblSlip = new JLabel("Slip*");
		GridBagConstraints gbc_lblSlip = new GridBagConstraints();
		gbc_lblSlip.gridx = 0;
		gbc_lblSlip.gridy = 3;
		gbc_lblSlip.anchor = GridBagConstraints.LINE_START;
		reference.add(lblSlip, gbc_lblSlip);

		txtSlip = new JTextField();
		txtSlip.setText("0");
		txtSlip.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"sn",txtSlip.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtSlip.setColumns(10);
		GridBagConstraints gbc_txtSlip = new GridBagConstraints();
			gbc_txtSlip.gridx = 1;
			gbc_txtSlip.gridy = 3;
			gbc_txtSlip.anchor = GridBagConstraints.LINE_START;
		reference.add( txtSlip, gbc_txtSlip);
		
		JLabel lblPole = new JLabel("Pair pole*");
		GridBagConstraints gbc_lblPole = new GridBagConstraints();
		gbc_lblPole.gridx = 0;
		gbc_lblPole.gridy = 4;
		gbc_lblPole.anchor = GridBagConstraints.LINE_START;
		reference.add(lblPole, gbc_lblPole);

		txtPole = new JTextField();
		txtPole.setText("0");
		txtPole.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"pol",txtPole.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtPole.setColumns(10);
		GridBagConstraints gbc_txtPole = new GridBagConstraints();
		gbc_txtPole.gridx = 1;
		gbc_txtPole.gridy = 4;
		gbc_txtPole.anchor = GridBagConstraints.LINE_START;
		reference.add( txtPole, gbc_txtPole);
		
		JLabel lblEfficiency = new JLabel("Efficiency");
		GridBagConstraints gbc_lblEfficiency = new GridBagConstraints();
		gbc_lblEfficiency.gridx = 0;
		gbc_lblEfficiency.gridy = 5;
		gbc_lblEfficiency.anchor = GridBagConstraints.LINE_START;
		reference.add(lblEfficiency, gbc_lblEfficiency);

		txtEfficiency = new JTextField();
		txtEfficiency.setText("0");
		txtEfficiency.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"Eta",txtEfficiency.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtEfficiency.setColumns(10);
		GridBagConstraints gbc_txtEfficiency = new GridBagConstraints();
		gbc_txtEfficiency.gridx = 1;
		gbc_txtEfficiency.gridy = 5;
		gbc_txtEfficiency.anchor = GridBagConstraints.LINE_START;
		reference.add( txtEfficiency, gbc_txtEfficiency);
		
		JLabel lblCos = new JLabel("Power factor(cos)*");
		GridBagConstraints gbc_lblCos = new GridBagConstraints();
		gbc_lblCos.gridx = 0;
		gbc_lblCos.gridy = 6;
		gbc_lblCos.anchor = GridBagConstraints.LINE_START;
		reference.add(lblCos, gbc_lblCos);

		txtCos = new JTextField();
		txtCos.setText("0");
		txtCos.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"cos",txtCos.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtCos.setColumns(10);
		GridBagConstraints gbc_txtCos = new GridBagConstraints();
			gbc_txtCos.gridx = 1;
			gbc_txtCos.gridy = 6;
			gbc_txtCos.anchor = GridBagConstraints.LINE_START;
		reference.add( txtCos, gbc_txtCos);
		
		JLabel lblMaxTorq = new JLabel("Maximum torque*(r.u.)");
		GridBagConstraints gbc_lblMaxTorq = new GridBagConstraints();
		
		gbc_lblMaxTorq.gridx = 0;
		gbc_lblMaxTorq.gridy = 7;
		gbc_lblMaxTorq.anchor = GridBagConstraints.LINE_START;
		reference.add(lblMaxTorq, gbc_lblMaxTorq);

		txtMaxTorq = new JTextField();
		txtMaxTorq.setText("0");
		txtMaxTorq.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"Mk",txtMaxTorq.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtMaxTorq.setColumns(10);
		GridBagConstraints gbc_txtMaxTorq = new GridBagConstraints();
			gbc_txtMaxTorq.gridx = 1;
			gbc_txtMaxTorq.gridy = 7;
			gbc_txtMaxTorq.anchor = GridBagConstraints.LINE_START;
		reference.add( txtMaxTorq, gbc_txtMaxTorq);
		
		JLabel lblStartTorq = new JLabel("Start torque(r.u.)");
		GridBagConstraints gbc_lblStartTorq = new GridBagConstraints();
		gbc_lblStartTorq.gridx = 0;
		gbc_lblStartTorq.gridy = 8;
		gbc_lblStartTorq.anchor = GridBagConstraints.LINE_START;
		reference.add(lblStartTorq, gbc_lblStartTorq);

		txtStartTorq = new JTextField();
		txtStartTorq.setText("0");
		txtStartTorq.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"Ms",txtStartTorq.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtStartTorq.setColumns(10);
		GridBagConstraints gbc_txtStartTorq = new GridBagConstraints();
			gbc_txtStartTorq.gridx = 1;
			gbc_txtStartTorq.gridy = 8;
			gbc_txtStartTorq.anchor = GridBagConstraints.LINE_START;
			gbc_txtStartTorq.weightx = 0.9;	
		reference.add( txtStartTorq, gbc_txtStartTorq);
		
		JLabel lblStartCurrent = new JLabel("Start current(r.u.)");
		GridBagConstraints gbc_lblStartCurrent = new GridBagConstraints();
		gbc_lblStartCurrent.gridx = 0;
		gbc_lblStartCurrent.gridy = 9;
		gbc_lblStartCurrent.anchor = GridBagConstraints.LINE_START;
		reference.add(lblStartCurrent, gbc_lblStartCurrent);

		txtStartCurrent = new JTextField();
		txtStartCurrent.setText("0");
		txtStartCurrent.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"Is",txtStartCurrent.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtStartCurrent.setColumns(10);
		GridBagConstraints gbc_txtStartCurrent = new GridBagConstraints();
			gbc_txtStartCurrent.gridx = 1;
			gbc_txtStartCurrent.gridy = 9;
			gbc_txtStartCurrent.anchor = GridBagConstraints.LINE_START;
		reference.add( txtStartCurrent, gbc_txtStartCurrent);
		
		JLabel lblInertia = new JLabel("Moment of inertia*");
		GridBagConstraints gbc_lblInertia = new GridBagConstraints();
		gbc_lblInertia.gridx = 0;
		gbc_lblInertia.gridy = 10;
		gbc_lblInertia.anchor = GridBagConstraints.LINE_START;
		gbc_lblInertia.weightx = 0.1;
		reference.add(lblInertia, gbc_lblInertia);

		txtInertia = new JTextField();
		txtInertia.setText("0");
		txtInertia.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("primary"))
						 entity.createElement("primary");
					 entity.putElementItem("primary", new Core(null,"j",txtInertia.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtInertia.setColumns(10);
		GridBagConstraints gbc_txtInertia = new GridBagConstraints();
			gbc_txtInertia.gridx = 1;
			gbc_txtInertia.gridy = 10;
			gbc_txtInertia.anchor = GridBagConstraints.LINE_START;
		reference.add( txtInertia, gbc_txtInertia);
	//calculated
 		JLabel lblIs = new JLabel("Isn(A)");
		GridBagConstraints gbc_lblIs = new GridBagConstraints();
		gbc_lblIs.insets = new Insets(0, 0, 5, 5);
		gbc_lblIs.gridx = 0;
		gbc_lblIs.gridy = 0;
		gbc_lblIs.anchor = GridBagConstraints.LINE_START;
		calculated.add(lblIs, gbc_lblIs);

		txtIs = new JTextField();
		txtIs.setEditable(false);
		txtIs.setText("0");
		txtIs.setColumns(10);
		GridBagConstraints gbc_txtIs = new GridBagConstraints();
		gbc_txtIs.insets = new Insets(0, 0, 5, 5);
			gbc_txtIs.gridx = 1;
			gbc_txtIs.gridy = 0;
			gbc_txtIs.anchor = GridBagConstraints.LINE_START;
			gbc_txtIs.weightx = 0.9;	
		calculated.add( txtIs, gbc_txtIs);
		
		
		
		JLabel lblIso = new JLabel("Iso(A)");
		GridBagConstraints gbc_lblIso = new GridBagConstraints();
		gbc_lblIso.insets = new Insets(0, 0, 5, 5);
		gbc_lblIso.gridx = 0;
		gbc_lblIso.gridy = 1;
		gbc_lblIso.anchor = GridBagConstraints.LINE_START;
		calculated.add(lblIso, gbc_lblIso);

		txtIso = new JTextField();
		txtIso.setEditable(false);
		txtIso.setText("0");
		txtIso.setColumns(10);
		GridBagConstraints gbc_txtIso = new GridBagConstraints();
		gbc_txtIso.insets = new Insets(0, 0, 5, 5);
			gbc_txtIso.gridx = 1;
			gbc_txtIso.gridy =1;
			gbc_txtIso.anchor = GridBagConstraints.LINE_START;
			gbc_txtIso.weightx = 0.9;	
		calculated.add( txtIso, gbc_txtIso);
		
		JLabel lblMn = new JLabel("Mn(Nm)");
		GridBagConstraints gbc_lblMn = new GridBagConstraints();
		gbc_lblMn.insets = new Insets(0, 0, 5, 5);
		gbc_lblMn.gridx = 0;
		gbc_lblMn.gridy = 2;
		gbc_lblMn.anchor = GridBagConstraints.LINE_START;
		calculated.add(lblMn, gbc_lblMn);

		txtMn = new JTextField();
		txtMn.setEditable(false);
		txtMn.setText("0");
		txtMn.setColumns(10);
		GridBagConstraints gbc_txtMn = new GridBagConstraints();
		gbc_txtMn.insets = new Insets(0, 0, 5, 5);
			gbc_txtMn.gridx = 1;
			gbc_txtMn.gridy = 2;
			gbc_txtMn.anchor = GridBagConstraints.LINE_START;
			gbc_txtMn.weightx = 0.9;	
		calculated.add( txtMn, gbc_txtMn);
		

		JLabel lblMmax = new JLabel("Mmax(Nm)");
		GridBagConstraints gbc_lblMmax = new GridBagConstraints();
		gbc_lblMmax.insets = new Insets(0, 0, 5, 5);
		gbc_lblMmax.gridx = 0;
		gbc_lblMmax.gridy = 3;
		gbc_lblMmax.anchor = GridBagConstraints.LINE_START;
		calculated.add(lblMmax, gbc_lblMmax);
		
		txtMmax = new JTextField();
		txtMmax.setEditable(false);
		txtMmax.setText("0");
		txtMmax.setColumns(10);
		GridBagConstraints gbc_txtMmax = new GridBagConstraints();
		gbc_txtMmax.insets = new Insets(0, 0, 5, 5);
		gbc_txtMmax.gridx = 1;
		gbc_txtMmax.gridy = 3;
		gbc_txtMmax.anchor = GridBagConstraints.LINE_START;
		calculated.add( txtMmax, gbc_txtMmax);
		
		JLabel lblNnom = new JLabel("Nnom(rpm)");
		GridBagConstraints gbc_lblNnom = new GridBagConstraints();
		gbc_lblNnom.insets = new Insets(0, 0, 5, 5);
		gbc_lblNnom.gridx = 0;
		gbc_lblNnom.gridy = 4;
		gbc_lblNnom.anchor = GridBagConstraints.LINE_START;
		calculated.add(lblNnom, gbc_lblNnom);

		txtNnom = new JTextField();
		txtNnom.setEditable(false);
		txtNnom.setText("0");
		txtNnom.setColumns(10);
		GridBagConstraints gbc_txtNnom = new GridBagConstraints();
		gbc_txtNnom.insets = new Insets(0, 0, 5, 5);
			gbc_txtNnom.gridx = 1;
			gbc_txtNnom.gridy = 4;
			gbc_txtNnom.anchor = GridBagConstraints.LINE_START;
		calculated.add( txtNnom, gbc_txtNnom);
		
		JButton btnCalculatedVuild = new JButton("Build");
		btnCalculatedVuild.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			   buildCalculated();
			}
		});
		GridBagConstraints gbc_btnCalculatedBuild = new GridBagConstraints();
		gbc_btnCalculatedBuild.insets = new Insets(5, 5, 5, 5);
		gbc_btnCalculatedBuild.gridx = 1;
		gbc_btnCalculatedBuild.gridy = 5;
		gbc_btnCalculatedBuild.anchor=GridBagConstraints.LINE_START;
		calculated.add(btnCalculatedVuild, gbc_btnCalculatedBuild);
		
				
	//given
		
 		JLabel lblRsG = new JLabel("Rs");
		GridBagConstraints gbc_lblRsG = new GridBagConstraints();
		gbc_lblRsG.insets = new Insets(0, 0, 5, 5);
		gbc_lblRsG.gridx = 0;
		gbc_lblRsG.gridy = 0;
		gbc_lblRsG.anchor = GridBagConstraints.LINE_START;
		given.add(lblRsG, gbc_lblRsG);

		txtRsG = new JTextField();
		txtRsG.setEditable(true);
		txtRsG.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("zgvn"))
						 entity.createElement("zgvn");
					 entity.putElementItem("zgvn", new Core(null,"rs",txtRsG.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtRsG.setColumns(10);
		GridBagConstraints gbc_txtRsG = new GridBagConstraints();
		gbc_txtRsG.insets = new Insets(0, 0, 5, 0);
			gbc_txtRsG.gridx = 1;
			gbc_txtRsG.gridy = 0;
			gbc_txtRsG.anchor = GridBagConstraints.LINE_START;
		given.add( txtRsG, gbc_txtRsG);
		
		JLabel lblXsG = new JLabel("Xs");
		GridBagConstraints gbc_lblXsG = new GridBagConstraints();
		gbc_lblXsG.insets = new Insets(0, 0, 5, 5);
		gbc_lblXsG.gridx = 0;
		gbc_lblXsG.gridy = 1;
		gbc_lblXsG.anchor = GridBagConstraints.LINE_START;
		given.add(lblXsG, gbc_lblXsG);

		txtXsG = new JTextField();
		txtXsG.setEditable(true);
		txtXsG.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("zgvn"))
						 entity.createElement("zgvn");
					 entity.putElementItem("zgvn", new Core(null,"xs",txtXsG.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtXsG.setColumns(10);
		GridBagConstraints gbc_txtXsG = new GridBagConstraints();
		gbc_txtXsG.insets = new Insets(0, 0, 5, 0);
			gbc_txtXsG.gridx = 1;
			gbc_txtXsG.gridy = 1;
			gbc_txtXsG.anchor = GridBagConstraints.LINE_START;
		//	gbc_txtXsG.weightx = 0.9;	
		given.add( txtXsG, gbc_txtXsG);
		
		JLabel lblRrG = new JLabel("Rr");
		GridBagConstraints gbc_lblRrG = new GridBagConstraints();
		gbc_lblRrG.insets = new Insets(0, 0, 5, 5);
		gbc_lblRrG.gridx = 0;
		gbc_lblRrG.gridy = 2;
		gbc_lblRrG.anchor = GridBagConstraints.LINE_START;
		//gbc_lblRrG.weightx = 0.1;
		given.add(lblRrG, gbc_lblRrG);

		txtRrG = new JTextField();
		txtRrG.setEditable(true);
		txtRrG.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("zgvn"))
						 entity.createElement("zgvn");
					 entity.putElementItem("zgvn", new Core(null,"r2",txtRrG.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		txtRrG.setColumns(10);
		GridBagConstraints gbc_txtRrG = new GridBagConstraints();
		gbc_txtRrG.insets = new Insets(0, 0, 5, 0);
			gbc_txtRrG.gridx = 1;
			gbc_txtRrG.gridy = 2;
			gbc_txtRrG.anchor = GridBagConstraints.LINE_START;
		given.add( txtRrG, gbc_txtRrG);
		
		JLabel lblXrG = new JLabel("Xr");
		GridBagConstraints gbc_lblXrG = new GridBagConstraints();
		gbc_lblXrG.insets = new Insets(0, 0, 5, 5);
		gbc_lblXrG.gridx = 0;
		gbc_lblXrG.gridy = 3;
		gbc_lblXrG.anchor = GridBagConstraints.LINE_START;
		given.add(lblXrG, gbc_lblXrG);

		txtXrG = new JTextField();
		txtXrG.setEditable(true);
		txtXrG.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("zgvn"))
						 entity.createElement("zgvn");
					 entity.putElementItem("zgvn", new Core(null,"x2",txtXrG.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });
		//txtXrG.setText("0");
		txtXrG.setColumns(10);
		GridBagConstraints gbc_txtXrG = new GridBagConstraints();
		gbc_txtXrG.insets = new Insets(0, 0, 5, 0);
			gbc_txtXrG.gridx = 1;
			gbc_txtXrG.gridy = 3;
			gbc_txtXrG.anchor = GridBagConstraints.LINE_START;
		given.add( txtXrG, gbc_txtXrG);
		
		JLabel lblXmG = new JLabel("Xm");
		GridBagConstraints gbc_lblXmG = new GridBagConstraints();
		gbc_lblXmG.insets = new Insets(0, 0, 5, 5);
		gbc_lblXmG.gridx = 0;
		gbc_lblXmG.gridy = 4;
		gbc_lblXmG.anchor = GridBagConstraints.LINE_START;
		given.add(lblXmG, gbc_lblXmG);

		txtXmG = new JTextField();
		txtXmG.setEditable(true);
		txtXmG.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("zgvn"))
						 entity.createElement("zgvn");
					 entity.putElementItem("zgvn", new Core(null,"xm",txtXmG.getText()));
					 console.getEntigrator().putEntity(entity);
				 }
			}
	      });

		txtXmG.setColumns(10);
		GridBagConstraints gbc_txtXmG = new GridBagConstraints();
		gbc_txtXmG.insets = new Insets(0, 0, 5, 0);
			gbc_txtXmG.gridx = 1;
			gbc_txtXmG.gridy = 4;
			gbc_txtXmG.anchor = GridBagConstraints.LINE_START;
		given.add( txtXmG, gbc_txtXmG);
	
		JButton btnViewGiven = new JButton("View");
		btnViewGiven.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String record$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/given.data";
				entity=MotorHandler.z_graph(entity, record$,true);
				view("given");
			}
		});
		btnViewGiven.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_btnViewGiven = new GridBagConstraints();
		gbc_btnViewGiven.insets = new Insets(0, 0, 0, 5);
		gbc_btnViewGiven.gridx = 1;
		gbc_btnViewGiven.gridy = 5;
		gbc_btnViewGiven.anchor=GridBagConstraints.LINE_START;
		given.add(btnViewGiven, gbc_btnViewGiven);
		
		JButton btnSetGiven = new JButton("Set");
		btnSetGiven.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				entity=MotorHandler.par_gvn2e(entity);
				//entity.printElement("epar");
				console.getEntigrator().putEntity(entity);
			}
		});
		btnSetGiven.setHorizontalAlignment(SwingConstants.RIGHT);
		GridBagConstraints gbc_btnSetGiven = new GridBagConstraints();
		gbc_btnSetGiven.insets = new Insets(0, 0, 0, 5);
		gbc_btnSetGiven.gridx = 0;
		gbc_btnSetGiven.gridy = 5;
		gbc_btnSetGiven.anchor=GridBagConstraints.LINE_END;
		given.add(btnSetGiven, gbc_btnSetGiven);
/*
		JPanel placebo=new JPanel();
		GridBagConstraints gbc_placebo = new GridBagConstraints();
		gbc_placebo.gridx = 1;
		gbc_placebo.gridy = 6;
		
		given.add(placebo, gbc_placebo);
*/
		//estimated
 		JLabel lblRs = new JLabel("Rs");
		GridBagConstraints gbc_lblRs = new GridBagConstraints();
		gbc_lblRs.insets = new Insets(0, 0, 5, 5);
		gbc_lblRs.gridx = 0;
		gbc_lblRs.gridy = 0;
		gbc_lblRs.anchor = GridBagConstraints.LINE_START;
		estimated.add(lblRs, gbc_lblRs);

		txtRs = new JTextField();
		txtRs.setEditable(false);
		txtRs.setText("0");
		txtRs.setColumns(10);
		GridBagConstraints gbc_txtRs = new GridBagConstraints();
		gbc_txtRs.insets = new Insets(0, 0, 5, 0);
			gbc_txtRs.gridx = 1;
			gbc_txtRs.gridy = 0;
			gbc_txtRs.anchor = GridBagConstraints.LINE_START;
			gbc_txtRs.weightx = 0.9;	
		estimated.add( txtRs, gbc_txtRs);
		
		JLabel lblXs = new JLabel("Xs");
		GridBagConstraints gbc_lblXs = new GridBagConstraints();
		gbc_lblXs.insets = new Insets(0, 0, 5, 5);
		gbc_lblXs.gridx = 0;
		gbc_lblXs.gridy = 1;
		gbc_lblXs.anchor = GridBagConstraints.LINE_START;
		estimated.add(lblXs, gbc_lblXs);

		txtXs = new JTextField();
		txtXs.setEditable(false);
		txtXs.setText("0");
		txtXs.setColumns(10);
		GridBagConstraints gbc_txtXs = new GridBagConstraints();
		gbc_txtXs.insets = new Insets(0, 0, 5, 0);
			gbc_txtXs.gridx = 1;
			gbc_txtXs.gridy = 1;
			gbc_txtXs.anchor = GridBagConstraints.LINE_START;
			gbc_txtXs.weightx = 0.9;	
		estimated.add( txtXs, gbc_txtXs);
		
		JLabel lblRr = new JLabel("Rr");
		GridBagConstraints gbc_lblRr = new GridBagConstraints();
		gbc_lblRr.insets = new Insets(0, 0, 5, 5);
		gbc_lblRr.gridx = 0;
		gbc_lblRr.gridy = 2;
		gbc_lblRr.anchor = GridBagConstraints.LINE_START;
		estimated.add(lblRr, gbc_lblRr);

		txtRr = new JTextField();
		txtRr.setEditable(false);
		txtRr.setText("0");
		txtRr.setColumns(10);
		GridBagConstraints gbc_txtRr = new GridBagConstraints();
		gbc_txtRr.insets = new Insets(0, 0, 5, 0);
			gbc_txtRr.gridx = 1;
			gbc_txtRr.gridy = 2;
			gbc_txtRr.anchor = GridBagConstraints.LINE_START;
			gbc_txtRr.weightx = 0.9;	
		estimated.add( txtRr, gbc_txtRr);
		
		JLabel lblXr = new JLabel("Xr");
		GridBagConstraints gbc_lblXr = new GridBagConstraints();
		gbc_lblXr.insets = new Insets(0, 0, 5, 5);
		gbc_lblXr.gridx = 0;
		gbc_lblXr.gridy = 3;
		gbc_lblXr.anchor = GridBagConstraints.LINE_START;
		estimated.add(lblXr, gbc_lblXr);

		txtXr = new JTextField();
		txtXr.setEditable(false);
		txtXr.setText("0");
		txtXr.setColumns(10);
		GridBagConstraints gbc_txtXr = new GridBagConstraints();
		gbc_txtXr.insets = new Insets(0, 0, 5, 0);
			gbc_txtXr.gridx = 1;
			gbc_txtXr.gridy = 3;
			gbc_txtXr.anchor = GridBagConstraints.LINE_START;
			gbc_txtXr.weightx = 0.9;	
		estimated.add( txtXr, gbc_txtXr);
		
		JLabel lblXm = new JLabel("Xm");
		GridBagConstraints gbc_lblXm = new GridBagConstraints();
		gbc_lblXm.insets = new Insets(0, 0, 5, 5);
		gbc_lblXm.gridx = 0;
		gbc_lblXm.gridy = 4;
		gbc_lblXm.anchor = GridBagConstraints.LINE_START;
		estimated.add(lblXm, gbc_lblXm);

		txtXm = new JTextField();
		txtXm.setEditable(false);
		txtXm.setText("0");
		txtXm.setColumns(10);
		GridBagConstraints gbc_txtXm = new GridBagConstraints();
		gbc_txtXm.insets = new Insets(0, 0, 5, 0);
			gbc_txtXm.gridx = 1;
			gbc_txtXm.gridy = 4;
			gbc_txtXm.anchor = GridBagConstraints.LINE_START;
		estimated.add( txtXm, gbc_txtXm);
		JButton btnViewEstimated = new JButton("View");
		btnViewEstimated.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String record$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/estimated.data";
				entity=MotorHandler.z_graph(entity, record$,false);
				view("estimated");
			}
		});
		GridBagConstraints gbc_btnViewEstimated = new GridBagConstraints();
		gbc_btnViewEstimated.insets = new Insets(0, 0, 0, 5);
		gbc_btnViewEstimated.gridx = 1;
		gbc_btnViewEstimated.gridy = 5;
		gbc_btnViewEstimated.anchor=GridBagConstraints.LINE_START;
		estimated.add(btnViewEstimated, gbc_btnViewEstimated);
	
		JButton btnSetEstimated = new JButton("Set");
		btnSetEstimated.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				entity=MotorHandler.par_z2e(entity);
				entity.printElement("epar");
				console.getEntigrator().putEntity(entity);
			}
		});
		btnSetEstimated.setHorizontalAlignment(SwingConstants.RIGHT);
		GridBagConstraints gbc_btnSetEstimated = new GridBagConstraints();
		gbc_btnSetEstimated.insets = new Insets(0, 0, 0, 5);
		gbc_btnSetEstimated.gridx = 0;
		gbc_btnSetEstimated.gridy = 5;
		gbc_btnSetEstimated.anchor=GridBagConstraints.LINE_END;
		estimated.add(btnSetEstimated, gbc_btnSetEstimated);
		///iterator
		iterator= new JPanel();
		parametersPane.addTab("Iterator", null, iterator, null);
		GridBagLayout gbl_iterator = new GridBagLayout();
		gbl_iterator.columnWidths = new int[] {30,100};
		gbl_iterator.columnWeights = new double[]{0.0,  Double.MIN_VALUE};
		iterator.setLayout(gbl_iterator);
	
		 
		JLabel lblLimit = new JLabel("Max cycles");
		GridBagConstraints gbc_lblLimit = new GridBagConstraints();
		gbc_lblLimit.gridx=0;
		gbc_lblLimit.gridy=0;
		gbc_lblLimit.anchor = GridBagConstraints.LINE_START;
		iterator.add(lblLimit, gbc_lblLimit);

		txtLim = new JTextField();
		txtLim.setText("100");
		txtLim.setColumns(10);
		
		GridBagConstraints gbc_txtLim = new GridBagConstraints();
		gbc_txtLim.gridx=1;
		gbc_txtLim.gridy=0;
		gbc_txtLim.anchor = GridBagConstraints.LINE_START;
		iterator.add( txtLim, gbc_txtLim);
		
		JLabel lblErr = new JLabel("Error ");
		GridBagConstraints gbc_lblErr = new GridBagConstraints();
		gbc_lblErr.gridx=0;
		gbc_lblErr.gridy=1;
		gbc_lblErr.anchor = GridBagConstraints.LINE_START;
		iterator.add(lblErr, gbc_lblErr);

		txtErr = new JTextField();
		txtErr.setText("1E-6");
		txtErr.setColumns(10);
		
		GridBagConstraints gbc_txtErr = new GridBagConstraints();
		gbc_txtErr.gridx=1;
		gbc_txtErr.gridy=1;
		gbc_txtErr.anchor = GridBagConstraints.LINE_START;
		iterator.add( txtErr, gbc_txtErr);
		
		run=new JButton("Run");
		GridBagConstraints gbc_btnRun = new GridBagConstraints();
		gbc_btnRun.insets = new Insets(5, 0, 0, 0);
		gbc_btnRun.gridx=1;
		gbc_btnRun.gridy=2;
		gbc_btnRun.anchor = GridBagConstraints.LINE_START;
		iterator.add(run, gbc_btnRun);
	    run.addActionListener( new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("JMotorEditor:run:locator="+getLocator());
			txaReport.setText(null);
			repaint();
			revalidate();
			String motor$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
			try {
			Thread t=new Thread(progress);
			t.start();
			console.getEntigrator().putEntity(motor);
			}catch(Exception ee) {
				System.out.println("JMotorEditor:run:"+ee.toString());
			}
		}
	    });
		
		txaReport=new JTextArea();
		GridBagConstraints gbc_txaReport = new GridBagConstraints();
		gbc_txaReport.insets = new Insets(10, 0, 2, 0);
		gbc_txaReport.gridx=0;
		gbc_txaReport.gridy=3;
		gbc_txaReport.gridwidth=2;
		gbc_txaReport.anchor = GridBagConstraints.LINE_START;
		gbc_txaReport.fill=GridBagConstraints.BOTH;
		gbc_txaReport.weightx = 1;
		gbc_txaReport.weighty = 1;
		iterator.add(txaReport, gbc_txaReport);
	
	    init();
		//
	//	console.setSubtitle(Locator.getProperty(locator$, Entigrator.ENTITY_LABEL));
		
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,MOTOR_FACET_NAME);
		locator.put(FacetHandler.FACET_TYPE,MOTOR_FACET_TYPE);
		locator.put(DEFAULT_PARENT, JEntityFacetList.KEY);
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.JMotorMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(JContext.CONTEXT_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.motor.JMotorEditor");
		return Locator.toString(locator);
	}
	//
	Runnable progress=new Runnable() {
		public void run() {
			try {
				reportStream = new PrintStream(new txaStream(txaReport));
				run.setEnabled(false);
				//String motor$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
				//Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
				entity.putAttribute(new Core("runtime",Sack.RESIDENT,Locator.LOCATOR_TRUE));
				if(!entity.existsElement("hj"))
					entity.createElement("hj");
				if(txtErr.getText()!=null)
				   entity.putElementItem("hj",new Core(null,"err",txtErr.getText()));
				if(txtLim.getText()!=null)
					entity.putElementItem("hj",new Core(null,"lim",txtLim.getText()));
				entity=MotorHandler.try_hj(entity,reportStream,false);
				console.getEntigrator().putEntity(entity);
				run.setEnabled(true);
				reportStream.close();
				String record$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/estimated.data";
				entity=MotorHandler.z_graph(entity, record$,false);
				String value$=entity.getElementItemAt("zpar", "rs");
				if(value$!=null)
					txtRs.setText(displayDouble(value$));
				else
					txtRs.setText("");
				value$=entity.getElementItemAt("zpar", "xs");
				if(value$!=null)
					txtXs.setText(displayDouble(value$));
				else
					txtXs.setText("");
				value$=entity.getElementItemAt("zpar", "r2");
				if(value$!=null)
					txtRr.setText(displayDouble(value$));
				else
					txtRr.setText("");
				value$=entity.getElementItemAt("zpar", "x2");
				if(value$!=null)
					txtXr.setText(displayDouble(value$));
				else
					txtXr.setText("");
				value$=entity.getElementItemAt("zpar", "xm");
				if(value$!=null)
					txtXm.setText(displayDouble(value$));
				else
					txtXm.setText("");
				entity.removeAttribute(Sack.RESIDENT);
				console.getEntigrator().putEntity(entity);
			}catch(Exception e) {
				System.out.println("JMotorEditor:progress:"+e.toString());
			}
		}
	};
	private String displayDouble(String value$) {
		try {
			NumberFormat numFormat = new DecimalFormat("0.#####E0");
			double value=Double.parseDouble(value$);
			return numFormat.format(value); 
		}catch(Exception e) {
			System.out.println("JMotorEditor:displayNumber="+value$+"   error="+e.toString());
			return null;
		}
	}
	private void init() {
		//System.out.println("JMotorEditor:init:locator="+getLocator());
		//entity.print();
		try {
		//Entigrator entigrator=console.getEntigrator();
		//String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		//entity=entigrator.getEntityAtLabel(entity$);
		String value$=null;
		value$=entity.getElementItemAt("primary", "P");
		
		if(value$!=null)
			txtPower.setText(value$);
		else
			txtPower.setText("");
		value$=entity.getElementItemAt("primary", "f");
		if(value$!=null)
			txtFreq.setText(value$);
		else
			txtFreq.setText("");
		value$=entity.getElementItemAt("primary", "Us");
		if(value$!=null)
			txtVoltage.setText(value$);
		else
			txtVoltage.setText("");
		value$=entity.getElementItemAt("primary", "sn");
		if(value$!=null)
			txtSlip.setText(value$);
		else
			txtSlip.setText("");
		
		value$=entity.getElementItemAt("primary", "Eta");
		if(value$!=null)
			txtEfficiency.setText(value$);
		else
			txtEfficiency.setText("");

		value$=entity.getElementItemAt("primary", "cos");
		if(value$!=null)
			txtCos.setText(value$);
		else
			txtCos.setText("");
		
		value$=entity.getElementItemAt("primary", "Mk");
		if(value$!=null)
			txtMaxTorq.setText(value$);
		else
			txtMaxTorq.setText("");
		value$=entity.getElementItemAt("primary", "pol");
		if(value$!=null)
			txtPole.setText(value$);
		else
			txtPole.setText("");
		
		value$=entity.getElementItemAt("primary", "Ms");
		if(value$!=null)
			txtStartTorq.setText(value$);
		else
			txtStartTorq.setText("");
		
		value$=entity.getElementItemAt("primary", "Is");
		if(value$!=null)
			txtStartCurrent.setText(value$);
		else
			txtStartCurrent.setText("");
		value$=entity.getElementItemAt("primary", "j");
		if(value$!=null)
			txtInertia.setText(value$);
		else
			txtInertia.setText("");
		
		//estimated
		//NumberFormat numFormat = new DecimalFormat("0.####E0");
		value$=entity.getElementItemAt("zpar", "rs");
		
		if(value$!=null)
			txtRs.setText(displayDouble(value$));
		else
			txtRs.setText("");
		
		value$=entity.getElementItemAt("zpar", "xs");
		if(value$!=null)
			txtXs.setText(displayDouble(value$));
		else
			txtXs.setText("");
		
		value$=entity.getElementItemAt("zpar", "r2");
		if(value$!=null)
			txtRr.setText(displayDouble(value$));
		else
			txtRr.setText("");
		
		value$=entity.getElementItemAt("zpar", "x2");
		if(value$!=null)
			txtXr.setText(displayDouble(value$));
		else
			txtXr.setText("");
		
		value$=entity.getElementItemAt("zpar", "xm");
		if(value$!=null)
			txtXm.setText(displayDouble(value$));
		else
			txtXm.setText("");
		//
     value$=entity.getElementItemAt("zgvn", "rs");
     //System.out.println("JMotorEditor:init:given:rs="+value$);	
		if(value$!=null)
			txtRsG.setText(displayDouble(value$));
		//else
		//	txtRsG.setText("");
		
		value$=entity.getElementItemAt("zgvn", "xs");
		if(value$!=null)
			txtXsG.setText(displayDouble(value$));
		//else
		//	txtXsG.setText("");
		
		value$=entity.getElementItemAt("zgvn", "r2");
		if(value$!=null)
			txtRrG.setText(displayDouble(value$));
		//else
		//	txtRrG.setText("");
		
		value$=entity.getElementItemAt("zgvn", "x2");
		if(value$!=null)
			txtXrG.setText(displayDouble(value$));
		//else
		//	txtXrG.setText("");
		
		value$=entity.getElementItemAt("zgvn", "xm");
		if(value$!=null)
			txtXmG.setText(displayDouble(value$));
		//else
		//	txtXmG.setText("");
		
		
		//
		
		
		value$=entity.getElementItemAt("hj", "lim");
		if(value$!=null&&txtLim!=null)
			txtLim.setText(value$);
		//else
		//	txtLim.setText("10");
		value$=entity.getElementItemAt("hj", "err");
		if(value$!=null&&txtErr!=null)
			txtErr.setText(displayDouble(value$));
		//else
		//	txtErr.setText("1E-4");
		buildCalculated();
		}catch(Exception e) {
			System.out.println("JMotorEditor:init:"+e.toString());
		}
	}
	class txaStream extends OutputStream {
	    private JTextArea textArea;
	    public txaStream(JTextArea textArea) {
	        this.textArea = textArea;
	    }
	    @Override
	    public void write(int b) throws IOException {
	        // redirects data to the text area
	        textArea.append(String.valueOf((char)b));
	        // scrolls the text area to the end of data
	        textArea.setCaretPosition(textArea.getDocument().getLength());
	    }
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override 
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		operatorMenu=new JMenu("Characteristic");
		menu.addSeparator();
		menu.add(operatorMenu);
		JMenuItem estimatedItem = new JMenuItem("Estimated");
		estimatedItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			calculateEstimated();
			}
		});
		operatorMenu.add(estimatedItem);	
		JMenuItem givenItem = new JMenuItem("Given");
		givenItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				buildGiven();
			}
		});
		operatorMenu.add(givenItem);	
		/*
		operatorMenu.add(resetItem);	
		JMenuItem reinitItem = new JMenuItem("Reinit");
		reinitItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			 //	OperatorHandler.insReinit(console.getEntigrator(), locator$);
			}
		});
		operatorMenu.add(reinitItem);	
		JMenuItem rewriteItem = new JMenuItem("Rewrite");
		rewriteItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int response = JOptionPane.showConfirmDialog(JMotorEditor.this, "Rewrite java code to default  ?", "Confirm",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	  		   // if (response == JOptionPane.YES_OPTION) 
	  		    	//OperatorHandler.rewrite(console.getEntigrator(), locator$);
			}
		});
		operatorMenu.add(rewriteItem);	
		*/
		return menu;
	}
	private void calculateEstimated() {
		try {
			Sack plot=getPlot("estimated");
			String record$=console.getEntigrator().getEntihome()+"/"+plot.getKey()+"/estimated.data";
			MotorHandler.z_graph(entity, record$,false);
		}catch(Exception e) {
			System.out.println("JMotorEditor:calculateEstimated:"+e.toString());
		}
	}
	private void buildGiven() {
		try {
			
			String record$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/given.data";
			MotorHandler.z_graph(entity, record$,true);
		}catch(Exception e) {
			System.out.println("JMotorEditor:buildGiven:"+e.toString());
		}
	}
	private void buildCalculated() {
		try {
			entity=MotorHandler.par_n2d(entity);
			txtIs.setText(displayDouble(entity.getElementItemAt("dpar", "Isn")));
			txtIso.setText(displayDouble(entity.getElementItemAt("dpar", "Iso"))); 
			txtMn.setText(displayDouble(entity.getElementItemAt("dpar", "Mn")));
			txtMmax.setText(displayDouble(entity.getElementItemAt("dpar", "Mmax")));
			txtNnom.setText(displayDouble(entity.getElementItemAt("dpar", "Nn")));
		}catch(Exception e) {
			System.out.println("JMotorEditor:buildCalculated:"+e.toString());
		}
	}
	private void view(String plotType$) {
		try {
			
			Sack plot=getPlot(plotType$);
			File in=new File(console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/"+plotType$+".data");
		    File out=new File(console.getEntigrator().getEntihome()+"/"+plot.getKey()+"/"+plotType$+".data");
		    if(!out.exists())
		    	out.createNewFile();
		    FileTool.copyFile(in, out);
		    String plotLocator$=JPlotPanel.classLocator();
		    plotLocator$=Locator.append(plotLocator$, Entigrator.ENTITY_LABEL, plot.getProperty("label"));
		    plotLocator$=Locator.append(plotLocator$, PARENT, getInstance());
		    SessionHandler.putLocator(console.getEntigrator(), getLocator());
		    JPlotPanel plotPanel=new JPlotPanel(console,plotLocator$);
		 //   System.out.println("JMotorEditor:view:plot locator="+plotLocator$);
		    console.replaceContext(this, plotPanel);
		}catch(Exception e) {
			System.out.println("JMotorEditor:view:"+e.toString());
		}
	}
	private Sack getPlot(String plotType$) {
		System.out.println("JMotorEditor:getPlot:plot type="+plotType$);
		if(plotType$==null)
			return null;
		try {
			Core[] ca=entity.elementGet("link");
			if(ca!=null) {
				for(Core c:ca) {
				  if(plotType$.equals(c.type)) {
					  Sack plot=console.getEntigrator().getEntity(c.name);
					  if(plot!=null)
						  return plot;
				  }
				}
			}
		
			String plotLabel$=entity.getProperty("label")+"Plot("+plotType$+")";
			//System.out.println("JSisoEditor:createPlot:plot label="+plotLabel$+" entity key="+entity.getKey());
			Properties plotLocator=new Properties();
			plotLocator.put( ModuleHandler.FACET_MODULE, "_TZ34ntGtza4ryheSV3Xo_JOLOIU");
			plotLocator.put( FacetMaster.MASTER_CLASS, "_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster");
			String plotLocator$=Locator.toString(plotLocator);
			PlotMaster plotMaster=(PlotMaster)FacetMaster.build(console, plotLocator$);
			Sack plot= plotMaster.createEntity(console.getEntigrator(), plotLabel$);
			console.getEntigrator().putEntity(plot);
			plot=console.getEntigrator().assignProperty("plot type", plotType$, plot.getKey());
			console.getEntigrator().link(entity, plot,plotType$);
			plot.createElement("Quadrant");
			plot.putElementItem("Quadrant", new Core("50","Vertical","0.8"));
			plot.putElementItem("Quadrant", new Core("50","Horizontal","0.8"));
			plot.createElement("Surface");
			plot.putElementItem("Surface", new Core(null,"Horizontal",null));
			plot.putElementItem("Surface", new Core("0","Vertical","0.8"));
			plot.putElementItem("Surface", new Core("0","Horizontal","0.8"));
			plot.createElement("canvas");
		    plot.putElementItem("canvas", new Core(null,"area","Quadrant"));
			plot.putElementItem("canvas", new Core(null	,"backcolor","white"));
			plot.putElementItem("canvas", new Core(null	,"font.color","blue"));
			plot.putElementItem("canvas", new Core(null,"font.size","12"));
			plot.putElementItem("canvas", new Core(null,"font.style","bold"));
			plot.putElementItem("canvas", new Core(null,"frontcolor","black"));
			plot.putElementItem("canvas", new Core(null,"pointer.size","6"));
			plot.putElementItem("canvas", new Core(null,"shift","20"));
			plot.putElementItem("canvas", new Core(null,"stroke","2"));
			plot.createElement("scale.layout");
			plot.putElementItem("scale.layout", new Core("Vertical","Y","0"));
        	plot.putElementItem("scale.layout", new Core("Horizontal","X","0"));
			plot.createElement("scale.mark");
		/*
			plot.putElementItem("scale.mark", new Core("(1/s)","frequency","2"));
			plot.putElementItem("scale.mark", new Core("","gain","2"));
			plot.createElement("scale.max");
			if(plotType==0||plotType==1) {
				int fmax=(int)(100*Math.log10(tmax/tmin));
				plot.putElementItem("scale.max", new Core("##.##","frequency",String.valueOf(fmax)));
			}
			if(plotType==2) {
				plot.putElementItem("scale.max", new Core("##.##","Im","2"));
				plot.putElementItem("scale.max", new Core("##.##","Re","2"));
			}
			if(plotType==3||plotType==4) {
				plot.putElementItem("scale.max", new Core("##.##","time",String.valueOf(tmax)));
				plot.putElementItem("scale.max", new Core("##.##","response","2"));
			}
			plot.createElement("scale.raster");
			if(plotType==0||plotType==1) {
			plot.putElementItem("scale.raster", new Core("logarithmic","frequency","10"));
			plot.putElementItem("scale.raster", new Core("logarithmic","gain","10"));
			}
			if(plotType==2) {
				plot.putElementItem("scale.raster", new Core("linear","Re","1"));
				plot.putElementItem("scale.raster", new Core("linear","Im","1"));
				}
			if(plotType==3||plotType==4) {
				plot.putElementItem("scale.raster", new Core("linear","time",String.valueOf(tmark)));
				plot.putElementItem("scale.raster", new Core("linear","response","0.5"));
				}
				*/
			String rayKey$=Identity.key();
			plot.createElement("ray.color");
			plot.putElementItem("ray.color", new Core(null,rayKey$,"red"));
			plot.createElement("ray.index");
			plot.putElementItem("ray.index", new Core(null,rayKey$,"0"));
			plot.createElement("ray.name");
			plot.putElementItem("ray.name", new Core(null,rayKey$,"y"));
			plot.createElement("ray.scale");
			plot.createElement("ray.shift");
			plot.putElementItem("ray.shift", new Core(null,rayKey$,"0"));
			plot.createElement("ray.symbol");
			plot.putElementItem("ray.symbol", new Core(null,rayKey$,""));
			plot.createElement("ray.visible");
			plot.putElementItem("ray.visible", new Core("2",rayKey$,"true"));
			console.getEntigrator().putEntity(plot);
			//plot.print();
			return plot;
		}catch(Exception e) {
			System.out.println("JMotorEditor:createPlot:"+e.toString());
		}
		return null;
	}

	@Override
	public String reply(JMainConsole console, String locator$) {
		return locator$;
	}
}
