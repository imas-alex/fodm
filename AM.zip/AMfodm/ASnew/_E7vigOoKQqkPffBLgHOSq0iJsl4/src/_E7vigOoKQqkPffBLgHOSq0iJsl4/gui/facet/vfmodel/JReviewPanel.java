package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.vfmodel;



import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import javax.swing.JDialog;

import java.awt.BorderLayout;
import javax.swing.JScrollPane;


public class JReviewPanel extends JDialog{
	private static final long serialVersionUID = 1L;
	private JTable table;
	public JReviewPanel(JMainConsole console,String locator$) {
	super();
	System.out.println("JNominalPanel:"+locator$);
	try {
	String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	setTitle(entity$);
	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
	String motor$=entity.getElementItemAt("vector", "motor");
	Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
	setLayout(new BorderLayout(0, 0));
		JScrollPane scrollPane = new JScrollPane();
		add(scrollPane, BorderLayout.CENTER);
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null,null, null, null},
				{null, null, null,null, null, null},
				{null, null, null,null, null, null},
				{null, null, null,null, null, null},
				{null, null, null,null, null, null},
			
			},
			new String[] {
				"Variable", "Nominal", "Static(given)", "Static(estimated)", "Vector(given)", "Vector(estimated)"
			}
		));
		scrollPane.setViewportView(table);
		getContentPane().add(scrollPane);
		table.getModel().setValueAt("M", 0, 0);
		table.getModel().setValueAt("Mmax", 1, 0);
		table.getModel().setValueAt("Is",2,0);
		table.getModel().setValueAt("Cos",3,0);
		table.getModel().setValueAt("Eta", 4,0);
		
		
		table.getModel().setValueAt(motor.getElementItemAt("dpar", "Mn"), 0, 1);
		table.getModel().setValueAt(motor.getElementItemAt("dpar", "Mmax"),1,1);
		table.getModel().setValueAt(motor.getElementItemAt("dpar", "Isn"),2,1);
		table.getModel().setValueAt(motor.getElementItemAt("primary", "cos"),3,1);
		table.getModel().setValueAt(motor.getElementItemAt("primary", "Eta"),4,1);
		
		table.getModel().setValueAt(entity.getElementItemAt("test.static.given", "m"), 0, 2);
		table.getModel().setValueAt(entity.getElementItemAt("test.static.given", "mmaxm"),1,2);
		table.getModel().setValueAt(entity.getElementItemAt("test.static.given", "isd"),2,2);
		table.getModel().setValueAt(entity.getElementItemAt("test.static.given", "cos"),3,2);
		table.getModel().setValueAt(entity.getElementItemAt("test.static.given", "eta"),4,2);
		
		table.getModel().setValueAt(entity.getElementItemAt("test.static.estimated", "m"), 0, 3);
		table.getModel().setValueAt(entity.getElementItemAt("test.static.estimated", "mmaxm"),1,3);
		table.getModel().setValueAt(entity.getElementItemAt("test.static.estimated", "isd"),2,3);
		table.getModel().setValueAt(entity.getElementItemAt("test.static.estimated", "cos"),3,3);
		table.getModel().setValueAt(entity.getElementItemAt("test.static.estimated", "eta"),4,3);
		
		table.getModel().setValueAt(entity.getElementItemAt("test.vector.given", "mn"), 0, 4);
		table.getModel().setValueAt(entity.getElementItemAt("test.vector.given", "mmaxm"),1,4);
		table.getModel().setValueAt(entity.getElementItemAt("test.vector.given", "isd"),2,4);
		table.getModel().setValueAt(entity.getElementItemAt("test.vector.given", "cos"),3,4);
		table.getModel().setValueAt(entity.getElementItemAt("test.vector.given", "eta"),4,4);

		table.getModel().setValueAt(entity.getElementItemAt("test.vector.estimated", "mn"), 0, 5);
		table.getModel().setValueAt(entity.getElementItemAt("test.vector.estimated", "mmaxm"),1,5);
		table.getModel().setValueAt(entity.getElementItemAt("test.vector.estimated", "isd"),2,5);
		table.getModel().setValueAt(entity.getElementItemAt("test.vector.estimated", "cos"),3,5);
		table.getModel().setValueAt(entity.getElementItemAt("test.vector.estimated", "eta"),4,5);
		
	}catch(Exception e) {
		System.out.println("JNominalPanel:"+e.toString());
	}
		//scrollPane.getColumnHeader().setVisible(true);
	}
	
	

}
