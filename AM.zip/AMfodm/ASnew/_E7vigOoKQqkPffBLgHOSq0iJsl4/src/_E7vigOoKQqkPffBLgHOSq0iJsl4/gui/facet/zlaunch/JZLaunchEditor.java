package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.zlaunch;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JGuiEditor;

public class JZLaunchEditor extends JGuiEditor{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_0j8PVmookKgK64kdt8rkR_NY_S2k";
	public static final String TEST_NOMINAL="Nominal";
	public static final String TEST_STATIC_GIVEN="Static(given)";
	public static final String TEST_STATIC_ESTIMATED="Static(estimated)";
	public static final String TEST_VECTOR_GIVEN="Vector(given)";
	public static final String TEST_VECTOR_ESTIMATED="Vector(estimated)";
	JComboBox<String> cbxMotor;
	JComboBox<String> cbxTest;
	
	JTextField txtV;
	JTextField txtF;
	JTextField txtM;
	JTextField txtL;
	JTextField txtU;
	Sack entity;
	boolean block=false;
	public JZLaunchEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {1};
		gridBagLayout.rowHeights = new int[] {1};
		gridBagLayout.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0,0.0,0.0,0.0,0.0,0.0,0.0,Double.MIN_VALUE};
		setLayout(gridBagLayout);
		//System.out.println("JZLaunchEditor:BEGIN");
		JLabel lblMotor = new JLabel("Motor");
		lblMotor.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
				String motor$=(String)cbxMotor.getSelectedItem();
				 Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
	              if(motor==null) {
	            	  System.out.println("JZLaunchEditor:cannot find entity="+motor$);
	            	  return;
	              }
	              String servicesLocator$=JEntityFacetList.classLocator();
	              servicesLocator$=Locator.append(servicesLocator$, Entigrator.ENTITY_LABEL, motor$);
	              JEntityFacetList entityFacetList=new JEntityFacetList(console,servicesLocator$);
				  JDisplay display=new JDisplay(console);
				  display.putContext(entityFacetList);
				  display.setLocationRelativeTo(JZLaunchEditor.this);
				  display.setVisible(true);
				  display.pack();
				  display.revalidate();
				  display.repaint();
				  //entityFacetList.rebuild(console);
				}catch(Exception ee) {
					System.out.println("JVFmodelEditor:motor click:"+ee.toString());
				}
				
			}
		});
		GridBagConstraints gbc_lblMotor = new GridBagConstraints();
		gbc_lblMotor.insets = new Insets(5, 5, 5, 5);
		gbc_lblMotor.gridx = 0;
		gbc_lblMotor.gridy = 0;
		add(lblMotor, gbc_lblMotor);
		
		cbxMotor = new JComboBox<String>();
		cbxMotor.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				saveValues();
			}
		});
		GridBagConstraints gbc_cbxMotor = new GridBagConstraints();
		gbc_cbxMotor.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxMotor.gridx = 1;
		gbc_cbxMotor.gridy = 0;
		gbc_cbxMotor.insets = new Insets(5, 5, 5, 0);
		add(cbxMotor, gbc_cbxMotor);
		
		JLabel lblTest = new JLabel("Test");
		GridBagConstraints gbc_lblTest = new GridBagConstraints();
		gbc_lblTest.insets = new Insets(5, 5, 5, 5);
		gbc_lblTest.gridx = 0;
		gbc_lblTest.gridy = 1;
		add(lblTest, gbc_lblTest);
		
		cbxTest = new JComboBox<String>();
		cbxTest.setModel(new DefaultComboBoxModel(new String[] {"given", "estimated"}));
		cbxTest.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				saveValues();
			}
		});
		GridBagConstraints gbc_cbxTest = new GridBagConstraints();
		gbc_cbxTest.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxTest.gridx = 1;
		gbc_cbxTest.gridy = 1;
		gbc_cbxTest.insets = new Insets(5, 5, 5, 0);
		add(cbxTest, gbc_cbxTest);
		
		JLabel lblFreq = new JLabel("Frequency");
		GridBagConstraints gbc_lblFreq = new GridBagConstraints();
		gbc_lblFreq.insets = new Insets(5, 5, 5, 5);
		gbc_lblFreq.gridx = 0;
		gbc_lblFreq.gridy = 2;
		add(lblFreq, gbc_lblFreq);
		
		txtF=new JTextField();
		txtF.setColumns(10);
		txtF.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	if(!block)
				saveValues();
				 }
	      });
		GridBagConstraints gbc_txtF = new GridBagConstraints();
		gbc_txtF.insets = new Insets(5, 5, 5, 5);
		gbc_txtF.gridx = 1;
		gbc_txtF.gridy = 2;
		gbc_txtF.anchor=GridBagConstraints.LINE_START;
		add(txtF, gbc_txtF);
		
		JLabel lblV = new JLabel("Voltage");
		GridBagConstraints gbc_lblV = new GridBagConstraints();
		gbc_lblV.insets = new Insets(5, 5, 5, 5);
		gbc_lblV.gridx = 0;
		gbc_lblV.gridy = 3;
		add(lblV, gbc_lblV);
		
		txtV=new JTextField();
		txtV.setColumns(10);
		txtV.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				if(!block)
				saveValues();
				 }
	      });
		GridBagConstraints gbc_txtV = new GridBagConstraints();
		gbc_txtV.insets = new Insets(5, 5, 5, 5);
		gbc_txtV.gridx = 1;
		gbc_txtV.gridy = 3;
		gbc_txtV.anchor=GridBagConstraints.LINE_START;
		add(txtV, gbc_txtV);
		
		JLabel lblT = new JLabel("Mc");
		GridBagConstraints gbc_lblT = new GridBagConstraints();
		gbc_lblT.insets = new Insets(5, 5, 5, 5);
		gbc_lblT.gridx = 0;
		gbc_lblT.gridy = 4;
		add(lblT, gbc_lblT);
		
		txtM=new JTextField();
		txtM.setColumns(10);
		txtM.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				if(!block)
				saveValues();
				 }
	      });
		GridBagConstraints gbc_txtM = new GridBagConstraints();
		gbc_txtM.insets = new Insets(5, 5, 5, 5);
		gbc_txtM.gridx = 1;
		gbc_txtM.gridy = 4;
		gbc_txtM.anchor=GridBagConstraints.LINE_START;
		add(txtM, gbc_txtM);
		
		JLabel lblL = new JLabel("Load time");
		GridBagConstraints gbc_lblL = new GridBagConstraints();
		gbc_lblL.insets = new Insets(5, 5, 5, 5);
		gbc_lblL.gridx = 0;
		gbc_lblL.gridy = 5;
		add(lblL, gbc_lblL);
		
		txtL=new JTextField();
		txtL.setColumns(10);
		txtL.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				if(!block)
				saveValues();
				 }
	      });
		GridBagConstraints gbc_txtL = new GridBagConstraints();
		gbc_txtL.insets = new Insets(5, 5, 5, 5);
		gbc_txtL.gridx = 1;
		gbc_txtL.gridy = 5;
		gbc_txtL.anchor=GridBagConstraints.LINE_START;
		add(txtL, gbc_txtL);
		
		JLabel lblU = new JLabel("Unload time");
		GridBagConstraints gbc_lblU = new GridBagConstraints();
		gbc_lblU.insets = new Insets(5, 5, 5, 5);
		gbc_lblU.gridx = 0;
		gbc_lblU.gridy = 6;
		add(lblU, gbc_lblU);
		
		txtU=new JTextField();
		txtU.setColumns(10);
		txtU.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				if(!block)
				saveValues();
				 }
	      });
		GridBagConstraints gbc_txtU = new GridBagConstraints();
		gbc_txtU.insets = new Insets(5, 5, 5, 5);
		gbc_txtU.gridx = 1;
		gbc_txtU.gridy = 6;
		gbc_txtU.anchor=GridBagConstraints.LINE_START;
		add(txtU, gbc_txtU);
		
		JPanel placebo=new JPanel();
		GridBagConstraints gbc_P = new GridBagConstraints();
		
		gbc_P.gridx = 1;
		gbc_P.gridy = 7;
		add(placebo, gbc_P);
		
		String entityLabel$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		if(entityLabel$!=null)
			entity=console.getEntigrator().getEntityAtLabel(entityLabel$);
		
		initContext();
	}
	

	public static String classLocator(){
		Properties locator=new Properties();
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(JContext.CONTEXT_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.zlaunch.JZLaunchEditor");
	    locator.put(Locator.LOCATOR_TITLE,"ZLaunch");
	    locator.put(FacetHandler.FACET_KEY,"_BOiROXZ_S78qwj6DlVa9Oq4hJ0jE");
	    locator.put(FacetHandler.FACET_NAME,"ZLaunch");
	    locator.put(FacetHandler.FACET_TYPE,"zlaunch");
	    locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.ZLaunchMaster");
	    locator.put(IconLoader.ICON_FILE,"zlaunch.png");
	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		 return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return locator$;
	}
	private void saveValues() {
		try {
			if(!entity.existsElement("zlaunch"))
				entity.createElement("zlaunch");
			String val$=(String)cbxMotor.getSelectedItem();
			entity.putElementItem("zlaunch", new Core(null,"motor",val$));
			val$=(String)cbxTest.getSelectedItem();
			entity.putElementItem("zlaunch", new Core(null,"test",val$));
			val$=txtF.getText();
			entity.putElementItem("zlaunch", new Core(null,"f",val$));
			val$=txtV.getText();
			entity.putElementItem("zlaunch", new Core(null,"v",val$));
			val$=txtM.getText();
			entity.putElementItem("zlaunch", new Core("","mc",val$));
			val$=txtL.getText();
			entity.putElementItem("zlaunch", new Core("","lt",val$));
			val$=txtU.getText();
			entity.putElementItem("zlaunch", new Core("","ut",val$));
			console.getEntigrator().putEntity(entity);
		}catch(Exception e) {
			System.out.println("JZLaunchEditor:saveValues:"+e.toString());
		}
	}
	private void initContext() {
		try {
			block=true;
			String[] sa=console.getEntigrator().listEntities("motor",Locator.LOCATOR_TRUE);
			DefaultComboBoxModel <String>model=new DefaultComboBoxModel<String>();
			ArrayList<String>sl=new ArrayList<String>();
			String label$;
			if(sa!=null) {
				for(String s:sa) {
					label$=console.getEntigrator().getLabel(s);
					if(label$!=null)
						sl.add(label$);
				}
			sa=new String[sl.size()];
			sl.toArray(sa);
			Arrays.sort(sa);
			model=new DefaultComboBoxModel<String>(sa);
			}
			cbxMotor.setModel(model);
			String motor$=entity.getElementItemAt("zlaunch", "motor");
			if(motor$!=null)
				selectCombo(cbxMotor,motor$);
			else {
				cbxMotor.setSelectedIndex(0);
			}
			String test$=entity.getElementItemAt("vlaunch", "test");
			if(test$!=null)
				selectCombo(cbxTest,test$);
			String f$=entity.getElementItemAt("zlaunch", "f");
			String v$=entity.getElementItemAt("zlaunch", "v");
			String m$=entity.getElementItemAt("zlaunch", "mc");
			String l$=entity.getElementItemAt("zlaunch", "lt");
			String u$=entity.getElementItemAt("zlaunch", "ut");
			String option$=entity.getElementItemAt("zlaunch", "test");
			txtF.setText(f$);
			selectCombo(cbxTest,option$);
			//System.out.println("JVLaunchEditor:initContext:v="+v$);
			txtV.setText(v$);
			txtM.setText(m$);
			txtL.setText(l$);
			txtU.setText(u$);
			block=false;
		}catch(Exception e) {
			System.out.println("JZLaunchEditor:initContext:"+e.toString());
		}
	}
}
