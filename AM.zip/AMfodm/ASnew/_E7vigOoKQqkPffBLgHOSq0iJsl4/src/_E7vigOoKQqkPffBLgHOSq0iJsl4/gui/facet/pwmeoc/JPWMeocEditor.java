package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmeoc;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;

import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JGuiEditor;

import java.awt.GridBagLayout;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;


import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class JPWMeocEditor extends JGuiEditor{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_oehxl1vaORZEYAHOG_Swy_S6oXr24";
	JTextField txtUd;
	JTextField txtKid;
	JTextField txtW;
	JTextField txtM;
	JTextField txtTco;
	JComboBox <String>cbxMotor;
	JComboBox <String>cbxTest;
	boolean block=false;
	Sack entity;
	public JPWMeocEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0,0,1};
		gridBagLayout.rowHeights = new int[]{0,0,0,0,0,1};
		gridBagLayout.columnWeights = new double[]{0.0,0.0,1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0,0.0,Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblUd = new JLabel("Ud");
		GridBagConstraints gbc_lblUd = new GridBagConstraints();
		gbc_lblUd.anchor = GridBagConstraints.LINE_START;
		gbc_lblUd.insets = new Insets(5, 5, 5, 5);
		gbc_lblUd.gridx = 0;
		gbc_lblUd.gridy = 0;
		add(lblUd, gbc_lblUd);
		
		txtUd = new JTextField();
		txtUd.setColumns(10);
		txtUd.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String ud$=txtUd.getText();
		    	if(!entity.existsElement("pwmeoc"))
		    		entity.createElement("pwmeoc");
	    		entity.putElementItem("pwmeoc", new Core(null,"Ud",ud$));	
				 console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtUd = new GridBagConstraints();
		gbc_txtUd.insets = new Insets(5, 5, 5, 5);
		gbc_txtUd.gridx = 1;
		gbc_txtUd.gridy = 0;
		gbc_txtUd.anchor = GridBagConstraints.LINE_START;
		add(txtUd, gbc_txtUd);
		
		JLabel lblKid = new JLabel("Kid");
		GridBagConstraints gbc_lblKid = new GridBagConstraints();
		gbc_lblKid.anchor = GridBagConstraints.LINE_START;
		gbc_lblKid.insets = new Insets(0, 5, 5, 5);
		gbc_lblKid.gridx = 0;
		gbc_lblKid.gridy = 1;
		add(lblKid, gbc_lblKid);
		
		txtKid = new JTextField();
		txtKid.setColumns(10);
		txtKid.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String kid$=txtKid.getText();
		    	if(!entity.existsElement("pwmeoc"))
		    		entity.createElement("pwmeoc");
	    		entity.putElementItem("pwmeoc", new Core(null,"Kid",kid$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtKid = new GridBagConstraints();
		gbc_txtKid.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF0.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtKid.gridx = 1;
		gbc_txtKid.gridy = 1;
		gbc_txtKid.anchor = GridBagConstraints.LINE_START;
		add(txtKid, gbc_txtKid);
		
		JLabel  lblW = new JLabel("W");
		GridBagConstraints gbc_lblW = new GridBagConstraints();
		gbc_lblW.insets = new Insets(0, 5, 5, 5);
		gbc_lblW.anchor=GridBagConstraints.LINE_START;
		gbc_lblW.gridx = 0;
		gbc_lblW.gridy = 2;
		add(lblW, gbc_lblW);
		
		txtW = new JTextField();
		txtW.setColumns(10);
		
		GridBagConstraints gbc_txtW = new GridBagConstraints();
		gbc_txtW.insets = new Insets(0, 5, 5, 5);
		gbc_txtW.gridx = 1;
		gbc_txtW.gridy = 2;
		gbc_txtW.anchor = GridBagConstraints.LINE_START;
		add(txtW, gbc_txtW);
		txtW.addCaretListener(new CaretListener() {
				@Override
				public void caretUpdate(CaretEvent e) {
					String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    	String w$=txtW.getText();
			    	if(!entity.existsElement("pwmeoc"))
			    		entity.createElement("pwmeoc");
		    		entity.putElementItem("pwmeoc", new Core(null,"W",w$));	
					console.getEntigrator().putEntity(entity);
					 }
		      });
		
		JLabel lblM = new JLabel("M");
		GridBagConstraints gbc_lblM = new GridBagConstraints();
		gbc_lblM.anchor = GridBagConstraints.LINE_START;
		gbc_lblM.insets = new Insets(0, 5, 5, 5);
		gbc_lblM.gridx = 0;
		gbc_lblM.gridy = 3;
		add(lblM, gbc_lblM);
		
		txtM = new JTextField();
		txtM.setColumns(10);
		txtM.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String m$=txtM.getText();
		    	if(!entity.existsElement("pwmeoc"))
		    		entity.createElement("pwmeoc");
	    		entity.putElementItem("pwmeoc", new Core(null,"M",m$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtM = new GridBagConstraints();
		gbc_txtM.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtM.gridx = 1;
		gbc_txtM.gridy = 3;
		gbc_txtM.anchor = GridBagConstraints.LINE_START;
		add(txtM, gbc_txtM);
		
		JLabel lblTco = new JLabel("Tco");
		GridBagConstraints gbc_lblTco = new GridBagConstraints();
		gbc_lblTco.anchor = GridBagConstraints.LINE_START;
		gbc_lblTco.insets = new Insets(0, 5, 5, 5);
		gbc_lblTco.gridx = 0;
		gbc_lblTco.gridy = 4;
		add(lblTco, gbc_lblTco);
		
		txtTco = new JTextField();
		txtTco.setColumns(10);
		txtTco.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String tco$=txtTco.getText();
		    	if(!entity.existsElement("pwmeoc"))
		    		entity.createElement("pwmeoc");
	    		entity.putElementItem("pwmeoc", new Core(null,"Tco",tco$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtTco = new GridBagConstraints();
		gbc_txtTco.insets = new Insets(0, 5, 5, 5);
		//gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtTco.gridx = 1;
		gbc_txtTco.gridy = 4;
		gbc_txtTco.anchor = GridBagConstraints.LINE_START;
		add(txtTco, gbc_txtTco);
		
		
		JLabel lblAM = new JLabel("Motor");
		lblAM.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					String motor$=(String)cbxMotor.getSelectedItem();
					 Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
		              if(motor==null) {
		            	  System.out.println("JPWMeocEditor:cannot find entity="+motor$);
		            	  return;
		              }
		              String servicesLocator$=JEntityFacetList.classLocator();
		              servicesLocator$=Locator.append(servicesLocator$, Entigrator.ENTITY_LABEL, motor$);
		              JEntityFacetList entityFacetList=new JEntityFacetList(console,servicesLocator$);
					  JDisplay display=new JDisplay(console);
					  display.putContext(entityFacetList);
					  display.setLocationRelativeTo(JPWMeocEditor.this);
					  display.setVisible(true);
					  display.pack();
					  display.revalidate();
					  display.repaint();
					}catch(Exception ee) {
						System.out.println("JPWMeocEditor:motor click:"+ee.toString());
					}
					
			}
		});
		GridBagConstraints gbc_lblAM = new GridBagConstraints();
		gbc_lblAM.anchor = GridBagConstraints.LINE_START;
		gbc_lblAM.insets = new Insets(0, 5, 5, 5);
		gbc_lblAM.gridx = 0;
		gbc_lblAM.gridy = 5;
		add(lblAM, gbc_lblAM);
		
		cbxMotor=new JComboBox();
		cbxMotor.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				saveValues();
			}
		});
		GridBagConstraints gbc_cbxAM = new GridBagConstraints();
		gbc_cbxAM.insets = new Insets(0, 5, 5, 5);
		gbc_cbxAM.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxAM.gridx = 1;
		gbc_cbxAM.gridy = 5;
		add(cbxMotor, gbc_cbxAM);
		
		JLabel lblTest = new JLabel("Test");
		GridBagConstraints gbc_lblTest = new GridBagConstraints();
		gbc_lblTest.insets = new Insets(5, 5, 5, 5);
		gbc_lblTest.gridx = 0;
		gbc_lblTest.gridy = 6;
		add(lblTest, gbc_lblTest);
		
		cbxTest = new JComboBox<String>();
		cbxTest.setModel(new DefaultComboBoxModel(new String[] {"given", "estimated"}));
		cbxTest.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if(!block)
				 saveValues();
			}
		});
		GridBagConstraints gbc_cbxTest = new GridBagConstraints();
		gbc_cbxTest.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxTest.gridx = 1;
		gbc_cbxTest.gridy = 6;
		gbc_cbxTest.insets = new Insets(5, 5, 5, 0);
		add(cbxTest, gbc_cbxTest);
		
		
		JPanel placebo=new JPanel();
		GridBagConstraints gbc_P = new GridBagConstraints();
		gbc_P.fill=GridBagConstraints.BOTH;
		gbc_P.gridx = 0;
		gbc_P.gridy = 7;
		add(placebo, gbc_P);
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
    	
		entity=console.getEntigrator().getEntityAtLabel(entity$);
    	initContext();
    	//System.out.println("JVFsupplyEditor:Uc="+uc$+" f0="+f0$+" Uc="+uc$+" f="+f$);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,"pwmeoc");
		locator.put(FacetHandler.FACET_TYPE,"pwmeoc");
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMidqMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(JContext.CONTEXT_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.pwmeoc.JPWMeocEditor");
		return Locator.toString(locator);
	}
	
	@Override
	public String reply(JMainConsole console, String locator$) {
		return locator$;
	}
	private void initContext() {
		try {
			block=true;
			String[] sa=console.getEntigrator().listEntities("motor",Locator.LOCATOR_TRUE);
			DefaultComboBoxModel <String>model=new DefaultComboBoxModel<String>();
			ArrayList<String>sl=new ArrayList<String>();
			String label$;
			if(sa!=null) {
				for(String s:sa) {
					label$=console.getEntigrator().getLabel(s);
					if(label$!=null)
						sl.add(label$);
				}
			sa=new String[sl.size()];
			sl.toArray(sa);
			Arrays.sort(sa);
			model=new DefaultComboBoxModel<String>(sa);
			}
			cbxMotor.setModel(model);
			String motor$=entity.getElementItemAt("pwmeoc", "motor");
			if(motor$!=null)
				selectCombo(cbxMotor,motor$);
			else {
				cbxMotor.setSelectedIndex(0);
			}
			String test$=entity.getElementItemAt("pwmeoc", "test");
			if(test$!=null)
				selectCombo(cbxTest,test$);
			//entity.printElement("pwmidqcontrol");
	    	String ua$=entity.getElementItemAt("pwmeoc", "Ud");
	    	txtUd.setText(ua$);
	    	String kid$=entity.getElementItemAt("pwmeoc", "Kid");
	    	txtKid.setText(kid$);
	    	String w$=entity.getElementItemAt("pwmeoc", "W");
	    	txtW.setText(w$);
	    	String m$=entity.getElementItemAt("pwmeoc", "M");
	    	txtM.setText(m$);
	    	String tco$=entity.getElementItemAt("pwmeoc", "Tco");
	    	txtTco.setText(tco$);
	    	block=false;
		}catch(Exception e) {
			System.out.println("JPWMeocEditor:initContext:"+e.toString());
		}
	}
	private void saveValues() {
		try {
			if(!entity.existsElement("pwmeoc"))
				entity.createElement("pwmeoc");
			String val$=(String)cbxMotor.getSelectedItem();
			entity.putElementItem("pwmeoc", new Core(null,"motor",val$));
			val$=(String)cbxTest.getSelectedItem();
			entity.putElementItem("pwmeoc", new Core(null,"test",val$));
			val$=txtKid.getText();
			entity.putElementItem("pwmeoc", new Core(null,"Kid",val$));
			val$=txtUd.getText();
			entity.putElementItem("pwmeoc", new Core(null,"Ud",val$));
			val$=txtM.getText();
			entity.putElementItem("pwmeoc", new Core(null,"M",val$));
			val$=txtW.getText();
			entity.putElementItem("pwmeoc", new Core("","W",val$));
			val$=txtTco.getText();
			entity.putElementItem("pwmeoc", new Core("","Tco",val$));
			console.getEntigrator().putEntity(entity);
		}catch(Exception e) {
			System.out.println("JPWMeocEditor:saveValues:"+e.toString());
		}
	}
}
