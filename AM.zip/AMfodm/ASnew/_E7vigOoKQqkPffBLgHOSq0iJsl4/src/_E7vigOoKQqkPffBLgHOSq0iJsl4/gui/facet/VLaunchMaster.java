package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet;

import java.util.Properties;

import javax.swing.JPopupMenu;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VLaunchHandler;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.vlaunch.JVLaunchEditor;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;

public class VLaunchMaster extends FacetMaster{
	public static final String KEY="_A6gEk0ViuLDEu9K6C_S_SjgfSbC2I";
	public VLaunchMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.VLaunchMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VLaunchHandler");
	    locator.put(HANDLER_KEY,"_AG53DHMtLaLaIJ5Y8P9pwBAW19k");
	    locator.put(Locator.LOCATOR_TITLE,"VLaunch");
	    locator.put(MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "vlaunch.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_TYPE,"vlaunch");
	    return Locator.toString(locator);
	    
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String display$=Locator.getProperty(handlerLocator$, JContext.DISPLAY);
		String itemLocator$=JItemPanel.classLocator();
		String controllerLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, controllerLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		
	}
	public VLaunchHandler getFacetHandler(Entigrator entigrator, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= VLaunchHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		//System.out.println("VectorMaster:getFacetHandler:locator="+locator$);
		return new VLaunchHandler(entigrator,handlerLocator$); 
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public String getName() {
		return "VLaunch";
	}

	@Override
	public String getType() {
		return "vlaunch";
	}

	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			//System.out.println("VectorMaster:entityFacetsItemOnClick:locator="+locator$);
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			//String parent$=console.saveContext();
			String parent$=Locator.getProperty(locator$, JContext.PARENT);
			//System.out.println("VectorMaster:entityFacetsItemOnClick:parent="+parent$);
			String vlaunchlEditor$=JVLaunchEditor.classLocator();
			vlaunchlEditor$=Locator.merge(vlaunchlEditor$,locator$);
			vlaunchlEditor$=Locator.append(vlaunchlEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			if(parent$!=null)
			  vlaunchlEditor$=Locator.append(vlaunchlEditor$,JContext.PARENT,parent$);
			//System.out.println("VectorMaster:entityFacetsItemOnClick:1");
			JVLaunchEditor vlaunchEditor=new JVLaunchEditor(console,vlaunchlEditor$);
			//System.out.println("VectorMaster:entityFacetsItemOnClick:2");
			console.replaceContext(context,(JContext)vlaunchEditor);
		}catch(Exception e) {
			System.out.println("VLaunchMaster:entityFacetsItemOnClick:"+e.toString());	
		}
		
	}

	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLocator() {
		return classLocator();
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",VLaunchHandler.KEY,VLaunchHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("VLaunchMaster:putToSession:"+e.toString());
	    }
	}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}

	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		//System.out.println("MechanicMaster:createEntity:entity="+entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",getType(),classLocator()));
		entity.putAttribute(new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4","icon","vlaunch.png"));
		entigrator.putEntity(entity);
		
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty( "operator","true", entity.getKey());
	//	String vfmodelHandler$=VFmodelHandler.classLocator();
	//	vfmodelHandler$=Locator.append(vfmodelHandler$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
	//	VFmodelHandler	 vectorHandler=getFacetHandler(entigrator, vfmodelHandler$);
		Properties adapterLocator=new Properties();
		entityKey$=entigrator.getKey(entityLabel$);
	    adapterLocator.put(Entigrator.ENTITY_KEY, entityKey$);
	    adapterLocator.put(SegueController.SEGUE_HANDLER, "VLaunchHandler");
	    adapterLocator.put(SegueController.SEGUE_INSTANCE, "vlaunchHandler");
	    adapterLocator.put(SegueController.SEGUE_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VLaunchHandler");
	    String adapterLocator$=Locator.toString(adapterLocator);
		SegueController.createAdapter(entigrator, adapterLocator$);
		return entity;
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

}
