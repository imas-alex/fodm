package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.controller;



import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;
import java.util.Stack;
import java.util.logging.Logger;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import javax.swing.JPanel;
import javax.swing.JTextField;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ControllerHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;


//


//


public class JControllerEditor   extends  JGuiEditor {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String CONTROLLER_FACET_TYPE="static controller";
	public static final String CONTROLLER_FACET_NAME="Static controller";
	
	
	public static final String CONTROLLER_FACET_CLASS="_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.controller.JControllerEditor";
	public static final String KEY="_CRvy1cjMOA_oAbNrJwUq2jxr81Q";
	//public static final String ACTION_NEW_ENTITY="action new entity";
	//public static final String ACTION_DISPLAY_ENTITY="action display entity";
	//protected Logger LOGGER=Logger.getLogger(JControllerEditor.class.getName());


	protected String entityKey$;
	protected String entityLabel$;
	protected String requesterAction$;
	protected Entigrator entigrator;
	protected Sack entity;
	protected JComboBox<String> cbxMotor ;
	protected JTextField txtCtakt;
	//protected JTextField txtKosc;
	protected JTextField txtKft;
	protected JTextField txtQtakt;
	protected JTextField txtKws;
	protected JTextField txtFdev;
	protected JTextField txtFbase;
	protected JTextField txtMbase;
	protected JTextField txtKfs;
	protected JTextField txtTdev;
	//protected JTextField txtKfp;
	protected JTextField txtWdev;
	protected JTextField txtEmax;
	protected JButton btnCancel;
	protected JButton btnSave;
	public JControllerEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		
		//	System.out.println("JControllerEditor:constructor:begin");
		     setLayout(new GridBagLayout());
			JLabel lblMotor= new JLabel("Motor");
				 GridBagConstraints gbc_lblMotor = new GridBagConstraints();
				 gbc_lblMotor.insets = new Insets(0, 0, 5, 5);
				 gbc_lblMotor.gridx = 0;
				 gbc_lblMotor.gridy = 0;
				  add(lblMotor, gbc_lblMotor);

				 cbxMotor = new JComboBox<String>();
				 cbxMotor.addActionListener(new ActionListener() {
				 	public void actionPerformed(ActionEvent arg0) {
				 		//initSettings();
				 	}
				 });
				 
				cbxMotor.setModel(new DefaultComboBoxModel());
				 GridBagConstraints gbc_cbxMotor = new GridBagConstraints();
				 gbc_cbxMotor.insets=new Insets(3, 3, 5, 3);
				 gbc_cbxMotor.fill = GridBagConstraints.HORIZONTAL;
				 gbc_cbxMotor.gridx = 1;
				 gbc_cbxMotor.gridy =0;
				 add( cbxMotor, gbc_cbxMotor);
				 
				 JLabel lblQtakt = new JLabel("Qtakt");
		         GridBagConstraints gbc_lblQtakt = new GridBagConstraints();
		    	gbc_lblQtakt.gridx = 0;
				gbc_lblQtakt.gridy = 1;
			    add(lblQtakt, gbc_lblQtakt);

			    txtQtakt = new JTextField();
			    txtQtakt.setText("0.000001");
			
			    GridBagConstraints gbc_txtQtakt = new GridBagConstraints();
			    gbc_txtQtakt.insets=new Insets(3,3,3,3);
				gbc_txtQtakt.fill = GridBagConstraints.HORIZONTAL;
				gbc_txtQtakt.gridx = 1;
				gbc_txtQtakt.gridy = 1;
			    add( txtQtakt, gbc_txtQtakt);
				 
			    JLabel lblCtakt = new JLabel("Ctakt");
		         GridBagConstraints gbc_lblCtakt = new GridBagConstraints();
		    	gbc_lblCtakt.gridx = 0;
				gbc_lblCtakt.gridy = 2;
			    add(lblCtakt, gbc_lblCtakt);

			    txtCtakt = new JTextField();
			    txtCtakt.setText("0.00025");
			
			    GridBagConstraints gbc_txtCtakt = new GridBagConstraints();
			    gbc_txtCtakt.insets=new Insets(3,3,3,3);
				gbc_txtCtakt.fill = GridBagConstraints.HORIZONTAL;
				gbc_txtCtakt.gridx = 1;
				gbc_txtCtakt.gridy = 2;
			    add( txtCtakt, gbc_txtCtakt);


				 JLabel lblKft = new JLabel("Kft");
		         GridBagConstraints gbc_lblRtakt = new GridBagConstraints();
		    	gbc_lblRtakt.gridx = 0;
				gbc_lblRtakt.gridy = 3;
			    add(lblKft, gbc_lblRtakt);

			    txtKft = new JTextField();
			    txtKft.setText("5");
			
			    GridBagConstraints gbc_txtFtakt = new GridBagConstraints();
			    gbc_txtFtakt.insets=new Insets(3,3,3,3);
				gbc_txtFtakt.fill = GridBagConstraints.HORIZONTAL;
				gbc_txtFtakt.gridx = 1;
				gbc_txtFtakt.gridy = 3;
			    add( txtKft, gbc_txtFtakt);
				 
		       			 ///////////////////
			    JLabel lblKws = new JLabel("Kws");
				  GridBagConstraints gbc_lblKws = new GridBagConstraints();
			    	gbc_lblKws.gridx = 0;
					gbc_lblKws.gridy = 4;
				    add(lblKws, gbc_lblKws);

				 txtKws = new JTextField();
				 txtKws.setText("4");
				
				 GridBagConstraints gbc_txtKws = new GridBagConstraints();
				 gbc_txtKws.insets=new Insets(3,3,3,3);
					gbc_txtKws.fill = GridBagConstraints.HORIZONTAL;
					gbc_txtKws.gridx = 1;
					gbc_txtKws.gridy = 4;
				    add( txtKws ,gbc_txtKws);
			    
			    
			 ///////////////////////   
			
				    JLabel lblKfs = new JLabel("Kfs");
					GridBagConstraints gbc_lblKfs = new GridBagConstraints();
						gbc_lblKfs.gridx = 0;
						gbc_lblKfs.gridy = 5;
					    add(lblKfs, gbc_lblKfs);

					 txtKfs = new JTextField();
					 txtKfs.setText("16");
					
			          GridBagConstraints gbc_txtKfs = new GridBagConstraints();
					 gbc_txtKfs.insets=new Insets(3,3,3,3);
						gbc_txtKfs.fill = GridBagConstraints.HORIZONTAL;
						gbc_txtKfs.gridx = 1;
						gbc_txtKfs.gridy = 5;
					    add( txtKfs ,gbc_txtKfs);
					    
					JLabel lblFbase = new JLabel("Fbase");
						  GridBagConstraints gbc_lblFbase = new GridBagConstraints();
							gbc_lblFbase.gridx = 0;
							gbc_lblFbase.gridy = 6;
						    add(lblFbase, gbc_lblFbase);

						 txtFbase = new JTextField();
						 txtFbase.setText("2");
						
					 GridBagConstraints gbc_txtFbase = new GridBagConstraints();
						 gbc_txtFbase.insets=new Insets(3,3,3,3);
							gbc_txtFbase.fill = GridBagConstraints.HORIZONTAL;
							gbc_txtFbase.gridx = 1;
							gbc_txtFbase.gridy = 6;
						    add( txtFbase ,gbc_txtFbase);  
						    
			  
			      JLabel lblFdev= new JLabel("Fdev");
				  GridBagConstraints gbc_lblFdev = new GridBagConstraints();
					gbc_lblFdev.gridx = 0;
					gbc_lblFdev.gridy = 7;
				    add(lblFdev, gbc_lblFdev);

				 txtFdev = new JTextField();
				 txtFdev.setText("1");
				
			 GridBagConstraints gbc_txtFdev = new GridBagConstraints();
				 gbc_txtFdev.insets=new Insets(3,3,3,3);
					gbc_txtFdev.fill = GridBagConstraints.HORIZONTAL;
					gbc_txtFdev.gridx = 1;
					gbc_txtFdev.gridy = 7;
				    add( txtFdev ,gbc_txtFdev);  
				    
			JLabel lblMbase = new JLabel("Mbase");
						GridBagConstraints gbc_lblMbase = new GridBagConstraints();
							gbc_lblMbase.gridx = 0;
							gbc_lblMbase.gridy = 8;
						    add(lblMbase, gbc_lblMbase);

						 txtMbase = new JTextField();
						 txtMbase.setText("40");
					
			 GridBagConstraints gbc_txtMbase = new GridBagConstraints();
						 gbc_txtMbase.insets=new Insets(3,3,3,3);
							gbc_txtMbase.fill = GridBagConstraints.HORIZONTAL;
							gbc_txtMbase.gridx = 1;
							gbc_txtMbase.gridy = 8;
						    add( txtMbase ,gbc_txtMbase);					    

		    JLabel lblWdev = new JLabel("Wdev");
							GridBagConstraints gbc_lblWdev = new GridBagConstraints();
							gbc_lblWdev.gridx = 0;
							gbc_lblWdev.gridy = 9;
							add(lblWdev, gbc_lblWdev);

							txtWdev = new JTextField();
							txtWdev.setText("20");
			 GridBagConstraints gbc_txtWdev = new GridBagConstraints();
							 gbc_txtWdev.insets=new Insets(3,3,3,3);
										gbc_txtWdev.fill = GridBagConstraints.HORIZONTAL;
										gbc_txtWdev.gridx = 1;
										gbc_txtWdev.gridy = 9;
									    add( txtWdev ,gbc_txtWdev);	
									    
			 JLabel lblTdev = new JLabel("Tdev");
										GridBagConstraints gbc_lblTdev = new GridBagConstraints();
										gbc_lblTdev.gridx = 0;
										gbc_lblTdev.gridy = 10;
										add(lblTdev, gbc_lblTdev);

										txtTdev = new JTextField();
										txtTdev.setText("0.00004");
			 GridBagConstraints gbc_txtTdev = new GridBagConstraints();
										 gbc_txtTdev.insets=new Insets(3,3,3,3);
													gbc_txtTdev.fill = GridBagConstraints.HORIZONTAL;
													gbc_txtTdev.gridx = 1;
													gbc_txtTdev.gridy = 10;
				 add( txtTdev ,gbc_txtTdev);										    
							    
								
								   JLabel lblEmax = new JLabel("Emax");
										GridBagConstraints gbc_lblEmax = new GridBagConstraints();
											gbc_lblEmax.gridx = 0;
											gbc_lblEmax.gridy = 11;
										    add(lblEmax, gbc_lblEmax);

										 txtEmax = new JTextField();
										 txtEmax.setText("450");
										
								          GridBagConstraints gbc_txtEmax = new GridBagConstraints();
										 gbc_txtEmax.insets=new Insets(3,3,3,3);
											gbc_txtEmax.fill = GridBagConstraints.HORIZONTAL;
											gbc_txtEmax.gridx = 1;
											gbc_txtEmax.gridy = 11;
										    add( txtEmax ,gbc_txtEmax);	
										    
										  
								
			JPanel desk=new JPanel();
			GridBagConstraints gbc_desk = new GridBagConstraints();
			//gbc_placebo.fill = GridBagConstraints.VERTICAL;
			gbc_desk.gridx = 1;
			gbc_desk.gridy = 12;
			
			add( desk, gbc_desk);
			desk.setLayout(new BoxLayout(desk, BoxLayout.X_AXIS));
			btnSave=new JButton("Save");
			btnSave.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					refreshMotor();
					entity=saveParameters();
					//System.out.println("JController:save");
					//entity=ControllerHandler.step(entity);
					entigrator.putEntity(entity);
					//JControllerEditor.this.done(console, locator$);
					//done(console,JControllerEditor.this);
					handleDone();
				}
			});
			btnCancel=new JButton("Cancel");
			btnCancel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					//JControllerEditor.this.done(console, locator$);
					handleDone();
				}
			});
			JButton btnReinit=new JButton("Reinit");
			btnReinit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					reinit();
					//JControllerEditor.this.done(console, locator$);
					handleDone();
				}
			});
			desk.add(btnCancel);
			desk.add(btnReinit);
			desk.add(btnSave);
			
			//desk.setLayout();
			JPanel placebo=new JPanel();
			//placebo.setSize(10, 1000);
			
			GridBagConstraints gbc_placebo = new GridBagConstraints();
			//gbc_placebo.fill = GridBagConstraints.VERTICAL;
			gbc_placebo.gridx = 0;
			gbc_placebo.gridy = 13;
			gbc_placebo.weighty=1;
			add( placebo, gbc_placebo);
		////
			Properties locator=Locator.toProperties(locator$);
			entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			entigrator=console.getEntigrator();
			entityKey$=entigrator.getKey(entityLabel$);
			entity=entigrator.getEntityAtLabel(entityLabel$);
			initMotors();
			initParameters();
			
			}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,CONTROLLER_FACET_NAME);
		locator.put(FacetHandler.FACET_TYPE,CONTROLLER_FACET_TYPE);
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4._E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.JControllerMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(JContext.CONTEXT_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4._E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.controller.JControllerEditor");
		return Locator.toString(locator);
	}
	/*
	public void reindex(JMainConsole console, Entigrator entigrator, Sack entity) {
		 try{
				// System.out.println("JPhoneEditor:reindex:0:entity="+entity.getProperty("label"));
			    	String fhandler$=ControllerHandler.class.getName();
			    	if(entity.getElementItem("fhandler", fhandler$)!=null){
						//System.out.println("JPhoneEditor:reindex:1:entity="+entity.getProperty("label"));
			    		entity.putElementItem("jfacet", new Core(JControllerFacetAddItem.class.getName(),fhandler$,JControllerFacetOpenItem.class.getName()));
						entity.putElementItem("fhandler", new Core("operator",fhandler$,ControllerHandler.EXTENSION_KEY));
						entity.putElementItem("fhandler", new Core(null,"gdt.data.entity.OperatorHandler",ControllerHandler.EXTENSION_KEY));
						
						entity.putElementItem("fhandler", new Core("hide",FieldsHandler.class.getName(),null));
						entigrator.ent_alter(entity);
					}
			    }catch(Exception e){
			    	Logger.getLogger(getClass().getName()).severe(e.toString());
			    }
		
		
	}
*/
//	@Override
	/*
	public String newEntity(JMainConsole console, String locator$) {
		JTextEditor textEditor=new JTextEditor();
	    String editorLocator$=textEditor.getLocator();
	    editorLocator$=Locator.append(editorLocator$, JTextEditor.TEXT, "Controller"+Identity.key().substring(0,4));
	    editorLocator$=Locator.append(editorLocator$,Locator.LOCATOR_TITLE,"Controller entity");
	    JControllerEditor fe=new JControllerEditor();
	    String feLocator$=fe.getLocator();
	    Properties responseLocator=Locator.toProperties(feLocator$);
	    entihome$=Locator.getProperty(locator$,Entigrator.ENTIHOME );
	    if(entihome$!=null)
	      responseLocator.setProperty(Entigrator.ENTIHOME,entihome$);
	   responseLocator.setProperty(BaseHandler.HANDLER_CLASS,JControllerEditor.class.getName());
		responseLocator.setProperty(BaseHandler.HANDLER_METHOD,"response");
		responseLocator.setProperty(BaseHandler.HANDLER_SCOPE,JConsoleHandler.CONSOLE_SCOPE);
		responseLocator.setProperty(BaseHandler.HANDLER_METHOD,"response");
		responseLocator.setProperty(JRequester.REQUESTER_ACTION,ACTION_NEW_ENTITY);
		responseLocator.setProperty(Locator.LOCATOR_TITLE,"Controller");
		 String responseLocator$=Locator.toString(responseLocator);
		String requesterResponseLocator$=Locator.compressText(responseLocator$);
		editorLocator$=Locator.append(editorLocator$,JRequester.REQUESTER_RESPONSE_LOCATOR,requesterResponseLocator$);
		editorLocator$=Locator.append(editorLocator$,Entigrator.ENTIHOME,entihome$);JConsoleHandler.execute(console,editorLocator$); 
		return editorLocator$;
	}
*/
	

	

//	@Override
	/*
	public void response(JMainConsole console, String locator$) {
		try{
			Properties locator=Locator.toProperties(locator$);
			String action$=locator.getProperty(JRequester.REQUESTER_ACTION);
			entihome$=locator.getProperty(Entigrator.ENTIHOME);
			Entigrator entigrator=console.getEntigrator(entihome$);
			String text$=locator.getProperty(JTextEditor.TEXT);
			if(ACTION_NEW_ENTITY.equals(action$)){
				Sack newEntity=entigrator.ent_new("controller", text$);
				//newEntity.createElement("operator");
				//newEntity.putElementItem("operator", new Core("input","in","1"));
				//newEntity.putElementItem("operator", new Core("output","out","0"));
				//newEntity.putElementItem("operator", new Core("parameter","maximal value ","100"));
				//newEntity.putElementItem("operator", new Core("state",Instrument.TIME,"0"));
				
				newEntity.createElement("fhandler");
				newEntity.putElementItem("fhandler", new Core("operator",ControllerHandler.class.getName(),ControllerHandler.EXTENSION_KEY));
				newEntity.putElementItem("fhandler", new Core(null,"gdt.data.entity.OperatorHandler",OperatorHandler.EXTENSION_KEY));
				
				
				//newEntity.putElementItem("fhandler", new Core(null,IntegratorHandler.class.getName(),null));
				newEntity.createElement("jfacet");
				newEntity.putElementItem("jfacet", new Core("gdt.jgui.entity.controller.JControllerFacetAddItem",ControllerHandler.class.getName(),"gdt.jgui.entity.controller.JControllerFacetOpenItem"));
				Core fh=newEntity.getElementItem("fhandler", FieldsHandler.class.getName());
				if(fh!=null){
					fh.type="hide";
					newEntity.putElementItem("fhandler",fh);	
					
				}
				newEntity.putAttribute(new Core (null,"icon","controller.png"));
				entigrator.ent_alter(newEntity);
			//	entigrator.ent_assignProperty(newEntity, "integrator", text$);
				entigrator.ent_assignProperty(newEntity, "controller", text$);
				entigrator.ent_assignProperty(newEntity, "operator","true");
				String icons$=entihome$+"/"+Entigrator.ICONS;
				Support.addHandlerIcon(OperatorHandler.class, "controller.png", icons$);
				newEntity=entigrator.ent_reindex(newEntity);
				reindex(console, entigrator, newEntity);
				JEntityFacetPanel efp=new JEntityFacetPanel(); 
				String efpLocator$=efp.getLocator();
				efpLocator$=Locator.append(efpLocator$,Locator.LOCATOR_TITLE,newEntity.getProperty("label"));
				efpLocator$=Locator.append(efpLocator$, Entigrator.ENTIHOME, entihome$);
				efpLocator$=Locator.append(efpLocator$, EntityHandler.ENTITY_KEY, newEntity.getKey());
				efpLocator$=Locator.append(efpLocator$, EntityHandler.ENTITY_LABEL, newEntity.getProperty("label"));
				JEntityPrimaryMenu.reindexEntity(console, efpLocator$);
				Stack<String> s=console.getTrack();
				s.pop();
				console.setTrack(s);
				JConsoleHandler.execute(console, efpLocator$);
				return;
			}
				String feLocator$=getLocator();
				feLocator$=Locator.append(locator$, Entigrator.ENTIHOME, entihome$);
				feLocator$=Locator.append(locator$, EntityHandler.ENTITY_KEY, entityKey$);
				feLocator$=Locator.remove(feLocator$, BaseHandler.HANDLER_METHOD);
				JConsoleHandler.execute(console, feLocator$);
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
		
	}
*/
	/*
	@Override
	public String getLocator() {
		try{
			Properties locator=new Properties();
			locator.setProperty(BaseHandler.HANDLER_CLASS,JControllerEditor.class.getName());
			locator.setProperty(BaseHandler.HANDLER_SCOPE,JConsoleHandler.CONSOLE_SCOPE);
			 locator.setProperty( JContext.CONTEXT_TYPE,getType());
			locator.setProperty(Locator.LOCATOR_TITLE,getTitle());
			locator.setProperty(BaseHandler.HANDLER_LOCATION,ControllerHandler.EXTENSION_KEY);
			if(entityLabel$!=null){
				locator.setProperty(EntityHandler.ENTITY_LABEL,entityLabel$);
			}
			if(entityKey$!=null)
				locator.setProperty(EntityHandler.ENTITY_KEY,entityKey$);
			
			if(entihome$!=null){
				locator.setProperty(Entigrator.ENTIHOME,entihome$);
				Entigrator entigrator=console.getEntigrator(entihome$);
			}
			locator.setProperty( Locator.LOCATOR_ICON_CONTAINER, Locator.LOCATOR_ICON_CONTAINER_CLASS);
	    	locator.setProperty( Locator.LOCATOR_ICON_CLASS, ControllerHandler.class.getName());
	    	locator.setProperty( Locator.LOCATOR_ICON_FILE, "controller.png");
			return Locator.toString(locator);
			}catch(Exception e){
	        Logger.getLogger(getClass().getName()).severe(e.toString());
	        return null;
			}
	}
*/
	
/*
	@Override
	public JMenu getContextMenu() {
		JMenu	menu=new JMenu("Context");
		 JMenuItem doneItem = new JMenuItem("Done");
		  doneItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					try{
					saveParameters();
					entigrator.ent_alter(entity);
					console.back();
					}catch(Exception ee){
						Logger.getLogger(JUnitEditor.class.getName()).severe(ee.toString());
					}
				}
			} );
		
			menu.add(doneItem);
			  JMenuItem cancelItem = new JMenuItem("Cancel");
			cancelItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					try{
						console.back();
					}catch(Exception ee){
						Logger.getLogger(JControllerEditor.class.getName()).severe(ee.toString());
					}
				}
			} );
			menu.add(cancelItem);	
		
				
			return menu;
	}
	*/
	
	private void initMotors() {
		try{
			String [] sa=entigrator.listEntities("entity", "motor");
			if(sa==null)
				return;
			ArrayList<String> sl= new ArrayList<String>();
			for(String s:sa) {
				sl.add(entigrator.getLabel(s));
			}
			
			Collections.sort(sl);
			sa=new String[sl.size()];
		//	System.out.println("JControllerEditor:initMotors:sa="+sa.length);
			sl.toArray(sa);
			DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String>(sa);
			cbxMotor.setModel(model);
	        Core motor=entity.getElementItem("controller", "motor");
	       
	        if(motor!=null) {
	        	
	        	if(motor.type!=null)
	        			selectCombo(cbxMotor,motor.type);
	        }
	        
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
	}
	private void initParameters() {
		txtCtakt.setText(entity.getElementItemAt("controller", "ctakt"));
		txtKft.setText(entity.getElementItemAt("controller", "kft"));
		txtQtakt.setText(entity.getElementItemAt("controller", "qtakt"));
		txtTdev.setText(entity.getElementItemAt("controller", "tdev"));
		txtKws.setText(entity.getElementItemAt("controller", "kws"));
		txtKfs.setText(entity.getElementItemAt("controller", "kfs"));
		txtFdev.setText(entity.getElementItemAt("controller", "fdev"));
		txtFbase.setText(entity.getElementItemAt("controller", "fbase"));
		txtMbase.setText(entity.getElementItemAt("controller", "mbase"));
		txtWdev.setText(entity.getElementItemAt("controller", "wdev"));
		txtEmax.setText(entity.getElementItemAt("controller", "emax"));
		//txtKfs.setText(entity.getElementItemAt("controller", "kfs"));
	}
	private void refreshMotor() {
		String lblMotor$=(String)cbxMotor.getSelectedItem();
		String keyMotor$=entigrator.getKey(lblMotor$);
		Sack motor=entigrator.getEntity(keyMotor$);
		String [] sa=motor.elementListNames("secondary");
		if(!entity.existsElement("controller"))
			entity.createElement("controller");
		for(String s:sa)
			entity.putElementItem("controller", motor.getElementItem("secondary",s));
		entity.putElementItem("controller", motor.getElementItem("nominal","pol"));
		entity.putElementItem("controller", motor.getElementItem("nominal","j"));
		entity.putElementItem("controller", new Core(lblMotor$,"motor",keyMotor$));
	}
	private Sack saveParameters() {
		if(!entity.existsElement("controller"))
			entity.createElement("controller");
		entity.putElementItem("controller", new Core(null,"ctakt",txtCtakt.getText()));
		entity.putElementItem("controller", new Core(null,"kft",txtKft.getText()));
		entity.putElementItem("controller", new Core(null,"qtakt",txtQtakt.getText()));
		
		entity.putElementItem("controller", new Core(null,"kws",txtKws.getText()));
		entity.putElementItem("controller", new Core(null,"kfs",txtKfs.getText()));
		entity.putElementItem("controller", new Core(null,"fdev",txtFdev.getText()));
		entity.putElementItem("controller", new Core(null,"fbase",txtFbase.getText()));
		entity.putElementItem("controller", new Core(null,"mbase",txtMbase.getText()));
		
		entity.putElementItem("controller", new Core(null,"tdev",txtTdev.getText()));
		entity.putElementItem("controller", new Core(null,"wdev",txtWdev.getText()));
		entity.putElementItem("controller", new Core(null,"emax",txtEmax.getText()));
		
		return entity;
	}
	/*
	private void selectCombo(JComboBox combo, String selection$){
		try{
		DefaultComboBoxModel<String> model=(DefaultComboBoxModel<String>) combo.getModel();
	   int size=model.getSize();
	   int sel=0;
	 for(int i=0;i<size;i++) {
		 if(selection$.equalsIgnoreCase((String)combo.getItemAt(i))) {
			 sel=i;
		 }
	 }
	try{combo.setSelectedIndex(sel);}catch(Exception e) {}
	}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
		
	}
	*/
	private void reinit() {
		entity=ControllerHandler.reinit(entity);
		entigrator.putEntity(entity);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
}
