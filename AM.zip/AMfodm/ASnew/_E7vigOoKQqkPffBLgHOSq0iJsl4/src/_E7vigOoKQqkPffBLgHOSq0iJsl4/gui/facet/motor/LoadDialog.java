package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.motor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;


import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
public class LoadDialog extends JDialog  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
//	private JTextField w0Text;
	private JTextField mcText;
	Entigrator entigrator;
	Sack entity;
	
	public LoadDialog(Entigrator entigrator,Sack entity) {
	    super();
	    setTitle("Load ");
		
	    GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{112, 112};
		gridBagLayout.rowHeights = new int[] {10, 10, 10};
		gridBagLayout.columnWeights = new double[]{0.0,  Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel mcLabel = new JLabel(" mc");
		mcLabel.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_mcLabel = new GridBagConstraints();
		gbc_mcLabel.fill = GridBagConstraints.BOTH;
		gbc_mcLabel.insets = new Insets(0, 0, 5, 5);
		gbc_mcLabel.gridx = 0;
		gbc_mcLabel.gridy = 0;
		getContentPane().add(mcLabel, gbc_mcLabel);
		
		mcText = new JTextField();
		mcText.setColumns(10);
		GridBagConstraints gbc_mcText = new GridBagConstraints();
		gbc_mcText.fill = GridBagConstraints.HORIZONTAL;
		gbc_mcText.insets = new Insets(0, 0, 5, 5);
		gbc_mcText.gridx = 1;
		gbc_mcText.gridy = 0;
		getContentPane().add(mcText, gbc_mcText);
		JButton btnOk = new JButton("OK");
		btnOk.setHorizontalAlignment(SwingConstants.RIGHT);
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//String w0$=w0Text.getText();
				//entity.putElementItem("operator",new Core("input","w0",w0$));
				//entity.putElementItem("control",new Core("input","w0",w0$));
				String mc$=mcText.getText();
				entity.putElementItem("operator",new Core("input","mc",mc$));
				entity.putElementItem("control",new Core("input","mc",mc$));
				entigrator.putEntity(entity);
				String usp$=entity.getElementItemAt("motor", "usp");
				if(usp$!=null)
					entity.saveXML(usp$);
				//entity.print("operator");
				LoadDialog.this.dispose();
			}
		});
		btnOk.setActionCommand("OK");
		//btnOk.addActionListener(this);
		GridBagConstraints gbc_btnOk = new GridBagConstraints();
		//gbc_button.fill = GridBagConstraints.BOTH;
		gbc_btnOk.insets = new Insets(0, 0, 0, 5);
		gbc_btnOk.gridx = 0;
		gbc_btnOk.anchor=GridBagConstraints.LINE_END;
		gbc_btnOk.gridy = 1;
		getContentPane().add(btnOk, gbc_btnOk);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setHorizontalAlignment(SwingConstants.LEFT);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				LoadDialog.this.dispose();
			}
		});
		
		btnCancel.setActionCommand("Cancel");
		GridBagConstraints gbc_btnCancel = new GridBagConstraints();
		gbc_btnCancel.insets = new Insets(0, 0, 0, 5);
		//gbc_button_1.fill = GridBagConstraints.BOTH;
		gbc_btnCancel.gridx =1;
		gbc_btnCancel.gridy =1;
		gbc_btnCancel.anchor=GridBagConstraints.LINE_START;
		getContentPane().add(btnCancel, gbc_btnCancel);
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.weighty = 1.0;
		
		gbc_panel.insets = new Insets(0, 0, 5, 5);
		gbc_panel.weightx = 0.0;
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 2;
		getContentPane().add(panel, gbc_panel);
		this.entigrator=entigrator;
		this.entity=entity;
		System.out.println("ControlDialog:entity="+entity.getProperty("label"));
		//String w0$=entity.getElementItemAt("operator","w0");
		//w0Text.setText(w0$);
		String mc$=entity.getElementItemAt("operator","mc");
		mcText.setText(mc$);
		setSize(200,150);	
		super.setVisible(true);
		}
	
	public void actionPerformed(ActionEvent arg0) {
	}

		

	
	
}


