package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPanel;


import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.ApplianceHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

//import jdk.internal.platform.Container;

import java.awt.GridBagLayout;
import java.awt.Desktop;
import java.awt.GridBagConstraints;
import java.awt.Insets;
public class ControllerDialog extends JDialog  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField w0Text;
	private JTextField mcText;
	private JComboBox<String> pCbx;
	Entigrator entigrator;
	Sack entity;
	
	public ControllerDialog(Entigrator entigrator,Sack entity) {
	    super();
	    setTitle("Control panel");
		this.entity=entity;
		this.entigrator=entigrator;
		System.out.println("ControllerDialog;entity="+entity.getProperty("label"));
	    GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{112, 112};
		gridBagLayout.rowHeights = new int[] {10,10, 10, 10,10};
		gridBagLayout.columnWeights = new double[]{0.0,  Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0,0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel w0Label = new JLabel(" w0");
		w0Label.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_w0Label = new GridBagConstraints();
		gbc_w0Label.fill = GridBagConstraints.BOTH;
		gbc_w0Label.insets = new Insets(10, 0, 5, 5);
		gbc_w0Label.gridx = 0;
		gbc_w0Label.gridy = 0;
		getContentPane().add(w0Label, gbc_w0Label);
		
		w0Text = new JTextField();
		w0Text.setColumns(10);
		GridBagConstraints gbc_w0Text = new GridBagConstraints();
		gbc_w0Text.fill = GridBagConstraints.HORIZONTAL;
		gbc_w0Text.insets = new Insets(10, 0, 5, 5);
		gbc_w0Text.gridx = 1;
		gbc_w0Text.gridy = 0;
		getContentPane().add(w0Text, gbc_w0Text);
		
		JLabel mcLabel = new JLabel(" mc");
		mcLabel.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_mcLabel = new GridBagConstraints();
		gbc_mcLabel.fill = GridBagConstraints.BOTH;
		gbc_mcLabel.insets = new Insets(0, 0, 5, 5);
		gbc_mcLabel.gridx = 0;
		gbc_mcLabel.gridy = 1;
		getContentPane().add(mcLabel, gbc_mcLabel);
		
		mcText = new JTextField();
		mcText.setColumns(10);
		GridBagConstraints gbc_mcText = new GridBagConstraints();
		gbc_mcText.fill = GridBagConstraints.HORIZONTAL;
		gbc_mcText.insets = new Insets(0, 0, 5, 5);
		gbc_mcText.gridx = 1;
		gbc_mcText.gridy = 1;
		getContentPane().add(mcText, gbc_mcText);
		
		JLabel pLabel = new JLabel("Protocol");
		pLabel.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_pLabel = new GridBagConstraints();
		gbc_pLabel.fill = GridBagConstraints.BOTH;
		gbc_pLabel.insets = new Insets(0, 0, 5, 5);
		gbc_pLabel.gridx = 0;
		gbc_pLabel.gridy = 2;
		getContentPane().add(pLabel, gbc_pLabel);
		
		
		pCbx= new JComboBox(new String[] {"NOP","Open","Clear"});
		
		GridBagConstraints gbc_pCbx = new GridBagConstraints();
		gbc_pCbx.fill = GridBagConstraints.HORIZONTAL;
		gbc_pCbx.insets = new Insets(0, 0, 5, 5);
		gbc_pCbx.gridx = 1;
		gbc_pCbx.gridy = 2;
		getContentPane().add(pCbx, gbc_pCbx);
		
		JButton btnOk = new JButton("OK");
		btnOk.setHorizontalAlignment(SwingConstants.RIGHT);
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//String w0$=w0Text.getText();
				//entity.putElementItem("operator",new Core("input","w0",w0$));
				//entity.putElementItem("control",new Core("input","w0",w0$));
				String mc$=mcText.getText();
				String w0$=w0Text.getText();
				entity.putElementItem("operator",new Core("input","mc",mc$));
				entity.putElementItem("operator",new Core("input","w0",w0$));
				int pMode=pCbx.getSelectedIndex();
				if(pMode!=0)
					processProtocol(pMode);
				entigrator.putEntity(entity);
				String usp$=entity.getElementItemAt("motor", "usp");
				if(usp$!=null)
					entity.saveXML(usp$);
				//entity.print("operator");
				ControllerDialog.this.dispose();
			}
		});
		btnOk.setActionCommand("OK");
		//btnOk.addActionListener(this);
		GridBagConstraints gbc_btnOk = new GridBagConstraints();
		//gbc_button.fill = GridBagConstraints.BOTH;
		gbc_btnOk.insets = new Insets(0, 0, 0, 5);
		gbc_btnOk.gridx = 0;
		gbc_btnOk.anchor=GridBagConstraints.LINE_END;
		gbc_btnOk.gridy = 3;
		getContentPane().add(btnOk, gbc_btnOk);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setHorizontalAlignment(SwingConstants.LEFT);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ControllerDialog.this.dispose();
			}
		});
		
		btnCancel.setActionCommand("Cancel");
		GridBagConstraints gbc_btnCancel = new GridBagConstraints();
		gbc_btnCancel.insets = new Insets(0, 0, 0, 5);
		//gbc_button_1.fill = GridBagConstraints.BOTH;
		gbc_btnCancel.gridx =1;
		gbc_btnCancel.gridy =3;
		gbc_btnCancel.anchor=GridBagConstraints.LINE_START;
		getContentPane().add(btnCancel, gbc_btnCancel);
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.weighty = 1.0;
		
		gbc_panel.insets = new Insets(0, 0, 5, 5);
		gbc_panel.weightx = 0.0;
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 4;
		getContentPane().add(panel, gbc_panel);
		this.entigrator=entigrator;
		this.entity=entity;
		System.out.println("ControlDialog:entity="+entity.getProperty("label"));
		//String w0$=entity.getElementItemAt("operator","w0");
		//w0Text.setText(w0$);
		String mc$=entity.getElementItemAt("operator","mc");
		mcText.setText(mc$);
		String w0$=entity.getElementItemAt("operator","w0");
		w0Text.setText(w0$);
		String flux$=entity.getElementItemAt("operator","flux");
		if("constant".equals(flux$))
			pCbx.setSelectedIndex(0);
		else
			pCbx.setSelectedIndex(1);
		setSize(250,200);	
		super.setVisible(true);
		}


	 void processProtocol(int pMode) {
		 
		 String controller$=ApplianceHandler.listApplianceComponents(entigrator, entity.getKey())[0];
		 
		 String home$=entigrator.folderFile(controller$).getPath();
		 
		 File protocol=new File(home$+"/protocol.csv");
		 if(!protocol.exists()) {
			 JOptionPane.showMessageDialog(this, "Protocol doesn't exist");
			 return;
		 }
			 
		 if(pMode==1) {
			 try {
				   if (Desktop.isDesktopSupported()) {
				    Desktop.getDesktop().open(protocol);
				   }
				  } catch (IOException ioe) {
				   System.out.println("ControllerDialog:"+ioe.toString());
				 }
		 }
		 if(pMode==2) {
			 try {
				 protocol.delete();	 
				   
				  } catch (Exception e) {
					  System.out.println("ControllerDialog:"+e.toString());
				 }
		 }
	 }
	
}


