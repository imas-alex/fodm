package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet;

import java.util.Properties;

import javax.swing.JPopupMenu;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VFmodelHandler;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ZLaunchHandler;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.vlaunch.JVLaunchEditor;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.zlaunch.JZLaunchEditor;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.facet.FacetMaster.JAllFacetsItem;
import gdt.gui.facet.FacetMaster.JEntityFacetsItem;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;

public class ZLaunchMaster extends FacetMaster{
	public static final String KEY="_yseb8Fi56DAzUPWDvkQTe3B_2w8";
	public ZLaunchMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.ZLaunchMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ZLaunchHandler");
	    locator.put(HANDLER_KEY,"_BOiROXZ_S78qwj6DlVa9Oq4hJ0jE");
	    locator.put(Locator.LOCATOR_TITLE,"ZLaunch");
	    locator.put(MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "zlaunch.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_TYPE,"zlaunch");
	    return Locator.toString(locator);
	    
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String controllerLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, controllerLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= ZLaunchHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		//System.out.println("VectorMaster:getFacetHandler:locator="+locator$);
		return new ZLaunchHandler(console.getEntigrator(),handlerLocator$); 
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public String getName() {
		return "ZLaunch";
	}

	@Override
	public String getType() {
		return "zlaunch";
	}

	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String parent$=Locator.getProperty(locator$, JContext.PARENT);
			String zlaunchlEditor$=JZLaunchEditor.classLocator();
			zlaunchlEditor$=Locator.merge(zlaunchlEditor$,locator$);
			zlaunchlEditor$=Locator.append(zlaunchlEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			if(parent$!=null)
			  zlaunchlEditor$=Locator.append(zlaunchlEditor$,JContext.PARENT,parent$);
			//System.out.println("VectorMaster:entityFacetsItemOnClick:1");
			JZLaunchEditor zlaunchEditor=new JZLaunchEditor(console,zlaunchlEditor$);
			//System.out.println("VectorMaster:entityFacetsItemOnClick:2");
			console.replaceContext(context,(JContext)zlaunchEditor);
		}catch(Exception e) {
			System.out.println("ZLaunchMaster:entityFacetsItemOnClick:"+e.toString());	
		}
		
	}

	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLocator() {
		return classLocator();
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",ZLaunchHandler.KEY,ZLaunchHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("ZLaunchMaster:putToSession:"+e.toString());
	    }
	}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}


	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		//System.out.println("MechanicMaster:createEntity:entity="+entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4",getType(),classLocator()));
		entity.putAttribute(new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4","icon","zlaunch.png"));
		entigrator.putEntity(entity);
		
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty( "operator","true", entity.getKey());
	//	String vfmodelHandler$=VFmodelHandler.classLocator();
	//	vfmodelHandler$=Locator.append(vfmodelHandler$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
	//	VFmodelHandler	 vectorHandler=getFacetHandler(entigrator, vfmodelHandler$);
		Properties adapterLocator=new Properties();
		entityKey$=entigrator.getKey(entityLabel$);
	    adapterLocator.put(Entigrator.ENTITY_KEY, entityKey$);
	    adapterLocator.put(SegueController.SEGUE_HANDLER, "ZLaunchHandler");
	    adapterLocator.put(SegueController.SEGUE_INSTANCE, "zlaunchHandler");
	    adapterLocator.put(SegueController.SEGUE_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ZLaunchHandler");
	    String adapterLocator$=Locator.toString(adapterLocator);
		SegueController.createAdapter(entigrator, adapterLocator$);
		return entity;
	}

}
