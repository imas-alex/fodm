package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Properties;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;


import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ControllerHandler;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.controller.JControllerEditor;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JAllFacetsList;
import gdt.gui.console.JDesignPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.entity.JListEntities;
import gdt.gui.facet.FacetMaster;
import gdt.gui.facet.FacetMaster.JAllFacetsItem;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;

public class ControllerMaster extends FacetMaster{
	public static final String KEY="_R4Tj3paccYriPmC0g6EkKGX7Yn8";
	public static final String NAME="Controller";
	public ControllerMaster() {
		super();
	}
	
	public ControllerMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
		// TODO Auto-generated constructor stub
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return NAME;
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.ControllerMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,ControllerHandler.CONTROLLER_FACET_CLASS);
	    locator.put(HANDLER_KEY,"_9XhC90iPxk2PqyLhtm6iIOZHl84");
	    locator.put(Locator.LOCATOR_TITLE,"Controller");
	    locator.put(MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "controller.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
	    locator.put(FacetHandler.FACET_TYPE,ControllerHandler.CONTROLLER_FACET_TYPE);
	    return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String controllerLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, controllerLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		
		return itemPanel;
	}

	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		System.out.println("ControllerMaster:getJEntityFacetsItem:locator="+handlerLocator$);
		String itemLocator$=JItemPanel.classLocator();
		String controllerLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, controllerLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= ControllerHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new ControllerHandler(console.getEntigrator(),handlerLocator$); 
	}

	

	@Override
	public void allFacetsItemOnClick(JMainConsole console, String locator$) {
		//listMembers(console,"controller");
		listFacetMembers(console,context,classLocator());
	}

	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			System.out.println("ControllerMaster:entityFacetsItemOnClick:entity label="+entityLabel$);
			String controllerEditor$=JControllerEditor.classLocator();
			controllerEditor$=Locator.merge(controllerEditor$,alocator$);
			controllerEditor$=Locator.append(controllerEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			JControllerEditor controllerEditor=new JControllerEditor(console,controllerEditor$);
			//JApplianceEditor applianceEditor=(JApplianceEditor)JContext.build(console,applianceEditor$);
			console.replaceContext(context,(JContext)controllerEditor);
		}catch(Exception e) {
			System.out.println("ApplianceMaster:entityFacetsItemOnClick:"+e.toString());	
		}
		
	}

	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		final String itemLocator$=alocator$;
		JPopupMenu popup=new JPopupMenu();
		JMenuItem newItem=new JMenuItem("New controller");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("ControllerMaster:allFacetsItemPopup:new entity:locator="+itemLocator$);
				popup.setVisible(false);
				String textEditor$=JTextEditor.classLocator();
				textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New controller");
				String facetList$=JEntityFacetList.classLocator();
				facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
				facetList$=Locator.append(facetList$,MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.ControllerMaster");
				facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
				SessionHandler.putLocator(console.getEntigrator(),facetList$);
				textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
				JTextEditor textEditor=new JTextEditor(console,textEditor$);
				console.replaceContext(context,textEditor);
			}
		} );
		popup.add(newItem);
		return popup;
	}

	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getType() {
		return "controller";
	}

	@Override
	public void addToSession(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Sack createEntity(Entigrator entigrator, String entitylabel$) {
		// TODO Auto-generated method stub
		return null;
	}
}
