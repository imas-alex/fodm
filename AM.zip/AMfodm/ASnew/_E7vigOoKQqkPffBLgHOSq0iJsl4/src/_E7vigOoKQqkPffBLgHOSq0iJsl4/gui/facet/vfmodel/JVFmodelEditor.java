package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.vfmodel;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Scanner;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.EventHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.FileTool;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JGuiEditor;
import java.awt.GridBagLayout;
import javax.swing.JLabel;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VFmodelHandler;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler.M2;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler.Z;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.JPlotEditor;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V4;

import java.awt.GridBagConstraints;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.JPanel;


public class JVFmodelEditor extends JGuiEditor{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_bbtkmai_SafvoWCoBZcvPHZYzNl8";
	public static final String TEST_NOMINAL="Nominal";
	public static final String TEST_STATIC_GIVEN="Static(given)";
	public static final String TEST_STATIC_ESTIMATED="Static(estimated)";
	public static final String TEST_VECTOR_GIVEN="Vector(given)";
	public static final String TEST_VECTOR_ESTIMATED="Vector(estimated)";
	JComboBox<String> cbxMotor;
	JComboBox<String> cbxTest;
	JTextField txtFconst;
	JTextField txtVmin;
	JTextField txtVdelta;
	JTextField txtVcount;
	
	JTextField txtVconst;
	JTextField txtFmin;
	JTextField txtFdelta;
	JTextField txtFcount;
	
	JTextField txtVFconst;
	JTextField txtVFvmin;
	JTextField txtVFdelta;
	JTextField txtVFcount;
	
	JTextField txtV;
	JTextField txtF;
	
	JButton btnView;
	JButton btnRun;
	JButton btnFCrun;
	JButton btnFCView;
	JButton btnVCrun;
	JButton btnVCView;
	JButton btnVFCView;
	JButton btnCustomRun;
	JButton btnCustomView;
	Sack entity;
	public JVFmodelEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {1};
		gridBagLayout.rowHeights = new int[] {1};
		gridBagLayout.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0.0, 1.0};
		setLayout(gridBagLayout);
		System.out.println("JVFmodelEditor:BEGIN");
		JLabel lblMotor = new JLabel("Motor");
		lblMotor.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
				String motor$=(String)cbxMotor.getSelectedItem();
				 Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
	              if(motor==null) {
	            	  System.out.println("JDriveEditor:cannot find entity="+motor$);
	            	  return;
	              }
	              String servicesLocator$=JEntityFacetList.classLocator();
	              servicesLocator$=Locator.append(servicesLocator$, Entigrator.ENTITY_LABEL, motor$);
	              JEntityFacetList entityFacetList=new JEntityFacetList(console,servicesLocator$);
				  JDisplay display=new JDisplay(console);
				  display.putContext(entityFacetList);
				  display.setLocationRelativeTo(JVFmodelEditor.this);
				  display.setVisible(true);
				  display.pack();
				  display.revalidate();
				  display.repaint();
				  //entityFacetList.rebuild(console);
				}catch(Exception ee) {
					System.out.println("JVFmodelEditor:motor click:"+ee.toString());
				}
				
			}
		});
		GridBagConstraints gbc_lblMotor = new GridBagConstraints();
		gbc_lblMotor.insets = new Insets(5, 5, 5, 5);
		gbc_lblMotor.gridx = 0;
		gbc_lblMotor.gridy = 0;
		add(lblMotor, gbc_lblMotor);
		
		cbxMotor = new JComboBox<String>();
		cbxMotor.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				String motor$=(String)cbxMotor.getSelectedItem();
				if(!entity.existsElement("vector"))
		    		entity.createElement("vector");
	    		entity.putElementItem("vector", new Core(null,"motor",motor$));	
				console.getEntigrator().putEntity(entity);
			}
		});
		GridBagConstraints gbc_cbxMotor = new GridBagConstraints();
		gbc_cbxMotor.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxMotor.gridx = 1;
		gbc_cbxMotor.gridy = 0;
		gbc_cbxMotor.insets = new Insets(5, 5, 5, 0);
		add(cbxMotor, gbc_cbxMotor);
		
		JLabel lblTest = new JLabel("Test");
		GridBagConstraints gbc_lblTest = new GridBagConstraints();
		gbc_lblTest.insets = new Insets(5, 5, 5, 5);
		gbc_lblTest.gridx = 0;
		gbc_lblTest.gridy = 1;
		add(lblTest, gbc_lblTest);
		
		cbxTest = new JComboBox<String>();
		cbxTest.setModel(new DefaultComboBoxModel<String>(new String[] {
				TEST_NOMINAL,
				TEST_STATIC_GIVEN,
				TEST_STATIC_ESTIMATED,
				TEST_VECTOR_GIVEN,
				TEST_VECTOR_ESTIMATED					
		}));
		cbxTest.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				String motor$=(String)cbxMotor.getSelectedItem();
				if(!entity.existsElement("vector"))
		    		entity.createElement("vector");
	    		entity.putElementItem("vector", new Core(null,"test",motor$));	
				console.getEntigrator().putEntity(entity);
				String test$=(String)cbxTest.getSelectedItem();
				System.out.println("JVFEditor:test="+test$);
				if(TEST_NOMINAL.equals(test$)) {
					btnCustomRun.setEnabled(false);
					btnCustomView.setEnabled(false);
					btnFCrun.setEnabled(false);
					btnFCView.setEnabled(false);
					//btnRun.setEnabled(false);
					btnVCrun.setEnabled(false);
					btnVCView.setEnabled(false);
					btnVFCView.setEnabled(false);
					//btnView.setEnabled(false);
				}else {
					btnCustomRun.setEnabled(true);
					btnCustomView.setEnabled(true);
					btnFCrun.setEnabled(true);
					btnFCView.setEnabled(true);
					//btnRun.setEnabled(true);
					btnVCrun.setEnabled(true);
					btnVCView.setEnabled(true);
					btnVFCView.setEnabled(true);
					//btnView.setEnabled(true);
				}
					
				
			}
		});
		GridBagConstraints gbc_cbxTest = new GridBagConstraints();
		gbc_cbxTest.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxTest.gridx = 1;
		gbc_cbxTest.gridy = 1;
		gbc_cbxTest.insets = new Insets(5, 5, 5, 0);
		add(cbxTest, gbc_cbxTest);
		
		btnRun=new JButton("Run");
		btnRun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			   run();
			}
		});
		GridBagConstraints gbc_btnRun = new GridBagConstraints();
		gbc_btnRun.insets = new Insets(5, 5, 5, 5);
		gbc_btnRun.gridx = 0;
		gbc_btnRun.gridy = 2;
		gbc_btnRun.anchor=GridBagConstraints.LINE_END;
		add(btnRun, gbc_btnRun);
		
		btnView=new JButton("Review");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//String motor$=(String)cbxMotor.getSelectedItem();
								
				JReviewPanel nominalPanel=new JReviewPanel(console,locator$);
				nominalPanel.setSize(300,200);
				nominalPanel.setLocationRelativeTo(JVFmodelEditor.this);
				nominalPanel.setVisible(true);
				
			    
			}
		});
		GridBagConstraints gbc_btnView= new GridBagConstraints();
		gbc_btnView.insets = new Insets(5, 5, 5, 0);
		gbc_btnView.gridx = 1;
		gbc_btnView.gridy = 2;
		gbc_btnView.anchor=GridBagConstraints.LINE_START;
		add(btnView, gbc_btnView);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.insets = new Insets(0, 0, 0, 5);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 3;
		gbc_tabbedPane.gridwidth=3;
		add(tabbedPane, gbc_tabbedPane);
	//F const	
		JPanel fconstPanel = new JPanel();
		tabbedPane.addTab("F constant", null, fconstPanel, null);
		GridBagLayout gbl_fconstPanel = new GridBagLayout();
		gbl_fconstPanel.columnWidths = new int[]{0, 0,1};
		gbl_fconstPanel.rowHeights = new int[]{0, 0, 0,0,0,0};
		gbl_fconstPanel.columnWeights = new double[]{0.0,0.0, Double.MIN_VALUE};
		gbl_fconstPanel.rowWeights = new double[]{0.0, 0.0,0.0, 0.0,0.0,Double.MIN_VALUE};
		fconstPanel.setLayout(gbl_fconstPanel);
		
		JLabel lblNewLabel = new JLabel("F(Hz)");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(5, 5, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		fconstPanel.add(lblNewLabel, gbc_lblNewLabel);

		txtFconst=new JTextField();
		txtFconst.setColumns(10);
		txtFconst.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String f$=txtFconst.getText();
		    	if(!entity.existsElement("fconst"))
		    		entity.createElement("fconst");
	    		entity.putElementItem("fconst", new Core(null,"f",f$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtFconst = new GridBagConstraints();
		gbc_txtFconst.gridx = 1;
		gbc_txtFconst.gridy = 0;
		fconstPanel.add(txtFconst, gbc_txtFconst);
		
		JLabel lblVmin = new JLabel("Vmin(V)");
		GridBagConstraints gbc_lblVmin= new GridBagConstraints();
		gbc_lblVmin.insets = new Insets(5, 5, 5, 5);
		gbc_lblVmin.gridx = 0;
		gbc_lblVmin.gridy = 1;
		fconstPanel.add(lblVmin, gbc_lblVmin);

		txtVmin=new JTextField();
		txtVmin.setColumns(10);
		txtVmin.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String vmin$=txtVmin.getText();
		    	if(!entity.existsElement("fconst"))
		    		entity.createElement("fconst");
	    		entity.putElementItem("fconst", new Core(null,"vmin",vmin$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtVmin = new GridBagConstraints();
		gbc_txtVmin.gridx = 1;
		gbc_txtVmin.gridy = 1;
		fconstPanel.add(txtVmin, gbc_txtVmin);
		
		JLabel lblVdelta = new JLabel("Vdelta(V)");
		GridBagConstraints gbc_lblVdelta= new GridBagConstraints();
		gbc_lblVdelta.insets = new Insets(5, 5, 5, 5);
		gbc_lblVdelta.gridx = 0;
		gbc_lblVdelta.gridy = 2;
		fconstPanel.add(lblVdelta, gbc_lblVdelta);

		txtVdelta=new JTextField();
		txtVdelta.setColumns(10);
		txtVdelta.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String vdelta$=txtVdelta.getText();
		    	if(!entity.existsElement("fconst"))
		    		entity.createElement("fconst");
	    		entity.putElementItem("fconst", new Core(null,"vdelta",vdelta$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtVdelta = new GridBagConstraints();
		gbc_txtVdelta.gridx = 1;
		gbc_txtVdelta.gridy = 2;
		fconstPanel.add(txtVdelta, gbc_txtVdelta);
		
		JLabel lblVcount = new JLabel("Vcount");
		GridBagConstraints gbc_lblVcount= new GridBagConstraints();
		gbc_lblVcount.insets = new Insets(5, 5, 5, 5);
		gbc_lblVcount.gridx = 0;
		gbc_lblVcount.gridy = 3;
		fconstPanel.add(lblVcount, gbc_lblVcount);

		txtVcount=new JTextField();
		txtVcount.setColumns(10);
		txtVcount.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String vcount$=txtVcount.getText();
		    	if(!entity.existsElement("fconst"))
		    		entity.createElement("fconst");
	    		entity.putElementItem("fconst", new Core(null,"vcount",vcount$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtVcount = new GridBagConstraints();
		gbc_txtVcount.gridx = 1;
		gbc_txtVcount.gridy = 3;
		fconstPanel.add(txtVcount, gbc_txtVcount);
		
		btnFCrun=new JButton("Run");
		btnFCrun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			 runFconst();
			}
		});
		GridBagConstraints gbc_btnFCRun = new GridBagConstraints();
		gbc_btnFCRun.insets = new Insets(5, 5, 5, 5);
		gbc_btnFCRun.gridx = 0;
		gbc_btnFCRun.gridy = 4;
		gbc_btnFCRun.anchor=GridBagConstraints.LINE_END;
		fconstPanel.add(btnFCrun, gbc_btnFCRun);
		
		btnFCView=new JButton("Review");
		btnFCView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Sack review=getReview("fconst");
				String data$="fconst"+getReviewSuffix();
				System.out.println("JVFmodelEditor:Fconst:Review:data="+data$);
				transferData(review.getKey(),data$);
				String reviewLocator$=JPlotEditor.classLocator();
				reviewLocator$=Locator.append(reviewLocator$, Entigrator.ENTITY_LABEL, review.getProperty("label"));
				JPlotEditor plotEditor=new JPlotEditor(console,reviewLocator$);
				console.replaceContext(JVFmodelEditor.this, plotEditor);
			}
		});
		GridBagConstraints gbc_btnFCView= new GridBagConstraints();
		gbc_btnFCView.insets = new Insets(5, 5, 5, 0);
		gbc_btnFCView.gridx = 1;
		gbc_btnFCView.gridy = 4;
		gbc_btnFCView.anchor=GridBagConstraints.LINE_START;
		fconstPanel.add(btnFCView, gbc_btnFCView);
	
	//V constant
		JPanel vconstPanel = new JPanel();
		tabbedPane.addTab("V constant", null, vconstPanel, null);
		GridBagLayout gbl_vconstPanel = new GridBagLayout();
		gbl_vconstPanel.columnWidths = new int[]{0, 0,1};
		gbl_vconstPanel.rowHeights = new int[]{0, 0, 0,0,0,0};
		gbl_vconstPanel.columnWeights = new double[]{0.0,0.0, Double.MIN_VALUE};
		gbl_vconstPanel.rowWeights = new double[]{0.0, 0.0,0.0, 0.0,0.0,Double.MIN_VALUE};
		vconstPanel.setLayout(gbl_vconstPanel);
		
		JLabel lblV = new JLabel("V(V)");
		GridBagConstraints gbc_lblV = new GridBagConstraints();
		gbc_lblV.insets = new Insets(5, 5, 5, 5);
		gbc_lblV.gridx = 0;
		gbc_lblV.gridy = 0;
		vconstPanel.add(lblV, gbc_lblV);

		txtVconst=new JTextField();
		txtVconst.setColumns(10);
		txtVconst.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String v$=txtVconst.getText();
		    	if(!entity.existsElement("vconst"))
		    		entity.createElement("vconst");
	    		entity.putElementItem("vconst", new Core(null,"v",v$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtVconst = new GridBagConstraints();
		gbc_txtVconst.gridx = 1;
		gbc_txtVconst.gridy = 0;
		vconstPanel.add(txtVconst, gbc_txtVconst);
		
		JLabel lblFmin = new JLabel("Fmin(Hz)");
		GridBagConstraints gbc_lblFmin= new GridBagConstraints();
		gbc_lblFmin.insets = new Insets(5, 5, 5, 5);
		gbc_lblFmin.gridx = 0;
		gbc_lblFmin.gridy = 1;
		vconstPanel.add(lblFmin, gbc_lblFmin);

		txtFmin=new JTextField();
		txtFmin.setColumns(10);
		txtFmin.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String fmin$=txtFmin.getText();
		    	if(!entity.existsElement("vconst"))
		    		entity.createElement("vconst");
	    		entity.putElementItem("vconst", new Core(null,"fmin",fmin$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtFmin = new GridBagConstraints();
		gbc_txtFmin.gridx = 1;
		gbc_txtFmin.gridy = 1;
		vconstPanel.add(txtFmin, gbc_txtFmin);
		
		JLabel lblFdelta = new JLabel("Fdelta(Hz)");
		GridBagConstraints gbc_lblFdelta= new GridBagConstraints();
		gbc_lblFdelta.insets = new Insets(5, 5, 5, 5);
		gbc_lblFdelta.gridx = 0;
		gbc_lblFdelta.gridy = 2;
		vconstPanel.add(lblFdelta, gbc_lblFdelta);

		txtFdelta=new JTextField();
		txtFdelta.setColumns(10);
		txtFdelta.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String fdelta$=txtFdelta.getText();
		    	if(!entity.existsElement("vconst"))
		    		entity.createElement("vconst");
	    		entity.putElementItem("vconst", new Core(null,"fdelta",fdelta$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtFdelta = new GridBagConstraints();
		gbc_txtFdelta.gridx = 1;
		gbc_txtFdelta.gridy = 2;
		vconstPanel.add(txtFdelta, gbc_txtFdelta);
		
		JLabel lblFcount = new JLabel("Fcount");
		GridBagConstraints gbc_lblFcount= new GridBagConstraints();
		gbc_lblFcount.insets = new Insets(5, 5, 5, 5);
		gbc_lblFcount.gridx = 0;
		gbc_lblFcount.gridy = 3;
		vconstPanel.add(lblFcount, gbc_lblFcount);

		txtFcount=new JTextField();
		txtFcount.setColumns(10);
		txtFcount.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String fcount$=txtFcount.getText();
		    	if(!entity.existsElement("vconst"))
		    		entity.createElement("vconst");
	    		entity.putElementItem("vconst", new Core(null,"fcount",fcount$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtFcount = new GridBagConstraints();
		gbc_txtFcount.gridx = 1;
		gbc_txtFcount.gridy = 3;
		vconstPanel.add(txtFcount, gbc_txtFcount);
		
		btnVCrun=new JButton("Run");
		btnVCrun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			   runVconst();
			}
		});
		GridBagConstraints gbc_btnVCRun = new GridBagConstraints();
		gbc_btnVCRun.insets = new Insets(5, 5, 5, 5);
		gbc_btnVCRun.gridx = 0;
		gbc_btnVCRun.gridy = 4;
		gbc_btnVCRun.anchor=GridBagConstraints.LINE_END;
		vconstPanel.add(btnVCrun, gbc_btnVCRun);
		
		btnVCView=new JButton("Review");
		btnVCView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Sack review=getReview("vconst");
				String data$="vconst"+getReviewSuffix();
				System.out.println("JVFmodelEditor:Vconst:Review:data="+data$);
				transferData(review.getKey(),data$);
				String reviewLocator$=JPlotEditor.classLocator();
				reviewLocator$=Locator.append(reviewLocator$, Entigrator.ENTITY_LABEL, review.getProperty("label"));
				JPlotEditor plotEditor=new JPlotEditor(console,reviewLocator$);
				console.replaceContext(JVFmodelEditor.this, plotEditor);
			}
		});
		GridBagConstraints gbc_btnVCView= new GridBagConstraints();
		gbc_btnVCView.insets = new Insets(5, 5, 5, 0);
		gbc_btnVCView.gridx = 1;
		gbc_btnVCView.gridy = 4;
		gbc_btnVCView.anchor=GridBagConstraints.LINE_START;
		vconstPanel.add(btnVCView, gbc_btnVCView);
	//V/F constant
		//V constant
				JPanel vfconstPanel = new JPanel();
				tabbedPane.addTab("V/F constant", null, vfconstPanel, null);
				GridBagLayout gbl_vfconstPanel = new GridBagLayout();
				gbl_vfconstPanel.columnWidths = new int[]{0, 0,1};
				gbl_vfconstPanel.rowHeights = new int[]{0, 0, 0,0,0,0};
				gbl_vfconstPanel.columnWeights = new double[]{0.0,0.0, Double.MIN_VALUE};
				gbl_vfconstPanel.rowWeights = new double[]{0.0, 0.0,0.0, 0.0,0.0,Double.MIN_VALUE};
				vfconstPanel.setLayout(gbl_vfconstPanel);
				
				JLabel lblVF = new JLabel("V/F");
				GridBagConstraints gbc_lblVF = new GridBagConstraints();
				gbc_lblVF.insets = new Insets(5, 5, 5, 5);
				gbc_lblVF.gridx = 0;
				gbc_lblVF.gridy = 0;
				vfconstPanel.add(lblVF, gbc_lblVF);

				txtVFconst=new JTextField();
				txtVFconst.setColumns(10);
				txtVFconst.addCaretListener(new CaretListener() {
					@Override
					public void caretUpdate(CaretEvent e) {
				    	String vf$=txtVFconst.getText();
				    	if(!entity.existsElement("vfconst"))
				    		entity.createElement("vfconst");
			    		entity.putElementItem("vfconst", new Core(null,"vf",vf$));	
						console.getEntigrator().putEntity(entity);
						 }
			      });
				GridBagConstraints gbc_txtVFconst = new GridBagConstraints();
				gbc_txtVFconst.gridx = 1;
				gbc_txtVFconst.gridy = 0;
				vfconstPanel.add(txtVFconst, gbc_txtVFconst);
				
				JLabel lblFvmin = new JLabel("Fmin(Hz)");
				GridBagConstraints gbc_lblFvmin= new GridBagConstraints();
				gbc_lblFvmin.insets = new Insets(5, 5, 5, 5);
				gbc_lblFvmin.gridx = 0;
				gbc_lblFvmin.gridy = 1;
				vfconstPanel.add(lblFvmin, gbc_lblFvmin);

				txtVFvmin=new JTextField();
				txtVFvmin.setColumns(10);
				txtFmin.addCaretListener(new CaretListener() {
					@Override
					public void caretUpdate(CaretEvent e) {
				    	String fmin$=txtFmin.getText();
				    	if(!entity.existsElement("vfconst"))
				    		entity.createElement("vfconst");
			    		entity.putElementItem("vfconst", new Core(null,"vfmin",fmin$));	
						console.getEntigrator().putEntity(entity);
						 }
			      });
				GridBagConstraints gbc_txtFvmin = new GridBagConstraints();
				gbc_txtFvmin.gridx = 1;
				gbc_txtFvmin.gridy = 1;
				vfconstPanel.add(txtVFvmin, gbc_txtFvmin);
				
				JLabel lblFvdelta = new JLabel("Fdelta(Hz)");
				GridBagConstraints gbc_lblFvdelta= new GridBagConstraints();
				gbc_lblFvdelta.insets = new Insets(5, 5, 5, 5);
				gbc_lblFvdelta.gridx = 0;
				gbc_lblFvdelta.gridy = 2;
				vfconstPanel.add(lblFvdelta, gbc_lblFvdelta);

				txtVFdelta=new JTextField();
				txtVFdelta.setColumns(10);
				txtVFdelta.addCaretListener(new CaretListener() {
					@Override
					public void caretUpdate(CaretEvent e) {
				    	String fdelta$=txtVFdelta.getText();
				    	if(!entity.existsElement("vfconst"))
				    		entity.createElement("vfconst");
			    		entity.putElementItem("vfconst", new Core(null,"vfdelta",fdelta$));	
						console.getEntigrator().putEntity(entity);
						 }
			      });
				GridBagConstraints gbc_txtFvdelta = new GridBagConstraints();
				gbc_txtFvdelta.gridx = 1;
				gbc_txtFvdelta.gridy = 2;
				vfconstPanel.add(txtVFdelta, gbc_txtFvdelta);
				
				JLabel lblVFcount = new JLabel("Fcount");
				GridBagConstraints gbc_lblVFcount= new GridBagConstraints();
				gbc_lblVFcount.insets = new Insets(5, 5, 5, 5);
				gbc_lblVFcount.gridx = 0;
				gbc_lblVFcount.gridy = 3;
				vfconstPanel.add(lblVFcount, gbc_lblVFcount);

				txtVFcount=new JTextField();
				txtVFcount.setColumns(10);
				txtVFcount.addCaretListener(new CaretListener() {
					@Override
					public void caretUpdate(CaretEvent e) {
				    	String vfcount$=txtVFcount.getText();
				    	if(!entity.existsElement("vfconst"))
				    		entity.createElement("vfconst");
			    		entity.putElementItem("vfconst", new Core(null,"vfcount",vfcount$));	
						console.getEntigrator().putEntity(entity);
						 }
			      });
				GridBagConstraints gbc_txtFvcount = new GridBagConstraints();
				gbc_txtFvcount.gridx = 1;
				gbc_txtFvcount.gridy = 3;
				vfconstPanel.add(txtVFcount, gbc_txtFvcount);
				
				JButton btnVFCrun=new JButton("Run");
				btnVFCrun.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						runVFconst();
					}
				});
				GridBagConstraints gbc_btnVFCRun = new GridBagConstraints();
				gbc_btnVFCRun.insets = new Insets(5, 5, 5, 5);
				gbc_btnVFCRun.gridx = 0;
				gbc_btnVFCRun.gridy = 4;
				gbc_btnVFCRun.anchor=GridBagConstraints.LINE_END;
				vfconstPanel.add(btnVFCrun, gbc_btnVFCRun);
				
				btnVFCView=new JButton("Review");
				btnVFCView.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Sack review=getReview("vfconst");
						String data$="vfconst"+getReviewSuffix();
						System.out.println("JVFmodelEditor:Vconst:Review:data="+data$);
						transferData(review.getKey(),data$);
						String reviewLocator$=JPlotEditor.classLocator();
						reviewLocator$=Locator.append(reviewLocator$, Entigrator.ENTITY_LABEL, review.getProperty("label"));
						JPlotEditor plotEditor=new JPlotEditor(console,reviewLocator$);
						console.replaceContext(JVFmodelEditor.this, plotEditor);
					}
				});
				GridBagConstraints gbc_btnVFCView= new GridBagConstraints();
				gbc_btnVFCView.insets = new Insets(5, 5, 5, 0);
				gbc_btnVFCView.gridx = 1;
				gbc_btnVFCView.gridy = 4;
				gbc_btnVFCView.anchor=GridBagConstraints.LINE_START;
				vfconstPanel.add(btnVFCView, gbc_btnVFCView);
	//custom
				JPanel customPanel = new JPanel();
				tabbedPane.addTab("Custom", null, customPanel, null);
				GridBagLayout gbl_custormPanel = new GridBagLayout();
				gbl_custormPanel.columnWidths = new int[]{0, 0,1};
				gbl_custormPanel.rowHeights = new int[]{0, 0, 0,0,0,0};
				gbl_custormPanel.columnWeights = new double[]{0.0,0.0, Double.MIN_VALUE};
				gbl_custormPanel.rowWeights = new double[]{0.0, 0.0,0.0,Double.MIN_VALUE};
				customPanel.setLayout(gbl_custormPanel);
				
				JLabel lblVcustom = new JLabel("V(V)");
				GridBagConstraints gbc_lblVcustom	= new GridBagConstraints();
				gbc_lblVcustom.insets = new Insets(5, 5, 5, 5);
				gbc_lblVcustom.gridx = 0;
				gbc_lblVcustom.gridy = 0;
				customPanel.add(lblVcustom, gbc_lblVcustom);

				txtV=new JTextField();
				txtV.setColumns(10);
				txtV.addCaretListener(new CaretListener() {
					@Override
					public void caretUpdate(CaretEvent e) {
				    	String v$=txtV.getText();
				    	if(!entity.existsElement("custom"))
				    		entity.createElement("custom");
			    		entity.putElementItem("custom", new Core(null,"v",v$));	
						console.getEntigrator().putEntity(entity);
						 }
			      });
				GridBagConstraints gbc_txtV = new GridBagConstraints();
				gbc_txtV.gridx = 1;
				gbc_txtV.gridy = 0;
				customPanel.add(txtV, gbc_txtV);
				
				JLabel lblF = new JLabel("F(Hz)");
				GridBagConstraints gbc_lblF= new GridBagConstraints();
				gbc_lblF.insets = new Insets(5, 5, 5, 5);
				gbc_lblF.gridx = 0;
				gbc_lblF.gridy = 1;
				customPanel.add(lblF, gbc_lblF);

				txtF=new JTextField();
				txtF.setColumns(10);
				txtF.addCaretListener(new CaretListener() {
					@Override
					public void caretUpdate(CaretEvent e) {
				    	String f$=txtF.getText();
				    	if(!entity.existsElement("custom"))
				    		entity.createElement("custom");
			    		entity.putElementItem("custom", new Core(null,"f",f$));	
						console.getEntigrator().putEntity(entity);
						 }
			      });
				GridBagConstraints gbc_txtF = new GridBagConstraints();
				gbc_txtF.gridx = 1;
				gbc_txtF.gridy = 1;
				customPanel.add(txtF, gbc_txtF);
				btnCustomRun=new JButton("Run");
				btnCustomRun.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
					   runCustom();
					}
				});
				GridBagConstraints gbc_btnCustomRun = new GridBagConstraints();
				gbc_btnCustomRun.insets = new Insets(5, 5, 5, 5);
				gbc_btnCustomRun.gridx = 0;
				gbc_btnCustomRun.gridy = 2;
				gbc_btnCustomRun.anchor=GridBagConstraints.LINE_END;
				customPanel.add(btnCustomRun, gbc_btnCustomRun);
				
				btnCustomView=new JButton("Review");
				btnCustomView.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Sack review=getReview("custom");
						String data$="custom"+getReviewSuffix();
						System.out.println("JVFmodelEditor:Custom:Review:data="+data$);
						transferData(review.getKey(),data$);
						String reviewLocator$=JPlotEditor.classLocator();
						reviewLocator$=Locator.append(reviewLocator$, Entigrator.ENTITY_LABEL, review.getProperty("label"));
						JPlotEditor plotEditor=new JPlotEditor(console,reviewLocator$);
						console.replaceContext(JVFmodelEditor.this, plotEditor);
					}
				});
				GridBagConstraints gbc_btnCustomView= new GridBagConstraints();
				gbc_btnCustomView.insets = new Insets(5, 5, 5, 0);
				gbc_btnCustomView.gridx = 1;
				gbc_btnCustomView.gridy = 2;
				gbc_btnCustomView.anchor=GridBagConstraints.LINE_START;
				customPanel.add(btnCustomView, gbc_btnCustomView);
					
		String entityLabel$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		if(entityLabel$!=null)
			entity=console.getEntigrator().getEntityAtLabel(entityLabel$);
		System.out.println("JVFmodelEditor:FINISH");
		init();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(JContext.CONTEXT_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.vfmodel.JVFmodelEditor");
	    locator.put(Locator.LOCATOR_TITLE,"VFmodel");
	    locator.put(FacetHandler.FACET_KEY,KEY);
	    locator.put(FacetHandler.FACET_NAME,"VFmodel");
	    locator.put(FacetHandler.FACET_TYPE,"vfmodel");
	    locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.VFmodelMaster");
	    locator.put(IconLoader.ICON_FILE,"vfmodel.png");
	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		 return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}

	@Override
	public String reply(JMainConsole console, String locator$) {
		return locator$;
	}
	private void init() {
		try {
			String[] sa=console.getEntigrator().listEntities("motor",Locator.LOCATOR_TRUE);
			DefaultComboBoxModel <String>model=new DefaultComboBoxModel<String>();
			ArrayList<String>sl=new ArrayList<String>();
			String label$;
			if(sa!=null) {
				for(String s:sa) {
					label$=console.getEntigrator().getLabel(s);
					if(label$!=null)
						sl.add(label$);
				}
			sa=new String[sl.size()];
			sl.toArray(sa);
			Arrays.sort(sa);
			model=new DefaultComboBoxModel<String>(sa);
			}
			cbxMotor.setModel(model);
			if(!entity.existsElement("vector"))
				entity.createElement("vector");
			String motor$=entity.getElementItemAt("vector", "motor");
			if(motor$!=null)
				selectCombo(cbxMotor,motor$);
			else {
				cbxMotor.setSelectedIndex(0);
			}
			console.getEntigrator().putEntity(entity);
			btnCustomRun.setEnabled(false);
			btnCustomView.setEnabled(false);
			btnFCrun.setEnabled(false);
			btnFCView.setEnabled(false);
			//btnRun.setEnabled(false);
			btnVCrun.setEnabled(false);
			btnVCView.setEnabled(false);
			btnVFCView.setEnabled(false);
			//btnView.setEnabled(false);
			txtFconst.setText(entity.getElementItemAt("fconst", "f"));
			txtVmin.setText(entity.getElementItemAt("fconst", "vmin"));
			txtVdelta.setText(entity.getElementItemAt("fconst", "vdelta"));
			txtVcount.setText(entity.getElementItemAt("fconst", "vcount"));
			txtVconst.setText(entity.getElementItemAt("vconst", "v"));
			txtFmin.setText(entity.getElementItemAt("vconst", "fmin"));
			txtFdelta.setText(entity.getElementItemAt("vconst", "fdelta"));
			txtFcount.setText(entity.getElementItemAt("vconst", "fcount"));
			txtVFconst.setText(entity.getElementItemAt("vfconst", "vf"));
			txtVFvmin.setText(entity.getElementItemAt("vfconst", "vfmin"));
			txtVFdelta.setText(entity.getElementItemAt("vfconst", "vfdelta"));
			txtVFcount.setText(entity.getElementItemAt("vfconst", "vfcount"));
			txtV.setText(entity.getElementItemAt("custom", "v"));
			txtF.setText(entity.getElementItemAt("custom", "f"));
			
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:init:"+e.toString());
		}
	}
	private void run() {
		try {
			if(entity!=null) 
				System.out.println("JVFmodelEditor:run:entity="+entity.getKey()+"  motor="+cbxMotor.getSelectedItem() );
			String motor$=(String)cbxMotor.getSelectedItem();
			Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
			String test$=(String)cbxTest.getSelectedItem();
			if(TEST_NOMINAL.equals(test$)) {
				motor=MotorHandler.par_n2d(motor);
				//motor=MotorHandler.par_d2z(motor);
				if(!entity.existsElement("test.nominal"))
					entity.createElement("test.nominal");
				Core[] ca=motor.elementGet("dpar");
				if(ca!=null) {	
					for(Core c:ca)
						if(c.name.equals("Mn")
						  ||c.name.equals("Mmax")		
						  ||c.name.equals("Isn")		
						)
						entity.putElementItem("test.nominal", c);
				}
					 ca=motor.elementGet("primary");
						if(ca!=null) {	
							for(Core c:ca)
								if(c.name.equals("cos")
								  ||c.name.equals("Eta")		
								)
								entity.putElementItem("test.nominal", c);	
				console.getEntigrator().putEntity(entity);
				}
			}
			if(TEST_STATIC_ESTIMATED.equals(test$)) {
				motor=MotorHandler.z_makeNomState(motor, false);
				//motor=MotorHandler.par_d2z(motor);
				if(!entity.existsElement("test.static.estimated"))
					entity.createElement("test.static.estimated");
				
			  Core[] ca=motor.elementGet("zvar");
			  for(Core c:ca) {
				  if(c.name.equals("cos")
					||c.name.equals("eta")
					||c.name.equals("isd")
					||c.name.equals("m")
					//||c.name.equals("mmaxm")
						)  
					  entity.putElementItem("test.static.estimated", c);		  
			  }
			  motor=MotorHandler.z_makeCriticalValues(motor, false);
			  Core core=motor.getElementItem("zvar", "mmaxm");
			  entity.putElementItem("test.static.estimated", core);
			  Core core2=motor.getElementItem("zvar", "skm");
			  entity.putElementItem("test.static.estimated", core2);
			console.getEntigrator().putEntity(entity);   
			}
			if(TEST_STATIC_GIVEN.equals(test$)) {
				motor=MotorHandler.z_makeNomState(motor, true);
				//motor=MotorHandler.par_d2z(motor);
				if(!entity.existsElement("test.static.given"))
					entity.createElement("test.static.given");
				
			  Core[] ca=motor.elementGet("zvar");
			  for(Core c:ca) {
				  if(c.name.equals("cos")
					||c.name.equals("eta")
					||c.name.equals("isd")
					||c.name.equals("m")
					//||c.name.equals("mmaxm")
						)  
					  entity.putElementItem("test.static.given", c);		  
			  }
			  motor=MotorHandler.z_makeCriticalValues(motor, true);
			  Core core=motor.getElementItem("zvar", "mmaxm");
			  entity.putElementItem("test.static.given", core);
			  Core core2=motor.getElementItem("zvar", "skm");
			  entity.putElementItem("test.static.given", core2);
			console.getEntigrator().putEntity(entity);   
			}
			if(TEST_VECTOR_GIVEN.equals(test$)) {
				//motor=MotorHandler.par_d2z(motor);
				if(!entity.existsElement("test.vector.given"))
					entity.createElement("test.vector.given");
				
			//motor=MotorHandler.z_makeNomState(motor, true);
			//motor=MotorHandler.par_gvn2e(motor);
			//motor.printElement("epar");
			console.getEntigrator().putEntity(motor);   
			String sn$=motor.getElementItemAt("primary", "sn");
			double sn=Double.parseDouble(sn$);
			//Hashtable  <String,Double> state= vectorMode(sn);
			Hashtable  <String,Double> state= makeVstate(sn);
			double mn=state.get("m");
			state.put("mn", mn);
			String skm$=entity.getElementItemAt("test.static.given", "skm");
			if(skm$!=null) {
			double skm=Double.parseDouble(skm$);
			//Hashtable  <String,Double> state2= vectorMode(skm);
			Hashtable  <String,Double> state2= makeVstate(skm);
			double mmaxm=state2.get("m");
			state.put("mmaxm", mmaxm);
			//System.out.println("JVectorEditor:run:vector estimated:mmaxm="+mmaxm);
			}
			Enumeration<String> en=state.keys();
			String key$;
			Double val;
			if(!entity.existsElement("test.vector.given"))
				entity.createElement("test.vector.given");
			while(en.hasMoreElements()) {
				
				key$=en.nextElement();
				if("m".equals(key$))
					continue;
				val=state.get(key$);
				entity.putElementItem("test.vector.given", new Core(null,key$,String.valueOf(val)));
			}
			console.getEntigrator().putEntity(entity);   
			}
          if(TEST_VECTOR_ESTIMATED.equals(test$)) {
				
				//motor=MotorHandler.par_d2z(motor);
				if(!entity.existsElement("test.vector.estimated"))
					entity.createElement("test.vector.estimated");
				
			//motor=MotorHandler.z_makeNomState(motor, true);
			//motor=MotorHandler.par_z2e(motor);
			//motor=MotorHandler.par_z2e(motor);
			console.getEntigrator().putEntity(motor);  
			String sn$=motor.getElementItemAt("primary", "sn");
			double sn=Double.parseDouble(sn$);
			//Hashtable  <String,Double> state= vectorMode(sn);
			Hashtable  <String,Double> state= makeVstate(sn);
			//EduHandler.printHashtableDouble("vector.estimated", state);
			double mn=state.get("m");
			state.put("mn", mn);
			String skm$=entity.getElementItemAt("test.static.estimated", "skm");
			if(skm$!=null) {
			double skm=Double.parseDouble(skm$);
			//Hashtable  <String,Double> state2= vectorMode(skm);
			Hashtable  <String,Double> state2= makeVstate(skm);
			double mmaxm=state2.get("m");
			state.put("mmaxm", mmaxm);
			//System.out.println("JVectorEditor:run:vector estimated:mmaxm="+mmaxm);
			}
			Enumeration<String> en=state.keys();
			String key$;
			Double val;
			if(!entity.existsElement("test.vector.estimated"))
				entity.createElement("test.vector.estimated");
			while(en.hasMoreElements()) {
				key$=en.nextElement();
				if("m".equals(key$))
					continue;
				val=state.get(key$);
				entity.putElementItem("test.vector.estimated", new Core(null,key$,String.valueOf(val)));
			}
			console.getEntigrator().putEntity(entity);   
			}
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:run:"+e.toString());
		}
	}
	private Hashtable  <String,Double>v_makeState(Hashtable  <String,Double>pars){
		try {
			
			double ls=pars.get("ls");
			double rs=pars.get("rs");
			double r2=pars.get("r2");
			double l2=pars.get("l2");
			double lm=pars.get("lm");
			double pol=pars.get("pol");
			double j=pars.get("j");
			double f=pars.get("f");
			double usd=pars.get("usd");
			double s=pars.get("s");
			double um=Math.sqrt(2)*usd;
			System.out.println("JVFmodelEditor:vectorMode:rs="+rs+" ls="+ls+" r2="+l2+" lm="+lm+" f="+f+" us="+usd);
			
			//System.exit(0);
			
			SinCos sinCos=new SinCos(um,f);
			String vfmodelHandler$=VFmodelHandler.classLocator();
			vfmodelHandler$=Locator.append(vfmodelHandler$, Entigrator.ENTITY_LABEL, (String)cbxMotor.getSelectedItem());
			VFmodelHandler vfmodelHandler=new VFmodelHandler(console.getEntigrator(),vfmodelHandler$);
			double time=0;
			V2 us2=new V2(0,0);
			Hashtable <String,Double>ins=new Hashtable <String,Double>();
			Hashtable <String,Double>out=new Hashtable <String,Double>();
			Hashtable <String,Double>settings=new Hashtable <String,Double>();
			//
			settings.put("ls",ls);
			settings.put("rs",rs);
			settings.put("l2",l2);
			settings.put("r2",r2);
			settings.put("lm",lm);
			settings.put("j",j);
			settings.put("pol",pol);
			double clock=1/(f*1000);
			double clockE=0.001*(ls+l2)/(rs+r2);
			if(clockE<clock)
				clock=clockE;
			vfmodelHandler.putSettings(settings);
			double endTime=100/f;
			double endTimeE=10*lm/r2;
			if(endTimeE>endTime)
				endTime=endTimeE;
			double w0=2*Math.PI*f;
			double wr=w0*(1-s);
			System.out.println("JVFmodelEditor:vectorModel:s="+s+"  wr="+wr+" time="+time+" end time="+endTime);
			while(time<endTime) {
				
				us2=sinCos.get(time);
				ins.put("usx", us2.x);
				ins.put("usy", us2.y);
				ins.put("clock", clock);
				ins.put("wr", wr);
				ins.put("mc", 0.0);
				out=vfmodelHandler.stride(ins);
				time=time+clock;
			}
			//EduHandler.printHashtableDouble("vector", out);
			double isx=out.get("isx");
			double isy=out.get("isy");
			double m=out.get("m");
			double is=Math.sqrt(isx*isx+isy*isy)/Math.sqrt(2);
			V2 is2=new V2(isx,isy);
			double angle=us2.angle(is2);
			double cos=Math.cos(Math.toRadians(angle));
			double pe=(is2.dotProduct(us2))*(1.5);
			double eta=m*wr/(pol*pe);
			Hashtable<String, Double>ret=new Hashtable<String, Double>();
			ret.put("cos", cos);
			ret.put("eta", eta);
			ret.put("m", m);
			ret.put("isd", is);
			//System.out.println("JVectorEditor:nominal:time="+time+" is="+is+ "  cos="+cos+"  angle="+angle+" p="+p+"  pe="+pe+" eta="+p/pe);
			return ret;
			}catch(Exception e) {
				System.out.println("JVFmodelEditor:vectorModel:"+e.toString());
			}
			return null;
		
	}
	private Hashtable  <String,Double>makeVstate(double s) {
		try {
		Hashtable  <String,Double>pars=getTestPars();
		pars.put("s", s);
		return v_makeState(pars);
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:makeVstate:"+e.toString());
		}
		return null;
	}
/*
	private Hashtable  <String,Double> getVFSstate(Hashtable  <String,Double> pars,double usd,double f, double s){ 
		try {
			pars.put("usd", usd);
			pars.put("f", f);
			pars.put("s", s);
			Hashtable<String,Double>state;
			String test$=(String)cbxTest.getSelectedItem();
			if(TEST_STATIC_ESTIMATED.equals(test$)||TEST_STATIC_GIVEN.equals(test$))
			     state=MotorHandler.z_makeState( pars);
			else 
				state=MotorHandler.z_makeState( pars);
			return state;
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:getVFSstate:"+e.toString());	
		}
		return null;
}
	*/
	private Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
		try {
			//input
			double usx=ins.get("usx");
			double usy=ins.get("usy");
			double wr=ins.get("wr");
			double mc=ins.get("mc");
			//parameters
			double clock=Double.MIN_VALUE;
			try {clock=ins.get("clock");}catch(Exception ee) {}
			double ls=ins.get("ls");
			double rs=ins.get("rs");
			double r2=ins.get("r2");
			double l2=ins.get("l2");
			double lm=ins.get("lm");
			double pol=ins.get("pol");
			double j=ins.get("j");
			//state
			double i2x=ins.get("i2x");
			double i2y=ins.get("i2y");
			double isx=ins.get("isx");
			double isy=ins.get("isy");
			double fx=ins.get("fx");
			double fy=ins.get("fy");
			//operator
			V2 i2= new  V2 (i2x,i2y);
			V2 f=new V2(fx,fy);  
			V4 s= new V4(f,i2);
			M2 ll=new M2(1+ls/lm,-ls,1,l2);
			M2 rr=new M2(-rs/lm,rs,0,-r2);
			M2 ee=new M2(0,0,1,l2);
			M2 lli=ll.inverse();
			double m=1.5*pol*f.crossProduct(i2);  
			M2 t1=lli.multiplication(rr);
			V4 s1=t1.product(s);		
			M2 t2=lli.multiplication(ee);
			V4 s2=t2.product(s.componentRotation().product(wr));
			V2 us= new  V2 (usx,usy);
			V4 u=new V4(us,new V2(0,0));
			V4 s3=lli.product(u);
			V4 ds= s1.add(s2).add(s3);
			V4 sn=s.add(ds.product(clock));   
		  	f=sn.v1;
			i2=sn.v2;
			V2 im=f.product(1/lm);
			V2 is=im.product(1).add(i2.product(-1));
			i2x=i2.x;
			i2y=i2.y;
			isx=is.x;
			isy=is.y;
			fx=f.x;
			fy=f.y;
			double dw2=(m-mc)*clock/j;
			double w2=wr/pol;
			w2=w2+dw2;
			wr=pol*w2;
			double id=is.norm()/1.41;
			//output
			Hashtable<String, Double>out=new Hashtable<String, Double>();
			//state
			out.put("i2x",i2x);
			out.put("i2y",i2y);
			out.put("isx",isx);
			out.put("isy",isy);
			out.put("fx",fx);
			out.put("fy",fy);
			//out
			out.put("m",m);
			out.put("wr",wr);
			out.put("w2",w2);
			out.put("id",id);
			//System.out.println("VFmodelEditor:stride:wr="+wr);
			return out;
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:stride:"+e.toString());
		}
	return null;	
	}
	private String getReviewSuffix() {
		StringBuffer suffix=new StringBuffer();
		String test$=(String)cbxTest.getSelectedItem();
        boolean given=true;
        if(TEST_STATIC_ESTIMATED.equals(test$)
        		||TEST_VECTOR_ESTIMATED.equals(test$))
        	given=false;
        boolean staticModel=false;
        if(TEST_STATIC_ESTIMATED.equals(test$)
        		||TEST_STATIC_GIVEN.equals(test$))
        	staticModel=true;
        if(staticModel)
        	suffix.append("stc");
        else
        	suffix.append("vct");
        if(given)
        	suffix.append("gvn");
        else
        	suffix.append("est");
        return suffix.toString();
	}
	private Hashtable  <String,Double> getTestPars(){
		try {
			String motor$=(String)cbxMotor.getSelectedItem();
			Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
            String test$=(String)cbxTest.getSelectedItem();
            boolean given=true;
            if(TEST_STATIC_ESTIMATED.equals(test$)
            		||TEST_VECTOR_ESTIMATED.equals(test$))
            	given=false;
           if(given)
        	   motor=MotorHandler.par_gvn2e(motor);
           else
        	   motor=MotorHandler.par_z2e(motor); 
           double r2=0;
			try{r2=Double.parseDouble(motor.getElementItemAt("epar","r2" ));} catch(NumberFormatException nfe){ r2=0; }
		 double l2=0;
			try{l2=Double.parseDouble(motor.getElementItemAt("epar","l2" ));} catch(NumberFormatException nfe){ r2=0; }
		double rs=0;
			try{rs=Double.parseDouble(motor.getElementItemAt("epar","rs" ));} catch(NumberFormatException nfe){ r2=0; }
		 double ls=0;
			try{ls=Double.parseDouble(motor.getElementItemAt("epar","ls" ));} catch(NumberFormatException nfe){ r2=0; }
			
		double lm=0;
			try{lm=Double.parseDouble(motor.getElementItemAt("epar","lm" ));} catch(NumberFormatException nfe){ lm=0; }
		double f=0;
		try{f=Double.parseDouble(motor.getElementItemAt("primary","f" ));} catch(NumberFormatException nfe){ f=0; }
		double usd=0;	
		try{usd=Double.parseDouble(motor.getElementItemAt("primary","Us" ));} catch(NumberFormatException nfe){ usd=0; }
		double pol=1;	
		try{pol=Double.parseDouble(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
		double j=0;	
		try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
		Hashtable  <String,Double>pars=new Hashtable  <String,Double>();
		pars.put("rs", rs);
		pars.put("ls", ls);
		pars.put("r2", r2);
		pars.put("l2", l2);
		pars.put("lm", lm);
		pars.put("f", f);
		pars.put("usd", usd);
		pars.put("pol", pol);
		pars.put("j", j);
		return pars;
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:getTestPars:"+e.toString());	
		}
		return null;
	}
	private Hashtable  <String,Double> makeStateVector(Hashtable  <String,Double> ins) {
		try {
			//EduHandler.printHashtableDouble("makeStateVector:ins", ins);
			double f=ins.get("f");
			double s=ins.get("s");
			double usd=ins.get("usd");
			double rs=ins.get("rs");
			double ls=ins.get("ls");
			double r2=ins.get("r2");
			double l2=ins.get("l2");
			double lm=ins.get("lm");
			double pol=ins.get("pol");
			double um=Math.sqrt(2)*usd;
			SinCos sinCos=new SinCos(um,f);
			V2 us2=new V2(0,0);
			Hashtable <String,Double>out=new Hashtable <String,Double>();
			double clock=1/(f*1000);
			double clockE=0.001*(ls+l2)/(rs+r2);
			if(clockE<clock)
				clock=clockE;
			double endTime=100/f;
			double endTimeE=10*lm/r2;
			if(endTimeE>endTime)
				endTime=endTimeE;
			double w0=2*Math.PI*f;
			double wr=w0*(1-s);
			//System.out.println("JVFmodelEditor:vectorModel:s="+s+"  wr="+wr+" end time="+endTime);
			double time=0;
			ins.put("i2x",0.0);
			ins.put("i2y",0.0);
			ins.put("isx",0.0);
			ins.put("isy",0.0);
			ins.put("fx",0.0);
			ins.put("fy",0.0);
			while(time<endTime) {
				us2=sinCos.get(time);
				ins.put("usx", us2.x);
				ins.put("usy", us2.y);
				ins.put("clock", clock);
				ins.put("wr", wr);
				ins.put("mc", 0.0);
				out=stride(ins);
				time=time+clock;
				ins.put("i2x",out.get("i2x"));
				ins.put("i2y",out.get("i2y"));
				ins.put("isx",out.get("isx"));
				ins.put("isy",out.get("isy"));
				ins.put("fx",out.get("fx"));
				ins.put("fy",out.get("fy"));
			}
			//EduHandler.printHashtableDouble("vector", out);
			double isx=out.get("isx");
			double isy=out.get("isy");
			double m=out.get("m");
			double is=Math.sqrt(isx*isx+isy*isy)/Math.sqrt(2);
			V2 is2=new V2(isx,isy);
			double angle=us2.angle(is2);
			double cos=Math.cos(Math.toRadians(angle));
			double pe=(is2.dotProduct(us2))*(1.5);
			double eta=m*wr/(pol*pe);
			Hashtable<String, Double>ret=new Hashtable<String, Double>();
			ret.put("cos", cos);
			ret.put("eta", eta);
			ret.put("m", m);
			ret.put("isd", is);
			//System.out.println("JVectorEditor:nominal:time="+time+" is="+is+ "  cos="+cos+"  angle="+angle+" p="+p+"  pe="+pe+" eta="+p/pe);
			return ret;
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:makeStateVector:"+e.toString());	
		}
		return null;
	}
	public static Hashtable<String,Double> makeStateStatic(Hashtable<String,Double> ins) {
		try {	
			double	f=ins.get("f");
			double	s=ins.get("s");
			double	usd=ins.get("usd");
			double	rs=ins.get("rs");
			double	ls=ins.get("ls");
			double	r2=ins.get("r2");
			double	l2=ins.get("l2");
			double	lm=ins.get("lm");
			double	pol=ins.get("pol");
			double w0=2*Math.PI*f;
			double xm=w0*lm;
			double xs=w0*ls;
			double x2=w0*l2;
			Z zm=new Z(0,xm);
			Z zs=new Z(rs,xs);
			Z zr=new Z(r2/s,x2);
			Z z1=zm.inverse().product(zr).add(new Z(1,0));
			Z z0=z1.product(zs).add(zr).inverse().product(-1);
			
			V2 us= new V2(Math.sqrt(2)*usd,0);
			V2 i2=z0.product(us); 
			double i2a=i2.norm();
			V2 is=z1.product(i2).product(-1);
			V2 im=is.add(i2);
			
			//double m=(1.5*pol*xm/w0)*i2.rotProduct(im);
			double m=(1.5*pol*lm)*i2.rotProduct(im);
			double isa=is.norm();
			double cos = i2a/isa; //a2
			double isd=isa/Math.sqrt(2);//a0
		//	System.out.println("MotorHandler:z_makeState:isd="+isd);	
			double pl= 3*(i2a*i2a*r2+isa*isa*rs);
			double pow= m*w0/pol;
			double eta=pow/(pow+pl);
			Hashtable<String,Double>out=new Hashtable<String,Double>();
			out.put("isd", isd);
			out.put("m", m);
			out.put("cos", cos);
			out.put("eta", eta);
			//a3
			return out;
		}catch(Exception e) {
			System.out.println("JVFEditor:makeStateStatic:"+e.toString());
			//Sack.traceCalls();
		}
			return null;
	 }
	private void runFconst() {
		try {
			double f=50;
			try {f=Double.parseDouble(txtFconst.getText());}catch(Exception ee) {}
			double vmin=Double.MIN_VALUE;
			try {vmin=Double.parseDouble(txtVmin.getText());}catch(Exception ee) {}
			double vdelta=1;
			try {vdelta=Double.parseDouble(txtVdelta.getText());}catch(Exception ee) {}
			int vcount=10;
			try {vcount=(int) Double.parseDouble(txtVcount.getText());}catch(Exception ee) {}
			Hashtable<String,Double>pars=getTestPars();
			Hashtable<String,Double>state;
			int scount=100;
			double s=-1;
			double deltaS=1.0/scount;
			System.out.println("JVFEditor:runVconst:delta s="+deltaS);
			double usd=vmin;
			pars.put("f", f);
			StringBuffer data=new StringBuffer("fconst");
			boolean staticModel=true;
			String test$=(String)cbxTest.getSelectedItem();
	        if(TEST_VECTOR_ESTIMATED.equals(test$)
	            		||TEST_VECTOR_GIVEN.equals(test$)) 
	        	staticModel=false;
	       
			boolean given=false;
			if(TEST_STATIC_GIVEN.equals(test$)
            		||TEST_VECTOR_GIVEN.equals(test$))
				given=true;
			if(staticModel)
				data.append("stc");
			else
				data.append("vct");
			if(given)
				data.append("gvn");
			else
				data.append("est");
			String path$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/"+data.toString()+".data";
			File out=new File(path$);
			if(out.exists())
				out.delete();
			PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(path$, true)));
			String format$="0.####E0";
			NumberFormat valFormat = new DecimalFormat(format$);
			double wg0=2*Math.PI*f;
			double wg=wg0;
			double m=0;
			StringBuffer sb;
			for(int i=-scount;i<scount;i++) {
				sb=new StringBuffer();
				pars.put("f", f);
			    pars.put("s", s);
			    wg=wg0*(1-s);
			    System.out.println("JVFEditor:runVconst:s="+s+"  wg="+wg+"  wg0="+wg0);
			    sb.append(valFormat.format(wg));
			    usd=vmin;
			    for(int j=0;j<vcount;j++) {
			    	pars.put("usd", usd);
			    	if(!staticModel)
			    		state=makeStateVector(pars);
			    	else
			    		state=makeStateStatic(pars);
			    	m=state.get("m");
			    	 sb.append(";"+valFormat.format(m));
			    	System.out.println("JVFEditor:runVconst:usd="+usd+" m="+m);
			    	usd=usd+vdelta;
			    }
		    	s=s+deltaS;
		    	//sb.append("\n");
		    	writer.println(sb.toString());
			}
			writer.close();
		}catch(Exception e) {
			System.out.println("JVFEditor:runVconst:"+e.toString());
		}
	}
	private void runVconst() {
		try {
			double usd=220;
			try {usd=Double.parseDouble(txtVconst.getText());}catch(Exception ee) {}
			double fmin=Double.MIN_VALUE;
			try {fmin=Double.parseDouble(txtFmin.getText());}catch(Exception ee) {}
			double fdelta=1;
			try {fdelta=Double.parseDouble(txtFdelta.getText());}catch(Exception ee) {}
			int fcount=10;
			try {fcount=(int) Double.parseDouble(txtFcount.getText());}catch(Exception ee) {}
			Hashtable<String,Double>pars=getTestPars();
			Hashtable<String,Double>state;
			int scount=100;
			double s=-1;
			double deltaS=1.0/scount;
			System.out.println("JVFEditor:runVconst:delta s="+deltaS);
			double f=fmin;
			StringBuffer data=new StringBuffer("vconst");
			boolean staticModel=true;
			String test$=(String)cbxTest.getSelectedItem();
	        if(TEST_VECTOR_ESTIMATED.equals(test$)
	            		||TEST_VECTOR_GIVEN.equals(test$)) 
	        	staticModel=false;
	       
			boolean given=false;
			if(TEST_STATIC_GIVEN.equals(test$)
            		||TEST_VECTOR_GIVEN.equals(test$))
				given=true;
			if(staticModel)
				data.append("stc");
			else
				data.append("vct");
			if(given)
				data.append("gvn");
			else
				data.append("est");
			String path$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/"+data.toString()+".data";
			File out=new File(path$);
			if(out.exists())
				out.delete();
			PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(path$, true)));
			String format$="0.####E0";
			NumberFormat valFormat = new DecimalFormat(format$);
			double wg0=2*Math.PI*f;
			double wg=wg0;
			double m=0;
			StringBuffer sb;
			//pars.put("usd", usd);
			double wmin=Double.MIN_VALUE;
			double wmax=4*Math.PI*(fmin+fdelta*fcount);
			double wdelta=(wmax-wmin)/200;
			double wr=wmin;
			double w0;
			System.out.println("JVFEditor:runVconst:wmax="+wmax+" wmin="+wmin+"  wr="+wr);
			while(wr<wmax) {
				sb=new StringBuffer();
				f=fmin;
				sb.append(valFormat.format(wr));
                for(int i=0;i<fcount;i++) {
                	pars.put("f", f);
                	w0=2*Math.PI*f;
                	s=(w0-wr)/w0;
                	pars.put("s", s);
                	pars.put("usd", usd);
                	if(!staticModel)
			    		state=makeStateVector(pars);
			    	else
			    		state=makeStateStatic(pars);
			    	m=state.get("m");
			    	sb.append(";"+valFormat.format(m));
                f=f+fdelta;	
                }
                writer.println(sb.toString());
				wr=wr+wdelta;
			}
			
			writer.close();
		}catch(Exception e) {
			System.out.println("JVFEditor:runVconst:"+e.toString());
		}
	}
	private void runVFconst() {
		try {
			//double usd=220;
			//try {usd=Double.parseDouble(txtV.getText());}catch(Exception ee) {}
			double vf=1;
			try {vf=Double.parseDouble(txtVFconst.getText());}catch(Exception ee) {}
			double fmin=Double.MIN_VALUE;
			try {fmin=Double.parseDouble(txtVFvmin.getText());}catch(Exception ee) {}
			double fdelta=1;
			try {fdelta=Double.parseDouble(txtVFdelta.getText());}catch(Exception ee) {}
			int fcount=10;
			try {fcount=(int) Double.parseDouble(txtVFcount.getText());}catch(Exception ee) {}
			Hashtable<String,Double>pars=getTestPars();
			Hashtable<String,Double>state;
			int scount=100;
			double s=-1;
			double deltaS=1.0/scount;
			System.out.println("JVFEditor:runFconst:delta s="+deltaS);
			double f=fmin;
			pars.put("f", f);
			StringBuffer data=new StringBuffer("vfconst");
			boolean staticModel=true;
			String test$=(String)cbxTest.getSelectedItem();
	        if(TEST_VECTOR_ESTIMATED.equals(test$)
	            		||TEST_VECTOR_GIVEN.equals(test$)) 
	        	staticModel=false;
	       
			boolean given=false;
			if(TEST_STATIC_GIVEN.equals(test$)
            		||TEST_VECTOR_GIVEN.equals(test$))
				given=true;
			if(staticModel)
				data.append("stc");
			else
				data.append("vct");
			if(given)
				data.append("gvn");
			else
				data.append("est");
			String path$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/"+data.toString()+".data";
			File out=new File(path$);
			if(out.exists())
				out.delete();
			PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(path$, true)));
			String format$="0.####E0";
			NumberFormat valFormat = new DecimalFormat(format$);
			double wg0=2*Math.PI*f;
			double wg=wg0;
			double m=0;
			StringBuffer sb;
			//pars.put("usd", usd);
			double wmin=Double.MIN_VALUE;
			double wmax=4*Math.PI*(fmin+fdelta*fcount);
			double wdelta=(wmax-wmin)/200;
			double wr=wmin;
			double w0;
			double usd=Double.MIN_VALUE;
			System.out.println("JVFEditor:runVFconst:wmax="+wmax+" wmin="+wmin+"  wr="+wr);
			while(wr<wmax) {
				sb=new StringBuffer();
				f=fmin;
				pars.put("f", f);
				sb.append(valFormat.format(wr));
                for(int i=0;i<fcount;i++) {
                	pars.put("f", f);
                	w0=2*Math.PI*f;
                	s=(w0-wr)/w0;
                	pars.put("s", s);
                	usd=f*vf;
                	pars.put("usd", usd);
                	if(!staticModel)
			    		state=makeStateVector(pars);
			    	else
			    		state=makeStateStatic(pars);
			    	m=state.get("m");
			    	sb.append(";"+valFormat.format(m));
                f=f+fdelta;	
                }
                writer.println(sb.toString());
				wr=wr+wdelta;
			}
			
			writer.close();
		}catch(Exception e) {
			System.out.println("JVFEditor:runVconst:"+e.toString());
		}
	}
	
	private void runCustom() {
		try {
			//btnCustomRun.setEnabled(false);
			double usd=220;
			try {usd=Double.parseDouble(txtV.getText());}catch(Exception ee) {}
			double f=50;
			try {f=Double.parseDouble(txtF.getText());}catch(Exception ee) {}
			Hashtable<String,Double>pars=getTestPars();
			Hashtable<String,Double>state;
			int scount=100;
			double s=-1;
			double deltaS=1.0/scount;
		
			StringBuffer data=new StringBuffer("custom");
			boolean staticModel=true;
			String test$=(String)cbxTest.getSelectedItem();
	        if(TEST_VECTOR_ESTIMATED.equals(test$)
	            		||TEST_VECTOR_GIVEN.equals(test$)) 
	        	staticModel=false;
	       
			boolean given=false;
			if(TEST_STATIC_GIVEN.equals(test$)
            		||TEST_VECTOR_GIVEN.equals(test$))
				given=true;
			if(staticModel)
				data.append("stc");
			else
				data.append("vct");
			if(given)
				data.append("gvn");
			else
				data.append("est");
			String path$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/"+data.toString()+".data";
			File out=new File(path$);
			if(out.exists())
				out.delete();
			PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(path$, true)));
			String format$="0.####E0";
			NumberFormat valFormat = new DecimalFormat(format$);
			double wg0=2*Math.PI*f;
			double m=0;
			StringBuffer sb;
			double wmin=Double.MIN_VALUE;
			double wmax=4*Math.PI*(f*2);
			double wdelta=(wmax-wmin)/200;
			double wr=wmin;
			double w0;
			while(wr<wmax) {
				pars.put("usd", usd);
				pars.put("f", f);
				sb=new StringBuffer();
				sb.append(valFormat.format(wr));
				s=(wg0-wr)/wg0;
                pars.put("s", s);
                if(!staticModel)
			    	state=makeStateVector(pars);
			    else
			    	state=makeStateStatic(pars);
			    m=state.get("m");
			    sb.append(";"+valFormat.format(m));
                writer.println(sb.toString());
				wr=wr+wdelta;
			}
			writer.close();
			notifyReview("custom");
			
		}catch(Exception e) {
			System.out.println("JVFEditor:runCustom:"+e.toString());
		}
		//btnCustomRun.setEnabled(true);
	}	
	private void transferData(String plotKey$,String data$) {
		try {
		String	in$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/"+data$+".data";
		String	out$=console.getEntigrator().getEntihome()+"/"+plotKey$+"/"+data$+".data";
		//System.out.println("JEduEditor:transferData:in="+in$+"  out="+out$);
		File in=new File(in$);
		Scanner ins = new Scanner(in);	
		File out=new File(out$);
		if(out.exists())
			out.delete();
		out=new File(out$);
		System.out.println("JEduEditor:transferData:in="+in$+" out="+out$);
		PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(out)));
		String line$;
		while(ins.hasNextLine()) {
			line$=ins.nextLine();
			writer.write(line$+"\n");
		}
		ins.close();
		writer.close();
		}catch(Exception e) {
			System.out.println("JEduEditor:transferData:"+e.toString());
		}
	}
	private void notifyReview(String event$) {
		try {
		Sack review=findReview(event$);
		if(review==null)
			return;
		String data$="custom"+getReviewSuffix();
		System.out.println("JVFmodelEditor:notifyReview:event="+event$+" data="+data$);
		transferData(review.getKey(),data$);
		Properties request=new Properties();
		   	request.put(EventHandler.REQUESTOR,entity.getKey());
		   	request.put(EventHandler.MESSAGE,data$);
		   	request.put(EventHandler.CONSUMER,review.getKey());
		    String request$=Locator.toString(request);
		    System.out.println("JVFmodelEditor:notifyReview:request="+request$);

		    console.getEntigrator().putRequest(request$);
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:notifyReview:"+e.toString());
		}
	}
	
	private Sack findReview(String prefix$) {
		try {
			String review$=getReviewSuffix();
			String plotLabel$=entity.getProperty("label")+"."+prefix$+review$;
			System.out.println("JVFEditor:getRebiew:"+plotLabel$);
			Sack plot=null;
			Core[]ca=entity.elementGet("link");
			if(ca!=null)
				for(Core c:ca)
					if(plotLabel$.equals(c.value)) {
						plot=console.getEntigrator().getEntity(c.name);
						if(plot!=null) {
							System.out.println("JVFEditor:getReview:already linked="+plotLabel$);
							return plot;
						}
					}
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:findVFReview:"+e.toString());
		}
		return null;
	}
	private Sack getReview(String prefix$) {
		//System.out.println("JSisoEditor:remakePlot:type="+plotType);
		try {
			String review$=getReviewSuffix();
			String plotLabel$=entity.getProperty("label")+"."+prefix$+review$;
			System.out.println("JSisoEditor:getReview:"+plotLabel$);
			Sack plot=null;
			Core[]ca=entity.elementGet("link");
			if(ca!=null)
				for(Core c:ca)
					if(plotLabel$.equals(c.value)) {
						plot=console.getEntigrator().getEntity(c.name);
						if(plot!=null) {
							System.out.println("JSisoEditor:getRebiew:already linked="+plotLabel$);
							return plot;
						}
					}
			//System.out.println("JSisoEditor:createPlot:plot label="+plotLabel$+" entity key="+entity.getKey());
			Properties plotLocator=new Properties();
			plotLocator.put( ModuleHandler.FACET_MODULE, "_TZ34ntGtza4ryheSV3Xo_JOLOIU");
			plotLocator.put( FacetMaster.MASTER_CLASS, "_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster");
			String plotLocator$=Locator.toString(plotLocator);
			PlotMaster plotMaster=(PlotMaster)FacetMaster.build(console, plotLocator$);
			plot= plotMaster.createEntity(console.getEntigrator(),plotLabel$ );
			//console.getEntigrator().assignLabel(plotLabel$, plot.getKey());
			
			console.getEntigrator().putEntity(plot);
			plot=console.getEntigrator().assignProperty("plot type", "review", plot.getKey());
			plot=console.getEntigrator().assignProperty("plot", "true", plot.getKey());
			console.getEntigrator().link(entity, plot);
			plot.createElement("Quadrant");
			plot.putElementItem("Quadrant", new Core("50","Vertical","0.8"));
			plot.putElementItem("Quadrant", new Core("50","Horizontal","0.8"));
			plot.createElement("Surface");
			plot.putElementItem("Surface", new Core(null,"Horizontal",null));
			plot.putElementItem("Surface", new Core("0","Vertical","0.8"));
			plot.putElementItem("Surface", new Core("0","Horizontal","0.8"));
			plot.createElement("canvas");
			plot.putElementItem("canvas", new Core(null	,"backcolor","white"));
			plot.putElementItem("canvas", new Core(null	,"font.color","blue"));
			plot.putElementItem("canvas", new Core(null,"font.size","12"));
			plot.putElementItem("canvas", new Core(null,"font.style","bold"));
			plot.putElementItem("canvas", new Core(null,"frontcolor","black"));
			plot.putElementItem("canvas", new Core(null,"pointer.size","6"));
			plot.putElementItem("canvas", new Core(null,"shift","20"));
			plot.putElementItem("canvas", new Core(null,"stroke","2"));
			plot.createElement("scale.layout");
				String rayKey$=Identity.key();
			plot.createElement("ray.color");
			plot.putElementItem("ray.color", new Core(null,rayKey$,"red"));
			plot.createElement("ray.index");
			plot.putElementItem("ray.index", new Core(null,rayKey$,"0"));
			plot.createElement("ray.name");
			plot.putElementItem("ray.name", new Core(null,rayKey$,"y"));
			plot.createElement("ray.scale");
			plot.createElement("ray.shift");
			plot.putElementItem("ray.shift", new Core(null,rayKey$,"0"));
			plot.createElement("ray.symbol");
			plot.putElementItem("ray.symbol", new Core(null,rayKey$,""));
			plot.createElement("ray.visible");
			plot.putElementItem("ray.visible", new Core("2",rayKey$,"true"));
			console.getEntigrator().putEntity(plot);
			console.getEntigrator().link(entity, plot);
			//plot.print();
			return plot;
		}catch(Exception e) {
			System.out.println("JVFmodelEditor:makeReview:"+e.toString());
		}
		return null;
	}

	class SinCos{
		double um=0;
		double w0=0;
		public SinCos(double um,double f) {
			this.um=um;
			w0=2*Math.PI*f;
		}
		public V2 get(double time) {
			try {
				double angle=w0*time;
				double cos=Math.cos(angle);
				double sin=Math.sin(angle);
				double usx=um*cos;
				double usy=um*sin;
				return new V2(usx,usy);
				}catch(Exception e) {
					System.out.println("JVFmodelEditor:run:"+e.toString());
				}
				return null;
		}
	}
	
}
