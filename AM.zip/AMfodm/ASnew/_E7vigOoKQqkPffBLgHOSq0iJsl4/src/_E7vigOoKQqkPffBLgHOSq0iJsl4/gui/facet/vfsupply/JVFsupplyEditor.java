package _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.vfsupply;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;

import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;

import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.Properties;

public class JVFsupplyEditor extends JGuiEditor{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_1Roc_SiX_9ZkY04LjCZj_7QftopM";
	JTextField txtUa;
	JTextField txtF0;
	JTextField txtUc;
	JTextField txtF;
	public JVFsupplyEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0,0,1};
		gridBagLayout.rowHeights = new int[]{0,0,0,0,0,1};
		gridBagLayout.columnWeights = new double[]{0.0,0.0,1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0.0,0.0,Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblUa = new JLabel("Ua");
		GridBagConstraints gbc_lblUa = new GridBagConstraints();
		gbc_lblUa.anchor = GridBagConstraints.LINE_START;
		gbc_lblUa.insets = new Insets(5, 5, 5, 5);
		gbc_lblUa.gridx = 0;
		gbc_lblUa.gridy = 0;
		add(lblUa, gbc_lblUa);
		
		txtUa = new JTextField();
		txtUa.setColumns(10);
		txtUa.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String ua$=txtUa.getText();
		    	if(!entity.existsElement("vfsupply"))
		    		entity.createElement("vfsupply");
	    		entity.putElementItem("vfsupply", new Core(null,"Ua",ua$));	
				 console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtUa = new GridBagConstraints();
		gbc_txtUa.insets = new Insets(5, 5, 5, 5);
		gbc_txtUa.gridx = 1;
		gbc_txtUa.gridy = 0;
		add(txtUa, gbc_txtUa);
		
		JLabel lblF0 = new JLabel("f0");
		GridBagConstraints gbc_lblF0 = new GridBagConstraints();
		gbc_lblF0.anchor = GridBagConstraints.LINE_START;
		gbc_lblF0.insets = new Insets(0, 5, 5, 5);
		gbc_lblF0.gridx = 0;
		gbc_lblF0.gridy = 1;
		add(lblF0, gbc_lblF0);
		
		txtF0 = new JTextField();
		txtF0.setColumns(10);
		txtF0.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String f0$=txtF0.getText();
		    	if(!entity.existsElement("vfsupply"))
		    		entity.createElement("vfsupply");
	    		entity.putElementItem("vfsupply", new Core(null,"f0",f0$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtF0 = new GridBagConstraints();
		gbc_txtF0.insets = new Insets(0, 5, 5, 5);
		gbc_txtF0.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtF0.gridx = 1;
		gbc_txtF0.gridy = 1;
		add(txtF0, gbc_txtF0);
		
		JLabel  lblUc = new JLabel("Uc");
		GridBagConstraints gbc_lblUc = new GridBagConstraints();
		gbc_lblUc.insets = new Insets(0, 5, 5, 5);
		gbc_lblUc.anchor=GridBagConstraints.LINE_START;
		gbc_lblUc.gridx = 0;
		gbc_lblUc.gridy = 2;
		add(lblUc, gbc_lblUc);
		
		txtUc = new JTextField();
		txtUc.setColumns(10);
		GridBagConstraints gbc_txtUc = new GridBagConstraints();
		gbc_txtUc.insets = new Insets(0, 5, 5, 5);
		gbc_txtUc.gridx = 1;
		gbc_txtUc.gridy = 2;
		add(txtUc, gbc_txtUc);
		txtUc.addCaretListener(new CaretListener() {
				@Override
				public void caretUpdate(CaretEvent e) {
					String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    	String uc$=txtUc.getText();
			    	if(!entity.existsElement("vfsupply"))
			    		entity.createElement("vfsupply");
		    		entity.putElementItem("vfsupply", new Core(null,"Uc",uc$));	
					console.getEntigrator().putEntity(entity);
					 }
		      });
		
		JLabel lblF = new JLabel("f");
		GridBagConstraints gbc_lblF = new GridBagConstraints();
		gbc_lblF.anchor = GridBagConstraints.LINE_START;
		gbc_lblF.insets = new Insets(0, 5, 5, 5);
		gbc_lblF.gridx = 0;
		gbc_lblF.gridy = 3;
		add(lblF, gbc_lblF);
		
		txtF = new JTextField();
		txtF.setColumns(10);
		txtF.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String f$=txtF.getText();
		    	if(!entity.existsElement("vfsupply"))
		    		entity.createElement("vfsupply");
	    		entity.putElementItem("vfsupply", new Core(null,"f",f$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtF = new GridBagConstraints();
		gbc_txtF.insets = new Insets(0, 5, 5, 5);
		gbc_txtF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtF.gridx = 1;
		gbc_txtF.gridy = 3;
		add(txtF, gbc_txtF);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
    	entity.printElement("vfsupply");
    	String ua$=entity.getElementItemAt("vfsupply", "Ua");
    	txtUa.setText(ua$);
    	String f0$=entity.getElementItemAt("vfsupply", "f0");
    	txtF0.setText(f0$);
    	String uc$=entity.getElementItemAt("vfsupply", "Uc");
    	txtUc.setText(uc$);
    	String f$=entity.getElementItemAt("vfsupply", "f");
    	txtF.setText(f$);
    	System.out.println("JVFsupplyEditor:Uc="+uc$+" f0="+f0$+" Uc="+uc$+" f="+f$);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,"VFsupply");
		locator.put(FacetHandler.FACET_TYPE,"VFsupply");
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.VFsupplyMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(JContext.CONTEXT_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.vfsupply.JVFsupplyEditor");
		return Locator.toString(locator);
	}
	
	@Override
	public String reply(JMainConsole console, String locator$) {
		return locator$;
	}
}
