package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.PWMsupply;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class PWMsupplyHandler extends  OperatorHandler{
	public static final String KEY="_yiTQ8xCaankf3v70xDZWOGK9fxM";
	Sack entity;
	PWMsupply pwmsupply;
	double preferredClock=Double.MIN_VALUE;
	double clock=Double.MIN_VALUE;
	double f=Double.MIN_VALUE;
	double Uc=Double.MIN_VALUE;
	double Kfuc=Double.MIN_VALUE;
	public PWMsupplyHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		System.out.println("PWMsupplyHandler:operator key="+operatorKey$);   
		if(operatorKey$!=null) {
			 entity=entigrator.getEntityAtLabel(operatorKey$);
			 pwmsupply=new PWMsupply(entigrator,locator$);
			reinit(entigrator, locator$);
			reset();
		   }
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"PWMsupply");
		locator.put(FACET_TYPE,"pwmsupply");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMsupplyHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMsupplyMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "pwmsupply.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}	
	public void reset() {
	try {
		 
		if(operatorKey$!=null) 
			 entity=entigrator.getEntity(operatorKey$);
		//entity.printElement("vfsupply");
		Hashtable<String, Double> settings=new Hashtable<String, Double>();
		double Ua=0;
	    try{Ua=Double.parseDouble(entity.getElementItemAt("pwmsupply","Ua"));}catch(Exception ee) {}
	    settings.put("Ua", Ua);
	    double f0=0;
	    try{f0=Double.parseDouble(entity.getElementItemAt("pwmsupply","f0"));}catch(Exception ee) {}
	    settings.put("f0", f0);
	    try{Uc=Double.parseDouble(entity.getElementItemAt("pwmsupply","Uc"));}catch(Exception ee) {}
	    try{f=Double.parseDouble(entity.getElementItemAt("pwmsupply","f"));}catch(Exception ee) {}
	    //System.out.println("VFsupplyHandler:reset:operator key="+operatorKey$+" f="+f+" Uc="+Uc);  
	    settings.put("Ucm", 10.0);
       // pwmsupply.putSettings(settings);	 
        preferredClock=0.001/f0;
        String motor$=entity.getElementItemAt("pwmsupply","motor");
		Sack motor=entigrator.getEntityAtLabel(motor$);
		String option$=entity.getElementItemAt("pwmsupply","test");
		 double w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
	    double rs=0;
	     if(PWMsupply.GIVEN.equals(option$))
		 try{rs=Double.parseDouble(motor.getElementItemAt("zgvn", "rs"));}catch(Exception ee) {}
	     
	     if(PWMsupply.ESTIMATED.equals(option$))
	  	   try{rs=Double.parseDouble(motor.getElementItemAt("zpar", "rs"));}catch(Exception ee) {}
	     settings.put("rs", rs);
		 double r2=0;
		 if(PWMsupply.GIVEN.equals(option$))
			 try{r2=Double.parseDouble(motor.getElementItemAt("zgvn", "r2"));}catch(Exception ee) {}
		 if(PWMsupply.ESTIMATED.equals(option$))
		  	   try{r2=Double.parseDouble(motor.getElementItemAt("zpar", "r2"));}catch(Exception ee) {}
		 settings.put("r2", r2);
		 double ls=0;
		 if(PWMsupply.GIVEN.equals(option$))
		 try{
			double xs=Double.parseDouble(motor.getElementItemAt("zgvn", "xs"));
			ls=xs/w0;
		 }catch(Exception ee) {}
		 if(PWMsupply.ESTIMATED.equals(option$))
			 try{
				double xs=Double.parseDouble(motor.getElementItemAt("zpar", "xs"));
					ls=xs/w0;
				 }catch(Exception ee) {}
		 settings.put("ls", ls);
		 double l2=0;
		 if(PWMsupply.GIVEN.equals(option$))
		 try{
			double x2=Double.parseDouble(motor.getElementItemAt("zgvn", "x2"));
			l2=x2/w0;
		 }catch(Exception ee) {}
		 if(PWMsupply.ESTIMATED.equals(option$))
			 try{
				double xs=Double.parseDouble(motor.getElementItemAt("zpar", "x2"));
				l2=xs/w0;
			 }catch(Exception ee) {}
		 settings.put("l2", l2);
		 double lm=0;
		 if(PWMsupply.GIVEN.equals(option$))
		 try{
				double xm=Double.parseDouble(motor.getElementItemAt("zgvn", "xm"));
				lm=xm/w0;
			 }catch(Exception ee) {}
		 if(PWMsupply.ESTIMATED.equals(option$))
			 try{
				double xm=Double.parseDouble(motor.getElementItemAt("zpar", "xm"));
					lm=xm/w0;
				 }catch(Exception ee) {}
		 settings.put("lm", lm);
		double j=Double.MIN_VALUE;
			try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
			settings.put("j", j);	
		int	pol=1; 
		try{pol=Integer.parseInt(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
		 settings.put("pol", (double)pol);
		//
		 double Usd=0;
		try{Usd=Double.parseDouble(motor.getElementItemAt("primary","Us" ));} catch(NumberFormatException nfe){ Usd=0; }
		//double Udm=2.34*Ua;
		double fnom=0;
		try{fnom=Double.parseDouble(motor.getElementItemAt("primary","f"));}catch(Exception ee) {}
		try{f=Double.parseDouble(entity.getElementItemAt("pwmsupply","f"));}catch(Exception ee) {}
		double Kfv=1;
		try{Kfv=Double.parseDouble(entity.getElementItemAt("pwmsupply","Kfv"));}catch(Exception ee) {}
	    //double uc=Usd*f/(fnom*Ua);
		
		//Kfuc=Usd*Kfv/(fnom*Ua);
		Kfuc=Usd*Kfv*Math.sqrt(2)/fnom;
	    settings.put("Kfuc", Kfuc);
	    System.out.println("PWMsupplyHandler:reset:Kfuc="+Kfuc+" Ua="+Ua+" fnom="+fnom);
		//
		 String amsupplyLocator$=Locator.append(locator$, PWMsupply.MOTOR, motor$);
		pwmsupply=new PWMsupply(entigrator,amsupplyLocator$); 
        pwmsupply.putSettings(settings);	 
        preferredClock=0.001/f0;
	}catch(Exception e) {
		System.out.println("PWMsupplyHandler:reset:"+e.toString());
	}

	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		 try {
				entity=entigrator.getEntity(operatorKey$);
			    String takt$=entity.getElementItemAt(OPERATOR, "takt");
				double takt=0;
				try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
				time=0;
				String time$=entity.getElementItemAt(OPERATOR, "time");
				try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
				String mc$=entity.getElementItemAt("pwmsupply", "mc");
				double mc=0;
				try {mc=Double.parseDouble(mc$);}catch(Exception ee) {} 
				// System.out.println("PWMsupplyHandler:step:time="+time+" takt="+takt+" f="+f+" Uc="+Uc);
				Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
				ins.put("f", f);
				ins.put("Uc", Uc);
				ins.put("mc", mc);
				double clock=takt; 
				Hashtable<String,Double> outs=null;
                if(takt>preferredClock) {
                	int cnt=(int)(takt/preferredClock);
                	if(cnt>0)
                		clock=takt/cnt;
                	for(int i=0;i<cnt;i++) {
                		ins.put("clock", clock);
                		ins.put("time", time);
                		ins.put("f", f);
        				ins.put("Uc", Uc);
        				ins.put("mc", mc);
                		pwmsupply.stride(ins);
                		time=time+clock;
                	}
                double dt=takt-cnt*preferredClock;
                if(dt>0) {
                	ins.put("clock", dt);
                	time=time+dt;
                	ins.put("time", time);
                	pwmsupply.stride(ins);
                }
                }else {
                	ins.put("clock", takt);
                	ins.put("time", time);
                	pwmsupply.stride(ins);
                }
                outs=pwmsupply.getOuts(); 
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            try {
					value=outs.get(key$);
		            }catch(java.lang.NullPointerException ee) {
		            	System.out.println("PWMsupplyHandler:step:cannot get"+key$+"  err="+ee.toString());
		            	continue;
		            }
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				
		  }catch(Exception e) {
			  System.out.println("PWMsupplyHandler:step:"+e.toString());  
		  }
		
	}

	@Override
	public void reset(Entigrator entigrator, String locator$) {
		reset();
	}

	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset();
	}

	@Override
	public String[] listOutputs(Entigrator entigrator) {
		if(pwmsupply==null)
			pwmsupply=new PWMsupply(entigrator,locator$);
		return pwmsupply.listOuts();
	}

	@Override
	public String[] listInputs(Entigrator entigrator) {
		if(pwmsupply==null)
			pwmsupply=new PWMsupply(entigrator,locator$);
		return pwmsupply.listIns();
	}

	

	@Override
	public String getName() {
		return "PWMsupply";
	}

	@Override
	public String getType() {
		return "pwmsupply";
	}

	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMsupplyHandler";
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
