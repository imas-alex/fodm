package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.PWMVFcontrol;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class PWMVFcontrolHandler extends  OperatorHandler{
	public static final String KEY="_3ptCX8TCCAtX0mGSQ1TNNoHgTCg";
	Sack entity;
	PWMVFcontrol pwmvfcontrol;
	double preferredClock=Double.MIN_VALUE;
	double clock=Double.MIN_VALUE;
	double f=Double.MIN_VALUE;
	double Uc=Double.MIN_VALUE;
	double Kfuc=Double.MIN_VALUE;
	public PWMVFcontrolHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		System.out.println("PWMVFcontrolHandler:operator key="+operatorKey$+"  alocator="+alocator$);   
		if(operatorKey$!=null) {
			 entity=entigrator.getEntityAtLabel(operatorKey$);
			 pwmvfcontrol=new PWMVFcontrol(entigrator,locator$);
			reinit(entigrator, locator$);
			reset();
		   }
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"PWMVFcontrolHandler");
		locator.put(FACET_TYPE,"pwmvfcontrolHandler");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMVFcontrolHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMVFcontrolMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "pwmvfcontrol.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	
	public void reset() {
	try {
		System.out.println("PWMVFcontrolHandler:reset:BEGIN");
		if(operatorKey$!=null) { 
			 entity=entigrator.getEntity(operatorKey$);
			 System.out.println("PWMVFcontrolHandler:reset:entity="+entity.getProperty("label"));
		}else {
			System.out.println("PWMVFcontrolHandler:reset:operator key is null. Return");
		return;
		}
		String motor$=entity.getElementItemAt("pwmvfcontrol", "motor");
		Sack motor=null;
		if(motor$!=null) {
		  locator$=Locator.append(locator$, PWMVFcontrol.MOTOR, motor$);
		  motor=entigrator.getEntityAtLabel(motor$);
		}else {
			System.out.println("PWMVFcontrolHandler:reset:motor is null in entity="+entity.getProperty("label"));
			return;
		}
		Hashtable<String, Double> settings=new Hashtable<String, Double>();
		String option$=entity.getElementItemAt("pwmvfcontrol","test");
		locator$=Locator.append(locator$, PWMVFcontrol.OPTION, option$);
		System.out.println("PWMVFcontrolHandler:reset:0"); 
		double w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
	    
		 double rs=0;
	     if(PWMVFcontrol.GIVEN.equals(option$))
		 try{rs=Double.parseDouble(motor.getElementItemAt("zgvn", "rs"));}catch(Exception ee) {}
	     
	     if(PWMVFcontrol.ESTIMATED.equals(option$))
	  	   try{rs=Double.parseDouble(motor.getElementItemAt("zpar", "rs"));}catch(Exception ee) {}
	     settings.put("rs", rs);
		 double r2=0;
		 if(PWMVFcontrol.GIVEN.equals(option$))
			 try{r2=Double.parseDouble(motor.getElementItemAt("zgvn", "r2"));}catch(Exception ee) {}
		 if(PWMVFcontrol.ESTIMATED.equals(option$))
		  	   try{r2=Double.parseDouble(motor.getElementItemAt("zpar", "r2"));}catch(Exception ee) {}
		 settings.put("r2", r2);
		 double ls=0;
		 if(PWMVFcontrol.GIVEN.equals(option$))
		 try{
			double xs=Double.parseDouble(motor.getElementItemAt("zgvn", "xs"));
			ls=xs/w0;
		 }catch(Exception ee) {}
		 if(PWMVFcontrol.ESTIMATED.equals(option$))
			 try{
				double xs=Double.parseDouble(motor.getElementItemAt("zpar", "xs"));
					ls=xs/w0;
				 }catch(Exception ee) {}
		 settings.put("ls", ls);
		 double l2=0;
		 if(PWMVFcontrol.GIVEN.equals(option$))
		 try{
			double x2=Double.parseDouble(motor.getElementItemAt("zgvn", "x2"));
			l2=x2/w0;
		 }catch(Exception ee) {}
		 if(PWMVFcontrol.ESTIMATED.equals(option$))
			 try{
				double xs=Double.parseDouble(motor.getElementItemAt("zpar", "x2"));
				l2=xs/w0;
			 }catch(Exception ee) {}
		 settings.put("l2", l2);
		 double lm=0;
		 if(PWMVFcontrol.GIVEN.equals(option$))
		 try{
				double xm=Double.parseDouble(motor.getElementItemAt("zgvn", "xm"));
				lm=xm/w0;
			 }catch(Exception ee) {}
		 if(PWMVFcontrol.ESTIMATED.equals(option$))
			 try{
				double xm=Double.parseDouble(motor.getElementItemAt("zpar", "xm"));
					lm=xm/w0;
				 }catch(Exception ee) {}
		 settings.put("lm", lm);
		double j=Double.MIN_VALUE;
			try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
			settings.put("j", j);	
		int	pol=1; 
		try{pol=Integer.parseInt(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
		 settings.put("pol", (double)pol);
		//
		 double Usd=0;
		try{Usd=Double.parseDouble(motor.getElementItemAt("primary","Us" ));} catch(NumberFormatException nfe){ Usd=0; }
		//double Udm=2.34*Ua;
		double fnom=0;
		try{fnom=Double.parseDouble(motor.getElementItemAt("primary","f"));}catch(Exception ee) {}

		
		String tc$=entity.getElementItemAt("pwmvfcontrol", "Tc");
		if(tc$!=null)
		  locator$=Locator.append(locator$, PWMVFcontrol.TC, tc$);
		String kc$=entity.getElementItemAt("pwmvfcontrol", "Kc");
		if(kc$!=null)
		  locator$=Locator.append(locator$, PWMVFcontrol.KC, kc$);
		
		pwmvfcontrol.reset(entigrator,locator$);
		//entity.printElement("vfsupply");
		
		double Ua=0;
	    try{Ua=Double.parseDouble(entity.getElementItemAt("pwmvfcontrol","Ua"));}catch(Exception ee) {}
	    settings.put("Ua", Ua);
	    double f0=0;
	    try{f0=Double.parseDouble(entity.getElementItemAt("pwmvfcontrol","f0"));}catch(Exception ee) {}
	    settings.put("f0", f0);
	    try{Uc=Double.parseDouble(entity.getElementItemAt("pwmvfcontrol","Uc"));}catch(Exception ee) {}
	    try{f=Double.parseDouble(entity.getElementItemAt("pwmvfcontrol","f"));}catch(Exception ee) {}
	    double Tc=0;
	    try{Tc=Double.parseDouble(entity.getElementItemAt("pwmvfcontrol","Tc"));}catch(Exception ee) {}
	    settings.put(PWMVFcontrol.TC, Tc);
	    double Kc=0;
	    try{Kc=Double.parseDouble(entity.getElementItemAt("pwmvfcontrol","Kc"));}catch(Exception ee) {}
	    settings.put(PWMVFcontrol.KC, Kc);
	    //System.out.println("PWMVFcontrolHandler:reset:0");
	    //System.out.println("VFsupplyHandler:reset:operator key="+operatorKey$+" f="+f+" Uc="+Uc);  
	    
	//    settings.put("Ucm", 10.0);
	    double Kfv=1;
		try{Kfv=Double.parseDouble(entity.getElementItemAt("pwmsupply","Kfv"));}catch(Exception ee) {}
	    //double uc=Usd*f/(fnom*Ua);
		try{Usd=Double.parseDouble(motor.getElementItemAt("primary","Us" ));} catch(NumberFormatException nfe){ Usd=0; }
		Kfuc=Usd*Kfv*Math.sqrt(2)/fnom;
	    settings.put("Kfuc", Kfuc);
	    pwmvfcontrol.putSettings(settings);	 
        preferredClock=0.001/f0;
	}catch(Exception e) {
		System.out.println("PWMVFcontrolHandler:reset:"+e.toString());
	}
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		 try {
				entity=entigrator.getEntity(operatorKey$);
				//System.out.println("PWMVFcontrolHandler:step:entity="+entity.getProperty("label"));
				String takt$=entity.getElementItemAt(OPERATOR, "takt");
				double takt=0;
				try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
				time=0;
				String time$=entity.getElementItemAt(OPERATOR, "time");
				try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
				double w=0;
				String w$=entity.getElementItemAt("pwmvfcontrol", "W");
				try {w=Double.parseDouble(w$);}catch(Exception ee) {}
				double mc=0;
				String mc$=entity.getElementItemAt("pwmvfcontrol", "M");
				try {mc=Double.parseDouble(mc$);}catch(Exception ee) {}
				
				double isa=0;
				String isa$=entity.getElementItemAt("pwmvfcontrol", "isa");
				try {isa=Double.parseDouble(isa$);}catch(Exception ee) {}
				double isb=0;
				String isb$=entity.getElementItemAt("pwmvfcontrol", "isb");
				try {isb=Double.parseDouble(isb$);}catch(Exception ee) {}
				double isc=0;
				String isc$=entity.getElementItemAt("pwmvfcontrol", "isc");
				try {isc=Double.parseDouble(isc$);}catch(Exception ee) {}
				// System.out.println("PWMsupplyHandler:step:time="+time+" takt="+takt+" f="+f+" Uc="+Uc);
				Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
				ins.put("w", w);
				ins.put("mc", mc);
				ins.put("isa", isa);
				ins.put("isb", isb);
				ins.put("isc", isc);
				double clock=takt; 
				Hashtable<String,Double> outs=null;
                if(takt>preferredClock) {
                	int cnt=(int)(takt/preferredClock);
                	if(cnt>0)
                		clock=takt/cnt;
                	for(int i=0;i<cnt;i++) {
                		ins.put("clock", clock);
                		ins.put("time", time);
                		ins.put("w", w);
        				ins.put("mc", mc);
                		time=time+clock;
                	}
                double dt=takt-cnt*preferredClock;
                if(dt>0) {
                	ins.put("clock", dt);
                	time=time+dt;
                	ins.put("time", time);
                	pwmvfcontrol.stride(ins);
                }
                }else {
                	ins.put("clock", takt);
                	ins.put("time", time);
                	pwmvfcontrol.stride(ins);
                }
                outs=pwmvfcontrol.getOuts(); 
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            try {
					value=outs.get(key$);
		            }catch(java.lang.NullPointerException ee) {
		            	System.out.println("PWMVFcontrolHandler:step:cannot get"+key$+"  err="+ee.toString());
		            	continue;
		            }
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				
		  }catch(Exception e) {
			  System.out.println("PWMVFcontrolHandler:step:"+e.toString());  
		  }
		
	}

	@Override
	public void reset(Entigrator entigrator, String locator$) {
		try {
		System.out.println("PWMVFcontrolHandler:reset:operator key=="+operatorKey$);
		entity=entigrator.getEntity(operatorKey$);
		String motor$=entity.getElementItemAt("pwmvfcontrol","motor");
		String test$=entity.getElementItemAt("pwmvfcontrol","test");
		if(motor$!=null) 
		locator$=Locator.append(locator$, PWMVFcontrol.MOTOR, motor$);
		else
			System.out.println("PWMVFcontrolHandler:reset:motor is null in entity="+entity.getProperty("label"));
		if(test$!=null) 
			locator$=Locator.append(locator$, PWMVFcontrol.OPTION,test$);
			else
				System.out.println("PWMVFcontrolHandler:reset:test is null in entity="+entity.getProperty("label"));
		
		if(pwmvfcontrol==null)
			pwmvfcontrol=new PWMVFcontrol(entigrator,locator$);
		pwmvfcontrol.reset( entigrator, locator$);
		}catch(Exception e) {
			System.out.println("PWMVFcontrolHandler:reset:"+e.toString());  
		}
		
	}

	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset();
	}

	@Override
	public String[] listOutputs(Entigrator entigrator) {
		if(pwmvfcontrol==null)
			pwmvfcontrol=new PWMVFcontrol(entigrator,locator$);
		return pwmvfcontrol.listOuts();
	}

	@Override
	public String[] listInputs(Entigrator entigrator) {
		if(pwmvfcontrol==null)
			pwmvfcontrol=new PWMVFcontrol(entigrator,locator$);
		return pwmvfcontrol.listIns();
	}

	

	@Override
	public String getName() {
		return "PWMVFcontrolHandler";
	}

	@Override
	public String getType() {
		return "pwmvfcontrolhandler";
	}

	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMVFcontrolHandler";
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
