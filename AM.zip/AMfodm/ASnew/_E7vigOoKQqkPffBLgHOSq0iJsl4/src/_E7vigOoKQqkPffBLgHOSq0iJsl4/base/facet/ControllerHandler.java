package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;
import java.io.File;
//import java.io.File;
//import java.lang.reflect.Method;
//import java.net.URL;
//import java.net.URLClassLoader;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import java.util.logging.Logger;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.M2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import gdt.base.store.Core;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
import gdt.base.store.Entigrator;
import java.io.FileWriter;
import java.io.BufferedWriter;
public class ControllerHandler  extends OperatorHandler implements SegueController  {
	private Logger LOGGER=Logger.getLogger(getClass().getName());
	//public static final String CONTROLLER="controller";
	public static final String KEY="_9XhC90iPxk2PqyLhtm6iIOZHl84";
	public static final String CONTROLLER_FACET_TYPE="controller";
	public static final String CONTROLLER_FACET_NAME="Controller";
	public static final String CONTROLLER_FACET_CLASS="_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ControllerHandler";
	
	public ControllerHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,CONTROLLER_FACET_NAME);
		locator.put(FACET_TYPE,CONTROLLER_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ControllerHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.ControllerMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put(IconLoader.ICON_FILE,"controller.png");
		locator.put(IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		//locator.put(OPERATOR,Locator.LOCATOR_TRUE);
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	public static Sack reinit(Sack controller) {
		try{
			System.out.println("ControllerHandler:reinit: controller="+controller.getProperty("label"));
			//reset variables
			controller.putElementItem("operator",new Core("input","fx","0"));
			controller.putElementItem("operator",new Core("input","fy","0"));
			controller.putElementItem("operator",new Core("input","wr","0"));
			controller.putElementItem("operator",new Core("input","w0","0"));
			controller.putElementItem("operator",new Core("input","id","0"));
			controller.putElementItem("operator",new Core("output","ox","0"));
			controller.putElementItem("operator",new Core("output","oy","0"));
			controller.putElementItem("operator",new Core(null,"iai","0"));
			controller.putElementItem("operator",new Core(null,"iqi","0"));
			controller.putElementItem("operator",new Core("output","id0","0"));
			controller.putElementItem("operator",new Core("output","vx","0"));
			controller.putElementItem("operator",new Core("output","vy","0"));
			controller.putElementItem("operator",new Core("output","edf","0"));
		
		}catch(Exception e){
			Logger.getLogger(ControllerHandler.class.getName());
		}
		return controller;  
		}
	
	public  static Sack step(Entigrator entigrator,Sack controller) {
		//controller=entigrator.ent_reload(controller.getKey());
		//controller.print("controller");
		//String path$=entigrator.getEntihome()+"/"+ Entigrator.ENTITY_BASE +"/data/"+controller.getKey();
		//Sack newController=Sack.readXml(entigrator,path$);
		//String stop$=newController.getElementItemAt("controller", "stop");
		//System.out.println("ControlHandler:step:BEGIN:stop="+stop$);
		/*
		try {
			///Motor handler	
			Core mcore=controller.getElementItem("state.holder", "motor");
			String motorKey$=mcore.value;
			//Sack motor=entigrator.getEntity(motor$);
			
			//String mlocator$=EntityHandler.getEntityLocator(entigrator, motor);
			String motor$=entigrator.getLabel(motorKey$);
			String motorHandler$=MotorHandler.classLocator();
			motorHandler$=Locator.append(motorHandler$, entigrator.ENTITY_LABEL, motor$);
			MotorHandler mh=new MotorHandler(entigrator,motorHandler$);
			Sack motor=entigrator.getEntity(motorKey$);
			HashMap<String,Object> mpars=mh.initPars(motor);
			double tw=(double)mpars.get("tw");
			double tf=(double)mpars.get("tf");
			controller.putElementItem("controller", new Core(null,"tw",String.valueOf(tw)));
			controller.putElementItem("controller", new Core(null,"tf",String.valueOf(tf)));
			//	System.out.println("ControlHandler:step:motor pars-----------------");
		//	StateHandler.print(mpars);
			HashMap<String,Object> mstate=mh.initState(motor);
			
			
		// controller
		
			String 	controllerHandler$=ControllerHandler.classLocator();
		controllerHandler$=Locator.append(controllerHandler$, Entigrator.ENTITY_LABEL,controller.getProperty(Entigrator.LABEL));
		ControllerHandler ch=new ControllerHandler (entigrator,controllerHandler$);
		HashMap<String,Object> cpars=ch.initPars(controller);
		HashMap<String,Object> cstate=ch.initState(controller);
		
		//regulator
		Core rcore=controller.getElementItem("state.holder", "regulator");
		String regulator$=rcore.value;
		Sack regulator=entigrator.getEntity(regulator$);
	//	String rlocator$=EntityHandler.getEntityLocator(entigrator, regulator);
		String rhandler$=rcore.type;
		ClassLoader parentLoader = ControllerHandler.class.getClassLoader();
		Class<?> rclass=parentLoader.loadClass(rhandler$);
		Object rh= rclass.getDeclaredConstructor().newInstance();
		cpars.put("rhandler", rh);
	//	HashMap<String,Object> rpars=((StateHandler)rh).initPars(regulator);
	//	HashMap<String,Object> rstate=((StateHandler)rh).initState(regulator);
		
		//filter
		String appliance$=controller.getElementItemAt("operator", "appliance");
		//String[]sa=ApplianceHandler.listComponents(entigrator, appliance$, "filter");
		String[]sa=null;
				
				//applianceHandler.listOperators(entigrator, appliance$);
		Sack filter=null;
		if(sa!=null) {
			for(String s:sa) {
				filter=entigrator.getEntity(s);
				
			}
		}
	
		HashMap<String,Object> state=new HashMap<String,Object>();
		//state=new HashMap<String,Object>();
		HashMap<String,Object> pars=new HashMap<String,Object>();
		HashMap<String,Object> fstate=new HashMap<String,Object>();
	
		//System.out.println("ControlHandler:step:3");
		
		state=StateHandler.updateMap(state, mstate);
		state=StateHandler.updateMap(state, rstate);
		state=StateHandler.updateMap(state, cstate);
		
		
		pars=StateHandler.updateMap(pars, mpars);
	
		pars=StateHandler.updateMap(pars, rpars);
		pars=StateHandler.updateMap(pars, cpars);
		//System.out.println("ControlHandler:step::kosc="+pars.get("kosc"));
		//prepare takt
	
		double time=Double.parseDouble(controller.getElementItemAt("operator", Instrument.TIME));
	
		double takt=Double.parseDouble(controller.getElementItemAt("operator", Instrument.TAKT));
		double endTakt=time+takt;
		double qtakt=Double.parseDouble(controller.getElementItemAt("controller", "qtakt"));
		
		
		//System.out.println("ControlHandler:step:8");
		
		//state.put("ctime",0.0);
		do {
			cstate=ch.quantum(time, qtakt, state, pars);
			state=StateHandler.updateMap(state, cstate);
			mstate=mh.quantum(time, qtakt, state, pars);
			state=StateHandler.updateMap(state, mstate);
			//fstate=fh.quantum(time, qtakt, state, pars);
			state=StateHandler.updateMap(state, fstate);
			time=time+qtakt;
			
		}while(time<endTakt);
		String flag$=entigrator.folderFile(controller.getKey()).getPath()+"/stop";
		File flag=new File(flag$);
		if(flag.exists()) {
			flag.delete();
			state.put("kcount","0");
			state.put("qcount","0");
			state.put("peakRipple","0");
			state.put("averageRipple","0"); 
			String time$=controller.getElementItemAt("operator", Instrument.TIME);
		    controller.putElementItem("operator", new Core(null,"start",time$));
		}
		controller=ch.commit(controller, state);
		motor=mh.commit(motor, state);
		regulator=((StateHandler)rh).commit(regulator, state);
		//filter=fh.commit(filter, state);
		entigrator.putEntity(motor);
		entigrator.putEntity(regulator);
		entigrator.putEntity(controller);
		entigrator.putEntity(filter);
		}catch(Exception e) {
			Logger.getLogger(ControllerHandler.class.getName()).severe(e.toString());
		}
		
		return controller;
		*/
			
			return null;
	}

	//@Override
  public   void stop  ( Entigrator entigrator,String locator$ ) {
	  //Sack controller=entigrator.getEntityAtKey(entityKey$);
	  String label$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	  Sack controller=entigrator.getEntityAtLabel(label$);
	  //controller.print("operator");
	 try {
	  int kprev=0;
		try {kprev=Integer.parseInt(controller.getElementItemAt("operator", "kprev"));}catch(Exception e) {}
		
		long kcount=0;
		try {kcount=Long.parseLong(controller.getElementItemAt("operator", "kcount"));}catch(Exception e) {}
		
		
		long qcount=0;
		try {qcount=Long.parseLong(controller.getElementItemAt("operator", "qcount"));}catch(Exception e) {}
		
		double peakRipple=0;
		try {peakRipple=Double.parseDouble(controller.getElementItemAt("operator", "peakRipple"));}catch(Exception e) {}
		
		
		double averageRipple=0;
		try {averageRipple=Double.parseDouble(controller.getElementItemAt("operator", "averageRipple"));}catch(Exception e) {}
		
		double idd=0;
		try {idd=Double.parseDouble(controller.getElementItemAt("operator", "idd"));}catch(Exception e) {}
		
		double qtakt=0;
		try {qtakt=Double.parseDouble(controller.getElementItemAt("controller", "qtakt"));}catch(Exception e) {}
		
		double time=0;
		try {time=Double.parseDouble(controller.getElementItemAt("operator", "time"));}catch(Exception e) {}
		
		double start=0;
		try {start=Double.parseDouble(controller.getElementItemAt("operator", "start"));}catch(Exception e) {}
		
		double ctakt=0;
		try {ctakt=Double.parseDouble(controller.getElementItemAt("controller", "ctakt"));}catch(Exception e) {}
		
		double kws=0;
		try {kws=Double.parseDouble(controller.getElementItemAt("controller", "kws"));}catch(Exception e) {}
		
		double kfs=0;
		try {kfs=Double.parseDouble(controller.getElementItemAt("controller", "kfs"));}catch(Exception e) {}
		
		double w0=0;
		try {w0=Double.parseDouble(controller.getElementItemAt("operator", "w0"));}catch(Exception e) {}
		
		
		
		String motorKey$=controller.getElementItemAt("controller","motor");
		Sack motor=entigrator.getEntity(motorKey$);
		double mc=0;
		try {mc=Double.parseDouble(motor.getElementItemAt("operator", "mc"));}catch(Exception e) {}
		
		
		System.out.println("ControlHandler:stop:start="+start);
		double qtime=qtakt*qcount;
		double freq=kcount/qtime;
		
		averageRipple=averageRipple/qtime;
		idd=idd/qtime;
		
		StringBuffer sb=new StringBuffer();
		sb.append(String.valueOf(w0)+",");
		sb.append(String.valueOf(mc)+",");
		sb.append(String.valueOf(start)+",");
		sb.append(String.valueOf(time)+",");
		sb.append(String.valueOf(ctakt)+",");
		sb.append(String.valueOf(kws)+",");
		sb.append(String.valueOf(kfs)+",");
		sb.append(String.valueOf(peakRipple)+",");
		sb.append(String.valueOf(averageRipple)+",");
		
		sb.append(String.valueOf(freq)+",");
		sb.append(String.valueOf(idd)+"\n");
		//System.out.println("ControlHandler:stop:kprev="+kprev+" kcount="+kcount+"  qcount="+qcount+" peakRipple="+peakRipple+"  averageRipple="+averageRipple+" freq="+freq +"  idd="+idd);
		String path$=entigrator.folderFile(controller.getKey()).getPath()+"/protocol.csv";
		File protocol=new File(path$);
		boolean addHeader=false;
		if(!protocol.exists()) {
				protocol.createNewFile();
				addHeader=true;
		}
		FileWriter fw= new FileWriter(protocol, true);
		BufferedWriter bw = new BufferedWriter(fw);
	    if(addHeader) {
				String header$="W0(1/s),MC(Nm),Start(s),End(s),Ctakt(s),Kws,Kfs,Peak ripple(1/s),Average ripple(1/s),Frequency (Hz),Id(A)\n";
				bw.append(header$);
	    }
	    bw.append(sb.toString());
		bw.close();
		
	  controller.putElementItem("operator",new Core("output","kcount","0"));
	  controller.putElementItem("operator",new Core("output","qcount","0"));
	  controller.putElementItem("operator",new Core("output","peakRipple","0"));
	  controller.putElementItem("operator",new Core("output","averageRipple","0"));
	  controller.putElementItem("operator",new Core("output","idd","0"));
	 // controller.putElementItem("operator", new Core("output","start",String.valueOf(time)));
	 // controller.putElementItem("operator",new Core("output","start","0"));
	  entigrator.putEntity(controller);
	  String flag$=entigrator.folderFile(controller.getKey()).getPath()+"/stop";
	  File flag=new File(flag$);
	if(!flag.exists())
		try {flag.createNewFile();}catch(Exception e) {}
	 }catch(Exception e) {
			Logger.getLogger(ControllerHandler.class.getName()).severe(e.toString());
		}  
  };
	private static V2 getVk(int k ){
		 double a=- Math.PI/6 +k*Math.PI/3;
		 double cos=Math.cos(a);
		 double sin=Math.sin(a);
		 return new V2(cos,sin);
	}
	private static int bestK (V2 v) {
		double worth=0;
		double best=0;
		V2 vk;
		int k=-1;
		for(int n=0;n<6;n++) {
			vk=getVk(n);
			worth=v.dotProduct(vk);
			if(worth>best) {
				best=worth;
				k=n;
			}
		}
		return k;
	}
	
	private static V2  fixIaq (double ia,double iq,double df,double dw,double dflim,double dwlim) {
		System.out.println("ControlHandler:fixI:ia="+ia+" iq="+iq+"  df="+df+"  dw="+dw);
		V2 aq=new V2(ia,iq);
		if(df>dflim) {
			aq.y=0.3*iq;
			
		}else {
			if(Math.abs(dw)>dwlim) {
				aq.x=0.5*ia;
			    
			}
		}
		aq.print("iaq");
		return aq;
	}
	private static int bestKm (V2 v,V2 f,double dw,double id,double iq) {
		double worth=0;
		double best=0;
		V2 vk;
		int k=-1;
		double di;
		for(int n=0;n<6;n++) {
			vk=getVk(n);
			di=iq-id*vk.crossProduct(f)/(f.norm()*vk.norm());
			System.out.println("ControllerHandler:bestKm:di="+di+"  n="+n+"  dw="+dw);
  		    worth=v.dotProduct(vk);
			
			//	worth=di*dw;	
			if(worth>best) {
				best=worth;
				k=n;
			}
		}
		
		if(dw>0.5)
			k=k+1;
		if(dw<-0.5)
			k=k-1;
		System.out.println("ControllerHandler:bestKm:k="+k);
		return k;
	}
	
	private static Sack initZ2params(Entigrator entigrator,Sack controller) {
		try {
		String motor$=controller.getElementItemAt("controller", "motor");
		Sack motor=entigrator.getEntity(motor$);	
		int pol=Integer.parseInt(motor.getElementItemAt("nominal", "pol"));
		double j=Double.parseDouble(motor.getElementItemAt("nominal", "j"));
		double tw0=j/pol;
		controller.putElementItem("controller",new Core(null,"tw0",String.valueOf(tw0)));
		double r2=Double.parseDouble(motor.getElementItemAt("epar", "r2"));
		double emax=Double.parseDouble(controller.getElementItemAt("controller", "emax"));
		double km0=r2/(pol*emax*emax);
		controller.putElementItem("controller",new Core(null,"km0",String.valueOf(km0)));
		}catch(Exception e) {
			System.out.println("ControllerHandler:initZ2params:"+e.toString());
		}
		return controller;
	}
	
	public void reset(Entigrator entigrator, String locator$) {
		try{
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			Sack controller=entigrator.getEntityAtLabel(entity$);
			if(!controller.existsElement("operator")) 
				controller.createElement("operator");
				controller.putElementItem("operator",new Core("input","fx","0"));
				controller.putElementItem("operator",new Core("input","fy","0"));
				controller.putElementItem("operator",new Core("input","wr","0"));
				controller.putElementItem("operator",new Core("input","w0","0"));
				controller.putElementItem("operator",new Core("input","id","0"));
				controller.putElementItem("operator",new Core("input","ed","0"));
				//controller.putElementItem("operator",new Core("output","oy","0"));
				controller.putElementItem("operator",new Core(null,"iai","0"));
				controller.putElementItem("operator",new Core(null,"iqi","0"));
				controller.putElementItem("operator",new Core("output","id0","0"));
				controller.putElementItem("operator",new Core("output","vx","1"));
				controller.putElementItem("operator",new Core("output","vy","0"));
				controller.putElementItem("operator",new Core("output","edf","0"));
				controller.putElementItem("operator",new Core("output","ia","0"));
				controller.putElementItem("operator",new Core("output","iq","0"));
				controller.putElementItem("operator",new Core("output","iai","0"));
				controller.putElementItem("operator",new Core("output","iqi","0"));
				controller.putElementItem("operator",new Core("output","mf","0"));
				controller.putElementItem("operator",new Core("output","ftime","0"));
				controller.putElementItem("operator",new Core("output","ctime","0"));
				controller.putElementItem("operator",new Core("output","kprev","0"));
				controller.putElementItem("operator",new Core("output","kcount","0"));
				controller.putElementItem("operator",new Core("output","qcount","0"));
				controller.putElementItem("operator",new Core("output","peakRipple","0"));
				controller.putElementItem("operator",new Core("output","averageRipple","0"));
				controller.putElementItem("operator",new Core("output","idd","0"));
				controller.putElementItem("operator",new Core("output","start","0"));		
				String flag$=entigrator.getEntihome()+controller.getKey()+"/stop";
				File flag=new File(flag$);
				if(flag.exists())
					flag.delete();
				controller.putElementItem("controller",new Core(null,"stop","false"));
				//controller.putElementItem("operator",new Core("output","wdev","0"));
				String appliance$=controller.getElementItemAt("operator", "appliance");
				Sack appliance=entigrator.getEntity(appliance$);
				Sack motor=null;
				Sack regulator=null;
				String[] sa=appliance.elementListNames("component");
				Sack candidate;
				for(String s:sa) {
					candidate=entigrator.getEntity(s);
					if("motor".equals(candidate.getProperty("state.holder")))
						motor=candidate;
					if("regulator".equals(candidate.getProperty("state.holder")))
						regulator=candidate;
				}
				if(!controller.existsElement("state.holder"))
					controller.createElement("state.holder");
				String stateHandler$=motor.getProperty("state.handler");
				controller.putElementItem("state.holder", new Core(stateHandler$,"motor",motor.getKey()));
				stateHandler$=regulator.getProperty("state.handler");
				controller.putElementItem("state.holder", new Core(stateHandler$,"regulator",regulator.getKey()));
				controller=initZ2params(entigrator, controller);
				entigrator.putEntity(controller);
			//super.reset(entigrator,locator$);
		    
		}catch(Exception e){
			LOGGER.info(e.toString());
		}	
	}
	
	

private boolean isGenerator(double w0,double wr) {
	if(w0==0&&wr==0)
		return false;
	double dw=w0-wr;
	if(Math.abs(dw)<10)
		return false;
	if(dw==0)
		return false;
	if(dw>0&&w0>=0)
		return false;
	if(dw<0&&w0<=0)
		return false;
	return true;
}
private int getN(double dw, double df, double[] marr,double[] zarr) {
	if(df>=0) {
		if(dw>=0) {
			for (int i=0;i<4;i++) 
				if(marr[i]>=0&&zarr[i]>=0)
					return i;
			
		}else {
			for (int i=0;i<4;i++) 
				if(marr[i]<0&&zarr[i]>=0) {
					System.out.println("ControllerHandler:getN:marr["+i+"]="+marr[i]+" zarr[i]="+zarr[i]);	
					return i;
				}
		}
	}else {
		if(dw>=0) {
			for (int i=0;i<4;i++) {
				if(marr[i]>=0&&zarr[i]<0)
					return i;
			}
			
		}else {
			for (int i=0;i<4;i++) 
				if(marr[i]<0&&zarr[i]<0)
					return i;
		}
	}
	
	
	return -1;
}
public static double limit(double var, double lim) {
	if(var>lim)
		return lim;
	if(var<-lim)
		return -lim;
	return var;
}

public HashMap<String, Object> quantum(double time, double qtakt, HashMap<String, Object> state,	HashMap<String, Object> pars) {
	
	try {
	
	
	double fx=0;
	try {fx=((Double)state.get("fx")).doubleValue();}catch(Exception e) {}
	double fy=0;
	try {fy=((Double)state.get("fy")).doubleValue();}catch(Exception e) {}
	double wr=0;
	try {wr=((Double)state.get("wr")).doubleValue();}catch(Exception e) {}
	double w0=0;
	try {w0=((Double)state.get("w0")).doubleValue();}catch(Exception e) {}
	double iqi=0;
	try {iqi=((Double)state.get("iqi")).doubleValue();}catch(Exception e) {}
	double iai=0;
	try {iai=((Double)state.get("iai")).doubleValue();}catch(Exception e) {}
	
	double id=0;
	try {id=((Double)state.get("id")).doubleValue();}catch(Exception e) {}
	double ctime=0;
	try {ctime=((Double)state.get("ctime")).doubleValue();}catch(Exception e) {}
	
	
	
	int fcount=0;
	try {fcount=((int)state.get("fcount"));}catch(Exception e) {}
	
	//moment filter
	double mf=0;
	try {mf=((Double)state.get("mf")).doubleValue();}catch(Exception e) {}
	double mq=0;
	try {mq=((Double)state.get("mq")).doubleValue();}catch(Exception e) {}
	//init  parameters
	int kft=5;
	try {kft=((int)pars.get("kft"));}catch(Exception e) {}
	double fbase=0;
	try {fbase=((Double)pars.get("fbase")).doubleValue();}catch(Exception e) {}
	double tdev=0;
	try {tdev=((Double)pars.get("tdev")).doubleValue();}catch(Exception e) {}
	double c0=0;
	try {c0=((Double)pars.get("c0")).doubleValue();}catch(Exception e) {}
	double c1=0;
	try {c1=((Double)pars.get("c1")).doubleValue();}catch(Exception e) {}
	double ctakt=0;
	try {ctakt=((Double)pars.get("ctakt")).doubleValue();}catch(Exception e) {}
		
	double kqw=0;
	try {kqw=((Double)pars.get("kqw")).doubleValue();}catch(Exception e) {}
	
	double kqwp=0;
	try {kqwp=((Double)pars.get("kqwp")).doubleValue();}catch(Exception e) {}
	
	double kaf=32;
	try {kaf=((Double)pars.get("kaf")).doubleValue();}catch(Exception e) {}
	double kafp=1;
	try {kafp=((Double)pars.get("kafp")).doubleValue();}catch(Exception e) {}
	
	int k=0;	
	try {k=((Integer)state.get("k"));}catch(Exception e) {}
	
	String z2$="false";
	try {z2$=((String)state.get("z2"));}catch(Exception e) {} 
	
	int kprev=0;	
	try {kprev=((Integer)state.get("kprev"));}catch(Exception e) {}
	long kcount=0;	
	try {kcount=((Long)state.get("kcount"));}catch(Exception e) {}
	
	long qcount=0;	
	try {qcount=((Long)state.get("qcount"));}catch(Exception e) {}
	
	 double  peakRipple=0;
	 try {peakRipple=((Double)state.get("peakRipple")).doubleValue();}catch(Exception e) {}
	 
	 double  averageRipple=0;
	 try {averageRipple=((Double)state.get("averageRipple")).doubleValue();}catch(Exception e) {}
	 
	 double  idd=0;
	 try {idd=((Double)state.get("idd")).doubleValue();}catch(Exception e) {}
	 
	ctime=ctime+qtakt;
  //criteria
	//
	if(k!=kprev) {
	   kcount++;
	  // System.out.println("ControllerHandler:quantum:k="+k+" kprev="+kprev+"  kcount="+kcount);
	}
   kprev=k;
   qcount++;
   double wDev=Math.abs(wr-w0);
   //System.out.println("ControllerHandler:quantum:0:peakRipple="+peakRipple);
   if(wDev>peakRipple) {
	   peakRipple=wDev;
	 // System.out.println("ControllerHandler:quantum:1:peakRipple="+peakRipple);
   }
   if(qcount>2) { 
      //averageRipple=(averageRipple+wDev*qtakt)/(qtakt*qcount);
	   averageRipple=averageRipple+Math.abs(wDev)*qtakt;
	   idd=idd+id*qtakt;
   }else {
	   averageRipple=0;
	   idd=0;
   }
 state.put("kprev",kprev); 
 state.put("kcount",kcount); 
 state.put("qcount",qcount); 
 state.put("peakRipple",peakRipple); 
 state.put("averageRipple",averageRipple); 
 state.put("idd",idd); 
// System.out.println("ControllerHandler:quantum:averageRipple="+averageRipple);
   //end criteria
   
  //CONTROLLER BEGIN
    
  if(ctime>ctakt) { 
	   ctime=0;
	fcount=fcount+1;
	//System.out.println("ControllerHandler:quantum:fcount="+fcount);
	if(fcount>kft) {
		fcount=0;
	}
	double fnom=2*fbase;
	Object rh=pars.get("rhandler");
//	HashMap<String, Object> rstate=((StateHandler)rh).quantum(time, qtakt, state, pars);
//	state=StateHandler.updateMap(state, rstate);
	 //detect zone 2
	 boolean z2=false;
	 if("true".equals(z2$))
		 z2=true;
	 double hw=20;
	 if(Math.abs(wr)<314-hw) {
		 z2=false;
			state.put("z2", "false");
	 }
	 if(Math.abs(wr)>314+hw) {
			z2=true;
			state.put("z2", "true");
	 }
	 //end detect zone 2
	
	double wz0=w0;
	
	if(z2) {
			if(Math.abs(w0-wr)<20)
						wz0=w0;
			else {
				if(w0>wr)
					wz0=wr+20;
				else
					wz0=wr-20;	
			}
		mf=0;
	    fnom=Math.abs(fnom*314/wz0);
		iqi=0;
	}else {
		///////////
		//mf=0;
		//fnom=fbase+mf*0.1*iq;
		//fnom=2.5*fbase;
	}
	double dw=wz0-wr;
	//	System.out.println("ControllerHandler:quantum:dw="+dw+"  wz0="+wz0+"  wr="+wr); 
   iqi=iqi+dw*kqw;	
   double ff=fx*fx+fy*fy;
   double fnorm=Math.sqrt(ff);
  
  //if( fnom>2)
//	  fnom=2;
 
   double dff=fnom-fnorm;
   iai=iai+ dff*kaf;
   if(iai>20)
	   iai=20;
   if(iai<-20)
	   iai=-20;
   state.put("iai", iai); 
   state.put("iqi", iqi);
   double iq=dw*kqwp+iqi;
 //  if(!z2)
  //   fnom=fbase+mf*0.1*Math.abs(iq);
   
   //System.out.println("ControllerHandler:quantum:iq=="+iq+"  iqi="+iqi+"  kqwp="+kqwp); 
 V2 f=new V2(fx, fy);
 double ia0=dff*kafp+iai;
 double ia=ia0-c0*wr*iq;
 //double ia=ia0+c0*wr*iq;
// ia=ia0;
 V2 vk=getVk(k);
 //double wf= wr+ctakt*vk.rotation().dotProduct(f)*id*c1/fnorm;
 //double wf= wr+ctakt*vk.rotation().dotProduct(f)*id*c1;
 double wf= wr;
 double ashift=ctakt*wf;
// ashift=ashift;
 mq=Math.abs(iq*fnorm);

 //mf=mf+ctakt*(0.3*mq-mf)/tdev;
 if(!z2) {
if(fnom<2)	 
     mf=mf+ctakt*(Math.abs(iq)-mf)*100;
     fnom=fbase+mf*0.1;
 }
 if(fnom>2)
	   fnom=2;
// System.out.println("ControllerHandler:quantum:iq="+iq+"  mf="+mf+" fnom="+fnom+"   ia="+ia+ "   fnorm="+fnorm);
state.put("mf", mf); 
	state.put("iq", iq);
	state.put("ia", ia);
	state.put("mq", mq);
	if(pars.get("print2")!=null)
				System.out.println("ControllerHandler:quantum:mq="+mq+"  ia="+ia+" iq="+iq+"  ia0="+ia0 );
	MotorHandler.Z faz=new MotorHandler.Z(c1,c0*wr);
	//MotorHandler.Z faz=new MotorHandler.Z(c1,-c0*wr);
	MotorHandler.Z fqz=new MotorHandler.Z(0,1);
	V2 iaq=new V2(ia,iq);
	//MotorHandler.V2 iaq=fixIaq(ia,iq,dff,dw,0.2,0.5);

	M2 rSin= new M2(1,-ashift,ashift,1);
	V2 fz= rSin.product(f);
	V2 fa=faz.product(fz);
	V2 fq=fqz.product(fz);
	V2 i= iaq.resolveProjections(fa, fq);
	double id0=i.norm();
	if(id0>50)
		id0=50;
	if(id0<-50)
		id0=-50;
	state.put("id0", id0);	
	///
	//MotorHandler.V2 ifix=fixI(i,dff,dw,0.2,0.5);
	//k=bestK(ifix);
	///
    k=bestK(i);
    vk=getVk(k);
    //1.5*pol*
 //   System.out.println("ControllerHandler:quantum:dff="+dff+"  ia="+ia+"  ia0="+ia0+"   fnom="+fnom+"  fnorm="+fnorm+"  iq="+iq);
  // if(Math.abs(dff)<0.3)
    {
    	//double md=1.5*3*id*vk.crossProduct(f);
    	double md=vk.crossProduct(f);
    	V2 vka=getVk(k-1);
    	//double mda=1.5*3*id*vka.crossProduct(f);
    	double mda=vka.crossProduct(f);
    	V2 vkb=getVk(k+1);
    	//double mdb=1.5*3*id*vkb.crossProduct(f);
    	double mdb=vkb.crossProduct(f);
    	// System.out.println("ControllerHandler:quantum:md="+1.5*3*id*vk.crossProduct(f)+" mda="+mda+" mdb="+mdb+"  k="+k+"   wr="+wr);
       
    	 if(dw>0) {
        	
        	if(mda>md)
        	   k=k-1;
        	if(mdb>md)
         	   k=k+1;
        }
           
    }
   if(k<0)
	   k=5;
   if(k>5)
	   k=0;
	state.put("k", k);
	state.put("fcount", fcount);
  }
 
////FINISH CONTROLLER
  

   
V2 vk=getVk(k);
 
 state.put("vx",vk.x ); 
 state.put("vy", vk.y); 
 state.put("ctime", ctime); 
 
 }catch(Exception e) {
		LOGGER.severe(e.toString());
}
	return state;
		
}
//	@Override
	public HashMap<String, Object> initPars(Sack controller) {
		//	System.out.println("ControllerHandler:initPars:controller="+controller.getProperty("label"));
		//controller parameters
		double ctakt=0.00025;
		try{ctakt=Double.parseDouble(controller.getElementItemAt("controller","ctakt" ));} catch(Exception nfe){}
		double kft=5;
		try{kft=Double.parseDouble(controller.getElementItemAt("controller","kft" ));} catch(Exception nfe){}
		
		
		double kws=4;
		try{kws=Double.parseDouble(controller.getElementItemAt("controller","kws" ));} catch(Exception nfe){}
		
		
		double emax=450;
		try{emax=Double.parseDouble(controller.getElementItemAt("controller","emax" ));} catch(Exception nfe){}
		double fdev=1;
		try{fdev=Double.parseDouble(controller.getElementItemAt("controller","fdev" ));} catch(Exception nfe){}
		double fbase=1;
		try{fbase=Double.parseDouble(controller.getElementItemAt("controller","fbase" ));} catch(Exception nfe){}
		double imax=50;
		try{imax=Double.parseDouble(controller.getElementItemAt("controller","imax" ));} catch(Exception nfe){}
		
		double mbase=40;
		try{mbase=Double.parseDouble(controller.getElementItemAt("controller","mbase" ));} catch(Exception nfe){}
		//double wdev=20;
		//try{wdev=Double.parseDouble(controller.getElementItemAt("controller","wdev" ));} catch(Exception nfe){}
		int kfs=1;
		try{kfs=Integer.parseInt(controller.getElementItemAt("controller","kfs" ));} catch(Exception nfe){}
		
		
		double tdev=0.00004;
		try{tdev=Double.parseDouble(controller.getElementItemAt("controller","tdev" ));} catch(Exception nfe){}
		//double tw=0.001;
		//try{tw=Double.parseDouble(controller.getElementItemAt("controller","tw" ));} catch(Exception nfe){}
		double c0=0.011476;
		try{c0=Double.parseDouble(controller.getElementItemAt("controller","c0" ));} catch(Exception nfe){}
		double c1=1.127508;
		try{c1=Double.parseDouble(controller.getElementItemAt("controller","c1" ));} catch(Exception nfe){}
		
		double c2=9;
		try{c2=Double.parseDouble(controller.getElementItemAt("controller","c2" ));} catch(Exception nfe){}
		
		double c3=16;
		try{c3=Double.parseDouble(controller.getElementItemAt("controller","c3" ));} catch(Exception nfe){}
		
		
		double fnom=1;
		try{fnom=Double.parseDouble(controller.getElementItemAt("controller","fnom" ));} catch(Exception nfe){}
		double km0=1;
		try{km0=Double.parseDouble(controller.getElementItemAt("controller","km0" ));} catch(Exception nfe){}
		
		double tw0=1;
		try{tw0=Double.parseDouble(controller.getElementItemAt("controller","tw0" ));} catch(Exception nfe){}
		
		double tw=1;
		try{tw=Double.parseDouble(controller.getElementItemAt("controller","tw" ));} catch(Exception nfe){}
		double tf=32;
		try{tf=Double.parseDouble(controller.getElementItemAt("controller","tf" ));} catch(Exception nfe){}
		
		
		
		 double ts=kws*ctakt;
		 double kqw=tw/(8*kws*kws*ctakt);
		 double kaf=1/(tf*kfs);
		 double kqwp=tw/(2*ts);
		 double kafp=1/(ctakt*kfs);
		 
		// System.out.println("ControllerHandler:initPars:kqwp="+kqwp+"  tw="+tw+"  ts="+ts);
		HashMap<String, Object>pars=new HashMap<String, Object>();
		
		pars.put("delay", ctakt);
		pars.put("kws", kws);
		pars.put("emax", emax);
		pars.put("fdev", fdev);
		pars.put("fbase", fbase);
		pars.put("mbase", mbase);
		pars.put("imax", imax);
		//pars.put("wdev", wdev);
		pars.put("kfs", kfs);
		pars.put("tdev",tdev);
		pars.put("ctakt",ctakt);
		pars.put("kft",kft);
		pars.put("c0",c0);
		pars.put("c1",c1);
		pars.put("c2",c2);
		pars.put("fnom",fnom);
		pars.put("km0",km0);
		pars.put("tw0",tw0);
		pars.put("kqw",kqw);
		pars.put("kqwp",kqwp);
		pars.put("kaf",kaf);
		pars.put("kafp",kafp);
		//pars.put("fwr",fwr$);
		//operative print control
		if("true".equals(controller.getElementItemAt("print", "1"))) 
			pars.put("print1", 1);
		if("true".equals(controller.getElementItemAt("print", "2"))) 
				pars.put("print2", 2);
		if("true".equals(controller.getElementItemAt("print", "3"))) 
					pars.put("print3", 3);		
		
		
		return pars;
	}
	//@Override
	public HashMap<String, Object> initState(Sack operator) {
		HashMap<String, Object>state=new HashMap<String, Object>();
		state.put("ctime", 0);
		
		double time=0;
		try {time=Double.parseDouble(operator.getElementItemAt("operator", "time"));}catch(Exception e) {}
		state.put("time", time);
	
		double iai=0;
		try {iai=Double.parseDouble(operator.getElementItemAt("operator", "iai"));}catch(Exception e) {}
		state.put("iai", iai);
		double iqi=0;
		try {iqi=Double.parseDouble(operator.getElementItemAt("operator", "iqi"));}catch(Exception e) {}
		state.put("iqi", iqi);
		double id0=0;
		try {id0=Double.parseDouble(operator.getElementItemAt("operator", "id0"));}catch(Exception e) {}
		state.put("id0", id0);
		double id=0;
		try {id=Double.parseDouble(operator.getElementItemAt("operator", "id"));}catch(Exception e) {}
		state.put("id", id);
		double iq=0;
		try {iq=Double.parseDouble(operator.getElementItemAt("operator", "iq"));}catch(Exception e) {}
		state.put("iq", iq);
		
		double ia=0;
		try {ia=Double.parseDouble(operator.getElementItemAt("operator", "ia"));}catch(Exception e) {}
		state.put("ia", ia);
		//moment filter{
		double mf=0;
		try {mf=Double.parseDouble(operator.getElementItemAt("operator", "mf"));}catch(Exception e) {}
		state.put("mf", mf);
		//}
		double ctime=0;
		try {ctime=Double.parseDouble(operator.getElementItemAt("operator", "ctime"));}catch(Exception e) {}
		state.put("ctime", ctime);
		int k=0;
		try {k=Integer.parseInt(operator.getElementItemAt("operator", "k"));}catch(Exception e) {}
		state.put("k", k);
		
		int fcount=0;
		try {fcount=Integer.parseInt(operator.getElementItemAt("operator", "fcount"));}catch(Exception e) {}
		state.put("fcount", fcount);
		
		String z2$="false";
		try {z2$=operator.getElementItemAt("operator", "z2");}catch(Exception e) {}
		state.put("z2", z2$);
		
		int kprev=0;
		try {kprev=Integer.parseInt(operator.getElementItemAt("operator", "kprev"));}catch(Exception e) {}
		state.put("kprev", kprev);	
		long kcount=0;
		try {kcount=Long.parseLong(operator.getElementItemAt("operator", "kcount"));}catch(Exception e) {}
		state.put("kcount", kcount);
		
		long qcount=0;
		try {qcount=Long.parseLong(operator.getElementItemAt("operator", "qcount"));}catch(Exception e) {}
		state.put("qcount", qcount);
		double peakRipple=0;
		try {peakRipple=Double.parseDouble(operator.getElementItemAt("operator", "peakRipple"));}catch(Exception e) {}
		state.put("peakRipple", peakRipple);
		
		double averageRipple=0;
		try {averageRipple=Double.parseDouble(operator.getElementItemAt("operator", "averageRipple"));}catch(Exception e) {}
		state.put("averageRipple", averageRipple);
		
		double idd=0;
		try {idd=Double.parseDouble(operator.getElementItemAt("operator", "idd"));}catch(Exception e) {}
		state.put("idd", idd);
		
		return state;
	}
	
	public Sack commit(Sack operator, HashMap<String, Object> state) {
		//System.out.println("ControllerHandler:commit:--------------------------");
		//StateHandler.print(state);
		double time=0;
		try {time=(double)state.get("time");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("global","time",String.valueOf(time)));
		double vx=1;
		try {vx=(double)state.get("vx");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","vx",String.valueOf(vx)));
		double vy=0;
		try {vy=(double)state.get("vy");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","vy",String.valueOf(vy)));
		//System.out.println("ControllerHandler:commit:vy="+vy);
		double iai=0;
		try {iai=(double)state.get("iai");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","iai",String.valueOf(iai)));
		double iqi=0;
		try {iqi=(double)state.get("iqi");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","iqi",String.valueOf(iqi)));
		double iq=0;
		try {iq=(double)state.get("iq");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","iq",String.valueOf(iq)));
		double ia=0;
		try {ia=(double)state.get("ia");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","ia",String.valueOf(ia)));
		double ctime=0;
		try {ctime=(double)state.get("ctime");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("local","ctime",String.valueOf(ctime)));
		int fcount=5;
		try {fcount=(int)state.get("fcount");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("local","fcount",String.valueOf(fcount)));
		
		double  mf=0;
		try {mf=(double)state.get("mf");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","mf",String.valueOf(mf)));
		//System.out.println("ControllerHandler:commit:ci="+ci);
		
		double w0=0;
		try {w0=(double)state.get("w0");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","w0",String.valueOf(w0)));
		
		double id0=0;
		try {id0=(double)state.get("id0");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","id0",String.valueOf(id0)));
		String fwr$="false";
		try {fwr$=((String)state.get("fwr"));}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","fwr",fwr$));
		
		int k=0;
		try {k=(int)state.get("k");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","k",String.valueOf(k)));
		
		String z2$="false";
		try {z2$=(String)state.get("z2");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","z2",z2$));
		
		int kprev=0;
		try {kprev=(int)state.get("kprev");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","kprev",String.valueOf(kprev)));
		
		long kcount=0;
		try {kcount=(long)state.get("kcount");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","kcount",String.valueOf(kcount)));
		long qcount=0;
		try {qcount=(long)state.get("qcount");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","qcount",String.valueOf(qcount)));
		double peakRipple=0;
		try {peakRipple=(double)state.get("peakRipple");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","peakRipple",String.valueOf(peakRipple)));
		double averageRipple=0;
		try {averageRipple=(double)state.get("averageRipple");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","averageRipple",String.valueOf(averageRipple)));
		double idd=0;
		try {idd=(double)state.get("idd");}catch(Exception e) {}
		operator.putElementItem("operator", new Core("output","idd",String.valueOf(idd)));
		return operator;
	}
	 public static double normalize(final double angle) {
	        return (angle >= 0 ? angle : (360 - ((-angle) % 360))) % 360;
	    }
	 
	public static void main(String[]aa) {
		       double angle =500;
		        double a=(angle >= 0 ? angle : (360 - ((-angle) % 360))) % 360;
		       // System.out.println(" angle="+angle+" a="+a);
		    }
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		
		return CONTROLLER_FACET_NAME;
	}
	@Override
	public String getType() {
		
		return CONTROLLER_FACET_TYPE;
	}
	@Override
	public String getFacetClass() {
		return CONTROLLER_FACET_CLASS;	}
	
	@Override
	public String[] listOutputs() {
		return new String[] {
				"kcount",
				"qcount",
				"peakRipple",
				"averageRipple",
				"idd"
		};
	}
	@Override
	public String[] listInputs() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
		try {
			///Motor handler	
			/*
			Core mcore=controller.getElementItem("state.holder", "motor");
			String motorKey$=mcore.value;
			//Sack motor=entigrator.getEntity(motor$);
			
			//String mlocator$=EntityHandler.getEntityLocator(entigrator, motor);
			String motor$=entigrator.getLabel(motorKey$);
			String motorHandler$=MotorHandler.classLocator();
			motorHandler$=Locator.append(motorHandler$, entigrator.ENTITY_LABEL, motor$);
			MotorHandler mh=new MotorHandler(entigrator,motorHandler$);
			Sack motor=entigrator.getEntity(motorKey$);
			HashMap<String,Object> mpars=mh.initPars(motor);
			double tw=(double)mpars.get("tw");
			double tf=(double)mpars.get("tf");
//			controller.putElementItem("controller", new Core(null,"tw",String.valueOf(tw)));
//			controller.putElementItem("controller", new Core(null,"tf",String.valueOf(tf)));
			//	System.out.println("ControlHandler:step:motor pars-----------------");
		//	StateHandler.print(mpars);
			HashMap<String,Object> mstate=mh.initState(motor);
			
			
		// controller
		String 	controllerHandler$=ControllerHandler.classLocator();
		controllerHandler$=Locator.append(controllerHandler$, Entigrator.ENTITY_LABEL,controller.getProperty(Entigrator.LABEL));
		ControllerHandler ch=new ControllerHandler (entigrator,controllerHandler$);
		HashMap<String,Object> cpars=ch.initPars(controller);
		HashMap<String,Object> cstate=ch.initState(controller);
		
		//regulator
		Core rcore=controller.getElementItem("state.holder", "regulator");
		String regulator$=rcore.value;
		Sack regulator=entigrator.getEntity(regulator$);
	//	String rlocator$=EntityHandler.getEntityLocator(entigrator, regulator);
		String rhandler$=rcore.type;
		ClassLoader parentLoader = ControllerHandler.class.getClassLoader();
		Class<?> rclass=parentLoader.loadClass(rhandler$);
		Object rh= rclass.getDeclaredConstructor().newInstance();
		cpars.put("rhandler", rh);
		HashMap<String,Object> rpars=((StateHandler)rh).initPars(regulator);
		HashMap<String,Object> rstate=((StateHandler)rh).initState(regulator);
		
		//filter
		String appliance$=controller.getElementItemAt("operator", "appliance");
		//String[]sa=ApplianceHandler.listComponents(entigrator, appliance$, "filter");
		String[]sa=null;
				
				//applianceHandler.listOperators(entigrator, appliance$);
		Sack filter=null;
		if(sa!=null) {
			for(String s:sa) {
				filter=entigrator.getEntity(s);
				
			}
		}
	
		HashMap<String,Object> state=new HashMap<String,Object>();
		//state=new HashMap<String,Object>();
		HashMap<String,Object> pars=new HashMap<String,Object>();
		HashMap<String,Object> fstate=new HashMap<String,Object>();
	
		//System.out.println("ControlHandler:step:3");
		state=StateHandler.updateMap(state, mstate);
		state=StateHandler.updateMap(state, rstate);
		state=StateHandler.updateMap(state, cstate);
		
		
		pars=StateHandler.updateMap(pars, mpars);
	
		pars=StateHandler.updateMap(pars, rpars);
		pars=StateHandler.updateMap(pars, cpars);
		//System.out.println("ControlHandler:step::kosc="+pars.get("kosc"));
		//prepare takt
	
		double time=Double.parseDouble(controller.getElementItemAt("operator", Instrument.TIME));
	
		double takt=Double.parseDouble(controller.getElementItemAt("operator", Instrument.TAKT));
		double endTakt=time+takt;
		double qtakt=Double.parseDouble(controller.getElementItemAt("controller", "qtakt"));
		
		
		//System.out.println("ControlHandler:step:8");
		
		//state.put("ctime",0.0);
		do {
			cstate=ch.quantum(time, qtakt, state, pars);
			state=StateHandler.updateMap(state, cstate);
			mstate=mh.quantum(time, qtakt, state, pars);
			state=StateHandler.updateMap(state, mstate);
			//fstate=fh.quantum(time, qtakt, state, pars);
			state=StateHandler.updateMap(state, fstate);
			time=time+qtakt;
			
		}while(time<endTakt);
		String flag$=entigrator.folderFile(controller.getKey()).getPath()+"/stop";
		File flag=new File(flag$);
		if(flag.exists()) {
			flag.delete();
			state.put("kcount","0");
			state.put("qcount","0");
			state.put("peakRipple","0");
			state.put("averageRipple","0"); 
			String time$=controller.getElementItemAt("operator", Instrument.TIME);
		    controller.putElementItem("operator", new Core(null,"start",time$));
		}
		controller=ch.commit(controller, state);
		motor=mh.commit(motor, state);
		regulator=((StateHandler)rh).commit(regulator, state);
		//filter=fh.commit(filter, state);
		entigrator.putEntity(motor);
		entigrator.putEntity(regulator);
		entigrator.putEntity(controller);
		entigrator.putEntity(filter);
		*/
		}catch(Exception e) {
			Logger.getLogger(ControllerHandler.class.getName()).severe(e.toString());
		}
		return null;
	}
	@Override
	public void reset() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Hashtable<String, Double> getSettings() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void putSettings(Hashtable<String, Double> settings) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Hashtable<String, Double> getOuts() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public double getClock() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void setClock(double clock) {
		// TODO Auto-generated method stub
		
	}
	
	
	@Override
	public void setEntigrator(Entigrator entigrator) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public String[] listOutputs(Entigrator entigrator) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String[] listInputs(Entigrator entigrator) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
