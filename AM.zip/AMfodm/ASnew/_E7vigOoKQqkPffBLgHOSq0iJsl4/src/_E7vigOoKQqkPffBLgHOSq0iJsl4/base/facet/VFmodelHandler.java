package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.Hashtable;
import java.util.Properties;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler.M2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V4;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class VFmodelHandler extends  FacetHandler implements SegueController{
	public static final String KEY="_AG53DHMtLaLaIJ5Y8P9pwBAW19k";
	Sack entity;
	double usx=0;
	double usy=0;
	double i2x=0;
	double i2y=0;
	double isx=0;
	double isy=0;
	double fx=0;
	double fy=0;
	
	double wr=0;
	double m=0;
	double clock=Double.MIN_VALUE;
	double preferredClock=Double.MIN_VALUE;	
	//parameters
	double ls=0;
	double rs=0;
	double l2=0;
	double r2=0;
	double lm=0;
	double j=0;
	int pol=1; 
	//double dt=0;
	double time=0;
	double mc=0;
	Sack motor;

	public VFmodelHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		try {
			String motorLabel$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
			motor=entigrator.getEntityAtLabel(motorLabel$);
			ls=0;
			rs=0;
			l2=0;
			r2=0;
			lm=0;
			j=Double.MIN_VALUE;
			pol=1;
			clock=Double.MIN_VALUE;
			if(motor!=null) {
			try{ls=Double.parseDouble(motor.getElementItemAt("epar","ls" ));} catch(NumberFormatException nfe){ ls=0; }
			
			try{rs=Double.parseDouble(motor.getElementItemAt("epar","rs" ));} catch(NumberFormatException nfe){ rs=0; }
			
			try{l2=Double.parseDouble(motor.getElementItemAt("epar","l2" ));} catch(NumberFormatException nfe){ l2=0; }
			
			try{r2=Double.parseDouble(motor.getElementItemAt("epar","r2" ));} catch(NumberFormatException nfe){ r2=0; }
			
			try{lm=Double.parseDouble(motor.getElementItemAt("epar","lm" ));} catch(NumberFormatException nfe){ lm=0; }
			
			try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
			 
			try{pol=Integer.parseInt(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
		    clock=ls/(rs*100);
			}
		}catch(Exception e) {
			System.out.println("VFmodelHandler:"+e.toString());	
		}
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"VFmodel");
		locator.put(FACET_TYPE,"vfmodel");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VFmodelHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.VFmodelMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "vfmodel.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	
	@Override
	public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
		try {
			usx=ins.get("usx");
			usy=ins.get("usy");
			wr=ins.get("wr");
			mc=ins.get("mc");
			try {clock=ins.get("clock");}catch(Exception ee) {}
			V2 i2= new  V2 (i2x,i2y);
			V2 f=new V2(fx,fy);  
			V4 s= new V4(f,i2);
			M2 ll=new M2(1+ls/lm,-ls,1,l2);
			M2 rr=new M2(-rs/lm,rs,0,-r2);
			M2 ee=new M2(0,0,1,l2);
			M2 lli=ll.inverse();
			m=1.5*pol*f.crossProduct(i2);  
			M2 t1=lli.multiplication(rr);
			V4 s1=t1.product(s);		
			M2 t2=lli.multiplication(ee);
			V4 s2=t2.product(s.componentRotation().product(wr));
			V2 us= new  V2 (usx,usy);
			V4 u=new V4(us,new V2(0,0));
			V4 s3=lli.product(u);
			V4 ds= s1.add(s2).add(s3);
			V4 sn=s.add(ds.product(clock));   
		  	f=sn.v1;
			i2=sn.v2;
			V2 im=f.product(1/lm);
			V2 is=im.product(1).add(i2.product(-1));
			i2x=i2.x;
			i2y=i2.y;
			isx=is.x;
			isy=is.y;
			fx=f.x;
			fy=f.y;
			double dw2=(m-mc)*clock/j;
			double w2=wr/pol;
			w2=w2+dw2;
			wr=pol*w2;
			double id=is.norm()/1.41;	
			//System.out.println("VFmodelHandler:stride:wr="+wr);
			return getOuts();
		}catch(Exception e) {
			System.out.println("VFmodelHandler:stride:"+e.toString());
		}
	return null;	
	}
	@Override
	public void reset() {
		i2x=0;
		i2y=0;
		fx=0;
		fy=0;
		wr=0;
		if(motor!=null) {
			try{ls=Double.parseDouble(motor.getElementItemAt("epar","ls" ));} catch(NumberFormatException nfe){ ls=0; }
			
			try{rs=Double.parseDouble(motor.getElementItemAt("epar","rs" ));} catch(NumberFormatException nfe){ rs=0; }
			
			try{l2=Double.parseDouble(motor.getElementItemAt("epar","l2" ));} catch(NumberFormatException nfe){ l2=0; }
			
			try{r2=Double.parseDouble(motor.getElementItemAt("epar","r2" ));} catch(NumberFormatException nfe){ r2=0; }
			
			try{lm=Double.parseDouble(motor.getElementItemAt("epar","lm" ));} catch(NumberFormatException nfe){ lm=0; }
			
			try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
			 
			try{pol=Integer.parseInt(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
		    clock=ls/(rs*100);
			}
	}
	@Override
	public Hashtable<String, Double> getSettings() {
		Hashtable<String, Double> settings=new Hashtable<String, Double>();
		settings.put("ls",ls);
		settings.put("rs",rs);
		settings.put("l2",l2);
		settings.put("r2",r2);
		settings.put("lm",lm);
		settings.put("j",j);
		settings.put("pol",(double)pol);
		return settings;
	}
	@Override
	public void putSettings(Hashtable<String, Double> settings) {
		try {
		try {ls=settings.get("ls");}catch(Exception ee) {}
		try {rs=settings.get("rs");}catch(Exception ee) {}
		try {l2=settings.get("l2");}catch(Exception ee) {}
		try {r2=settings.get("r2");}catch(Exception ee) {}
		try {lm=settings.get("lm");}catch(Exception ee) {}
		try {j=settings.get("j");}catch(Exception ee) {}
		try{pol=(int)settings.get("pol").intValue();}catch(Exception ee) {}
		try{clock=settings.get("clock").intValue();}catch(Exception ee) {}
		}catch(Exception e) {
			System.out.println("VFmodelHandler:putSettings:"+e.toString());
		}
	}
	@Override
	public Hashtable<String, Double> getOuts() {
		Hashtable<String, Double> outs=new Hashtable<String, Double>();
		outs.put("i2x", i2x);
		outs.put("i2y", i2y);
		outs.put("isx", isx);
		outs.put("isy", isy);
		outs.put("fx", fx);
		outs.put("fy", fy);
		outs.put("wr", wr);
		outs.put("m", m);
		return outs;
	}
	@Override
	public double getClock() {
		return clock;
	}
	@Override
	public void setClock(double clock) {
		this.clock=clock;
	}
	@Override
	public String[] listInputs() {
		return new String[] {"usx","usy"};
	}
	@Override
	public String[] listOutputs() {
		return new String[] {"i2x","i2y","isx","isy","fx","fy","wr","m"};
	}
	@Override
	public void setEntigrator(Entigrator entigrator) {
		this.entigrator=entigrator;
	}
	@Override
	public String getName() {
		return "VFmodel";
	}
	@Override
	public String getType() {
		return "vfmodel";
	}
	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VFmodelHandler";
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
