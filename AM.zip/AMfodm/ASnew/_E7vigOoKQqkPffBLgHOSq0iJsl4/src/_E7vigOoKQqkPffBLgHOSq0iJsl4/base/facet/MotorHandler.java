package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import java.util.logging.Logger;



import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
//import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.Instrument;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V4;
import gdt.base.store.Core;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
import gdt.base.store.Entigrator;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.*;
public class MotorHandler  extends OperatorHandler implements SegueController{
	//public static final String MOTOR="motor";
	public static final String KEY="_9KrEWOlwlMKHHXLfLg_cTZ22Iyc";
	public static final String MOTOR_FACET_TYPE="motor";
	public static final String MOTOR_FACET_NAME="Motor";
	public static final String MOTOR_FACET_CLASS="_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler";
	public MotorHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}

	private Logger LOGGER=Logger.getLogger(getClass().getName());
	//public static final String EXTENSION_KEY="_woEkcFAdsVZ98Koi1N16gO4y6u8";
	
/*
	public void step(Entigrator entigrator,String locator$) {
		try{
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			Sack entity=entigrator.getEntityAtLabel(entity$);
			if(!entity.existsElement("operator")) {
				entity.createElement("operator");
		    entigrator.putEntity(entity);
			 }
			insStep(entigrator,locator$);
		}catch(Exception e){
			LOGGER.info(e.toString());
		}
	  
	}
*/
	@Override
	public void reset() {
		try{
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			Sack entity=entigrator.getEntityAtLabel(entity$);
			if(!entity.existsElement("operator")) {
				entity.createElement("operator");
				entigrator.putEntity(entity);
			 }
			//insReset(entigrator,locator$);
		    
		}catch(Exception e){
			LOGGER.info(e.toString());
		}	
	}
	
	public boolean hasControl(Entigrator entigrator){
		return true;
		
	}
	/*
	@Override
	public  String  newEntity(Entigrator entigrator,String locator$) {
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String entityLocator$=classLocator();
		entityLocator$=Locator.append(entityLocator$, Entigrator.ENTITY_LABEL, entity$);
	    return FacetHandler.createEntity(entigrator,entityLocator$);  
	}
	*/
/*
@Override
	public String newEntity(Entigrator entigrator, String locator$) {
			String label$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String entityKey$=entigrator.getKey(label$);
			if(entityKey$!=null)
				label$=label$+Identity.key().substring(0,4);
			Sack entity= entigrator.newEntity(label$, MOTOR);
			if(entity==null) {
				System.out.println("MotorHandler:newEntity:cannot create motor="+ label$);
				locator$=Locator.append(locator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_FALSE); 
				return locator$;
			}
			 if(!entity.existsElement(FACET))
		      	entity.createElement(FACET);
  		 String entityLocator$=classLocator();
			 entityLocator$=Locator.append( entityLocator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
		    entity.putElementItem(FACET, new Core(ModuleHandler.SYSTEM,KEY,entityLocator$));
		    entity=entigrator.assignProperty(MOTOR,Locator.LOCATOR_TRUE, entity.getKey());
		    entigrator.putEntity(entity);
		    entityLocator$=Locator.append(entityLocator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_TRUE);
			return entityLocator$;
	}
*/
		public static String classLocator() {
			Properties locator=new Properties();
			locator.put(FACET_KEY,KEY);
			locator.put(FACET_NAME,MOTOR_FACET_NAME);
			locator.put(FACET_TYPE,MOTOR_FACET_TYPE);
			locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
			locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
			locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler");
			locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.MotorMaster");
			locator.put( IconLoader.ICON_FILE, "motor.png");
		    locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
			locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		//	locator.put(OPERATOR,Locator.LOCATOR_TRUE);
			return Locator.toString(locator);
		}
		@Override
		public String getType() {
			return MOTOR_FACET_TYPE;
		}
		@Override
		public String getName() {
			return MOTOR_FACET_NAME;
		}
		@Override
		public String getFacetClass() {
			return MOTOR_FACET_CLASS;	


		}
		@Override
		public String getLocator() {
			return Locator.merge(locator$, classLocator());
		}
/*
		@Override
	public String[] listParameters(Entigrator entigrator) {
		// TODO Auto-generated method stub
		return null;
	}
	*/
	////////////////
	//special
	//classes
	public static class V5{
		public double a0;
		public double a1;
		public double a2;
		public double a3;
		public double a4;
		public V5(double a0,double a1,double a2,double a3,double a4) {
			this.a0=a0;
			this.a1=a1;
			this.a2=a2;
			this.a3=a3;
			this.a4=a4;
		}
	  public V5 scale(V5 v) {
		  return new V5(v.a0*a0,v.a1*a1,v.a2*a2,v.a3*a3,v.a4*a4);
	  }
	  public V5 subtract(V5 v) {
		  return new V5(a0-v.a0,a1-v.a1,a2-v.a2,a3-v.a3,a4-v.a4);
	  }
	  public double worth() {
		  return Math.abs(a0)+Math.abs(a1)+Math.abs(a2)+Math.abs(a3)+Math.abs(a4);
	  }
	  public double norm() {
		  return a0*a0+a1*a1+a2*a2+a3*a3+a4*a4;
		  //return worth();
	  }
	  public double getVal(int i) {
		  switch(i) {
		  case 0:
			  return a0;
		  case 1:
			  return a1;	
		  case 2:
			  return a2;
		  case 3:
			  return a3;
		  case 4:
			  return a4;			  
		  }
		  return 0;
		  
	  }
	  public V5 clone() {
		  return new V5(a0,a1,a2,a3,a4);  
	  }
	  public V5 product(double factor) {
		  return new V5(a0*factor,a1*factor,a2*factor,a3*factor,a4*factor);  
	  }
	  public void print(String name$) {
		  System.out.println("MotorHandler:name="+name$+" a0="+a0+" a1="+a1+" a2="+a2+" a3="+a3+" a4="+a4);
	  }
	  public void print(String name$,String a0$,String a1$,String a2$,String a3$,String a4$) {
		  System.out.println("MotorHandler:"+name$+","+a0$+"="+a0);
		  System.out.println("MotorHandler:"+name$+","+a1$+"="+a1);
		  System.out.println("MotorHandler:"+name$+","+a2$+"="+a2);
		  System.out.println("MotorHandler:"+name$+","+a3$+"="+a3);
		  System.out.println("MotorHandler:"+name$+","+a4$+"="+a4);
		
	  }
 }

	//
	public static Sack par_t2z(Sack motor) {
		String par$=motor.getElementItemAt("tpar","rs");
		motor.putElementItem("zpar",new Core(null,"rs",par$));
		par$=motor.getElementItemAt("tpar","xs"); 
		motor.putElementItem("zpar",new Core(null,"xs",par$));
		par$=motor.getElementItemAt("tpar","r2"); 
		motor.putElementItem("zpar",new Core(null,"r2",par$));
		par$=motor.getElementItemAt("tpar","x2"); 
		motor.putElementItem("zpar",new Core(null,"x2",par$));
		par$=motor.getElementItemAt("tpar","xm"); 
		motor.putElementItem("zpar",new Core(null,"xm",par$));
		return motor;
	}
	public static Sack par_n2d(Sack motor) {
		 try {
		//	 System.out.println("MotorHandler:par_n2d:motor="+motor.getProperty("label"));
			 double sn =0.05;
			try {sn=Double.parseDouble(motor.getElementItemAt("primary","sn"));}catch(Exception e) {}
			 //System.out.println("MotorHandler:par_n2d:1");
			 int pol =1;
			try {pol= Integer.parseInt(motor.getElementItemAt("primary","pol"));}catch(Exception e) {}
			int f =0;
			try{f=Integer.parseInt(motor.getElementItemAt("primary","f"));}catch(Exception e) {}
			 double cos =1;
			 try{cos=Double.parseDouble(motor.getElementItemAt("primary","cos"));}catch(Exception e) {}
		//	 System.out.println("MotorHandler:par_n2d:0");
			 double us =0;
			 try {us= Double.parseDouble(motor.getElementItemAt("primary","Us"));}catch(Exception e) {}
			 double pow =0;
			try {pow= Double.parseDouble(motor.getElementItemAt("primary","P"));}catch(Exception e) {}
			 double mk =0;
			 try{mk=Double.parseDouble(motor.getElementItemAt("primary","Mk"));}catch(Exception e) {}
			 double eta =0;
			try {eta= Double.parseDouble(motor.getElementItemAt("primary","Eta"));}catch(Exception e) {}
			double Is=1;
			try {Is= Double.parseDouble(motor.getElementItemAt("primary","Is"));}catch(Exception e) {}
			//System.out.println("MotorHandler:us="+us+" cos="+cos+" eta=");
			 double a= 3*us*cos*eta;
			 double isn=pow/a;
			 double iso=Is*isn;
			 double w0= f*2*Math.PI;
			 double wg0= w0/pol;
			 double wr=wg0*(1-sn);
			 double n=wr*30/(Math.PI);
			 double mn=pow/wr;
			 double mmax=mn*mk;
			 double i2n=isn*cos;
			 double imn=isn*Math.sqrt(1-cos*cos);
			 if(!!motor.existsElement("dpar"))
				 motor.createElement("dpar");
			 else
				 motor.clearElement("dpar");
			 motor.putElementItem("dpar", new Core(null,"Isn",String.valueOf(isn)));
			 motor.putElementItem("dpar", new Core(null,"Iso",String.valueOf(iso)));
			 motor.putElementItem("dpar", new Core(null,"w0",String.valueOf(w0)));
			 motor.putElementItem("dpar", new Core(null,"wg0",String.valueOf(wg0)));
			 motor.putElementItem("dpar", new Core(null,"Mn",String.valueOf(mn)));
			 motor.putElementItem("dpar", new Core(null,"Mmax",String.valueOf(mmax)));
			 motor.putElementItem("dpar", new Core(null,"I2n",String.valueOf(i2n)));
			 motor.putElementItem("dpar", new Core(null,"Imn",String.valueOf(imn)));
			 motor.putElementItem("dpar", new Core(null,"Nn",String.valueOf(n)));

		 }catch(Exception e) {
			 System.out.println("MotorHandler:par_n2d:"+e.toString());
		 }
		 return motor;
	 }
	public static Sack par_d2z(Sack motor) {
		 try {
			 System.out.println("MotorHandler:par_n2z:BEGIN");
			 double w0 =Double.parseDouble(motor.getElementItemAt("dpar","w0"));
			 double mn =Double.parseDouble(motor.getElementItemAt("dpar","Mn"));
			 double mmax =Double.parseDouble(motor.getElementItemAt("dpar","Mmax"));
			 double i2n =Double.parseDouble(motor.getElementItemAt("dpar","I2n"));
			 double imn =Double.parseDouble(motor.getElementItemAt("dpar","Imn"));
			 double us =Double.parseDouble(motor.getElementItemAt("primary","Us"));
			 double sn =Double.parseDouble(motor.getElementItemAt("primary","sn"));
			 int pol =Integer.parseInt(motor.getElementItemAt("primary","pol"));
			 double xm=us/imn;
			 double r2=mn*sn*w0/(3*pol*(i2n*i2n));
			 double x2=3*pol*us*us/(2*w0*mmax);
			 if(!!motor.existsElement("zpar"))
				 motor.createElement("zpar");
			 else
				 motor.clearElement("zpar");
			 motor.putElementItem("zpar", new Core(null,"xm",String.valueOf(xm)));
			 motor.putElementItem("zpar", new Core(null,"r2",String.valueOf(r2)));
			 motor.putElementItem("zpar", new Core(null,"x2",String.valueOf(x2)));
			 motor.putElementItem("zpar", new Core(null,"rs",String.valueOf(r2)));
			 motor.putElementItem("zpar", new Core(null,"xs",String.valueOf(x2)));
			 if(!!motor.existsElement("zlimit"))
				 motor.createElement("zlimit");
			 else
				 motor.clearElement("zlimit");
			 motor.putElementItem("zlimit", new Core(null,"xm",String.valueOf(xm/10)));
			 motor.putElementItem("zlimit", new Core(null,"r2",String.valueOf(r2/10)));
			 motor.putElementItem("zlimit", new Core(null,"x2",String.valueOf(x2/10)));
			 motor.putElementItem("zlimit", new Core(null,"rs",String.valueOf(r2/10)));
			 motor.putElementItem("zlimit", new Core(null,"xs",String.valueOf(x2/10)));
			 
		 }catch(Exception e) {
			 System.out.println("MotorHandler:par_d2z:"+e.toString());
		 }
		 return motor;
	 }
	public static V5 par_getZ(Sack motor,boolean given) {
		try {
		if(!given) {
		 double	xs=Double.parseDouble(motor.getElementItemAt("zpar", "xs"));
		 double	xm=Double.parseDouble(motor.getElementItemAt("zpar", "xm"));
		 double	x2=Double.parseDouble(motor.getElementItemAt("zpar", "x2"));
		 double	rs=Double.parseDouble(motor.getElementItemAt("zpar", "rs"));
		 double	r2=Double.parseDouble(motor.getElementItemAt("zpar", "r2"));
		 return new V5(rs,xs,r2,x2,xm);
		}else {
			double	xs=Double.parseDouble(motor.getElementItemAt("zgvn", "xs"));
			 double	xm=Double.parseDouble(motor.getElementItemAt("zgvn", "xm"));
			 double	x2=Double.parseDouble(motor.getElementItemAt("zgvn", "x2"));
			 double	rs=Double.parseDouble(motor.getElementItemAt("zgvn", "rs"));
			 double	r2=Double.parseDouble(motor.getElementItemAt("zgvn", "r2"));
			 return new V5(rs,xs,r2,x2,xm);
		}
		}catch(Exception e) {
			System.out.println("MotorHandler:par_getZ:"+e.toString());	
			return null;
		}
	 }
	public static Sack par_e2z(Sack motor) {
		double	w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
		motor.putElementItem("zpar",motor.getElementItem("epar", "rs"));// new Core(null,"rs",String.valueOf(zpars.a0)));
		motor.putElementItem("zpar",motor.getElementItem("epar", "r2"));
		double l= Double.parseDouble(motor.getElementItemAt("epar", "ls"));
		double x=l*w0;
		motor.putElementItem("zpar",new Core(null,"xs",String.valueOf(x)));
		l= Double.parseDouble(motor.getElementItemAt("epar", "l2"));
		x=l*w0;
		motor.putElementItem("zpar",new Core(null,"x2",String.valueOf(x)));
		l= Double.parseDouble(motor.getElementItemAt("epar", "lm"));
		x=l*w0;
		motor.putElementItem("zpar",new Core(null,"xm",String.valueOf(x)));
   	 return motor;
	 }
	public static Sack z_setInput(Sack motor,V5 zIn) {
		if(!motor.existsElement("zin"))
				motor.createElement("zin");
		zIn.print("zIn");
		motor.putElementItem("zin", new Core("input","w0",String.valueOf(zIn.a0)));
		motor.putElementItem("zin", new Core("input","usd",String.valueOf(zIn.a1)));
		motor.putElementItem("zin", new Core("input","s",String.valueOf(zIn.a2)));
		motor.putElementItem("zin", new Core("input","m",String.valueOf(zIn.a3)));
		motor.putElementItem("zin", new Core("input","mmax",String.valueOf(zIn.a4)));
		return motor;
	}
	public static Sack z_setInputNominal(Sack motor) {
		motor.putElementItem("zin", new Core("input","w0",motor.getElementItemAt("dpar", "w0")));
		motor.putElementItem("zin", new Core("input","usd",motor.getElementItemAt("primary", "Us")));
		motor.putElementItem("zin", new Core("input","s",motor.getElementItemAt("primary", "sn")));
		motor.putElementItem("zin", new Core("input","m",motor.getElementItemAt("dpar", "Mn")));
		motor.putElementItem("zin", new Core("input","mmax",motor.getElementItemAt("dpar", "Mmax")));
		return motor;
	}
	
	private static Sack z_getCriticalSlip(Sack motor,boolean given) {
		boolean generator=false;
		String generator$=motor.getElementItemAt("hj", "generator");
	//	System.out.println("MotorHandler:getCriticalSlip:generator="+generator$);
		if("true".equals(generator$))
				generator=true;
		
		double sa=0;
		try {sa=Double.parseDouble(motor.getElementItemAt("hj", "sa"));}catch(Exception e) {}
		double sb=1;
		try {sb=Double.parseDouble(motor.getElementItemAt("hj", "sb"));}catch(Exception e) {}
		double err=0;
		try {err=Double.parseDouble(motor.getElementItemAt("hj", "err"));}catch(Exception e) {}
		
		if(Math.abs(sa-sb)<=err) {
			motor.putElementItem("zvar", new Core(null,"mmax",motor.getElementItemAt("zvar", "m")));
			//System.out.println("MotorHandler:getCriticalSlip:return:sa="+sa+" sb="+sb);
			return motor;
		}
		
		double d= (sb-sa)/1.618;
		double  s2=sa+ d;
		double  s1= sb-d;
		
		motor.putElementItem("zin", new Core(null,"s",String.valueOf(sa)));
		motor= z_makeState( motor,given);
		double ma=Double.parseDouble(motor.getElementItemAt("zvar", "m"));
		motor.putElementItem("zin", new Core(null,"s",String.valueOf(sb)));
		motor= z_makeState( motor,given);
		double mb=Double.parseDouble(motor.getElementItemAt("zvar", "m"));
		if(Math.abs(mb-ma)<=err){
			//System.out.println("MotorHandler:getCriticalSlip:return mb="+mb);
			motor.putElementItem("hj", new Core(null,"mmax",motor.getElementItemAt("zvar", "m")));
			return motor;
		}
		motor.putElementItem("zin", new Core(null,"s",String.valueOf(s1)));
		motor= z_makeState( motor,given);
		double m1=Double.parseDouble(motor.getElementItemAt("zvar", "m"));
		motor.putElementItem("zin", new Core(null,"s",String.valueOf(s2)));
		motor= z_makeState( motor,given);
		double m2=Double.parseDouble(motor.getElementItemAt("zvar", "m"));
		//System.out.println("MotorHandler:getCriticalSlip:sa="+sa+" sb="+sb+" s1="+s1+" s2="+s2+" ma="+ma+" mb="+mb+ " m1="+m1+" m2="+m2);
		if(!generator) {
		 if(m2 >=m1 ) {
		 	
		     motor.putElementItem("hj", new Core(null,"sa",String.valueOf(s1))); 	
			return z_getCriticalSlip( motor,given);	
		
		}else {
			 motor.putElementItem("hj", new Core(null,"sb",String.valueOf(s2))); 	
				return z_getCriticalSlip( motor,given);		
		}
		}else {
			//System.out.println("MotorHandler:getCriticalSlip:generator");
			if(m2 <=m1 ) {
				//System.out.println("MotorHandler:getCriticalSlip:m2<m1");
			     motor.putElementItem("hj", new Core(null,"sa",String.valueOf(s1))); 	
				return z_getCriticalSlip( motor,given);	
			}else {
				 motor.putElementItem("hj", new Core(null,"sb",String.valueOf(s2))); 	
					return z_getCriticalSlip( motor,given);		
			}	
		}
		
			
		}
	
	public static double hj_z2dev(Sack motor,boolean given) {
		//System.out.print("MotorHandler:hj_makeDev");
			V5 nv=z_getNomVar(motor);
		//	nv.print("nv");
			V5 cv=par_z2v(motor,given);
		//	cv.print("cv");
			V5 dif=nv.subtract(cv);
			V5 scl=hj_getScale(motor);
			V5 sdif=dif.scale(scl); 
		//	System.out.print("norm="+dif.norm()+"  ");
		//	dif.print("dif");
			return sdif.norm();
			
		}
	public static V5 par_z2v(Sack motor,boolean given) {
		motor.putElementItem("hj",new Core("input","generator","false"));
		motor.putElementItem("hj",new Core("input","sa","0"));
		motor.putElementItem("hj",new Core("input","sb","1"));
		motor=z_getCriticalSlip( motor,given);
		String mmax$=motor.getElementItemAt("hj", "mmax");
		motor.putElementItem("zvar",new Core(null,"mmax",mmax$));
       // motor.print("zpar");
		String sn$=motor.getElementItemAt("primary", "sn");
		motor.putElementItem("zin", new Core(null,"s",String.valueOf(sn$)));
		String usd$=motor.getElementItemAt("primary", "Us");
		motor.putElementItem("zin", new Core(null,"usd",String.valueOf(usd$)));
		String w0$=motor.getElementItemAt("dpar", "w0");
		motor.putElementItem("zin", new Core(null,"w0",String.valueOf(w0$)));
		motor= z_makeState( motor,given);
       
        return z_getVar(motor);
	}
	public static Sack z_makeNomVars(Sack motor,boolean given) {
		 String sn$=motor.getElementItemAt("primary", "sn");
		motor.putElementItem("zin", new Core(null,"s",String.valueOf(sn$)));
		String usd$=motor.getElementItemAt("primary", "Us");
		motor.putElementItem("zin", new Core(null,"usd",String.valueOf(usd$)));
		String w0$=motor.getElementItemAt("dpar", "w0");
		motor.putElementItem("zin", new Core(null,"w0",String.valueOf(w0$)));
		motor=z_makeCriticalValues(motor,given);
		return z_makeState( motor,given);
	}
	public static Sack z_makeCriticalValues(Sack motor,boolean given) {
		//System.out.print("MotorHandler:z_makeCriticalValues:BEGIN");
		motor=z_makeMmaxm(motor,given);
		return z_makeMmaxg(motor,given);
	}
	private static Sack z_makeMmaxm(Sack motor,boolean given) {
		motor.putElementItem("hj",new Core("input","generator","false"));
		motor.putElementItem("hj",new Core("input","sa","0"));
		motor.putElementItem("hj",new Core("input","sb","1"));
		motor=z_getCriticalSlip( motor,given);
		String mmax$=motor.getElementItemAt("hj", "mmax");
		motor.putElementItem("zvar",new Core(null,"mmaxm",mmax$));
		String sk$=motor.getElementItemAt("hj", "sa");
		motor.putElementItem("zvar",new Core(null,"skm",sk$));
		return motor;
		
	}
	private static Sack z_makeMmaxg(Sack motor,boolean given) {
		motor.putElementItem("hj",new Core("input","generator","true"));
		motor.putElementItem("hj",new Core("input","sa","-1"));
		motor.putElementItem("hj",new Core("input","sb","0"));
		motor=z_getCriticalSlip( motor,given);
		String mmax$=motor.getElementItemAt("hj", "mmax");
		motor.putElementItem("zvar",new Core(null,"mmaxg",mmax$));
		String sk$=motor.getElementItemAt("hj", "sa");
		motor.putElementItem("zvar",new Core(null,"skg",sk$));
		return motor;
		
	}
	public static Sack z_makeNomState(Sack motor,boolean given) {
		String usd$=motor.getElementItemAt("primary", "Us");
		String sn$=motor.getElementItemAt("primary", "sn");
		String w0$=motor.getElementItemAt("dpar", "w0");
		//System.out.println("MotorHandler:z_makeNomState:given="+given+" w0="+w0$+" usd="+usd$+"  sn="+sn$);	
		motor.putElementItem("zin", new Core(null,"w0",w0$));
		motor.putElementItem("zin", new Core(null,"usd",usd$));
		motor.putElementItem("zin", new Core(null,"s",sn$));
		motor=  z_makeState( motor, given);
	//	motor.print();
		return motor;
	}
	public static Sack z_makeState(Sack motor,boolean given) {
		
	try {	
		double	w0=Double.parseDouble(motor.getElementItemAt("zin", "w0"));
		double	usd=Double.parseDouble(motor.getElementItemAt("zin", "usd"));
		double	s=Double.parseDouble(motor.getElementItemAt("zin", "s"));
		//System.out.println("MotorHandler:z_makeState:1");	
		if(s>=0&&s<0.0001)
	    	s=0.0001;
	    if(s<0&&s>-0.0001)
	    	s=-0.0001; 
	   // System.out.println("MotorHandler:z_makeState:2");	
	    V5 zpars=par_getZ(motor,given);
	    double rs=zpars.a0;
		double xs=zpars.a1;
		Z zs=new Z(rs,xs);
		double r2=zpars.a2;
		double x2=zpars.a3;
		Z zr=new Z(r2/s,x2);
		double xm=zpars.a4;
		Z zm=new Z(0,xm);
		//System.out.println("MotorHandler:z_makeState:3:xm="+xm);	
		//zm.print("zm");
		Z z1=zm.inverse().product(zr).add(new Z(1,0));
		
		Z z0=z1.product(zs).add(zr).inverse().product(-1);
			
		int pol=Integer.parseInt(motor.getElementItemAt("primary","pol"));
		V2 us= new V2(Math.sqrt(2)*usd,0);
		V2 i2=z0.product(us); 
		double i2a=i2.norm();
		V2 is=z1.product(i2).product(-1);
		V2 im=is.add(i2);
		
		double m=(1.5*pol*xm/(w0))*i2.rotProduct(im);
		double isa=is.norm();
		double cos = i2a/isa; //a2
		double isd=isa/Math.sqrt(2);//a0
	//	System.out.println("MotorHandler:z_makeState:isd="+isd);	
		double pl= 3*(i2a*i2a*r2+isa*isa*rs);
		double pow= m*w0/pol;
		double eta=pow/(pow+pl);//a3
		motor.putElementItem("zvar", new Core("output","isd",String.valueOf(isd)));
		motor.putElementItem("zvar", new Core("output","m",String.valueOf(m)));
		motor.putElementItem("zvar", new Core("output","cos",String.valueOf(cos)));
		motor.putElementItem("zvar", new Core("output","eta",String.valueOf(eta)));
	}catch(Exception e) {
		System.out.println("MotorHandler:z_makeState:"+e.toString());
		Sack.traceCalls();
	}
		return motor;
		
		
 }
	public static Hashtable<String,Double> z_makeState(Hashtable<String,Double> ins) {
		try {	
			double	f=ins.get("f");
			double	s=ins.get("s");
			double	usd=ins.get("usd");
			double	rs=ins.get("rs");
			double	ls=ins.get("ls");
			double	r2=ins.get("r2");
			double	l2=ins.get("l2");
			double	lm=ins.get("lm");
			double	pol=ins.get("pol");
			double w0=2*Math.PI*f;
			double xm=w0*lm;
			double xs=w0*ls;
			double x2=w0*l2;
			Z zm=new Z(0,xm);
			Z zs=new Z(rs,xs);
			Z zr=new Z(r2,x2);
			Z z1=zm.inverse().product(zr).add(new Z(1,0));
			Z z0=z1.product(zs).add(zr).inverse().product(-1);
			
			V2 us= new V2(Math.sqrt(2)*usd,0);
			V2 i2=z0.product(us); 
			double i2a=i2.norm();
			V2 is=z1.product(i2).product(-1);
			V2 im=is.add(i2);
			
			double m=(1.5*pol*xm/(w0))*i2.rotProduct(im);
			double isa=is.norm();
			double cos = i2a/isa; //a2
			double isd=isa/Math.sqrt(2);//a0
		//	System.out.println("MotorHandler:z_makeState:isd="+isd);	
			double pl= 3*(i2a*i2a*r2+isa*isa*rs);
			double pow= m*w0/pol;
			double eta=pow/(pow+pl);
			Hashtable<String,Double>out=new Hashtable<String,Double>();
			out.put("isd", isd);
			out.put("m", m);
			out.put("cos", cos);
			out.put("eta", eta);
			//a3
			return out;
		}catch(Exception e) {
			System.out.println("MotorHandler:z_makeState:"+e.toString());
			//Sack.traceCalls();
		}
			return null;
	 }
		
	public static Sack z_setNomVar(Sack motor) {
		motor=par_n2d(motor);
		if(!motor.existsElement("nvar"))
			motor.createElement("nvar");
		motor.putElementItem("nvar", new Core(null,"isd",motor.getElementItemAt("dpar","Isn")));
		motor.putElementItem("nvar", new Core(null,"cos",motor.getElementItemAt("primary","cos")));
		motor.putElementItem("nvar", new Core(null,"mn",motor.getElementItemAt("dpar","Mn")));
		motor.putElementItem("nvar", new Core(null,"eta",motor.getElementItemAt("primary","Eta")));
		motor.putElementItem("nvar", new Core(null,"mmax",motor.getElementItemAt("dpar","Mmax")));
		 return motor;
	 }
	public static V5 z_getNomVar(Sack motor) {
		 double isd= Double.parseDouble(motor.getElementItemAt("dpar","Isn"));
		 double cos =Double.parseDouble(motor.getElementItemAt("primary","cos"));
		 double mn =Double.parseDouble(motor.getElementItemAt("dpar","Mn"));
		 double eta =Double.parseDouble(motor.getElementItemAt("primary","Eta"));
		 double mmax =Double.parseDouble(motor.getElementItemAt("dpar","Mmax"));
		if(!motor.existsElement("nvar"))
			motor.createElement("nvar");
		motor.putElementItem("nvar", new Core(null,"isd",motor.getElementItemAt("dpar","Isn")));
		motor.putElementItem("nvar", new Core(null,"cos",motor.getElementItemAt("primary","cos")));
		motor.putElementItem("nvar", new Core(null,"mn",motor.getElementItemAt("dpar","Mn")));
		motor.putElementItem("nvar", new Core(null,"eta",motor.getElementItemAt("primary","Eta")));
		motor.putElementItem("nvar", new Core(null,"mmax",motor.getElementItemAt("dpar","Mmax")));
		
		 return new V5(isd,mn,cos,eta,mmax);
	 }
	public static V5 z_getVar(Sack motor) {
		double isd=0;
		 try { isd= Double.parseDouble(motor.getElementItemAt("zvar","isd"));}catch(Exception e) {}
		 double cos =0; 
		 try { cos =Double.parseDouble(motor.getElementItemAt("zvar","cos"));}catch(Exception e) {}
		 double mn =0;
		 try { mn =Double.parseDouble(motor.getElementItemAt("zvar","m"));}catch(Exception e) {}
		 double eta =0;
		 try { eta =Double.parseDouble(motor.getElementItemAt("zvar","eta"));}catch(Exception e) {}
		 double mmax =0;
		 try { mmax =Double.parseDouble(motor.getElementItemAt("zvar","mmax"));}catch(Exception e) {}
		return new V5(isd,mn,cos,eta,mmax);
	 }
	/*
	public static double z_t2dev(Sack motor,boolean given) {
		motor=par_t2z(motor);
		motor=z_makeNomVars(motor,given);
	    return hj_z2dev(motor);
	 }
	*/
	public static Sack z_graph(Sack motor, String record$,boolean given) {
		double s=1.0;
		double h=1.0/300;
		try {
		double	w0=Double.parseDouble(motor.getElementItemAt("zin", "w0"));
		int pol=Integer.parseInt(motor.getElementItemAt("primary", "pol"));
		
		double wr=0;
		double n=0;
		String m$;
		String isd$;
		String cos$;
		String eta$;
		String line$;
	   // String rec$=motor.getElementItemAt("setting", "graph.rec");
		File rec=new File(record$);
		if(rec.exists())
			rec.delete();
		rec.createNewFile();
		 FileOutputStream fos = new FileOutputStream(rec, false);
		 Writer writer = new OutputStreamWriter(fos, "UTF-8");
		 //writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n");
		 do {
		motor.putElementItem("zin", new Core(null,"s",String.valueOf(s)));
		motor=z_makeState(motor, given);
		//motor.print("zvar");
		wr=w0*(1-s);
		n=wr*30/(Math.PI*pol);
		isd$=motor.getElementItemAt("zvar", "isd");
		m$=motor.getElementItemAt("zvar", "m");
		cos$=motor.getElementItemAt("zvar", "cos");
		eta$=motor.getElementItemAt("zvar", "eta");
		line$=String.valueOf(wr)+";"+String.valueOf(n)+";"+isd$+";"+m$+";"+cos$+";"+eta$;
		//System.out.println(line$);
		writer.write(line$+"\n");
		s=s-h;	
		}while (s>0);
		 writer.close();
		}catch(Exception e) {
		System.out.println("Motorhandler:z_graph:"+e.toString());	
		}
		return motor;
	 }
	private static V5 hj_getScale(Sack motor) {
		V5 weight=new V5(1,1,1,1,1);
		 double isd= Double.parseDouble(motor.getElementItemAt("dpar","Isn"));
		 double mn =Double.parseDouble(motor.getElementItemAt("dpar","Mn"));
		 double mmax =Double.parseDouble(motor.getElementItemAt("dpar","Mmax"));
		//V5(isd,mn,cos,eta,mmax);
		if(!motor.existsElement("zscale")) {
			motor.createElement("zscale");
			motor.putElementItem("zscale", new Core(null,"isd","1"));
			motor.putElementItem("zscale", new Core(null,"mn","1"));
			motor.putElementItem("zscale", new Core(null,"cos","1"));
			motor.putElementItem("zscale", new Core(null,"eta","1"));
			motor.putElementItem("zscale", new Core(null,"mmax","1"));
			return weight;
		}
		double w=1; 
		 try { w =Double.parseDouble(motor.getElementItemAt("zscale","isn"));}catch(Exception e) {}
		 weight.a0=w/isd;
		 w=1;
		 try { w =Double.parseDouble(motor.getElementItemAt("zscale","mn"));}catch(Exception e) {}
		 weight.a1=w/mn;
		 w=1;
		 try { w =Double.parseDouble(motor.getElementItemAt("zscale","cos"));}catch(Exception e) {}
		 weight.a2=w;
		 w=1;
		 try { w =Double.parseDouble(motor.getElementItemAt("zscale","eta"));}catch(Exception e) {}
		 weight.a3=w;
		 w=1;
		 try { w =Double.parseDouble(motor.getElementItemAt("zscale","mmax"));}catch(Exception e) {}
		 weight.a4=w/mmax;
		 return weight;
		
	}
	public static Sack par_z2e(Sack motor) {
		try {
			motor.printElement("dpar");
		double w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
		 if(!motor.existsElement("epar"))
			 motor.createElement("epar");
		motor.putElementItem("epar",motor.getElementItem("zpar", "rs"));
		motor.putElementItem("epar",motor.getElementItem("zpar", "r2"));
		double x= Double.parseDouble(motor.getElementItemAt("zpar", "xs"));
		double l=x/w0;
		motor.putElementItem("epar",new Core(null,"ls",String.valueOf(l)));
		
		x= Double.parseDouble(motor.getElementItemAt("zpar", "x2"));
		l=x/w0;
		motor.putElementItem("epar",new Core(null,"l2",String.valueOf(l)));
		x= Double.parseDouble(motor.getElementItemAt("zpar", "xm"));
		l=x/w0;
		motor.putElementItem("epar",new Core(null,"lm",String.valueOf(l)));
		
		}catch(Exception e) {
		System.out.println("MotorHandler:par_z2e:"+e.toString());	
		}
		 return motor;
	 }
	public static Sack par_gvn2e(Sack motor) {
		double w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
		 if(!motor.existsElement("epar"))
			 motor.createElement("epar");
		motor.putElementItem("epar",motor.getElementItem("zgvn", "rs"));
		motor.putElementItem("epar",motor.getElementItem("zgvn", "r2"));
		double x= Double.parseDouble(motor.getElementItemAt("zgvn", "xs"));
		double l=x/w0;
		motor.putElementItem("epar",new Core(null,"ls",String.valueOf(l)));
		x= Double.parseDouble(motor.getElementItemAt("zgvn", "x2"));
		l=x/w0;
		motor.putElementItem("epar",new Core(null,"l2",String.valueOf(l)));
		x= Double.parseDouble(motor.getElementItemAt("zgvn", "xm"));
		l=x/w0;
		motor.putElementItem("epar",new Core(null,"lm",String.valueOf(l)));
   	 return motor;
	 }
	private static Sack hj_putZpar(Sack motor,int i, double par) {
		
		switch( i) {
		  case 0:
			  motor.putElementItem("zpar", new Core(null,"rs",String.valueOf(par)));
		    break;
		  case 1:
		
			  motor.putElementItem("zpar", new Core(null,"xs",String.valueOf(par)));
		    break;
		  case 2:
		
			  motor.putElementItem("zpar", new Core(null,"r2",String.valueOf(par)));
		    break;
		  case 3:
		
			  motor.putElementItem("zpar", new Core(null,"x2",String.valueOf(par)));
		    break;  
		  case 4:
		
			  motor.putElementItem("zpar", new Core(null,"xm",String.valueOf(par)));
		    break;   
		  default:
		    // code block
		}
		return motor;
	}
	
	private static Sack hj_locMin(Sack motor,int i,double pa,double pb,double err) {
		int l=0;
		try {l=Integer.parseInt(motor.getElementItemAt("hj", "l"));}catch(Exception e) {}
		l=l+1;
		motor.putElementItem("hj", new Core(null,"l",String.valueOf(l)));
		motor= hj_putZpar( motor, i, pa);
		double da=hj_z2dev(motor,false);	
		
		motor= hj_putZpar( motor, i, pb);
		double db=hj_z2dev(motor,false);	
	    double dif=Math.abs(pa-pb)/pa; 
		if(dif<err) {
		//	System.out.println("MotorHandler:hj_locMin3:return:l="+l+" err="+err+" diff="+dif);
			motor=hj_putZpar(motor,i,pa);
			return motor;
		}
		
		double d= (pb-pa)/1.618;
		double  p2=pa+ d;
		motor= hj_putZpar( motor, i, p2);
		double d2=hj_z2dev(motor,false);	
	
		double  p1= pb-d;
		motor= hj_putZpar( motor, i, p1);
		double d1=hj_z2dev(motor,false);

		//	System.out.println("------------------");
	//	System.out.println("MotorHandler:hj_locMin3:l="+l+"  pa="+pa+" pb="+pb+" p1="+p1+" p2="+p2);
	//	System.out.println("MotorHandler:hj_locMin3:i="+i+"  da="+da+" db="+db+" d1="+d1+" d2="+d2);
		if(d1 <d2 ){
			 return hj_locMin(motor, i,pa,p2,err);	
		}else {
			 return hj_locMin(motor, i,p1,pb,err);	
		}
		
	}
	
	public static Sack par_n2z(Sack motor) {
		motor=par_n2d(motor);
		motor=par_d2z(motor);
		return motor;
	}
	public static Sack hj_globMin(Sack motor,PrintStream reportStream,boolean given) {
		try {
		double w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
		double usd=Double.parseDouble(motor.getElementItemAt("primary", "Us"));
		double sn=Double.parseDouble(motor.getElementItemAt("primary", "sn"));
		V5 zIn=new V5(w0,usd,sn,0,0);
		motor=z_setInput(motor,zIn);
		
		double err=Double.parseDouble(motor.getElementItemAt("hj", "err"));
		
		int lim=Integer.parseInt(motor.getElementItemAt("hj", "lim"));
		motor=par_n2z(motor);
		V5 nZpar =par_getZ(motor,false);
		V5 aZpar=nZpar.product(0.25);
		V5 bZpar=nZpar.product(4);
		double prevDev=0;
		double nextDev=0;
		int n=0;
		double pa=0;
		double pb=0;
	   	System.out.println("     Iteration:   err="+err+"  lim="+lim);
		aZpar=par_getZ(motor,false).product(0.25);
		bZpar=par_getZ(motor,false).product(4);
	    	do {
	    		if(reportStream!=null)
	    			reportStream.print(".");
	    		else
	    		    System.out.print(".");
	    		 prevDev=hj_z2dev(motor,given);
	    		
	    		for(int i=0;i<5;i++)
	    		    {
	    			motor.putElementItem("hj", new Core(null,"l","0"));
	    		//	System.out.println("MotorHandler:hj_globMin:i="+i);
		    		pa=aZpar.getVal(i);
		    		pb=bZpar.getVal(i);
	    		    motor=hj_locMin(motor, i,pa,pb,err);
	    	}
    	     n=n+1;
    	     nextDev=hj_z2dev(motor,given);
	    	//	System.out.println("AsHandler:globalMinimum:n="+n+"  dev="+nextDev+"  deltaDev="+deltaDev);
	    	}while(prevDev-nextDev>err&&n<lim);
	  	   	motor.putElementItem("hj", new Core("output","n",String.valueOf(n)));
	    	motor.putElementItem("hj", new Core("output","deviation",String.valueOf(nextDev)));
	    	//System.out.println("");
	    	//System.out.println("     finish:   deviation="+nextDev+ " cycles="+n);
	    	reportStream.println("\n     finish:   deviation="+nextDev+ " cycles="+n);
	    	return motor;
		}catch(Exception e) {
			System.out.println("MotorHandler:hj_globMin:"+e.toString());
			return motor;
		}
	    }
	public static Sack try_hj(Sack motor,PrintStream reportStream,boolean given) {
		System.out.println("Hooke-Jeeves search of parameters");
		motor=par_n2d(motor);
		System.out.println("Hooke-Jeeves search of parameters:1");
		motor=par_n2z(motor);
		System.out.println("Hooke-Jeeves search of parameters:2");
		motor=hj_globMin(motor,reportStream,given);
		System.out.println("Hooke-Jeeves search of parameters:3");
		//System.out.println("Parameters");
		reportStream.println("Parameters");
		print_pars(motor,reportStream);
		//System.out.println("Variables");
		reportStream.println("Variables");
		print_vars(motor,reportStream);
		return motor;
	}
	public static Sack try_tst(Sack motor,PrintStream reportStream,boolean given) {
		System.out.println("Test parameters");
		motor=par_t2z(motor);
		par_z2v(motor,given);
		System.out.println("Parameters");
		print_pars(motor,reportStream);
		System.out.println("Variables");
		print_vars(motor,reportStream);
		return motor;
	}
	public static Sack try_nom(Sack motor) {
		System.out.println("Nominal variables");
		motor= z_setNomVar( motor);
	
		String isd$=motor.getElementItemAt("nvar", "isd");
		String cos$=motor.getElementItemAt("nvar", "cos");
		String eta$=motor.getElementItemAt("nvar", "eta");
		String m$=motor.getElementItemAt("nvar", "mn");
		String mmax$=motor.getElementItemAt("nvar", "mmax");
        System.out.println("isd="+isd$+" cos="+cos$+ " eta="+eta$+" m="+m$+ "  mmax="+mmax$);
        return motor;
	}
//Printing
	public static void print_vars(Sack motor,PrintStream reportStream) {
		String isd$=motor.getElementItemAt("zvar", "isd");
		String cos$=motor.getElementItemAt("zvar", "cos");
		String eta$=motor.getElementItemAt("zvar", "eta");
		String m$=motor.getElementItemAt("zvar", "m");
		String mmax$=motor.getElementItemAt("zvar", "mmax");
     //System.out.println("Variables");
     //System.out.println("isd="+isd$+" cos="+cos$+ " eta="+eta$+" m="+m$+ "  mmax="+mmax$);
		reportStream.println("isd="+displayDouble(isd$)+" cos="+displayDouble(cos$)+ " eta="+displayDouble(eta$)+" m="+displayDouble(m$)+ "  mmax="+displayDouble(mmax$));
	}
	public static void print_pars(Sack motor,PrintStream reportStream) {
		String rs$=motor.getElementItemAt("zpar", "rs");
		String xs$=motor.getElementItemAt("zpar", "xs");
		String r2$=motor.getElementItemAt("zpar", "r2");
		String x2$=motor.getElementItemAt("zpar", "x2");
		String xm$=motor.getElementItemAt("zpar", "xm");
     //System.out.println("Variables");
    // System.out.println("rs="+rs$+" xs="+xs$+ " r2="+r2$+" x2="+x2$+ "  xm="+xm$);
		 reportStream.println("rs="+displayDouble(rs$)+" xs="+displayDouble(xs$)+ " r2="+displayDouble(r2$)+" x2="+displayDouble(x2$)+ "  xm="+displayDouble(xm$));
	}
	public static String displayDouble(String value$) {
		try {
			NumberFormat numFormat = new DecimalFormat("0.#####E0");
			double value=Double.parseDouble(value$);
			return numFormat.format(value); 
		}catch(Exception e) {
			System.out.println("JMotorEditor:displayNumber="+value$+"   error="+e.toString());
			return null;
		}
	}
	public static void print_tstPars(Sack motor,PrintStream reportStream) {
		String rs$=motor.getElementItemAt("tpar", "rs");
		String xs$=motor.getElementItemAt("tpar", "xs");
		String r2$=motor.getElementItemAt("tpar", "r2");
		String x2$=motor.getElementItemAt("tpar", "x2");
		String xm$=motor.getElementItemAt("tpar", "xm");
     //System.out.println("Variables");
     //System.out.println("rs="+rs$+" xs="+xs$+ " r2="+r2$+" x2="+x2$+ "  xm="+xm$);
		reportStream.println("rs="+displayDouble(rs$)+" xs="+displayDouble(xs$)+ " r2="+displayDouble(r2$)+" x2="+displayDouble(x2$)+ "  xm="+displayDouble(xm$));
	}
// Static
	public static Sack stc_reset(Sack motor) {
		//motor.putElementItem("operator", new Core("output","id","0"));
		motor.putElementItem("operator", new Core("output","cos","0"));
		motor.putElementItem("operator", new Core("output","eta","0"));
		motor.putElementItem("operator", new Core("output","wr","0"));
		motor.putElementItem("operator", new Core("output","mc","0"));
		motor.putElementItem("operator", new Core("output","m","0"));
		motor.putElementItem("operator",new Core("output","isd","0"));
		return motor;
	}
	/*
	public static Sack stc_step(Sack motor) {
		try{
			
			
			
			double time=Double.parseDouble(motor.getElementItemAt("operator", Instrument.TIME));
			double takt=Double.parseDouble(motor.getElementItemAt("operator", Instrument.TAKT));
			double wr=Double.parseDouble(motor.getElementItemAt("operator", "wr"));
			
			///
			double mc=0;
			try {mc=Double.parseDouble(motor.getElementItemAt("operator", "mc"));}catch(Exception ee) {};
			double j=Double.parseDouble(motor.getElementItemAt("primary", "j"));
			double w0=Double.parseDouble(motor.getElementItemAt("dpar", "w0"));
			int pol= Integer.parseInt(motor.getElementItemAt("primary", "pol"));
			//System.out.println(motor_KEY+":takt="+takt+"  j="+j+" m="+m+" time="+time+  "   wr="+wr);
			
			double s=(w0-wr)/w0;
			motor.putElementItem("zin", new Core(null,"s",String.valueOf(s)));
			motor=z_makeState(motor);
			double m=Double.parseDouble(motor.getElementItemAt("zvar", "m"));
			wr=wr+pol*(m-mc)*takt/j;
			motor.putElementItem("operator", new Core("output","wr",String.valueOf(wr)));
			motor.putElementItem("operator", new Core("output","m",String.valueOf(m)));
			motor.putElementItem("operator",new Core("output","isd",motor.getElementItemAt("zvar", "isd")));
			motor.putElementItem("operator",new Core("output","cos",motor.getElementItemAt("zvar", "cos")));
			motor.putElementItem("operator",new Core("output","eta",motor.getElementItemAt("zvar", "eta")));
			}catch(Exception e){
				System.out.println("MotorHandler:stc_step:"+e.toString());
			
			}
		return motor;
	}
	*/
	/*
	public static Sack hj_reinit(Sack motor){
	  		motor=try_hj(motor,null);
	  		motor=par_z2e(motor);
	  		return motor;
	}
	*/
	public static Sack tst_reinit(Sack motor,PrintStream reportStream,boolean given){
  		motor=try_tst(motor,reportStream,given);
  		motor=par_z2e(motor);
  		return motor;
	}
	public static Sack nom_reinit(Sack motor){
  		motor=try_nom(motor);
  		return motor;
}
	
	
	//Vector
	public static Sack vec_supply(Sack motor) {
		double time=0;
		try{time=Double.parseDouble(motor.getElementItemAt("operator","time"));} catch(NumberFormatException nfe){ time=0; }
		double w0=0;
		try{w0=Double.parseDouble(motor.getElementItemAt("zin","w0" ));} catch(NumberFormatException nfe){ w0=0; }
		double usd=0;
		try{usd=Double.parseDouble(motor.getElementItemAt("zin","usd" ));} catch(NumberFormatException nfe){ usd=0; }
		double um=1.414213562*usd;
		double angle=w0*time;
		double cos=Math.cos(angle);
		double sin=Math.sin(angle);
		double usx=um*cos;
		double usy=um*sin;
		motor.putElementItem("operator",new Core("output","usx",String.valueOf(usx)));	
		motor.putElementItem("operator",new Core("output","usy",String.valueOf(usy)));
		return motor;
	}
	public static Sack vec_step(Sack motor) {
		try{
			//System.out.println(ENTITY_KEY+":vec_step:begin");
			double usx=0;
			try{usx=Double.parseDouble(motor.getElementItemAt("operator","usx" ));} catch(NumberFormatException nfe){ usx=0; }
			double usy=0;
			try{usy=Double.parseDouble(motor.getElementItemAt("operator","usy" ));} catch(NumberFormatException nfe){ usy=0; }
			double i2x=0;
			try{i2x=Double.parseDouble(motor.getElementItemAt("operator","i2x" ));} catch(NumberFormatException nfe){ i2x=0; }
			double i2y=0;
			try{i2y=Double.parseDouble(motor.getElementItemAt("operator","i2y" ));} catch(NumberFormatException nfe){ i2y=0; }
			double fx=0;
			try{fx=Double.parseDouble(motor.getElementItemAt("operator","fx" ));} catch(NumberFormatException nfe){ fx=0; }
			double fy=0;
			try{fy=Double.parseDouble(motor.getElementItemAt("operator","fy" ));} catch(NumberFormatException nfe){ fy=0; }
			double wr=0;
			try{wr=Double.parseDouble(motor.getElementItemAt("operator","wr" ));} catch(NumberFormatException nfe){ wr=0; }
			
			//parameters
			double ls=0;
			try{ls=Double.parseDouble(motor.getElementItemAt("epar","ls" ));} catch(NumberFormatException nfe){ ls=0; }
			double rs=0;
			try{rs=Double.parseDouble(motor.getElementItemAt("epar","rs" ));} catch(NumberFormatException nfe){ rs=0; }
			double l2=0;
			try{l2=Double.parseDouble(motor.getElementItemAt("epar","l2" ));} catch(NumberFormatException nfe){ l2=0; }
			double r2=0;
			try{r2=Double.parseDouble(motor.getElementItemAt("epar","r2" ));} catch(NumberFormatException nfe){ r2=0; }
			double lm=0;
			try{lm=Double.parseDouble(motor.getElementItemAt("epar","lm" ));} catch(NumberFormatException nfe){ lm=0; }
			double j=0;
			try{j=Double.parseDouble(motor.getElementItemAt("primary","j" ));} catch(NumberFormatException nfe){ j=0; }
			int pol=0; 
			try{pol=Integer.parseInt(motor.getElementItemAt("primary","pol" ));} catch(NumberFormatException nfe){ pol=1; }
			double dt=0;
			try{dt=Double.parseDouble(motor.getElementItemAt("operator","takt" ));} catch(NumberFormatException nfe){ dt=0; }
		//	double time=0;
		//	try{time=Double.parseDouble(motor.getElementItemAt("operator",Instrument.TIME ));} catch(NumberFormatException nfe){ time=0; }
			double mc=0;
			try{mc=Double.parseDouble(motor.getElementItemAt("operator","mc" ));} catch(NumberFormatException nfe){ mc=0; }
			
			V2 i2= new  V2 (i2x,i2y);
			V2 f=new V2(fx,fy);  
			V4 s= new V4(f,i2);
			
			M2 ll=new M2(1+ls/lm,-ls,1,l2);
			M2 rr=new M2(-rs/lm,rs,0,-r2);
			M2 ee=new M2(0,0,1,l2);
			
			M2 lli=ll.inverse();
			double m=1.5*pol*f.crossProduct(i2);  
			M2 t1=lli.multiplication(rr);
			V4 s1=t1.product(s);		
			M2 t2=lli.multiplication(ee);
			V4 s2=t2.product(s.componentRotation().product(wr));
			V2 us= new  V2 (usx,usy);
			V4 u=new V4(us,new V2(0,0));
			V4 s3=lli.product(u);
			V4 ds= s1.add(s2).add(s3);
			V4 sn=s.add(ds.product(dt));   
		  	f=sn.v1;
			i2=sn.v2;
			V2 im=f.product(1/lm);
			V2 is=im.product(1).add(i2.product(-1));
			
			double dw2=(m-mc)*dt/j;
			double w2=wr/pol;
			w2=w2+dw2;
			wr=pol*w2;
			double id=is.norm()/1.41;

			motor.putElementItem("operator",new Core("output","usx",String.valueOf(us.x)));	
			motor.putElementItem("operator",new Core("output","usy",String.valueOf(us.y)));	
			motor.putElementItem("operator",new Core("output","isx",String.valueOf(is.x)));	
			motor.putElementItem("operator",new Core("output","isy",String.valueOf(is.y)));
			motor.putElementItem("operator",new Core("output","i2x",String.valueOf(i2.x)));
			motor.putElementItem("operator",new Core("output","i2y",String.valueOf(i2.y)));
			motor.putElementItem("operator",new Core("output","fx",String.valueOf(f.x)));	
			motor.putElementItem("operator",new Core("output","fy",String.valueOf(f.y)));	
			motor.putElementItem("operator",new Core("output","wr",String.valueOf(wr)));	
			motor.putElementItem("operator",new Core("output","m",String.valueOf(m)));	
			motor.putElementItem("operator",new Core("output","isd",String.valueOf(id)));
		}catch(Exception e){
		Logger.getLogger(MotorHandler.class.getName()).info(e.getMessage());;
		}
		return motor;
	}
	public static Sack vec_reset(Sack motor) {
		try{
			motor.putElementItem("operator",new Core("output","usx","0"));	
			motor.putElementItem("operator",new Core("output","usy","0"));	
			motor.putElementItem("operator",new Core("output","isx","0"));	
			motor.putElementItem("operator",new Core("output","isy","0"));
			motor.putElementItem("operator",new Core("output","i2x","0"));
			motor.putElementItem("operator",new Core("output","i2y","0"));
			motor.putElementItem("operator",new Core("output","fx","0"));	
			motor.putElementItem("operator",new Core("output","fy","0"));	
			motor.putElementItem("operator",new Core("output","wr","0"));	
			motor.putElementItem("operator",new Core("output","m","0"));	
			motor.putElementItem("operator",new Core("output","mc","0"));	
	   
		}catch(Exception e){
		Logger.getLogger(MotorHandler.class.getName());
		}
		return motor;
	}
	// control
	public static Sack ctl_step(Sack motor) {
		try{
			
			//System.out.println("MotorHandler:ctl_step:BEGIN");
			//	double w0=Double.parseDouble(motor.getElementItemAt("operator","w0"));
			double wr=0;
				try { wr=Double.parseDouble(motor.getElementItemAt("operator","wr"));}catch(Exception e) {}
				double ud=0;
				try {ud=Double.parseDouble(motor.getElementItemAt("operator","ud"));}catch(Exception e) {}
				double mc=0;
				try {mc=Double.parseDouble(motor.getElementItemAt("operator","mc"));}catch(Exception e) {}
				double fx=0; 
				try{ fx=Double.parseDouble(motor.getElementItemAt("operator","fx"));}catch(Exception e) {}
				double fy=0;
				try{fy=Double.parseDouble(motor.getElementItemAt("operator","fy"));}catch(Exception e) {}	
				double vx=0;
				try{vx=Double.parseDouble(motor.getElementItemAt("operator","vx"));}catch(Exception e) {}
				double vy=0;
				try{vy=Double.parseDouble(motor.getElementItemAt("operator","vy"));}catch(Exception e) {}	
				double dt=0;
				try{dt=Double.parseDouble(motor.getElementItemAt("operator","takt"));}catch(Exception e) {}
				double	id=0;
				try{id=Double.parseDouble(motor.getElementItemAt("operator", "id"));}catch(Exception e) {}
				double c0 =0;
				try{c0 =Double.parseDouble(motor.getElementItemAt("secondary","c0" ));}catch(Exception e) {}
				double c1 =0;
				try{c1 =Double.parseDouble(motor.getElementItemAt("secondary","c1" ));}catch(Exception e) {}
				double c2 =0;
				try{c2 =Double.parseDouble(motor.getElementItemAt("secondary","c2" ));}catch(Exception e) {}
				double c3 =0;
				try{c3 =Double.parseDouble(motor.getElementItemAt("secondary","c3" ));}catch(Exception e) {}
				double c4 =0;
				try{c4 =Double.parseDouble(motor.getElementItemAt("secondary","c4" ));}catch(Exception e) {}
				double c5 =0;
				try{c5 =Double.parseDouble(motor.getElementItemAt("secondary","c5" ));}catch(Exception e) {}
				double j =0;
				try{j =Double.parseDouble(motor.getElementItemAt("primary","j" ));}catch(Exception e) {}
				int pol =1;
				try{pol =Integer.parseInt(motor.getElementItemAt("primary","pol" ));}catch(Exception e) {}
			//	double	udf=Double.parseDouble(motor.getElementItemAt("operator", "udf"));
			//	double	pdf=Double.parseDouble(motor.getElementItemAt("operator", "pdf"));
				//System.out.println("MotorHandler:step:1");	
				V2 f=new V2(fx,fy);
				V2 vk=new V2(vx,vy);
			//System.out.println(ENTITY_KEY+":motor:arc="+arc+"   arc1="+arc1);
				double did= c3*ud -c4*id+vk.dotProduct(f)*c5 -vk.crossProduct(f)*c3*wr;
			//	System.out.println("MotorHandler:ctl_step:did="+did);
				V2 df= vk.product(c0*did).add(f.product(-c2)).add(f.rotation().product(wr)).add(vk.rotation().product(id*wr*(-c0))).add(vk.product(id*c1));
				//df.print("df");
				id=id+did*dt;
		//		double alpha=Math.toDegrees(wr*dt);
				//f=f.add(df.rotation(alpha).product(dt));
				f=f.add(df.product(dt));
				double m=1.5*pol*id*(vk.crossProduct(f));
				//System.out.println(ENTITY_KEY+":motor:m="+m+"  id="+id+" fnorm="+f.norm()+"  vk.crossProduct(f)="+vk.crossProduct(f));
				double dw=(m-mc)/j;
				wr=wr+dw*pol*dt;
			//	udf=udf+1000*dt*(ud-udf);
			//	pdf=udf*id;
				 motor.putElementItem("operator",new Core("output","id",String.valueOf(id)));
				 motor.putElementItem("operator",new Core("output","wr",String.valueOf(wr)));
				 motor.putElementItem("operator",new Core("output","m",String.valueOf(m)));
				 motor.putElementItem("operator",new Core("output","fx",String.valueOf(f.x)));
				 motor.putElementItem("operator",new Core("output","fy",String.valueOf(f.y)));
			
			//	 motor.putElementItem("operator",new Core("output","pdf",String.valueOf(pdf)));
			//	 motor.putElementItem("operator",new Core("output","udf",String.valueOf(udf)));
	}catch(Exception e){
				Logger.getLogger(MotorHandler.class.getName());
			
			}
		return motor;
	}
	public static Sack ctl_reset(Sack motor) {
		try{
			//System.out.println("MotorHandler:ctl_reset:motor="+motor.getProperty("label"));
			motor.putElementItem("operator",new Core("output","id","0"));
			 motor.putElementItem("operator",new Core("output","wr","0"));
			 motor.putElementItem("operator",new Core("output","m","0"));
			 motor.putElementItem("operator",new Core("output","fx","0"));
			 motor.putElementItem("operator",new Core("output","fy","0"));
			// motor.putElementItem("operator",new Core("input","vx","0"));
			// motor.putElementItem("operator",new Core("input","vy","0"));
			// motor.putElementItem("operator",new Core("input","ud","0"));
		     
		}catch(Exception e){
			Logger.getLogger(MotorHandler.class.getName());
		
		}
		//motor.print("operator");
	return motor;
}
	
	// Classes	
	public static class M2{
		public double a11;
		public double a12;
		public double a21;
		public double a22;
		public M2(double a11,double a12,double a21,double a22){
			
			this.a11=a11;
			this.a12=a12;
			this.a21=a21;
			this.a22=a22;
	 	
	}
	
private M2 getMinor(){
	return new M2(a22,a21,a12,a11);
}
private M2 getCofactor(){
	return new M2(a11, -a12, -a21,a22);
}
private M2 getTranspose(){
   return new M2(a11,a21,a12,a22   );
}
private M2 divide(double factor){
	return new M2(a11/factor,a12/factor,a21/factor,a22/factor);
}

public M2 inverse(){
	 try{
			double det=  a11*a22-a12*a21;
			if(det==0)
				det =1E-5;
			M2 minor=getMinor();
			M2 cofactor=minor.getCofactor();
			M2 transpose=cofactor.getTranspose();
			return transpose.divide(det);	
		 }catch(Exception ee){
			 return null;
		 }
	
}
public M2 multiplication(M2  m2){
	    double b11=a11*m2.a11+a12*m2.a21;
	    double b12=a11*m2.a12+a12*m2.a22;
	   double b21=a21*m2.a11+a22*m2.a21;
	   double  b22= a21*m2.a12+ a22*m2.a22;
	   return new M2(b11,b12,b21,b22);
	
}
public M2 add(M2  m2){
    double b11=a11+m2.a11;
    double b12=a12+m2.a12;
   double b21=a21+m2.a21;
   double  b22= a22+m2.a22;
   return new M2(b11,b12,b21,b22);
}
public M2 minus(){
    double b11= -a11;
    double b12= -a12;
   double b21= -a21;
   double  b22= -a22;
   return new M2(b11,b12,b21,b22);
}
public V2 product(V2 v){
	double x=a11*v.x+ a12*v.y;
	double y=a21*v.x+ a22*v.y;
	return new V2(x,y);
}

public V4 product(V4 v){
	return new V4(v.v1.product(a11).add(v.v2.product(a12)),v.v1.product(a21).add(v.v2.product(a22)));
}
public void print(String name$){
	System.out.println("M2    "+name$);
	System.out.println("a11= "+a11+"   a12="+a12+ "   a21="+a21+ "   a22="+a22); 
}
public static M2 rot(double angle) {
	double ar= (angle/180)*Math.PI;
	double cos=Math.cos(ar);
	double sin=Math.sin(ar);
	return new M2(cos,-sin,sin,cos);
}
	}
public static class Z{
		public double re;
		public double im;
		public Z( double re,double im){
			this.re=re;
			this.im=im;
		}
		public Z add(Z  z2){
			Z ret=new Z(0,0);
			ret.re=re+z2.re;
			ret.im=im+z2.im;
		   return ret;
	}	
		
		public Z inverse(){
			double det= re*re+im*im;
			if(det==0)
				return null;
			Z ret=new Z(0,0);
			ret.re=re/det;
			ret.im=-im/det;
			return ret;
		}
		public Z product(Z z){
			double a=re*z.re-im*z.im;
			double b=re*z.im+im*z.re;
			return new Z(a,b);
		
		}
		public V2 product(V2 v){
			V2 ret=new V2(0,0);
			ret.x=re*v.x-im*v.y;
			ret.y=re*v.y+im*v.x;
			return ret;
		
		}
		public Z product(double factor){
			Z ret=new Z(0,0);
			ret.re=re*factor;
			ret.im=im*factor;
			return ret;
		
		}
		public double norm() {
			return Math.sqrt(re*re+im*im);
		}
		public V2 unit() {
			double factor=norm();
			double cos=re/factor;
			double sin =im/factor;
			return new V2(cos,sin);
		}
		public V2 unit(V2 v) {
			double factor=norm();
			double cos=re/factor;
			double sin =im/factor;
			double x=v.x*cos-v.y*sin;
			double y=v.x*sin+v.y*cos;
			double m=Math.sqrt(x*x+y*y);
			return new V2(x/m,y/m);
		}
		public void print(String name$){
			System.out.println("MotorHandler:Z="+name$+"  re="+re+ " im="+im);
		}
	}
//@Override
public HashMap<String,Object>  quantum(double time, double qt, HashMap<String,Object>  state, HashMap <String,Object> pars) {
	try {
		//init pars
		double c0=((Double)pars.get("c0")).doubleValue();	
		double c1=((Double)pars.get("c1")).doubleValue();
		double c2=((Double)pars.get("c2")).doubleValue();
		double c3=((Double)pars.get("c3")).doubleValue();	
		double c4=((Double)pars.get("c4")).doubleValue();
		double c5=((Double)pars.get("c5")).doubleValue();
		double j=((Double)pars.get("j")).doubleValue();
		int pol=((Integer)pars.get("pol")).intValue();
		//init vars

		double wr=0;
		try{wr=(double)state.get("wr");}catch(Exception e) {}
		double ud=0;
		try{ud=	(double)state.get("ud");}catch(Exception e) {}
		double mc=0;
		try{mc=(double)state.get("mc");}catch(Exception e) {}
		double fx=0;
		try{fx=((double)state.get("fx"));}catch(Exception e) {}
		double fy=0;
		try{fy=((double)state.get("fy"));}catch(Exception e) {}
				
		double vx=0;
		try{vx=((double)state.get("vx"));}catch(Exception e) {}
				
		double vy=0;
		try{vy=((double)state.get("vy"));}catch(Exception e) {}
		double id=0;
		try{id=(double)state.get("id");}catch(Exception e) {}
		//System.out.println("MotorHandler:quantum: ud="+ud);
		
		V2 f=new V2(fx,fy);
		V2 vk=new V2(vx,vy);
		
		//StateHandler.print(pars);
		double ed=vk.crossProduct(f)*c3*wr;
		double did= c3*ud -c4*id+vk.dotProduct(f)*c5 -ed;
		//System.out.println("MotorHandler:quantum:ed="+ed/c3);
		V2 df= vk.product(c0*did).add(f.product(-c2)).add(f.rotation().product(wr)).add(vk.rotation().product(id*wr*(-c0))).add(vk.product(id*c1));
		//V2 df= vk.product(c0*did).add(f.product(-c2)).add(f.rotation().product(wr)).add(vk.rotation().product(id*wr*(c0))).add(vk.product(id*c1));
		
		///debug
//		MotorHandler.V2 vc0=vk.rotation().product(id*wr*(c0));
//		double c0dot=vc0.dotProduct(f);
//		double fdot=df.dotProduct(f);
//		double vkdot=vk.dotProduct(f);
		
//		double diddot=vk.product(c0*did).dotProduct(f);
//		double c1dot=vk.product(id*c1).dotProduct(f);
		//System.out.println("MotorHandler:quantum:c0dot="+c0dot+"  diddot="+diddot+"  c1dot="+c1dot);
		///end debug
		
		id=id+did*qt;
		f=f.add(df.product(qt));
		//System.out.println("MotorHandler:quantum:dfdot="+fdot+"  vkdot="+vkdot+"  c0dot="+c0dot+"  fnorm="+f.norm());
		double m=1.5*pol*id*(vk.crossProduct(f));
		//System.out.println("MotorHandler:quantum:m="+m);
		double dw=(m-mc)/j;
		wr=wr+dw*pol*qt;
		state.put("wr", Double.valueOf(wr));
		state.put("id", Double.valueOf(id));
		state.put("fx", Double.valueOf(f.x));
		state.put("fy", Double.valueOf(f.y));
		state.put("m", Double.valueOf(m));
		state.put("ed", Double.valueOf(ed/c3));
		//state.put(Instrument.TIME, Double.valueOf(time));
	}catch(Exception e) {
		LOGGER.severe(e.toString());
	}
	return state;
}
//@Override
public HashMap<String,Object>  initPars(Sack motor) {
	//System.out.println("MotorHandler:initPars:motor="+motor.getProperty("label"));
	//motor.print("secondary");
	HashMap<String,Object>  pars =new HashMap<String,Object>();
	double c0 =0;
	try{c0 =Double.parseDouble(motor.getElementItemAt("secondary","c0" ));}catch(Exception e) {}
	pars.put("c0", Double.valueOf(c0));
	double c1 =0;
	try{c1 =Double.parseDouble(motor.getElementItemAt("secondary","c1" ));}catch(Exception e) {}
	pars.put("c1", Double.valueOf(c1));
	double c2 =0;
	try{c2 =Double.parseDouble(motor.getElementItemAt("secondary","c2" ));}catch(Exception e) {}
	pars.put("c2", Double.valueOf(c2));
	double c3 =0;
	try{c3 =Double.parseDouble(motor.getElementItemAt("secondary","c3" ));}catch(Exception e) {}
	pars.put("c3", Double.valueOf(c3));
	double c4 =0;
	try{c4 =Double.parseDouble(motor.getElementItemAt("secondary","c4" ));}catch(Exception e) {}
	pars.put("c4", Double.valueOf(c4));
	double c5 =0;
	try{c5 =Double.parseDouble(motor.getElementItemAt("secondary","c5" ));}catch(Exception e) {}
	pars.put("c5", Double.valueOf(c5));
	double j =0;
	try{j =Double.parseDouble(motor.getElementItemAt("primary","j" ));}catch(Exception e) {}
	pars.put("j", Double.valueOf(j));
	int pol =1;
	try{pol =Integer.parseInt(motor.getElementItemAt("primary","pol" ));}catch(Exception e) {}
	pars.put("pol", Integer.valueOf(pol));
	
	double tw= 2*j/(3*pol*pol);
	pars.put("tw", tw);
	
	//System.out.println("MotorHandler:initPars:tw="+tw);
	double tf= 2/c2;
	pars.put("tf", tf);
	
		pars.put("j", Double.valueOf(j));
	
	
	//StateHandler.print(pars);
	return pars;
}
//@Override
public HashMap<String, Object> initState(Sack operator) {
	HashMap<String, Object> state=new HashMap<String, Object>();
	double wr=0;
	try {wr=Double.parseDouble(operator.getElementItemAt("operator", "wr"));}catch(Exception e) {}
	state.put("wr", wr);
	
	double w0=0;
	try {w0=Double.parseDouble(operator.getElementItemAt("operator", "w0"));}catch(Exception e) {}
	state.put("w0", w0);
	
	double ud=0;
	try {ud=Double.parseDouble(operator.getElementItemAt("operator", "ud"));}catch(Exception e) {}
	state.put("ud", ud);
	double id=0;
	try {id=Double.parseDouble(operator.getElementItemAt("operator", "id"));}catch(Exception e) {}
	state.put("id", id);
	double mc=0;
	try {mc=Double.parseDouble(operator.getElementItemAt("operator", "mc"));}catch(Exception e) {}
	state.put("mc", mc);
	double fx=0;
	try {fx=Double.parseDouble(operator.getElementItemAt("operator", "fx"));}catch(Exception e) {}
	state.put("fx", fx);
	double fy=0;
	try {fy=Double.parseDouble(operator.getElementItemAt("operator", "fy"));}catch(Exception e) {}
	state.put("fy", fy);
	
	String flux$=operator.getElementItemAt("operator", "flux");
	if(flux$!=null)
		state.put("flux", flux$);
	
	//double vx=0;
	//try {vx=Double.parseDouble(operator.getElementItemAt("operator", "vx"));}catch(Exception e) {}
	//state.put("vx", vx);
	//double vy=0;
	//try {vy=Double.parseDouble(operator.getElementItemAt("operator", "vy"));}catch(Exception e) {}
	//state.put("vy", vy);
	
	return state;
}

public Sack commit(Sack operator, HashMap<String, Object> state) {
	double wr=0;
	try {wr=(double)state.get("wr");}catch(Exception e) {}
	operator.putElementItem("operator", new Core("output","wr",String.valueOf(wr)));
	double id=0;
	try {id=(double)state.get("id");}catch(Exception e) {}
	operator.putElementItem("operator", new Core("output","id",String.valueOf(id)));
	double fx=0;
	try {fx=(double)state.get("fx");}catch(Exception e) {}
	operator.putElementItem("operator", new Core("output","fx",String.valueOf(fx)));
	double fy=0;
	try {fy=(double)state.get("fy");}catch(Exception e) {}
	operator.putElementItem("operator", new Core("output","fy",String.valueOf(fy)));
	double m=0;
	try {m=(double)state.get("m");}catch(Exception e) {}
	operator.putElementItem("operator", new Core("output","m",String.valueOf(m)));
	double ed=0;
	try {ed=(double)state.get("ed");}catch(Exception e) {}
	operator.putElementItem("operator", new Core("output","ed",String.valueOf(ed)));
	return operator;
}

/*
@Override
public String add(Entigrator entigrator, String locator$) {
	// TODO Auto-generated method stub
	return null;
}
*/
/*
@Override
public String remove(Entigrator entigrator, String locator$) {
	// TODO Auto-generated method stub
	return null;
}
*/
@Override
public String getKey() {
	return KEY;
}
@Override
public String[] listOutputs() {
	return new String[] {
	//static
		"wr",
		"isd",
		"m"
	};
}
@Override
public String[] listInputs() {
	return new String[] {
				"usd",
				"mc",
				"jc"
			};
}



@Override
public Sack apply(Entigrator entigrator, Sack entity) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public Sack remove(Entigrator entigrator, Sack entity) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
	// TODO Auto-generated method stub
	return null;
}



@Override
public Hashtable<String, Double> getSettings() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void putSettings(Hashtable<String, Double> settings) {
	// TODO Auto-generated method stub
	
}

@Override
public Hashtable<String, Double> getOuts() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public double getClock() {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public void setClock(double clock) {
	
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
}

@Override
public void step(Entigrator entigrator, String locator$) {
	// TODO Auto-generated method stub
	
}

@Override
public void reset(Entigrator entigrator, String locator$) {
	reset();
	
}

@Override
public void reinit(Entigrator entigrator, String locator$) {
	// TODO Auto-generated method stub
	
}

@Override
public String[] listOutputs(Entigrator entigrator) {
	return listOutputs();
}

@Override
public String[] listInputs(Entigrator entigrator) {
	return listInputs();
}
public static void main(String[] aa) {
	 String entihome$="/home/alexander/ASrel0";
	 Entigrator entigrator=new Entigrator(entihome$);
	 String motor$="4А112МВ6УЗ";
	 Sack motor=entigrator.getEntityAtLabel(motor$);
	 motor.putElementItem("zin", new Core(null,"w0","314"));
	 motor.putElementItem("zin", new Core(null,"usd","220"));
	 motor.putElementItem("zin", new Core(null,"s","0.051"));
	 motor=MotorHandler.z_makeState(motor, false);
	 motor.printElement("zvar");
 }
}
