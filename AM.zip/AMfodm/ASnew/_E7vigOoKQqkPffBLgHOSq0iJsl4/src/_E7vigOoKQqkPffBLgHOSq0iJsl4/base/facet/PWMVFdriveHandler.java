package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.PWMVFdrive;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class PWMVFdriveHandler extends  OperatorHandler{
	public static final String KEY="_5ZTQcM_zAjSObea5Qx5_SeoOl8KI";
	Sack entity;
	PWMVFdrive pwmvfdrive;
	double preferredClock=Double.MIN_VALUE;
	double clock=Double.MIN_VALUE;
	double f=Double.MIN_VALUE;
	double Uc=Double.MIN_VALUE;
	public PWMVFdriveHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		System.out.println("PWMVFdriveHandler:operator key="+operatorKey$+"  alocator="+alocator$);   
		if(operatorKey$!=null) {
			 entity=entigrator.getEntityAtLabel(operatorKey$);
			 pwmvfdrive=new PWMVFdrive(entigrator,locator$);
			reinit(entigrator, locator$);
			reset();
		   }
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"PWMVFdriveHandler");
		locator.put(FACET_TYPE,"pwmvfdriveHandler");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMVFdriveHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMVFdriveMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "pwmvfdrive.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	
	public void reset() {
	try {
		System.out.println("PWMVFdriveHandler:reset:BEGIN");
		if(operatorKey$!=null) { 
			 entity=entigrator.getEntity(operatorKey$);
			 System.out.println("PWMVFdriveHandler:reset:entity="+entity.getProperty("label"));
		}else {
			System.out.println("PWMVFdriveHandler:reset:operator key is null. Return");
		return;
		}
		String motor$=entity.getElementItemAt("pwmvfdrive", "motor");
		if(motor$!=null)
		  locator$=Locator.append(locator$, PWMVFdrive.MOTOR, motor$);
		else
			System.out.println("PWMVFdriveHandler:reset:motor is null in entity="+entity.getProperty("label"));
		String option$=entity.getElementItemAt("pwmvfdrive", "test");
		if(option$!=null)
		locator$=Locator.append(locator$, PWMVFdrive.OPTION, option$);
		else
			System.out.println("PWMVFdriveHandler:reset:option is null in entity="+entity.getProperty("label"));	
		pwmvfdrive.reset(entigrator,locator$);
		//entity.printElement("vfsupply");
		Hashtable<String, Double> settings=new Hashtable<String, Double>();
		double Ua=0;
	    try{Ua=Double.parseDouble(entity.getElementItemAt("pwmvfdrive","Ua"));}catch(Exception ee) {}
	    settings.put("Ua", Ua);
	    double f0=0;
	    try{f0=Double.parseDouble(entity.getElementItemAt("pwmvfdrive","f0"));}catch(Exception ee) {}
	    settings.put("f0", f0);
	    try{Uc=Double.parseDouble(entity.getElementItemAt("pwmvfdrive","Uc"));}catch(Exception ee) {}
	    try{f=Double.parseDouble(entity.getElementItemAt("pwmvfdrive","f"));}catch(Exception ee) {}
	    //System.out.println("VFsupplyHandler:reset:operator key="+operatorKey$+" f="+f+" Uc="+Uc);  
	    settings.put("Ucm", 10.0);
	    
	    pwmvfdrive.putSettings(settings);	 
        preferredClock=0.001/f0;
	}catch(Exception e) {
		System.out.println("PWMVFdriveHandler:reset:"+e.toString());
	}
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		 try {
				entity=entigrator.getEntity(operatorKey$);
				System.out.println("PWMVFdriveHandler:step:entity="+entity.getProperty("label"));
				String takt$=entity.getElementItemAt(OPERATOR, "takt");
				double takt=0;
				try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
				time=0;
				String time$=entity.getElementItemAt(OPERATOR, "time");
				try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
				double w=0;
				String w$=entity.getElementItemAt("pwmvfdrive", "W");
				try {w=Double.parseDouble(w$);}catch(Exception ee) {}
				double mc=0;
				String mc$=entity.getElementItemAt("pwmvfdrive", "M");
				try {mc=Double.parseDouble(mc$);}catch(Exception ee) {}
				
				double isa=0;
				String isa$=entity.getElementItemAt("pwmvfdrive", "isa");
				try {isa=Double.parseDouble(isa$);}catch(Exception ee) {}
				double isb=0;
				String isb$=entity.getElementItemAt("pwmvfdrive", "isb");
				try {isb=Double.parseDouble(isb$);}catch(Exception ee) {}
				double isc=0;
				String isc$=entity.getElementItemAt("pwmvfdrive", "isc");
				try {isc=Double.parseDouble(isc$);}catch(Exception ee) {}
				// System.out.println("PWMsupplyHandler:step:time="+time+" takt="+takt+" f="+f+" Uc="+Uc);
				Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
				ins.put("w", w);
				ins.put("mc", mc);
				ins.put("isa", isa);
				ins.put("isb", isb);
				ins.put("isc", isc);
				double clock=takt; 
				Hashtable<String,Double> outs=null;
                if(takt>preferredClock) {
                	int cnt=(int)(takt/preferredClock);
                	if(cnt>0)
                		clock=takt/cnt;
                	for(int i=0;i<cnt;i++) {
                		ins.put("clock", clock);
                		ins.put("time", time);
                		ins.put("w", w);
        				ins.put("mc", mc);
                		time=time+clock;
                	}
                double dt=takt-cnt*preferredClock;
                if(dt>0) {
                	ins.put("clock", dt);
                	time=time+dt;
                	ins.put("time", time);
                	pwmvfdrive.stride(ins);
                }
                }else {
                	ins.put("clock", takt);
                	ins.put("time", time);
                	pwmvfdrive.stride(ins);
                }
                outs=pwmvfdrive.getOuts(); 
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            try {
					value=outs.get(key$);
		            }catch(java.lang.NullPointerException ee) {
		            	System.out.println("PWMVFdriveHandler:step:cannot get"+key$+"  err="+ee.toString());
		            	continue;
		            }
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				
		  }catch(Exception e) {
			  System.out.println("PWMVFdriveHandler:step:"+e.toString());  
		  }
		
	}

	@Override
	public void reset(Entigrator entigrator, String locator$) {
		try {
		System.out.println("PWMVFdriveHandler:reset:operator key=="+operatorKey$);
		entity=entigrator.getEntity(operatorKey$);
		String motor$=entity.getElementItemAt("pwmvfdrive","motor");
		String test$=entity.getElementItemAt("pwmvfdrive","test");
		if(motor$!=null) 
		locator$=Locator.append(locator$, PWMVFdrive.MOTOR, motor$);
		else
			System.out.println("PWMVFdriveHandler:reset:motor is null in entity="+entity.getProperty("label"));
		if(test$!=null) 
			locator$=Locator.append(locator$, PWMVFdrive.OPTION,test$);
			else
				System.out.println("PWMVFdriveHandler:reset:test is null in entity="+entity.getProperty("label"));
		
		if(pwmvfdrive==null)
			pwmvfdrive=new PWMVFdrive(entigrator,locator$);
		pwmvfdrive.reset( entigrator, locator$);
		}catch(Exception e) {
			System.out.println("PWMVFdriveHandler:reset:"+e.toString());  
		}
		
	}

	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset();
	}

	@Override
	public String[] listOutputs(Entigrator entigrator) {
		if(pwmvfdrive==null)
			pwmvfdrive=new PWMVFdrive(entigrator,locator$);
		return pwmvfdrive.listOuts();
	}

	@Override
	public String[] listInputs(Entigrator entigrator) {
		if(pwmvfdrive==null)
			pwmvfdrive=new PWMVFdrive(entigrator,locator$);
		return pwmvfdrive.listIns();
	}

	

	@Override
	public String getName() {
		return "PWMVFdriveHandler";
	}

	@Override
	public String getType() {
		return "pwmvfdrivehandler";
	}

	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMVFdriveHandler";
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
