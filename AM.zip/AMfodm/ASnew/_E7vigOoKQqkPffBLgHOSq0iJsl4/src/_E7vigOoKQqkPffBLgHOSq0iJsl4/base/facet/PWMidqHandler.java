package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.PWMidq;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class PWMidqHandler extends  OperatorHandler{
	public static final String KEY="_zXGWizB5Ah18YxBE7GW24uk_hY8";
	Sack entity;
	PWMidq pwmidq;
	double preferredClock=Double.MIN_VALUE;
	double clock=Double.MIN_VALUE;
	double Kid=Double.MIN_VALUE;
	double Ud=Double.MIN_VALUE;
	double Tco=Double.MIN_VALUE;
	public PWMidqHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		System.out.println("PWMidqHandler:operator key="+operatorKey$+"  alocator="+alocator$);   
		if(operatorKey$!=null) {
			 entity=entigrator.getEntityAtLabel(operatorKey$);
			 
			 pwmidq=new PWMidq(entigrator,locator$);
			reinit(entigrator, locator$);
			reset();
		   }
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"PWMidqHandler");
		locator.put(FACET_TYPE,"pwmvidqHandler");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMidqHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMidqMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "pwmidq.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	
	public void reset() {
	try {
		//System.out.println("PWMVFcontrolHandler:reset:BEGIN");
		if(operatorKey$!=null) { 
			 entity=entigrator.getEntity(operatorKey$);
			 System.out.println("PWMidqHandler:reset:entity="+entity.getProperty("label"));
			 locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
		}else {
			System.out.println("PWMidqHandler:reset:operator key is null. Return");
		return;
		}
		String motor$=entity.getElementItemAt("pwmidq", "motor");
		if(motor$!=null)
		  locator$=Locator.append(locator$, PWMidq.MOTOR, motor$);
		else
			System.out.println("PWMidqHandler:reset:motor is null in entity="+entity.getProperty("label"));
		String option$=entity.getElementItemAt("pwmidq", "test");
		if(option$!=null)
		locator$=Locator.append(locator$, PWMidq.OPTION, option$);
		else
			System.out.println("PWMidqHandler:reset:option is null in entity="+entity.getProperty("label"));
		
		pwmidq.reset(entigrator,locator$);
		
		//entity.printElement("vfsupply");
		Hashtable<String, Double> settings=new Hashtable<String, Double>();
		double Ud=0;
	    try{Ud=Double.parseDouble(entity.getElementItemAt("pwmidq","Ud"));}catch(Exception ee) {}
	    settings.put("Ud", Ud);
	    double Kid=0;
	    try{Kid=Double.parseDouble(entity.getElementItemAt("pwmidq","Kid"));}catch(Exception ee) {}
	    settings.put("Kid", Kid);
	    try{Tco=Double.parseDouble(entity.getElementItemAt("pwmidq","Tco"));}catch(Exception ee) {}
	    pwmidq.putSettings(settings);	 
        
	}catch(Exception e) {
		System.out.println("PWMidqHandler:reset:"+e.toString());
	}
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		 try {
				entity=entigrator.getEntity(operatorKey$);
				//System.out.println("PWMVFcontrolHandler:step:entity="+entity.getProperty("label"));
				String takt$=entity.getElementItemAt(OPERATOR, "takt");
				double takt=0;
				try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
				time=0;
				String time$=entity.getElementItemAt(OPERATOR, "time");
				try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
				double w=0;
				String w$=entity.getElementItemAt("pwmidq", "W");
				try {w=Double.parseDouble(w$);}catch(Exception ee) {}
				double mc=0;
				String mc$=entity.getElementItemAt("pwmidq", "M");
				try {mc=Double.parseDouble(mc$);}catch(Exception ee) {}
				
				double isa=0;
				String isa$=entity.getElementItemAt("pwmidq", "isa");
				try {isa=Double.parseDouble(isa$);}catch(Exception ee) {}
				double isb=0;
				String isb$=entity.getElementItemAt("pwmidq", "isb");
				try {isb=Double.parseDouble(isb$);}catch(Exception ee) {}
				double isc=0;
				String isc$=entity.getElementItemAt("pwmidq", "isc");
				try {isc=Double.parseDouble(isc$);}catch(Exception ee) {}
				// System.out.println("PWMsupplyHandler:step:time="+time+" takt="+takt+" f="+f+" Uc="+Uc);
				Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
				ins.put("w", w);
				ins.put("mc", mc);
				ins.put("isa", isa);
				ins.put("isb", isb);
				ins.put("isc", isc);
				double clock=takt; 
				Hashtable<String,Double> outs=null;
                /*
				if(takt>preferredClock) {
                	int cnt=(int)(takt/preferredClock);
                	if(cnt>0)
                		clock=takt/cnt;
                	for(int i=0;i<cnt;i++) {
                		ins.put("clock", clock);
                		ins.put("time", time);
                		ins.put("w", w);
        				ins.put("mc", mc);
                		time=time+clock;
                	}
                double dt=takt-cnt*preferredClock;
                if(dt>0) {
                	ins.put("clock", dt);
                	time=time+dt;
                	ins.put("time", time);
                	pwmfoc.stride(ins);
                }
                }else {
                */
                	ins.put("clock", takt);
                	ins.put("time", time);
                	pwmidq.stride(ins);
                //}
                outs=pwmidq.getOuts(); 
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            try {
					value=outs.get(key$);
		            }catch(java.lang.NullPointerException ee) {
		            	System.out.println("PWMidqHandler:step:cannot get"+key$+"  err="+ee.toString());
		            	continue;
		            }
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				
		  }catch(Exception e) {
			  System.out.println("PWMidqHandler:step:"+e.toString());  
		  }
		
	}

	@Override
	public void reset(Entigrator entigrator, String locator$) {
		try {
		System.out.println("PWMidqHandler:reset:operator key=="+operatorKey$);
		entity=entigrator.getEntity(operatorKey$);
		locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
		String motor$=entity.getElementItemAt("pwmidq","motor");
		String test$=entity.getElementItemAt("pwmidq","test");
		if(motor$!=null) 
		locator$=Locator.append(locator$, PWMidq.MOTOR, motor$);
		else
			System.out.println("PWMidqHandler:reset:motor is null in entity="+entity.getProperty("label"));
		if(test$!=null) 
			locator$=Locator.append(locator$, PWMidq.OPTION,test$);
			else
				System.out.println("PWMidqHandler:reset:test is null in entity="+entity.getProperty("label"));
		
		if(pwmidq==null)
			pwmidq=new PWMidq(entigrator,locator$);
		pwmidq.reset( entigrator, locator$);
		}catch(Exception e) {
			System.out.println("PWMidqHandler:reset:"+e.toString());  
		}
		
	}

	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset();
	}

	@Override
	public String[] listOutputs(Entigrator entigrator) {
		if(pwmidq==null)
			pwmidq=new PWMidq(entigrator,locator$);
		return pwmidq.listOuts();
	}

	@Override
	public String[] listInputs(Entigrator entigrator) {
		if(pwmidq==null)
			pwmidq=new PWMidq(entigrator,locator$);
		return pwmidq.listIns();
	}

	

	@Override
	public String getName() {
		return "PWMidqHandler";
	}

	@Override
	public String getType() {
		return "pwmidqhandler";
	}

	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMidqHandler";
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
