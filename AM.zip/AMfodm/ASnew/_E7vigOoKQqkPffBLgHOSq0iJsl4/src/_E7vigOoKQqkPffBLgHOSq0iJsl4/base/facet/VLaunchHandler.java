package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.SinCos;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.U2model;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class VLaunchHandler extends  OperatorHandler implements SegueController{
	public static final String KEY="_YuotuEyfwkGA5xLCe0axedAHtQs";
	Sack entity;
	double m=0;
	double isd=0;
	double preferredClock=Double.MIN_VALUE;	
	double f=50;
	double usd=220;
	double time=0;
	double mc=0;
	double lt=0;
	double ut=0;
    U2model u2model;
    SinCos sinCos;
    V2 us=new V2(0,0);
	public VLaunchHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	   if(operatorKey$!=null) {
		 entity=entigrator.getEntityAtLabel(operatorKey$);
		reinit(entigrator, locator$);
		reset();
	   }
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"Vlaunch");
		locator.put(FACET_TYPE,"vlaunch");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VLaunchHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.VLaunchMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "vlaunch.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	
	@Override
	public void step(Entigrator entigrator, String locator$) {
	  try {
			String takt$=entity.getElementItemAt(OPERATOR, "takt");
			double takt=0;
			try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
			double time=0;
			String time$=entity.getElementItemAt(OPERATOR, "time");
			try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
			String mc$=entity.getElementItemAt("vlaunch", "mc");
			try {mc=Double.parseDouble(mc$);}catch(Exception ee) {} 
			Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
			ins.put("time", time);
			ins.put("clock", takt);
			ins.put("mc", mc);
			Hashtable<String,Double> outs=stride(ins);
			Enumeration<String>  oe= outs.keys();
			String key$=null;
			double value;
			while (oe.hasMoreElements()) {
				key$ = oe.nextElement();
	            try {
				value=outs.get(key$);
	            }catch(java.lang.NullPointerException ee) {
	            	System.out.println("VLaunchHandler:step:cannot get"+key$+"  err="+ee.toString());
	            	continue;
	            }
	            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
			}
			double isx=0;
			try { isx=outs.get("isx");}catch(Exception ee) {}
			double isy=0;
			try { isy=outs.get("isy");}catch(Exception ee) {}
			isd=Math.sqrt(isx*isx+isy*isy)/1.5;
			outs.put("isd", isd);
			entity.putElementItem(OPERATOR, new Core("out","usx",String.valueOf(outs.get("usx"))));
			entity.putElementItem(OPERATOR, new Core("out","usy",String.valueOf(outs.get("usy"))));
			entity.putElementItem(OPERATOR, new Core("out","isd",String.valueOf(outs.get("isd"))));
			entigrator.putEntity(entity);
			
	  }catch(Exception e) {
		  System.out.println("VLaunchHandler:step:"+e.toString());  
	  }
		
	}
	@Override
	public void reset() {
	try {	
		time=0;
		String motor$=entity.getElementItemAt("vlaunch", "motor");
		String option$=entity.getElementItemAt("vlaunch", "test");
		String v$=entity.getElementItemAt("vlaunch", "v");
		String f$=entity.getElementItemAt("vlaunch", "f");
		String l$=entity.getElementItemAt("vlaunch", "lt");
		String u$=entity.getElementItemAt("vlaunch", "ut");
		try {
			double v=Double.parseDouble(v$);
			double um=Math.sqrt(2)*v;
			double f=Double.parseDouble(f$);
			sinCos=new SinCos(um,f);
		}catch(Exception ee) {}
		try {mc=Double.parseDouble(entity.getElementItemAt("vlaunch", "mc"));}catch(Exception ee) {}
		try {lt=Double.parseDouble(entity.getElementItemAt("vlaunch", "lt"));}catch(Exception ee) {}
		try {ut=Double.parseDouble(entity.getElementItemAt("vlaunch", "ut"));}catch(Exception ee) {}
		System.out.println("VLaunchHandler:reset:motor="+motor$+"  option="+option$+" mc="+mc);
		entity.putElementItem(OPERATOR, new Core("in","mc",String.valueOf(mc)));
		Properties props=new Properties();
		props.put(U2model.MOTOR, motor$);
		props.put(U2model.OPTION, option$);
		String u2locator$=Locator.toString(props);
		System.out.println("VLaunchHandler:reset:u2locator="+u2locator$);
		u2model=new U2model(entigrator,u2locator$);
	}catch(Exception e) {
		System.out.println("VLaunchHandler:reset:"+e.toString());
	}
	}
	@Override
	public Hashtable<String, Double> getSettings() {
		if(u2model!=null)
			return u2model.getSettings();
		else
			return null;
	}
	@Override
	public void putSettings(Hashtable<String, Double> settings) {
		if(u2model!=null)
			 u2model.putSettings(settings);
	}
	@Override
	public Hashtable<String, Double> getOuts() {
		if(u2model!=null) {
			Hashtable<String, Double>outs= u2model.getOuts();
			double isx=0;
			try { isx=outs.get("isx");}catch(Exception ee) {}
			double isy=0;
			try { isy=outs.get("isy");}catch(Exception ee) {}
			isd=Math.sqrt(isx*isx+isy*isy);
			outs.put("isd", isd);
			
			return outs;
		}
		else
			return null;
	}
	
	
	@Override
	public String[] listInputs() {
		return new String[] {"","f","time"};
	}
	@Override
	public String[] listOutputs() {
		return new String[] {"i2x","i2y","isx","isy","fx","fy","wr","m","isd"};
	}
	
	@Override
	public String getName() {
		return "VLaunch";
	}
	@Override
	public String getType() {
		return "vlaunch";
	}
	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VLaunchHandler";
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public double getClock() {
		if(u2model!=null)
			return u2model.getClock();
		else
			return 0;
	}
	@Override
	public void setClock(double clock) {
		
	}
	@Override
	public void setEntigrator(Entigrator entigrator) {
		this.entigrator=entigrator;
	}
	
	public Hashtable<String,Double> stride(Hashtable<String,Double> ins) {
		try {
			time=0;
			try {time=ins.get("time");}catch(Exception ee) {}
			double ml=0;
			
			//if(time>lt&&time<ut)
				ml=mc;
			us=sinCos.get(time);
			double clock=0;
			try {clock=ins.get("clock");}catch(Exception ee) {}
			if(clock<=0) {
			    clock=u2model.getClock();
			    ins.put("clock",clock);
			}
			Hashtable<String,Double> outs=new Hashtable<String,Double>();
			outs.put("usx", us.x);
			outs.put("usy", us.y);
			ins.put("usx", us.x);
			ins.put("usy", us.y);
			ins.put("mc", ml);
			//EduHandler.printHashtableDouble("VLaunchHandler:step:ins", ins);
			u2model.stride(ins);
			outs=u2model.getOuts();
			outs.put("usx", us.x);
			outs.put("usy", us.y);
			//EduHandler.printHashtableDouble("VLaunchHandler:stride:outs", outs);
			return outs;
		}catch(Exception e) {
			System.out.println("VLaunchHandler:stride:"+e.toString());
			return null;
		}
		
	}
	@Override
	public void reset(Entigrator entigrator, String locator$) {
		try {
			entity=entigrator.getEntity(operatorKey$);
			System.out.println("VLaunchHandler:reinit:entity="+entity.getProperty("label")+" operator="+operatorKey$);

			reset();
			if(entity!=null) {
				if(!entity.existsElement(OPERATOR))
					entity.createElement(OPERATOR);
		   String[] sa=listOutputs();
		   for(String s:sa)
			   entity.putElementItem(OPERATOR, new Core(null,s,"0"));
			entity.putElementItem(OPERATOR, new Core(null,"time","0"));
			entity.putElementItem(OPERATOR, new Core(null,"usx","0"));
			entity.putElementItem(OPERATOR, new Core(null,"usy","0"));
			entity.putElementItem(OPERATOR, new Core(null,"isd","0"));
			entigrator.putEntity(entity);
			}
		}catch(Exception e) {
			System.out.println("VLaunchHandler:reset:"+e.toString());
		}
		
	}
	
	@Override
	public String[] listOutputs(Entigrator entigrator) {
		String[] outs=listOutputs();
		ArrayList <String>list=new ArrayList<String>();
		for(String s:outs)
			list.add(s);
		list.add("isd");
		list.add("usx");
		list.add("usy");
		outs=new String[list.size()];
		list.toArray(outs);
		return outs;
	}
	@Override
	public String[] listInputs(Entigrator entigrator) {
		
		return listInputs();
	}
	@Override
	public void reinit(Entigrator entigrator, String alocator$) {
		entity=entigrator.getEntity(operatorKey$);
	}	
}
