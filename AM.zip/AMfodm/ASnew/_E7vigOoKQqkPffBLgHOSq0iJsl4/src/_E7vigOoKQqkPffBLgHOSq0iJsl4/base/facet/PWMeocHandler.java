package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.PWMeoc;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class PWMeocHandler extends  OperatorHandler{
	public static final String KEY="_H2Yjz08_SVC9SaD_SAYA3WsSSQAN0";
	Sack entity;
	PWMeoc pwmeoc;
	double preferredClock=Double.MIN_VALUE;
	double clock=Double.MIN_VALUE;
	double Kid=Double.MIN_VALUE;
	double Ud=Double.MIN_VALUE;
	double Tco=Double.MIN_VALUE;
	public PWMeocHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		System.out.println("PWMeocHandler:operator key="+operatorKey$+"  alocator="+alocator$);   
		if(operatorKey$!=null) {
			 entity=entigrator.getEntityAtLabel(operatorKey$);
			 pwmeoc=new PWMeoc(entigrator,locator$);
			 reinit(entigrator, locator$);
			reset();
		   }
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"PWMeocHandler");
		locator.put(FACET_TYPE,"pwmeocHandler");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMeocHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMeocMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "pwmeoc.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	
	public void reset() {
	try {
		//System.out.println("PWMVFcontrolHandler:reset:BEGIN");
		if(operatorKey$!=null) { 
			 entity=entigrator.getEntity(operatorKey$);
			 System.out.println("PWMeocHandler:reset:entity="+entity.getProperty("label"));
			 locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
		}else {
			System.out.println("PWMeocHandler:reset:operator key is null. Return");
		return;
		}
		String motor$=entity.getElementItemAt("pwmeoc", "motor");
		if(motor$!=null)
		  locator$=Locator.append(locator$, PWMeoc.MOTOR, motor$);
		else
			System.out.println("PWMeocHandler:reset:motor is null in entity="+entity.getProperty("label"));
		String option$=entity.getElementItemAt("pwmeoc", "test");
		if(option$!=null)
		locator$=Locator.append(locator$, PWMeoc.OPTION, option$);
		else
			System.out.println("PWMeocHandler:reset:option is null in entity="+entity.getProperty("label"));
		
		pwmeoc.reset(entigrator,locator$);
		
		//entity.printElement("vfsupply");
		Hashtable<String, Double> settings=new Hashtable<String, Double>();
		double Ud=0;
	    try{Ud=Double.parseDouble(entity.getElementItemAt("pwmeoc","Ud"));}catch(Exception ee) {}
	    settings.put("Ud", Ud);
	    double Kid=0;
	    try{Kid=Double.parseDouble(entity.getElementItemAt("pwmeoc","Kid"));}catch(Exception ee) {}
	    settings.put("Kid", Kid);
	    try{Tco=Double.parseDouble(entity.getElementItemAt("pwmeoc","Tco"));}catch(Exception ee) {}
	    pwmeoc.putSettings(settings);	 
        
	}catch(Exception e) {
		System.out.println("PWMeocHandler:reset:"+e.toString());
	}
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		 try {
				entity=entigrator.getEntity(operatorKey$);
				//System.out.println("PWMeocHandler:step:entity="+entity.getProperty("label"));
				String takt$=entity.getElementItemAt(OPERATOR, "takt");
				double takt=0;
				try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
				time=0;
				String time$=entity.getElementItemAt(OPERATOR, "time");
				try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
				double w=0;
				String w$=entity.getElementItemAt("pwmeoc", "W");
				try {w=Double.parseDouble(w$);}catch(Exception ee) {}
				double mc=0;
				String mc$=entity.getElementItemAt("pwmeoc", "M");
				try {mc=Double.parseDouble(mc$);}catch(Exception ee) {}
				
				double isa=0;
				String isa$=entity.getElementItemAt("pwmeoc", "isa");
				try {isa=Double.parseDouble(isa$);}catch(Exception ee) {}
				double isb=0;
				String isb$=entity.getElementItemAt("pwmeoc", "isb");
				try {isb=Double.parseDouble(isb$);}catch(Exception ee) {}
				double isc=0;
				String isc$=entity.getElementItemAt("pwmeoc", "isc");
				try {isc=Double.parseDouble(isc$);}catch(Exception ee) {}
				// System.out.println("PWMsupplyHandler:step:time="+time+" takt="+takt);
				Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
				ins.put("w", w);
				ins.put("mc", mc);
				ins.put("isa", isa);
				ins.put("isb", isb);
				ins.put("isc", isc);
				double clock=takt; 
				Hashtable<String,Double> outs=null;
                
                	ins.put("clock", takt);
                	ins.put("time", time);
                	pwmeoc.stride(ins);
                //}
                outs=pwmeoc.getOuts(); 
              //  EduHandler.printHashtableDouble("outs", outs);
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            try {
					value=outs.get(key$);
		            }catch(java.lang.NullPointerException ee) {
		            	System.out.println("PWMeocHandler:step:cannot get"+key$+"  err="+ee.toString());
		            	continue;
		            }
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				
		  }catch(Exception e) {
			  System.out.println("PWMeocHandler:step:"+e.toString());  
		  }
		
	}

	@Override
	public void reset(Entigrator entigrator, String locator$) {
		try {
		System.out.println("PWMeocHandler:reset:operator key=="+operatorKey$);
		entity=entigrator.getEntity(operatorKey$);
		locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
		String motor$=entity.getElementItemAt("pwmeoc","motor");
		String test$=entity.getElementItemAt("pwmeoc","test");
		if(motor$!=null) 
		locator$=Locator.append(locator$, PWMeoc.MOTOR, motor$);
		else
			System.out.println("PWMeocHandler:reset:motor is null in entity="+entity.getProperty("label"));
		if(test$!=null) 
			locator$=Locator.append(locator$, PWMeoc.OPTION,test$);
			else
				System.out.println("PWMeocHandler:reset:test is null in entity="+entity.getProperty("label"));
		
		if(pwmeoc==null)
			pwmeoc=new PWMeoc(entigrator,locator$);
		pwmeoc.reset( entigrator, locator$);
		}catch(Exception e) {
			System.out.println("PWMeocHandler:reset:"+e.toString());  
		}
		
	}

	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset();
	}

	@Override
	public String[] listOutputs(Entigrator entigrator) {
		if(pwmeoc==null)
			pwmeoc=new PWMeoc(entigrator,locator$);
		return pwmeoc.listOuts();
	}

	@Override
	public String[] listInputs(Entigrator entigrator) {
		if(pwmeoc==null)
			pwmeoc=new PWMeoc(entigrator,locator$);
		return pwmeoc.listIns();
	}

	

	@Override
	public String getName() {
		return "PWMeocHandler";
	}

	@Override
	public String getType() {
		return "pwmeochandler";
	}

	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMeocHandler";
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
