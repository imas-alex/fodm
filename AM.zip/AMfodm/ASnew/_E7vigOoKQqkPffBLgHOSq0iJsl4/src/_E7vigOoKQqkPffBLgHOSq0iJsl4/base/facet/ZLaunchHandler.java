package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.Zmodel;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class ZLaunchHandler extends  OperatorHandler implements SegueController {
	public static final String KEY="_BOiROXZ_S78qwj6DlVa9Oq4hJ0jE";
	Sack entity;
	double m=0;
	double isd=0;
	double preferredClock=Double.MIN_VALUE;	
	double f=50;
	double usd=220;
	double time=0;
	double mc=0;
	double ml=0;
	double lt=0;
	double ut=0;
    Zmodel zmodel;
  public ZLaunchHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		//System.out.println("ZLaunchHandler:constructor");   
		if(operatorKey$!=null) {
			 entity=entigrator.getEntityAtLabel(operatorKey$);
			reinit(entigrator, locator$);
			//reset();
		   }
	}


	@Override
	public void step(Entigrator entigrator, String locator$) {
		 try {
				entity=entigrator.getEntity(entity.getKey());
			    String takt$=entity.getElementItemAt(OPERATOR, "takt");
				double takt=0;
				try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
				time=0;
				String time$=entity.getElementItemAt(OPERATOR, "time");
				try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
				Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
				ins.put("time", time);
				ins.put("clock", takt);
				Hashtable<String,Double> outs=stride(ins);
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            try {
					value=outs.get(key$);
		            }catch(java.lang.NullPointerException ee) {
		            	System.out.println("ZLaunchHandler:step:cannot get"+key$+"  err="+ee.toString());
		            	continue;
		            }
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				
		  }catch(Exception e) {
			  System.out.println("ZLaunchHandler:step:"+e.toString());  
		  }
		
	}

	@Override
	public void reset(Entigrator entigrator, String locator$) {
		reset();
		
	}

	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		entity=entigrator.getEntity(operatorKey$);
		if(zmodel==null)
		   zmodel=new Zmodel(entigrator,locator$);
		zmodel.reset();
	}

	@Override
	public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
		try {
			
			
			try {time=ins.get("time");}catch(Exception ee) {}
			mc=0;
			if(time>lt&&time<ut)
				mc=ml;
			double clock=0;
			try {clock=ins.get("clock");}catch(Exception ee) {}
			if(clock<=0) {
			    clock=zmodel.getClock();
			    ins.put("clock",clock);
			}
			ins.put("usd", usd);
			ins.put("mc", mc);
			//System.out.println("ZLaunchHandler:stride:lt="+lt+" ut="+ut+" mc="+ins.get("mc")+" ml="+ml+"  time="+time+ " clock="+clock);
			//EduHandler.printHashtableDouble("ZLaunchHandler:stride:ins", ins);
			zmodel.stride(ins);
			Hashtable<String, Double>outs=zmodel.getOuts();
			
			//EduHandler.printHashtableDouble("ZLaunchHandler:stride:outs", outs);
			//time=time+clock;
			return outs;
		}catch(Exception e) {
			System.out.println("ZLaunchHandler:stride:"+e.toString());
			return null;
		}
	}

	@Override
	public void reset() {
		try {
			entity=entigrator.getEntity(operatorKey$);
			System.out.println("ZLaunchHandler:reset:entity="+entity.getProperty("label")+" operator="+operatorKey$);
			//if(zmodel==null)
			Properties zmodelLocator=new Properties();
			String motor$=entity.getElementItemAt("zlaunch", "motor");
			String option$=entity.getElementItemAt("zlaunch", "test");
			String f$=entity.getElementItemAt("zlaunch", "f");
			String v$=entity.getElementItemAt("zlaunch", "v");
			String lt$=entity.getElementItemAt("zlaunch", "lt");
			String ut$=entity.getElementItemAt("zlaunch", "ut");
			String ml$=entity.getElementItemAt("zlaunch", "mc");
			lt=0;
			try{lt=Double.parseDouble(lt$);}catch(Exception ee) {}
			ut=0;
			try{ut=Double.parseDouble(ut$);}catch(Exception ee) {}
			ml=0;
			try{ml=Double.parseDouble(ml$);}catch(Exception ee) {}
			zmodelLocator.put(Zmodel.MOTOR, motor$);
			zmodelLocator.put(Zmodel.OPTION, option$);
			zmodelLocator.put(Zmodel.VOLTAGE, v$);
			zmodelLocator.put(Zmodel.FREQUENCY, f$);
			
			String zmodelLocator$=Locator.toString(zmodelLocator);
			zmodel=new Zmodel(entigrator,zmodelLocator$);
			zmodel.reset();
			//reset();
			if(entity!=null) {
				if(!entity.existsElement(OPERATOR))
					entity.createElement(OPERATOR);
		   String[] sa=listOutputs();
		   for(String s:sa)
			   entity.putElementItem(OPERATOR, new Core(null,s,"0"));
			entity.putElementItem(OPERATOR, new Core(null,"time","0"));
			entity.putElementItem(OPERATOR, new Core(null,"isd","0"));
			entigrator.putEntity(entity);
			}
		}catch(Exception e) {
			System.out.println("ZLaunchHandler:reset:"+e.toString());
		}
		
	}

	@Override
	public Hashtable<String, Double> getSettings() {
		if(zmodel!=null)
			return zmodel.getSettings();
		else
			return null;
	}

	@Override
	public void putSettings(Hashtable<String, Double> settings) {
		if(zmodel!=null)
			 zmodel.putSettings(settings);
	}

	@Override
	public Hashtable<String, Double> getOuts() {
		if(zmodel!=null) 
			return zmodel.getOuts();
		else
			return null;
	}

	@Override
	public double getClock() {
		if(zmodel!=null)
			return zmodel.getClock();
		else
			return 0;
	}

	@Override
	public void setClock(double clock) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String[] listInputs() {
		return new String[] {"usd","f","time"};
	}

	@Override
	public String[] listOutputs() {
		return new String[] {"wr","m","isd"};
	}

	@Override
	public void setEntigrator(Entigrator entigrator) {
		this.entigrator=entigrator;
	}

	@Override
	public String[] listOutputs(Entigrator entigrator) {
		String[] outs=listOutputs();
		ArrayList <String>list=new ArrayList<String>();
		for(String s:outs)
			list.add(s);
		list.add("isd");
		outs=new String[list.size()];
		list.toArray(outs);
		return outs;
	}

	@Override
	public String[] listInputs(Entigrator entigrator) {
		return listInputs();
	}

	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"Zlaunch");
		locator.put(FACET_TYPE,"zlaunch");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ZLaunchHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.ZLaunchMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "zlaunch.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	

	@Override
	public String getName() {
		return "ZLaunch";
	}

	@Override
	public String getType() {
		return "zlaunch";
	}

	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ZLaunchHandler";
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
