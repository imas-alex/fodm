package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.VFsupply;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class VFsupplyHandler extends  OperatorHandler{
	public static final String KEY="_DXWii8Ib1_7WDYb8Dv9ltNFDOmw";
	Sack entity;
	VFsupply vfsupply;
	double preferredClock=Double.MIN_VALUE;
	double clock=Double.MIN_VALUE;
	double f=Double.MIN_VALUE;
	double Uc=Double.MIN_VALUE;
	public VFsupplyHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		System.out.println("VFsupplyHandler:operator key="+operatorKey$);   
		if(operatorKey$!=null) {
			 entity=entigrator.getEntityAtLabel(operatorKey$);
			 vfsupply=new VFsupply();
			reinit(entigrator, locator$);
			reset();
		   }
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"VFsupply");
		locator.put(FACET_TYPE,"vfsupply");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VFsupplyHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.VFsupplyMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "vfsupply.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}	
	public void reset() {
	try {
		 
		if(operatorKey$!=null) 
			 entity=entigrator.getEntity(operatorKey$);
		//entity.printElement("vfsupply");
		Hashtable<String, Double> settings=new Hashtable<String, Double>();
		double Ua=0;
	    try{Ua=Double.parseDouble(entity.getElementItemAt("vfsupply","Ua"));}catch(Exception ee) {}
	    settings.put("Ua", Ua);
	    double f0=0;
	    try{f0=Double.parseDouble(entity.getElementItemAt("vfsupply","f0"));}catch(Exception ee) {}
	    settings.put("f0", f0);
	    try{Uc=Double.parseDouble(entity.getElementItemAt("vfsupply","Uc"));}catch(Exception ee) {}
	    try{f=Double.parseDouble(entity.getElementItemAt("vfsupply","f"));}catch(Exception ee) {}
	    //System.out.println("VFsupplyHandler:reset:operator key="+operatorKey$+" f="+f+" Uc="+Uc);  
	    settings.put("Ucm", 10.0);
        
	    
	    vfsupply.putSettings(settings);	 
        preferredClock=0.001/f0;
        
	}catch(Exception e) {
		System.out.println("VFsupplyHandler:reset:"+e.toString());
	}
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		 try {
				entity=entigrator.getEntity(operatorKey$);
			    String takt$=entity.getElementItemAt(OPERATOR, "takt");
				double takt=0;
				try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
				time=0;
				String time$=entity.getElementItemAt(OPERATOR, "time");
				try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
				
			//	 System.out.println("VFsupplyHandler:step:time="+time+" takt="+takt+" f="+f+" Uc="+Uc);
				Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
				ins.put("f", f);
				ins.put("Uc", Uc);
				double clock=takt; 
				Hashtable<String,Double> outs=null;
                if(takt>preferredClock) {
                	int cnt=(int)(takt/preferredClock);
                	if(cnt>0)
                		clock=takt/cnt;
                	for(int i=0;i<cnt;i++) {
                		ins.put("clock", clock);
                		ins.put("time", time);
                		ins.put("f", f);
        				ins.put("Uc", Uc);
                		vfsupply.stride(ins);
                		time=time+clock;
                	}
                double dt=takt-cnt*preferredClock;
                if(dt>0) {
                	ins.put("clock", dt);
                	time=time+dt;
                	ins.put("time", time);
                	vfsupply.stride(ins);
                }
                }else {
                	ins.put("clock", takt);
                	ins.put("time", time);
                	vfsupply.stride(ins);
                }
                outs=vfsupply.getOuts(); 
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            try {
					value=outs.get(key$);
		            }catch(java.lang.NullPointerException ee) {
		            	System.out.println("VFsupplyHandler:step:cannot get"+key$+"  err="+ee.toString());
		            	continue;
		            }
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				
		  }catch(Exception e) {
			  System.out.println("VFsupplyHandler:step:"+e.toString());  
		  }
		
	}

	@Override
	public void reset(Entigrator entigrator, String locator$) {
		reset();
	}

	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset();
	}

	@Override
	public String[] listOutputs(Entigrator entigrator) {
		if(vfsupply==null)
			vfsupply=new VFsupply();
		return vfsupply.listOuts();
	}

	@Override
	public String[] listInputs(Entigrator entigrator) {
		if(vfsupply==null)
			vfsupply=new VFsupply();
		return vfsupply.listIns();
	}

	

	@Override
	public String getName() {
		
		return "VFsupply";
	}

	@Override
	public String getType() {
		return "vfsupply";
	}

	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VFsupplyHandler";
	}

	@Override
	public String getKey() {
		
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
