package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.PWMeoc;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.PWMfec;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class PWMfecHandler extends  OperatorHandler{
	public static final String KEY="_Dv4E6hI0HT64vKHialC_GkMo7lk";
	Sack entity;
	PWMfec pwmfec;
	double preferredClock=Double.MIN_VALUE;
	double clock=Double.MIN_VALUE;
	double Kid=Double.MIN_VALUE;
	double Ud=Double.MIN_VALUE;
	double Tiq=Double.MIN_VALUE;
	double Kiq=Double.MIN_VALUE;
	double Krs=Double.MIN_VALUE;
	public PWMfecHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		System.out.println("PWMfecHandler:operator key="+operatorKey$+"  alocator="+alocator$);   
		if(operatorKey$!=null) {
			 entity=entigrator.getEntityAtLabel(operatorKey$);
			 pwmfec=new PWMfec(entigrator,locator$);
			 reinit(entigrator, locator$);
			 reset();
		   }
	}
	public void reset() {
		try {
			//System.out.println("PWMfecHandler:reset:BEGIN");
			if(operatorKey$!=null) { 
				 entity=entigrator.getEntity(operatorKey$);
				 System.out.println("PWMfecHandler:reset:entity="+entity.getProperty("label"));
				 locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
			}else {
				System.out.println("PWMfecHandler:reset:operator key is null. Return");
			return;
			}
			String motor$=entity.getElementItemAt("pwmfec", "motor");
			if(motor$!=null)
			  locator$=Locator.append(locator$, PWMeoc.MOTOR, motor$);
			else
				System.out.println("PWMfecHandler:reset:motor is null in entity="+entity.getProperty("label"));
			String option$=entity.getElementItemAt("pwmfec", "test");
			if(option$!=null)
			locator$=Locator.append(locator$, PWMeoc.OPTION, option$);
			else
				System.out.println("PWMeocHandler:reset:option is null in entity="+entity.getProperty("label"));
			
			pwmfec.reset(entigrator,locator$);
			Hashtable<String, Double> settings=new Hashtable<String, Double>();
			double Ud=0;
		    try{Ud=Double.parseDouble(entity.getElementItemAt("pwmfec","Ud"));}catch(Exception ee) {}
		    settings.put("Ud", Ud);
		    double Kid=0;
		    try{Kid=Double.parseDouble(entity.getElementItemAt("pwmfec","Kid"));}catch(Exception ee) {}
		    settings.put("Kid", Kid);
		    Tiq=Double.MIN_VALUE;
		    try{Tiq=Double.parseDouble(entity.getElementItemAt("pwmfec","Tiq"));}catch(Exception ee) {}
		    settings.put("Tiq", Tiq);
		    Kiq=Double.MIN_VALUE;
		    try{Kiq=Double.parseDouble(entity.getElementItemAt("pwmfec","Kiq"));}catch(Exception ee) {}
		    settings.put("Kiq", Kiq);
		    Krs=Double.MIN_VALUE;
		    try{Krs=Double.parseDouble(entity.getElementItemAt("pwmfec","Krs"));}catch(Exception ee) {}
		    settings.put("Krs", Krs);
		    pwmfec.putSettings(settings);	 
	        
		}catch(Exception e) {
			System.out.println("PWMeocHandler:reset:"+e.toString());
		}
		}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		 try {
				entity=entigrator.getEntity(operatorKey$);
				//System.out.println("PWMeocHandler:step:entity="+entity.getProperty("label"));
				String takt$=entity.getElementItemAt(OPERATOR, "takt");
				double takt=0;
				try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
				time=0;
				String time$=entity.getElementItemAt(OPERATOR, "time");
				try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
				double w=0;
				String w$=entity.getElementItemAt("pwmfec", "W");
				try {w=Double.parseDouble(w$);}catch(Exception ee) {}
				double mc=0;
				String mc$=entity.getElementItemAt("pwmfec", "M");
				try {mc=Double.parseDouble(mc$);}catch(Exception ee) {}
				
				Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
				ins.put("w", w);
				ins.put("mc", mc);
				double clock=takt; 
				Hashtable<String,Double> outs=null;
             
             	ins.put("clock", takt);
             	ins.put("time", time);
             	pwmfec.stride(ins);
             //}
             outs=pwmfec.getOuts(); 
           //  EduHandler.printHashtableDouble("outs", outs);
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            try {
					value=outs.get(key$);
		            }catch(java.lang.NullPointerException ee) {
		            	System.out.println("PWMfecHandler:step:cannot get"+key$+"  err="+ee.toString());
		            	continue;
		            }
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				
		  }catch(Exception e) {
			  System.out.println("PWMfecHandler:step:"+e.toString());  
		  }
		
		
	}

	@Override
	public void reset(Entigrator entigrator, String locator$) {
		try {
			System.out.println("PWMfecHandler:reset:operator key=="+operatorKey$);
			entity=entigrator.getEntity(operatorKey$);
			locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
			String motor$=entity.getElementItemAt("pwmfec","motor");
			String test$=entity.getElementItemAt("pwmfec","test");
			if(motor$!=null) 
			locator$=Locator.append(locator$, PWMfec.MOTOR, motor$);
			else {
				System.out.println("PWMfecHandler:reset:motor is null in entity="+entity.getProperty("label"));
				entity.printElement("pwmfec");
			}
			if(test$!=null) 
				locator$=Locator.append(locator$, PWMeoc.OPTION,test$);
				else
					System.out.println("PWMfecHandler:reset:test is null in entity="+entity.getProperty("label"));
			
			if(pwmfec==null)
				pwmfec=new PWMfec(entigrator,locator$);
			pwmfec.reset( entigrator, locator$);
			}catch(Exception e) {
				System.out.println("PWMfecHandler:reset:"+e.toString());  
			}
		
	}

	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset();
		
	}

	@Override
	public String[] listOutputs(Entigrator entigrator) {
		if(pwmfec==null)
			pwmfec=new PWMfec(entigrator,locator$);
		return pwmfec.listOuts();
	}

	@Override
	public String[] listInputs(Entigrator entigrator) {
		if(pwmfec==null)
			pwmfec=new PWMfec(entigrator,locator$);
		return pwmfec.listIns();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"PWMfecHandler");
		locator.put(FACET_TYPE,"pwmfecHandler");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMfecHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMfecMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "pwmfec.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}

	@Override
	public String getName() {
		return "PWMfecHandler";
	}

	@Override
	public String getType() {
		return "pwmfechandler";
	}

	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMfecHandler";
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}
}
