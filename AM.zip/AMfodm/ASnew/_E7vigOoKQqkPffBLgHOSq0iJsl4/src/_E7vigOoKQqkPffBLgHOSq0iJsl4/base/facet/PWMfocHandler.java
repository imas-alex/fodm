package _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.PWMVFcontrol;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.gui.generic.PWMfoc;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class PWMfocHandler extends  OperatorHandler{
	public static final String KEY="_bJq2G_SAgAxYtRphLCHpqj_VAN4E";
	Sack entity;
	PWMfoc pwmfoc;
	double preferredClock=Double.MIN_VALUE;
	double clock=Double.MIN_VALUE;
	double f=Double.MIN_VALUE;
	double Uc=Double.MIN_VALUE;
	public PWMfocHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		System.out.println("PWMfocHandler:operator key="+operatorKey$+"  alocator="+alocator$);   
		if(operatorKey$!=null) {
			 entity=entigrator.getEntityAtLabel(operatorKey$);
			 pwmfoc=new PWMfoc(entigrator,locator$);
			reinit(entigrator, locator$);
			reset();
		   }
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"PWMfocHandler");
		locator.put(FACET_TYPE,"pwmvfocHandler");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMfocHandler");
		locator.put(FACET_MASTER_CLASS,"_E7vigOoKQqkPffBLgHOSq0iJsl4.gui.facet.PWMfocMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		locator.put( IconLoader.ICON_FILE, "pwmfoc.png");
		locator.put( IconLoader.ICON_CONTAINER,"_E7vigOoKQqkPffBLgHOSq0iJsl4");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	
	public void reset() {
	try {
		//System.out.println("PWMVFcontrolHandler:reset:BEGIN");
		if(operatorKey$!=null) { 
			 entity=entigrator.getEntity(operatorKey$);
			 System.out.println("PWMfocHandler:reset:entity="+entity.getProperty("label"));
		}else {
			System.out.println("PWMfocHandler:reset:operator key is null. Return");
		return;
		}
		String motor$=entity.getElementItemAt("pwmfoc", "motor");
		if(motor$!=null)
		  locator$=Locator.append(locator$, PWMfoc.MOTOR, motor$);
		else
			System.out.println("PWMfocHandler:reset:motor is null in entity="+entity.getProperty("label"));
		String option$=entity.getElementItemAt("pwmfoc", "test");
		if(option$!=null)
		locator$=Locator.append(locator$, PWMfoc.OPTION, option$);
		else
			System.out.println("PWMfocHandler:reset:option is null in entity="+entity.getProperty("label"));
		/*
		String tc$=entity.getElementItemAt("pwmfoc", "Tc");
		if(tc$!=null)
		  locator$=Locator.append(locator$, PWMfoc.TC, tc$);
		else
			System.out.println("PWMfocHandler:reset:motor is null in entity="+entity.getProperty("label"));
		
		String kc$=entity.getElementItemAt("pwmvfcontrol", "Kc");
		if(tc$!=null)
		  locator$=Locator.append(locator$, PWMVFcontrol.KC, kc$);
		else
			System.out.println("PWMVFcontrolHandler:reset:motor is null in entity="+entity.getProperty("label"));
			*/
		pwmfoc.reset(entigrator,locator$);
		
		//entity.printElement("vfsupply");
		Hashtable<String, Double> settings=new Hashtable<String, Double>();
		double Ua=0;
	    try{Ua=Double.parseDouble(entity.getElementItemAt("pwmfoc","Ua"));}catch(Exception ee) {}
	    settings.put("Ua", Ua);
	    double f0=0;
	    try{f0=Double.parseDouble(entity.getElementItemAt("pwmfoc","f0"));}catch(Exception ee) {}
	    settings.put("f0", f0);
	    try{Uc=Double.parseDouble(entity.getElementItemAt("pwmfoc","Uc"));}catch(Exception ee) {}
	    try{f=Double.parseDouble(entity.getElementItemAt("pwmfoc","f"));}catch(Exception ee) {}
	   /*
	    double Tc=0;
	    try{Tc=Double.parseDouble(entity.getElementItemAt("pwmfoc","Tc"));}catch(Exception ee) {}
	    settings.put(PWMVFcontrol.TC, Tc);
	    double Kc=0;
	    try{Kc=Double.parseDouble(entity.getElementItemAt("pwmvfcontrol","Kc"));}catch(Exception ee) {}
	    settings.put(PWMVFcontrol.KC, Kc);
	    */
	    //System.out.println("VFsupplyHandler:reset:operator key="+operatorKey$+" f="+f+" Uc="+Uc);  
	    settings.put("Ucm", 10.0);
	    
	    pwmfoc.putSettings(settings);	 
        preferredClock=0.001/f0;
	}catch(Exception e) {
		System.out.println("PWMfocHandler:reset:"+e.toString());
	}
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		 try {
				entity=entigrator.getEntity(operatorKey$);
				//System.out.println("PWMVFcontrolHandler:step:entity="+entity.getProperty("label"));
				String takt$=entity.getElementItemAt(OPERATOR, "takt");
				double takt=0;
				try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
				time=0;
				String time$=entity.getElementItemAt(OPERATOR, "time");
				try {time=Double.parseDouble(time$);}catch(Exception ee) {} 
				double w=0;
				String w$=entity.getElementItemAt("pwmfoc", "W");
				try {w=Double.parseDouble(w$);}catch(Exception ee) {}
				double mc=0;
				String mc$=entity.getElementItemAt("pwmfoc", "M");
				try {mc=Double.parseDouble(mc$);}catch(Exception ee) {}
				
				double isa=0;
				String isa$=entity.getElementItemAt("pwmfoc", "isa");
				try {isa=Double.parseDouble(isa$);}catch(Exception ee) {}
				double isb=0;
				String isb$=entity.getElementItemAt("pwmfoc", "isb");
				try {isb=Double.parseDouble(isb$);}catch(Exception ee) {}
				double isc=0;
				String isc$=entity.getElementItemAt("pwmfoc", "isc");
				try {isc=Double.parseDouble(isc$);}catch(Exception ee) {}
				// System.out.println("PWMsupplyHandler:step:time="+time+" takt="+takt+" f="+f+" Uc="+Uc);
				Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
				ins.put("w", w);
				ins.put("mc", mc);
				ins.put("isa", isa);
				ins.put("isb", isb);
				ins.put("isc", isc);
				double clock=takt; 
				Hashtable<String,Double> outs=null;
                if(takt>preferredClock) {
                	int cnt=(int)(takt/preferredClock);
                	if(cnt>0)
                		clock=takt/cnt;
                	for(int i=0;i<cnt;i++) {
                		ins.put("clock", clock);
                		ins.put("time", time);
                		ins.put("w", w);
        				ins.put("mc", mc);
                		time=time+clock;
                	}
                double dt=takt-cnt*preferredClock;
                if(dt>0) {
                	ins.put("clock", dt);
                	time=time+dt;
                	ins.put("time", time);
                	pwmfoc.stride(ins);
                }
                }else {
                	ins.put("clock", takt);
                	ins.put("time", time);
                	pwmfoc.stride(ins);
                }
                outs=pwmfoc.getOuts(); 
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            try {
					value=outs.get(key$);
		            }catch(java.lang.NullPointerException ee) {
		            	System.out.println("PWMfocHandler:step:cannot get"+key$+"  err="+ee.toString());
		            	continue;
		            }
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				
		  }catch(Exception e) {
			  System.out.println("PWMfocHandler:step:"+e.toString());  
		  }
		
	}

	@Override
	public void reset(Entigrator entigrator, String locator$) {
		try {
		System.out.println("PWMfocHandler:reset:operator key=="+operatorKey$);
		entity=entigrator.getEntity(operatorKey$);
		String motor$=entity.getElementItemAt("pwmfoc","motor");
		String test$=entity.getElementItemAt("pwmfoc","test");
		if(motor$!=null) 
		locator$=Locator.append(locator$, PWMfoc.MOTOR, motor$);
		else
			System.out.println("PWMfocHandler:reset:motor is null in entity="+entity.getProperty("label"));
		if(test$!=null) 
			locator$=Locator.append(locator$, PWMfoc.OPTION,test$);
			else
				System.out.println("PWMfocHandler:reset:test is null in entity="+entity.getProperty("label"));
		
		if(pwmfoc==null)
			pwmfoc=new PWMfoc(entigrator,locator$);
		pwmfoc.reset( entigrator, locator$);
		}catch(Exception e) {
			System.out.println("PWMfocHandler:reset:"+e.toString());  
		}
		
	}

	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset();
	}

	@Override
	public String[] listOutputs(Entigrator entigrator) {
		if(pwmfoc==null)
			pwmfoc=new PWMfoc(entigrator,locator$);
		return pwmfoc.listOuts();
	}

	@Override
	public String[] listInputs(Entigrator entigrator) {
		if(pwmfoc==null)
			pwmfoc=new PWMfoc(entigrator,locator$);
		return pwmfoc.listIns();
	}

	

	@Override
	public String getName() {
		return "PWMfocHandler";
	}

	@Override
	public String getType() {
		return "pwmfochandler";
	}

	@Override
	public String getFacetClass() {
		return "_E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.PWMfocHandler";
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}

}
