import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.logging.Logger;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.net.URLClassLoader;

import javax.swing.JPanel;

//import com.sun.javafx.geom.Ellipse2D;
//import com.sun.javafx.geom.Point2D;
//import com.sun.javafx.geom.Rectangle;

//import com.sun.prism.BasicStroke;
import java.awt.BasicStroke;

import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;

import gdt.data.entity.EntityHandler;
import gdt.data.grain.Core;
import gdt.data.grain.Locator;
import gdt.data.store.Entigrator;
import gdt.data.grain.Sack;


public class _r294_iXw7VkGBmXFGz62ASq4MmA {
private final static String ENTIHOME="/home/imasa/AC";
private final static String ENTITY_KEY="_r294_iXw7VkGBmXFGz62ASq4MmA";
private static final String EXTENSION_KEY="_woEkcFAdsVZ98Koi1N16gO4y6u8";
Point2D center;
public BasicStroke lineStroke;
Graphics2D  g2;
Sack entity;

public void show(Entigrator entigrator ,Sack entity, JPanel panel){
try{
this.entity=entity;
String label$=entigrator.indx_getLabel(ENTITY_KEY);
// Put  code here
//System.out.println(ENTITY_KEY+": diagramm="+entity.getProperty("label"));
int w=panel.getWidth();
int h=panel.getHeight();
lineStroke=new BasicStroke(3,BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND, 100);

center=new Point2D.Double(w/2,h/2);
g2=(Graphics2D)panel.getGraphics();
g2.clearRect(0, 0, w,h);
g2.setColor(Color.DARK_GRAY);
g2.drawLine(0, (int)center.getY(),w ,(int)center.getY());
g2.drawLine((int)center.getX(),0, (int)center.getX(),h);
ArrayList<String>sl=new ArrayList<String>();
Core[] ca=entity.elementGet("ray.visible");
String ray$;
Point2D imStart=center;
Ray ray;
if(ca!=null)
	for(Core c:ca)
		if("true".equals(c.value)){
			ray$=entity.getElementItemAt("ray.name", c.name);
			if(ray$!=null){
				ray=new Ray(ray$,center);
				//if("i2".equals(ray$))
				//	imStart=ray.end;
				//if("im".equals(ray$))
				//	continue;
			    ray.draw();
			    new Entry(ray$).draw2( (int)ray.end.getX(),(int)ray.end.getY());
			}
			    
		}
	new Ray("im",imStart).draw();
}catch(Exception e){
Logger.getLogger(getClass().getName()).severe(e.toString());;
}
legend();
}
public void legend(){
	Core[] ca=entity.elementGet("ray.visible");
	String ray$;
	ArrayList<Entry>el=new ArrayList<Entry>();
	int x=5;
	int y=20;
	int space=20;
	if(ca!=null)
		for(Core c:ca)
			if("true".equals(c.value)){
				ray$=entity.getElementItemAt("ray.name", c.name);
				if(ray$!=null){
					new Entry(ray$).draw( x, y);
					y=y+space;
				}
			}
}
private   Color getColor(String color$){
	
	Color color=Color.white;;
	if("black".equals(color$))
		color=Color.black;
	if("blue".equals(color$))
		color=Color.blue;
	if("red".equals(color$))
		color=Color.red;
	if("orange".equals(color$))
		color=Color.orange;
	if("magenta".equals(color$))
		color=Color.magenta;
	if("cyan".equals(color$))
		color=Color.cyan;
	return color;
}
class Ray{
	String name$;
	public Point2D start;
	public Point2D end;
	double factor;
	double lineWidth=lineStroke.getLineWidth();
	Color color;
	boolean visible=false;
	public Ray(String name$, Point2D start){
		try{
			this.name$=name$;
			String key$=entity.getElementItemAtValue("ray.name",name$);
			Core xy=entity.getElementItem("ray.XY", key$);
			
			double xv=Double.parseDouble(entity.getElementItemAt("operator", xy.type));
			double yv=Double.parseDouble(entity.getElementItemAt("operator", xy.value));
			if( Math.abs(xv)<0.01)
				xv=0.01;
			if(Math.abs(yv)<0.01)
				yv=0.01;
			//factor			=Double.parseDouble(entity.getElementItemAt("ray.factor",key$));			
			
			try{
				factor=Double.parseDouble(entity.getElementItemAt("ray.factor",key$));
			   }catch(NumberFormatException nfe ){
				   factor=0;
			   }
			this.start=start;
	       
			double xvf=xv*factor;
			double yvf=yv*factor;
			double xe=start.getX()+xvf;
			double ye=start.getY()-yvf;
			//x=400;
			//y=300;
			
			//System.out.println(ENTITY_KEY+": name="+name$+"   vector    xv="+xv+"   yv="+yv+"   ray end : xe="+xe+" y="+ye+ " center x="+start.getX()+ "  y="+start.getY());
			
			end=new Point2D.Double((int)xe,(int)ye);
			String color$=entity.getElementItemAt("ray.color",key$);
			color=getColor(color$);
			String visible$=entity.getElementItemAt("ray.visible",key$);
			if("true".equals(visible$))
				visible=true;
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
	}
	public void draw(){
		if(visible){
		g2.setColor(color);
		drawArrow (g2, start,end,  lineStroke,lineStroke, 20);
		}
	}
	void drawAt(Ray r2 ){
		
	}	
		
	void drawArrow (final Graphics2D gfx, final Point2D start, final Point2D end, final Stroke lineStroke, final Stroke arrowStroke, final float arrowSize) {

	  //  gfx.setStroke(lineStroke);
	    
	//	 gfx.drawLine( (int)start.getX(),   (int) start.getY(),  (int) end.getX(),  (int) end.getY() );
		 double xg = end.getX()-start.getX();
	     double yg =-(end.getY()-start.getY());
	   //  System.out.println("vector   xg="+xg+",    yg="+yg);
	     double angle=Math.PI / 2;
	     double a=2* lineWidth;
	     double b= lineWidth;
	     if (xg!=0.0d){
         double tan=Math.abs(yg/xg);
            angle=  Math.atan(tan);
	     }
	     int quadrant=0;
	     if(xg>=0&&yg>=0)
	    	 quadrant=1;
	     if(xg<=0&&yg>=0)
	    	 quadrant=2;
	     if(xg<=0&&yg<=0)
	    	 quadrant=3;
	     if(xg>=0&&yg<=0)
	    	 quadrant=4;
	     if(xg==0&&yg==0)
	    	 quadrant=0;
	     
	    double  dx=a* Math.cos(angle);
	    double  dy=a* Math.sin(angle);
	    double xe=end.getX();
	    double ye=end.getY();
	    
	 //   System.out.println("angle="+angle+ "      quadrant="+ quadrant+"  dx="+dx+ "  dy="+dy+ "  xe="+xe+"  ye="+ye);
	///--------------------------------------------------------------------------------------
	    double x1=0;
	    //=end.getX()-dx;
	    double y1=0;;
	    //=end.getY()-dy;
	    double x11=0;
	    //=end.getX()-dx/2;
	    double y11=0;
	    //=end.getY()-dy/2;
	   
	    double x2=0;
	    //=x1+dy;
	    double y2=0;;
	    //=y1-dx;
	    double x4=0;;
	    //=x1-dy;
	    double y4=0;
	  ///--------------------------------   1   ----------------------------------------------	 
	    
	    if( quadrant==1){
	    	x1=xe-dx;
	    	y1=ye+dy;
	    	 x11=xe-dx/2;
	    	 y11=ye+dy/2;
	    	 x2=x1-dy;
	    	 y2=y1-dx; 
	    	 x4=x1+dy;
	    	 y4=y1+dx;
	    	 
	    }
 ///--------------------------------   4   ----------------------------------------------	 
	    
	    if( quadrant==4){
	    	x1=xe-dx;
	    	y1=ye-dy;
	    	 x11=xe-dx/2;
	    	 y11=ye-dy/2;
	    	 x2=x1+dy;
	    	 y2=y1-dx; 
	    	 x4=x1-dy;
	    	 y4=y1+dx;
	    	 
	    }
 ///--------------------------------   2   ----------------------------------------------	 
	    
	    if( quadrant==2){
	    	x1=xe+dx;
	    	y1=ye+dy;
	    	 x11=xe+dx/2;
	    	 y11=ye+dy/2;
	    	 x2=x1+dy;
	    	 y2=y1-dx; 
	    	 x4=x1-dy;
	    	 y4=y1+dx;
	    	 
	    }
///--------------------------------   3   ----------------------------------------------	 
	    
	    if( quadrant==3){
	    	x1=xe+dx;
	    	y1=ye-dy;
	    	 x11=xe+dx/2;
	    	 y11=ye-dy/2;
	    	 x2=x1-dy;
	    	 y2=y1-dx; 
	    	 x4=x1+dy;
	    	 y4=y1+dx;
	    	 
	    }
	   GeneralPath polygon = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
	   polygon.moveTo(end.getX(),end.getY());
	   polygon.lineTo(x2,y2);
	   polygon.lineTo(x4, y4);
	   polygon.lineTo(end.getX(),end.getY());
	    polygon.closePath();
	 //   System.out.println("1  x="+x1+",    y="+y1);
	  //  System.out.println("dx="+dx+",    dy="+dy);
	   // System.out.println(end.getX()+",    "+end.getY()+"\n "+x2+",    "+y2+"\n "+x4+",   "+y4+"\n "+end.getX()+",    "+end.getY());
	    gfx.fill	    (polygon);
	    gfx.setStroke(lineStroke);
	     gfx.drawLine	  ((int)start.getX(),(int)start.getY(),(int)(x11),(int)(y11));
	}
	}


	
	
	class Entry{
		public String entry$;
		public Color color;
		double norm=-1;
		String unit$;
		BigDecimal bd;
		public Entry(String entry$){
			this.entry$=entry$;
			String key$=entity.getElementItemAtValue("ray.name",entry$);
			color=getColor(entity.getElementItemAt ("ray.color", key$));
			unit$=entity.getElementItemAt("ray.unit",key$);
			Core xy=entity.getElementItem("ray.XY", key$);
			if(xy!=null){
				try{
				double x=Double.parseDouble(entity.getElementItemAt("operator", xy.type));
				double y=Double.parseDouble(entity.getElementItemAt("operator", xy.value));
				norm=Math.sqrt(x*x+y*y);
				 bd = new BigDecimal(norm);
			    bd = bd.setScale(2, RoundingMode.HALF_UP);
				
				}catch(Exception e){
				}
			}
		
		}
		public void draw(int x ,int y){
			Font font = new Font("Serif", Font.BOLD, 12);
		  g2.setFont(font);
		 g2.setColor(color);
		  g2.drawString(entry$+"="+String.valueOf(bd)+" "+unit$,x,y);
			 
		}
		public void draw2(int x ,int y){
			Font font = new Font("Serif", Font.BOLD, 12);
		  g2.setFont(font);
		 g2.setColor(color);
		  g2.drawString(entry$,x,y);
			 
		}
	}
	
	public void step(Entigrator entigrator){
		try{
		
		//System.out.println(ENTITY_KEY+":step:dia");
		}catch(Exception e){
		Logger.getLogger(getClass().getName());
		}
		}
	private Sack invoke(Entigrator entigrator,Sack dia,String method$) {
		try {
			String extension$= entigrator.getEntihome()+"/"+EXTENSION_KEY+"/dynsys.jar";
			File extension=new File(extension$);
			URL url = extension.toURI().toURL();
			URL[] urls = new URL[]{url};
			ClassLoader parentLoader = Entigrator.class.getClassLoader();
			URLClassLoader cl = new URLClassLoader(urls,parentLoader);
			Class<?>cls = cl.loadClass("gdt.jgui.entity.diagramm.DiaLaunchAdapter");
			Method method = cls.getMethod(method$, dia.getClass());
		    dia=(Sack)method.invoke(null, dia);
			cl.close();
			entigrator.ent_alter(dia);
		}catch(Exception e){
			Logger.getLogger(getClass().getName());
			}
		return dia;
			
	}
    public void reset(Entigrator entigrator) {
    	System.out.println(ENTITY_KEY+":reset:");
    	reinit( entigrator);
    }
    
	public void reinit(Entigrator entigrator){
		try{
		Sack dia=entigrator.getEntityAtKey(ENTITY_KEY);
		System.out.println(ENTITY_KEY+":reinit:");
		invoke(entigrator,dia,"reinit");
		}catch(Exception e){
		Logger.getLogger(getClass().getName());
		}
		}
}






