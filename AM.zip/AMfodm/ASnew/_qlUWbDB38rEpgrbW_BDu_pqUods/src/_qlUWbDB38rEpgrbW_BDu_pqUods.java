import gdt.base.store.Entigrator;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VectorHandler;
import java.util.Hashtable;
import java.util.Properties;
import gdt.base.generic.Locator;
public class _qlUWbDB38rEpgrbW_BDu_pqUods implements SegueController{
private final static String ENTITY_KEY="_qlUWbDB38rEpgrbW_BDu_pqUods";
private _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VectorHandler vectorHandler;
public _qlUWbDB38rEpgrbW_BDu_pqUods(){}
public Hashtable<String,Double>  stride(Hashtable<String,Double>  ins){ 
return vectorHandler. stride(ins);
} 
public void reset(){ 
vectorHandler.reset();
} 
public Hashtable<String,Double> getSettings(){ 
return vectorHandler.getSettings();
} 
public void putSettings(Hashtable<String,Double> settings){ 
vectorHandler.putSettings(settings); 
} 
public Hashtable<String,Double> getOuts(){ 
return vectorHandler.getOuts();
}
public double getClock(){
return vectorHandler.getClock();
}
public void setClock(double clock){ 
vectorHandler.setClock(clock); 
} 
public String[] listInputs(){ 
return vectorHandler.listInputs(); 
}
public String[] listOutputs(){ 
return vectorHandler.listOutputs(); 
}
public void setEntigrator(Entigrator entigrator){ 
 String entity$=entigrator.getLabel(ENTITY_KEY);
 Properties props=new Properties();
 props.put(Entigrator.ENTITY_LABEL, entity$);
 String locator$=Locator.toString(props);
vectorHandler=new VectorHandler(entigrator,locator$);
vectorHandler.setEntigrator(entigrator);
} 
}
