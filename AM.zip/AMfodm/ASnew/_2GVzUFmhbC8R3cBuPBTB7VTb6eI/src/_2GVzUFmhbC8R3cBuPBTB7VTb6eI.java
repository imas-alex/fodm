import java.util.Hashtable;

import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.MotorHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _2GVzUFmhbC8R3cBuPBTB7VTb6eI  implements SegueController {
private final static String ENTITY_KEY="_2GVzUFmhbC8R3cBuPBTB7VTb6eI";
Entigrator entigrator;
double preferredClock=0.0001;
double m=0;
double mc=0;
double wr=0;
double wr0=0;
double n=0;
double i=0;
double j=0;
double clock=0.0001;
Sack motor;
@Override
public void reset() {
	try {
	Sack mechanic=entigrator.getEntity(ENTITY_KEY);
	String motor$=mechanic.getElementItemAt("mechanic", "motor");
	motor=entigrator.getEntityAtLabel(motor$);
	m=0;
	mc=0;
	wr=0;
	n=0;
	i=0;
	try{j=Double.parseDouble(motor.getElementItemAt("primary", "j")); }catch(Exception e) {}
	try{wr0=Double.parseDouble(motor.getElementItemAt("dpar", "wg0")); }catch(Exception e) {}
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+":reset:"+e.toString());
	}
	//System.out.println(ENTITY_KEY+":reset:B");
}
@Override
public Hashtable<String, Double> getSettings()  {
Hashtable<String,Double> set=new Hashtable<String,Double> ();
set.put("j", j);
return set;
}
@Override
public String[] listInputs(){
return new String[] {"mc"};
}
@Override
public String[] listOutputs(){
return new String[] {"wr","m","n","i"};
}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins){
boolean closed=false;
double open=1;
//EduHandler.printHashtableDouble(ENTITY_KEY+":ins", ins);
double s=(wr0-wr)/wr0;
motor.putElementItem("zin",new Core(null,"s",String.valueOf(s)));
motor=MotorHandler.z_makeState(motor, false);
try{m=Double.parseDouble(motor.getElementItemAt("zvar", "m")); }catch(Exception e) {}
try{i=Double.parseDouble(motor.getElementItemAt("zvar", "isd")); }catch(Exception e) {}
clock=ins.get("clock");
//System.out.println(ENTITY_KEY+":stride:m="+m);
wr=wr+clock*m/j;
Hashtable<String,Double> outs=new Hashtable<String,Double>();
outs.put("wr", wr);
outs.put("m", m);
outs.put("i", i);
return outs;
}
@Override
public Hashtable<String, Double> getOuts() {
Hashtable<String, Double>outs=new Hashtable<String, Double>();
outs.put("wr",wr);
outs.put("n",n);
outs.put("m",m);
outs.put("i",i);
return outs;
}
@Override
public double getClock() {
return preferredClock;
}
@Override
public void setClock(double clock) {
this.clock=clock;
}
@Override
public void setEntigrator(Entigrator entigrator) {
this.entigrator=entigrator;
}
@Override
public void putSettings(Hashtable<String, Double> settings) {
}
}
