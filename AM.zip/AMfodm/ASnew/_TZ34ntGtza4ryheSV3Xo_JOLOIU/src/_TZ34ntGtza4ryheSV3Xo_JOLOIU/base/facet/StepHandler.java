package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import gdt.base.store.Entigrator;
public interface StepHandler {
	public void step(Entigrator entigrator, String locator$);
	public void reset(Entigrator entigrator, String locator$);
	public void reinit(Entigrator entigrator, String locator$);
}
