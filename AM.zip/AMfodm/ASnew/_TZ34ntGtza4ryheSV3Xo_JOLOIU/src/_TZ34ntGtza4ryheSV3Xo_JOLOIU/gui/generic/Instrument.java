package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import gdt.base.store.Entigrator;
public interface Instrument {
public static final String RESET="reset";	
public static final String UPDATE="update";	
public static final String SHOW="show";	
public static final String INDEX="index";	
public static final String MODE="mode";	
public static final String START_VIEW="start view";	
public static final String VIEW_TIME="vtime";	
public static final String TAKT="takt";	
public static final String QTAKT="qtakt";	
public static final String TIME="time";	
public static final String STOP="stop";	
public void revise(Entigrator entigrator,String locator$);

public void associate(Entigrator entigrator,String locator$);
public void reset(Entigrator entigrator);
public void revise(Entigrator entigrator);
public void revise(Entigrator entigrator,int cnt);
public void saveRecord(Entigrator entigrator,String recordHome$);
}
