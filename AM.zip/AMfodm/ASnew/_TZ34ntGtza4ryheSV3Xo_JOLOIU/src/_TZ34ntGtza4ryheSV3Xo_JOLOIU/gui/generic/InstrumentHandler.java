package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
public interface InstrumentHandler {
	public final static String GAUGE="gauge";
	public final static String TUBE="tube";
	public final static String DIAGRAMM="diagramm";
	
   public   Instrument getInstrument();
   public   String getInstrumentType();
}
