package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Properties;
import javax.swing.JPopupMenu;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.edu.JEduEditor;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JItemPanel;

public  class EduMaster extends FacetMaster{ 
	public static final String KEY="_ooapTrUsv5StHjHg1UBF0RSZPCY";
	public static final String NAME="Edu";
	public EduMaster() {
		super();
	}
	public EduMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		//System.out.println("SisoMaster:getJEntityFacetsItem:locator="+handlerLocator$);
		String entity$=Locator.getProperty(handlerLocator$,Entigrator.ENTITY_LABEL);
		String parent$=Locator.getProperty(handlerLocator$, JContext.PARENT);
		String itemLocator$=JItemPanel.classLocator();
		if(entity$!=null)
		  itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
			  itemLocator$=Locator.append(itemLocator$,JContext.PARENT, parent$);
		itemLocator$=Locator.merge(itemLocator$, locator$);
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		if(container$!=null)
			itemLocator$=Locator.append(itemLocator$,JContextContainer.CONTAINER,container$);
		itemLocator$=Locator.append(itemLocator$,FacetMaster.MASTER_CLASS, Locator.LOCATOR_FALSE);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String locator$) {
	}
@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		//System.out.println("SisoMaster:getFacetHandler:locator="+locator$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= EduHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new EduHandler(console.getEntigrator(),handlerLocator$); 
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return NAME;
	}
	@Override
	public String getType() {
		return "edu";
	}
	
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			if(entityLabel$==null) {
				String entityKey$=Locator.getProperty(locator$, Entigrator.ENTITY_KEY);
				entityLabel$=console.getEntigrator().getLabel(entityKey$);
				if(entityLabel$==null) {
					System.out.println("EduMaster:entityFacetsItemOnClick:cannot finde label at key="+entityKey$);
					return;
				}
			}
			//	System.out.println("EduMaster:entityFacetsItemOnClick:alocator="+alocator$);
			String parent$=Locator.getProperty(alocator$, JContext.PARENT);
			String eduEditor$=JEduEditor.classLocator();
			eduEditor$=Locator.merge(eduEditor$,alocator$);
			eduEditor$=Locator.append(eduEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			if(parent$!=null)
			  eduEditor$=Locator.append(eduEditor$,JContext.PARENT, parent$);
	       	JEduEditor eduEditor=new JEduEditor(console,eduEditor$);	
			console.replaceContext(context,eduEditor);
		}catch(Exception e) {
			System.out.println("EduMaster:entityFacetsItemOnClick:"+e.toString());	
		}
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public String getLocator() {
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String parent$=Locator.getProperty(locator$,JContext.PARENT);
		String thisLocator$=classLocator();
		if(entity$!=null)
		   thisLocator$=Locator.append(thisLocator$,Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
			   thisLocator$=Locator.append(thisLocator$,JContext.PARENT, parent$);
		return thisLocator$;
	}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",getType(),classLocator()));
		entity.putAttribute(new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU","icon","edu.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty("operator", "true", entity.getKey());
		createSource( entigrator,entityLabel$);
		return entity;
	}
	private void createSource(Entigrator entigrator, String entityLabel$){
		try{
//			System.out.println("JProcedurePanel:createSource.procedure key="+procedureKey$);
			String entityKey$=entigrator.getKey(entityLabel$);
			File sourceHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src");
			if(!sourceHome.exists())
				sourceHome.mkdirs();
			File binHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin");
			if(!binHome.exists())
				binHome.mkdirs();
			File procedureJava=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src/"+entityKey$+".java");
			if(!procedureJava.exists())
				procedureJava.createNewFile();
			 FileOutputStream fos = new FileOutputStream(procedureJava, false);
			 Writer writer = new OutputStreamWriter(fos, "UTF-8");
				writer.write("import java.util.Hashtable;\n");
				writer.write("import gdt.base.store.Sack;\n");
				writer.write("import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;\n");
				writer.write("public class " +entityKey$+"  implements SegueController {\n");
				writer.write("private final static String ENTITY_KEY=\""+entityKey$+"\";\n");
				writer.write("@Override\n");
				writer.write("public void reset() {}\n");
				writer.write("@Override\n");
				writer.write("public Hashtable<String, Double> getSettings()  {return null;}\n");
				writer.write("@Override\n");
				writer.write("public Hashtable<String, Double> getSettings(Sack entity)   {return null;}\n");
				writer.write("@Override\n");
				writer.write("public void putSettings(Hashtable<String, Double> set)  {}\n");
				writer.write("@Override\n");
				writer.write("public String[] listInputs(){return null;}\n");
				writer.write("@Override\n");
				writer.write("public String[] listOutputs(){return null;}\n"); 
				writer.write("@Override\n");
				writer.write("public Hashtable<String, Double> transition(Hashtable<String, Double> ins){return null;}\n"); 
				writer.write("}\n");
			 writer.close();   
		}catch(Exception e){
			System.out.println("EduMaster:createSource:"+e.toString());
		}
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.EduMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler");
	    locator.put(FacetHandler.FACET_KEY,"_sQY6aqECy8rZbR3p_SL4z6LagLsQ");
	    locator.put(Locator.LOCATOR_TITLE,"Edu");
	    locator.put(FacetHandler.FACET_MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "edu.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_sQY6aqECy8rZbR3p_SL4z6LagLsQ");
	    locator.put(FacetHandler.FACET_TYPE,"edu");
	    locator.put(FacetMaster.MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.EduMaster");
	    return Locator.toString(locator);
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",EduHandler.KEY,EduHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("EduMaster:addToSession:"+e.toString());
	    }	
		}
}
