package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.ArrayList;
public abstract class PointDisplay {
protected String dataPath$;
     public void setDataPath(String dataPath$) {
    	 this.dataPath$=dataPath$;
     }
	public abstract String pointsString(ArrayList<NamedPoint> pl);
}
