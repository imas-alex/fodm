package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import javax.swing.JDialog;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

public class JDiagrammDialog extends JDialog{
	private static final long serialVersionUID = 1L;
	private JTextField status;
	JPanel screen;
	public JDiagrammDialog() {
		screen = new JPanel();
		getContentPane().add(screen, BorderLayout.CENTER);
		screen.setLayout(new BorderLayout(0, 0));
		status = new JTextField();
		status.setEditable(false);
		getContentPane().add(status, BorderLayout.SOUTH);
		status.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		status.setText("status");
		
	}
 public void addDiagrammPanel(DiagrammPanel diaPanel) {
	 screen.add(diaPanel,BorderLayout.CENTER);
	 diaPanel.setStatus(status);
	 diaPanel.parent=this;
	 this.setTitle(diaPanel.getTitle());
 }
 public void revise(int cnt) {
	 	System.out.println("TubePanel:revise:cnt="+cnt); 
	 	DiagrammPanel diaPanel=(DiagrammPanel)screen.getComponent(0);
	 	diaPanel.last=false;
	 	diaPanel.cnt=cnt;
	 	diaPanel.repaint();
	 	
	 	
	}
}
