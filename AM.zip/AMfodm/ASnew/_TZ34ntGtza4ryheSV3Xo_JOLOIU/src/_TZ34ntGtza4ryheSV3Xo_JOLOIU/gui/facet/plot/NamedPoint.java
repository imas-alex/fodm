package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot;
/*
 * Copyright 2016-2023 Alexander Imas
 */
public class NamedPoint {
	public String name$;
	public String format$;
	public String direction$;
	public double val;
public NamedPoint(String name$,String format$,String direction$,double val) {
		this.name$=name$;
		this.format$=format$;
		this.direction$=direction$;
		this.val=val;
	}
	public String toString() {
		String ret$="name="+name$+"  format="+format$+" direction="+direction$+" value="+String.valueOf(val);
		return ret$;
	}
	public String getName() {
		return name$;
	}
	public double getValue() {
		return val;
	}
}	

