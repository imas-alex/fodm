package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;
import javax.swing.JPanel;
import javax.swing.JTextField;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

public class DiagrammPanel extends JPanel {
	public static final String DIA_TITLE="dia title";
	BasicStroke lineStroke;
	Point2D center;
	String entity$;
	Graphics2D  g2;
	Sack entity;
	JTextField status;
	String status$;
	boolean last=true;
	int cnt=0;
	JDiagrammDialog parent;
	ArrayList<Vector>vectors=new ArrayList<Vector>();
	public DiagrammPanel(Entigrator entigrator,String locator$) {
		super();
		//System.out.println("DiagrammPanel:locator="+locator$);	
		if(locator$==null)
			return;
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		entity=entigrator.getEntityAtLabel(entity$);
		initVectors();
        //System.out.println("DiagrammPanel:parent="+parent.getClass().getName());	
		}
	/**
	 * @wbp.parser.constructor
	 */
	public DiagrammPanel(Entigrator entigrator,Sack tube) {
		super();
		entity=tube;
		initVectors();
		}
	public void setStatus(JTextField status) {
		this.status=status;
	}
	public void setTube(Sack tube) {
		entity=tube;
	}
	public void initVectors() {
		if(entity==null) {
		System.out.println("DiagrammPanel:initVectors:entity is null");
		return;
		}
		if(vectors==null)
			vectors=new  ArrayList<Vector>();
		else
			vectors.clear();
		Core[] ca=entity.elementGet("v.name");
		if(ca==null)
			return;
		   	for(Core c:ca) {
		  		try {
		  			//System.out.println("DiagrammPanel:initVectors:vname="+c.value);	
		  			Vector vector=new Vector(c.value);
// format				
				try {
			  String vkey$=entity.getElementItemAtValue("v.name", vector.name$);
			   Core xy=entity.getElementItem("v.xy",vkey$);
				Core[] fa=entity.elementGet("ray.format");
				if(fa!=null)
					for(Core f:fa)
						if(xy.type.equals(f.type)) {
							vector.format$=f.value;
							//System.out.println("DiagrammPanel:restoreValues:vd="+vector.name$+"  format="+f.value);
				}  
				}catch(Exception ee) {
					System.out.println("DiagrammPanel:restoreValues:vd="+vector.name$+":  "+ee.toString());
				}
				vectors.add(vector);
			}catch(Exception ee) {
				System.out.println("DiagrammPanel:initVectors:vector="+c.value+": "+ee.toString());
			}
		    }
		    }
	
	public void addVector(String vname$,double x,double y) {
		if(vectors.size()>0)
			for(Vector v:vectors) {
				if(vname$.equals(v.name$)) {
					v.addValue(x, y);
					break;
				}
			}
	}
	public String getVectorName(String xname$) {
		Core[] ca=entity.elementGet("v.xy");
		if(ca!=null)
			for(Core c:ca) {
				if(xname$.equals(c.type))
					return entity.getElementItemAt("v.name", c.name);
			}
		return null;
	}
	@Override
    protected void paintComponent(Graphics  g) {
	  super.paintComponent(g); 
	  drawAxes(g); 
	  drawVectors(g);
	}
	private void drawAxes(Graphics g) {
	Dimension d2=getSize();
	int w=d2.width;
	int h=d2.height;
	lineStroke=new BasicStroke(3,BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND, 100);
	center=new Point2D.Double(w/2,h/2);
	g2=(Graphics2D)g;
	g2.clearRect(0, 0, w,h);
	g2.setColor(Color.DARK_GRAY);
	g2.drawLine(0, (int)center.getY(),w ,(int)center.getY());
	g2.drawLine((int)center.getX(),0, (int)center.getX(),h);
	legend(entity);
	}
	private void drawVectors(Graphics g) {
		Dimension d2=getSize();
		//System.out.println("DiagrammPanel:drawVectors:last="+last+" cnt="+cnt);
		if(d2.width<10||d2.height<10)
			return;
		int w=d2.width;
		int h=d2.height;
		lineStroke=new BasicStroke(3,BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND, 100);
		center=new Point2D.Double(w/2,h/2);
		Graphics2D g2=(Graphics2D)g;
		status.setText("");
		for(Vector v:vectors) {
			v.draw(g2, center);
		}
	}
private  void legend(Sack entity){
		Core[] ca=entity.elementGet("ray.visible");
		String ray$;

		int x=5;
		int y=50;
		int space=20;
		if(ca!=null)
			for(Core c:ca)
				if("true".equals(c.value)){
					ray$=entity.getElementItemAt("ray.name", c.name);
					if(ray$!=null){
						//new Entry(ray$,entity).draw( x, y);
						y=y+space;
					}
				}
	}
private Vector  getVector(String vname$) {
		if(vectors.size()<1) {
			System.out.println("DiagrammPanel:getVector:empty vector list.");
			return null;
		}
		for(Vector v:vectors)
			if(vname$.equals(v.name$))
				return v;
		return null;
	}
public void reset() {
//		System.out.println("DiagrammPanel:reset:BEGIN");
		Dimension d2=getSize();
		int w=d2.width;
		int h=d2.height;
		lineStroke=new BasicStroke(3,BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND, 100);
		center=new Point2D.Double(w/2,h/2);
		g2=(Graphics2D)getGraphics();
		if(g2!=null) {
		g2.clearRect(0, 0, w,h);
		g2.setColor(Color.DARK_GRAY);
		g2.drawLine(0, (int)center.getY(),w ,(int)center.getY());
		g2.drawLine((int)center.getX(),0, (int)center.getX(),h);
		}
		initVectors();
	}
	public void revise(Sack entity) {
		revise(entity,true, 0);
	}
	public void revise(Sack entity,int cnt) {
		revise(entity,false, cnt);
	}
	private void revise(Sack entity,boolean last, int cnt) {
		//System.out.println("DiagrammPanel:revise:last="+last+" cnt="+cnt);
		this.last=last;
		this.cnt=cnt;
		double x=0;
		double y=0;
		String x$;
		String y$;
		Core xy;
			for(Vector v:vectors) {
				try {
				NumberFormat mFormat = new DecimalFormat(v.format$);
				String vkey$=entity.getElementItemAtValue("v.name", v.name$);
			//	System.out.println("DiagrammPanel:revise:vector="+v.name$+"   vkey="+vkey$);
	            xy=entity.getElementItem("v.xy", vkey$);
	            if(xy==null) {
	            	System.out.println("DiagrammPanel:revise:xy is null for vkey="+vkey$);
	            	continue;
	            }
	            x=0;
	            x$=entity.getElementItemAt(OperatorHandler.OPERATOR, xy.type);
	            y$=entity.getElementItemAt(OperatorHandler.OPERATOR, xy.value);
	            try {x= java.lang.Double.parseDouble(x$);}catch(Exception e) {	}
				y=0;
	            try {y=java.lang.Double.parseDouble(y$);}catch(Exception e) {}
				v.addValue(x, y);
		//		System.out.println("DiagrammPanel:revise:x="+x+" y="+y);
				}catch(Exception e) {
					 System.out.println("DiagrammPanel:revise:"+e.toString());
				}
				}
	//	System.out.println("DiagrammPanel:revise:vectors="+vectors.size());
		repaint();
		if(parent!=null)
			parent.toFront();
		}
private   static Color getColor(String color$){
		Color color=Color.white;;
		if("black".equals(color$))
			color=Color.black;
		if("blue".equals(color$))
			color=Color.blue;
		if("red".equals(color$))
			color=Color.red;
		if("orange".equals(color$))
			color=Color.orange;
		if("magenta".equals(color$))
			color=Color.magenta;
		if("cyan".equals(color$))
			color=Color.cyan;
		return color;
	}
	class Vector{
			String name$;
			ArrayList<MathUtil.V2>values=new ArrayList<MathUtil.V2>();
			Color color;
			boolean visible=true;
			double factor;
			float arrowSize=20;
			String format$="###.0";
			public Vector(String vname$){
				name$=vname$;
//				System.out.println("DiagrammPanel:vector:entity is null");
				String vkey$=entity.getElementItemAtValue("v.name", vname$);
				Core vn=entity.getElementItem("v.name", vkey$);
				if("false".equals(vn.type))
					visible=false;
	//			System.out.println("DiagrammPanel:vector:vkey="+vkey$);
				Core fc=entity.getElementItem("v.fc",vkey$);
				factor=1;
				try {factor=java.lang.Double.parseDouble(fc.type);}catch(Exception e){}
				color=getColor(fc.value);
				Core xy=entity.getElementItem("v.xy",vkey$);
				Core[] ca=entity.elementGet("ray.format");
				if(ca!=null)
					for(Core c:ca)
						if(xy.type.equals(c.type)) {
							
							format$=c.value;
						}
		//		System.out.println("DiagrammPanel:vector:vname="+vname$+" factor="+factor+" format="+format$);
			  }
			public void clear() {
				values.clear();
			}
			public void addValue(double x,double y) {
				MathUtil.V2 v=new MathUtil.V2(x, y);
			//	System.out.println("DiagrammPanel:Vector="+name$+" add value: V2->");
				//v.print("v");
				if(values==null)
					values= new ArrayList<MathUtil.V2>();
				values.add(v);
			}
			public void drawRelative(Graphics2D g, Point2D start,String vo$) {
			//	System.out.println("DiagrammPanel:Vector:draw relative : rv$="+vo$);
				if(values.size()<1)
					return;
				int n=0;
				if(last)
				   n=values.size()-1;
				else
					n=cnt;
				drawRelative( g,start, n,vo$);
			}
			private void drawRelative(Graphics2D g, Point2D start,int n,String rv$) {
			//	System.out.println("DiagrammPanel:Vector:draw relative n="+n); 
				if(values.size()<n+1||n<0)
					return ;
				MathUtil.V2 v=values.get(n);
				//v.print("v");
				Vector rv=getVector(rv$);
			//	System.out.println("DiagrammPanel:Vector:draw relative : rv="+rv.name$);
				MathUtil.V2 rvv=rv.values.get(n-1);
				String v$;
				String a$;
				NumberFormat aFormat = new DecimalFormat("###.#");
				NumberFormat mFormat = new DecimalFormat(format$);
		        if(rvv!=null) {
		        		MathUtil.V2 vn=v.relative(rvv);
		        		draw( g, start,  vn);
		        		StringBuffer sb=new StringBuffer();
		        		if(status!=null) {
		        		sb.append(status.getText());
		        		sb.append("  "+name$+ ": m="+aFormat.format(vn.norm())+" a="+aFormat.format(v.angle(rvv)));
		        		status.setText(sb.toString());
		        		}
		        		}
			}
		public void draw(Graphics2D g, Point2D start) {
				//System.out.println("DiagrammPanel:Vector:draw::last="+last+"  cnt="+cnt+"  values="+values.size());
				if(values.size()<1) {
					return;
				}
				MathUtil.V2 v;
				if(last) 
				 v=values.get(values.size()-1);
				else {
					int n=cnt;
					if(cnt> values.size()-1)
						n=values.size()-1;
					 v=values.get(n);
				}
				draw(g,start, v);
			}
			private void draw(Graphics2D g, Point2D start, MathUtil.V2 v) {
				if(!visible)
					return;
				MathUtil.V2 v2=v.product(factor);
	//			System.out.println("DiagrammPanel:Vector:draw:: v: x="+v.x+"   y="+v.y+  "   v2:  x="+v2.x+"  y="+v2.y);
				LineV2 lv=new LineV2(start,v2,name$);
				g.setStroke(lineStroke);
				g.setColor(color);
				lv.draw(g);
				String v$;
				String a$;
				NumberFormat aFormat = new DecimalFormat("###.#");
				NumberFormat mFormat = new DecimalFormat(format$);
        		StringBuffer sb=new StringBuffer();
        		if(status!=null) {
		        		sb.append(status.getText());
		        		sb.append("  "+name$+ ": m="+aFormat.format(v.norm())+" a="+aFormat.format(v.angle()));
		        		status.setText(sb.toString());
		        		}
			}
			}
	 class LineV2 extends Line2D.Double  {
		MathUtil.V2 v;
		String name$;
		public LineV2 (Point2D center,MathUtil.V2 v,String name$) {
			this.v=v;
			this.name$=name$;
			x1=center.getX();
			y1=center.getY();
			x2=center.getX()+v.x;
			y2=center.getY()-v.y;
		}
		public  LineV2 rotate90() {
		//	System.out.println("DiagrammPanel:rotate:before: start x="+x1+"   y="+y1+"   end  x="+x2+"  y="+y2);
			MathUtil.V2 v2=v.rotation();
			LineV2 lv=new  LineV2 (center,v2,name$);
			return lv;
		}
		public  void draw(Graphics2D g) {
			//System.out.println("DiagrammPanel:draw:LineV2:  x="+v.x+"   y="+v.y);
			g.setStroke(lineStroke);
			g.draw(this);
			Point2D end=new Point2D.Double(x2,y2);
			Point2D start=new Point2D.Double(x1,y1);
			drawArrow (g,  start, end, 6);
		}
	
	 void drawArrow (final Graphics2D gfx, final Point2D start, final Point2D end, final float arrowSize) {
		 double xg = end.getX()-start.getX();
	     double yg =-(end.getY()-start.getY());
	   //  System.out.println("vector   xg="+xg+",    yg="+yg);
	     double angle=Math.PI / 2;
	     double a=arrowSize;
	     if (xg!=0.0d){
         double tan=Math.abs(yg/xg);
            angle=  Math.atan(tan);
	     }
	     int quadrant=0;
	     if(xg>=0&&yg>=0)
	    	 quadrant=1;
	     if(xg<=0&&yg>=0)
	    	 quadrant=2;
	     if(xg<=0&&yg<=0)
	    	 quadrant=3;
	     if(xg>=0&&yg<=0)
	    	 quadrant=4;
	     if(xg==0&&yg==0)
	    	 quadrant=0;
	    double  dx=a* Math.cos(angle);
	    double  dy=a* Math.sin(angle);
	    double xe=end.getX();
	    double ye=end.getY();
	    double x1=0;
	    double y1=0;;
	    double x11=0;
	    double y11=0;
	    double x2=0;
	    double y2=0;;
	    double x4=0;;
	    double y4=0;
	    if( quadrant==1){
	    	x1=xe-dx;
	    	y1=ye+dy;
	    	 x11=xe-dx/2;
	    	 y11=ye+dy/2;
	    	 x2=x1-dy;
	    	 y2=y1-dx; 
	    	 x4=x1+dy;
	    	 y4=y1+dx;
	    	 gfx.drawString(name$,(int)(xe+10),(int)ye);
	    	 
	    }
    if( quadrant==4){
	    	x1=xe-dx;
	    	y1=ye-dy;
	    	 x11=xe-dx/2;
	    	 y11=ye-dy/2;
	    	 x2=x1+dy;
	    	 y2=y1-dx; 
	    	 x4=x1-dy;
	    	 y4=y1+dx;
	    	 gfx.drawString(name$,(int)(xe+10),(int)ye); 
	    }
    if( quadrant==2){
	    	x1=xe+dx;
	    	y1=ye+dy;
	    	 x11=xe+dx/2;
	    	 y11=ye+dy/2;
	    	 x2=x1+dy;
	    	 y2=y1-dx; 
	    	 x4=x1-dy;
	    	 y4=y1+dx;
	    	 gfx.drawString(name$,(int)(xe-20),(int)ye);	 
	    }
	    if( quadrant==3){
	    	x1=xe+dx;
	    	y1=ye-dy;
	    	 x11=xe+dx/2;
	    	 y11=ye-dy/2;
	    	 x2=x1-dy;
	    	 y2=y1-dx; 
	    	 x4=x1+dy;
	    	 y4=y1+dx;
	    	 gfx.drawString(name$,(int)(xe-20),(int)ye);		 
	    }
	   GeneralPath polygon = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
	   polygon.moveTo(end.getX(),end.getY());
	   polygon.lineTo(x2,y2);
	   polygon.lineTo(x4, y4);
	   polygon.lineTo(end.getX(),end.getY());
	   polygon.closePath();
	   gfx.fill	    (polygon);
	   gfx.setStroke(lineStroke);
	   gfx.drawLine	  ((int)start.getX(),(int)start.getY(),(int)(x11),(int)(y11));
	}
	}
	 private ArrayList <Vector> sortVl(){
		 if(vectors==null)
			 return null;
		 if(vectors.size()==1)
			 return vectors;
		HashMap <String,Vector>vm=new  HashMap <String,Vector>();
		String[] sa=new String[ vectors.size()];
		Vector v;
		String vname$;
		for(int i=0;i<vectors.size();i++) {
			v=vectors.get(i);
            vm.put(v.name$, v);
            sa[i]=v.name$;
		}
		Arrays.sort(sa);
		ArrayList<Vector>svl=new ArrayList<Vector>();
		for(int i=0;i<sa.length;i++)
			svl.add(vm.get(sa[i]));
		return svl;
	 }
	 
	 public void saveValues(Entigrator entigrator,String recordPath$){
	//	 System.out.println("DiagrammPanel:saveValues::BEGIN:record path="+recordPath$);	
				if(entity==null){
					System.out.println("DiagrammPanel:saveValues::cannot find entity is null");
					return;
				}
			try{
				    File record=new File(recordPath$);
					 if(record.exists())
						 record.delete();
					 record.createNewFile();
					 PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(record.getPath(), true)));
					 StringBuffer sb=new StringBuffer();
			        if(vectors.size()<1) {
			        	System.out.println("DiagrammPanel:saveValues::no vectors.Return");
			        	writer.close();
			        	return;
			        }
			   vectors=sortVl();
			   Vector v0=vectors.get(0);
			   int vsize=v0.values.size();
			  // System.out.println("DiagrammPanel:saveValues:vectors="+vl.size()+" values="+vsize);
			   double x=0;
			   double y=0;
			   String x$;
			   String y$;
			   NumberFormat valFormat = new DecimalFormat("0.####E0");
			   for(int i=0;i<vsize;i++) {
			      for(Vector v:vectors) {
				      MathUtil.V2 vv=v.values.get(i);
				      x$=valFormat.format(vv.x);      
				      y$=valFormat.format(vv.y);
				      sb.append(x$+":"+y$+";");
			      }
			      if( sb.length() > 0 )
			            sb.deleteCharAt(sb.length() - 1 );
				  writer.println(sb.toString());	
				  sb.delete(0, sb.length());   
			   }
			writer.close();
			}catch(Exception e){
				System.out.println("TubePanel:refresh:2:"+e.toString());
			}
	 }
	 public void restoreValues(String recordPath$){
		 	try{
		//	System.out.println("DiagrammPanel:restoreValues:record path=="+recordPath$);
			recordPath$=recordPath$.replace(".rec", ".dgr");
				String line$="";
				String[] va;
				Scanner sc = null;
				FileInputStream inputStream = new FileInputStream(recordPath$);
			    sc = new Scanner(inputStream, "UTF-8");
			  MathUtil.V2 v;
			  String x$;
			  String y$;
			  double x=0;
			  double y=0;
			  String [] xya;
			  vectors=sortVl();
			//  System.out.println("DiagrammPanel:restoreValues:vl="+vl.size()); 
			  for(Vector vd:vectors) {
				  vd.clear();
			  }
			  while (sc.hasNextLine()) {
			    	line$ = sc.nextLine();
			        va=line$.split(";");
			        for(int i=0;i<va.length;i++) {
			        	x=0;
			        	y=0;
			        	xya=va[i].split(":");
			        	try { x=Double.parseDouble(xya[0]);}catch(Exception e){}
			        	try { y=Double.parseDouble(xya[1]);}catch(Exception e){}
			        	v=new MathUtil.V2(x,y);
			        	vectors.get(i).addValue(x, y);
			        }
			    } 
			    inputStream.close();
			    sc.close();
			   	}catch(Exception e){
			   		System.out.println("DiagrammPanel:restoreValues:"+e.toString());
			   	}
		}
	 public String getTitle() {
		if(entity!=null)
		 return entity.getProperty("label");
		return "Vector diagramm";
	 }
}
