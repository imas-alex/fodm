package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;
import javax.swing.JPanel;
import  java.io.BufferedWriter;
import  java.io.FileWriter;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.base.generic.Locator;
import javax.swing.border.TitledBorder;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.gauge.Meter;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Instrument;

//import com.sun.tools.doclint.Entity;

import javax.swing.border.LineBorder;
public class TubePanel extends JPanel implements Instrument{
	private static final long serialVersionUID = 1L;
	private final int WIDTH=2000;
	private final int HIGTH=2000;
	private String LOOK="bw";
	ArrayList<Ray>rays;//=new ArrayList<Ray>();
	ArrayList<Scale>scales=new ArrayList<Scale>();
	//int maxY=0;
	//int maxX=0;
	int passes=0; 
	int border=10;
	private String key$;
	int width;
	int xTime=0;
	int offset=0;
	Sack tube;
	File record;
	TitledBorder titledBorder;
	String time$;
	String look$;
	String status$;
	boolean store=true;
	int sliderPosition=-1;
	double startView=0;
	public double factor=1;
	public String start$;
	public String stop$;
	DiagrammPanel diaPanel;
	Entigrator entigrator;
	int reviseCount=0;
	double ptime=0;
	double clearTime=0;
	public TubePanel(Entigrator entigrator,String locator$) {
		super();
		this.entigrator=entigrator;
		if(locator$==null)
			return;
		key$=Locator.getProperty(locator$, Entigrator.ENTITY_KEY);
		String start$=Locator.getProperty(locator$, Instrument.START_VIEW);
		try{startView=Double.parseDouble(start$);}catch(Exception e) {}
		if(key$!=null) {
		tube=entigrator.getEntity(key$);
		init(tube);
		diaPanel=new DiagrammPanel(entigrator,tube);
		}
	}
	private void init(Sack tube) {
		//System.out.println("TubePanel:init:BEGIN:tube="+tube.getProperty("label"));
		rays=new ArrayList<Ray>();
		String title$=tube.getProperty("label");
		titledBorder=new TitledBorder(new LineBorder(new Color(184, 207, 229)), title$, TitledBorder.LEADING, TitledBorder.TOP, null, Color.CYAN);
		setBorder(titledBorder);
		//setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), title$, TitledBorder.LEADING, TitledBorder.TOP, null, Color.CYAN));
		this.tube=tube;
		String frequency$=tube.getElementItemAt("tube", "frequency");
	    String takt$=tube.getElementItemAt("tube", Instrument.TAKT);
	    String width$=tube.getElementItemAt("tube", "width");
	    String height$=tube.getElementItemAt("tube", "height");
		look$=tube.getElementItemAt("tube", "look");
		start$=tube.getElementItemAt("tube", Instrument.START_VIEW);
		stop$=tube.getElementItemAt("tube", Instrument.STOP);
		int frequency=1;
		double takt=1;
		startView=0;
		int width=WIDTH;
		int height=HIGTH;
		try {frequency=Integer.parseInt(frequency$);}catch(Exception e) {};
		try {takt=Double.parseDouble(takt$);}catch(Exception e) {};
		try {startView=Double.parseDouble(start$);}catch(Exception e) {};
		try {width=	Integer.parseInt(width$);}catch(Exception e) {};
		try {height=Integer.parseInt(width$);}catch(Exception e) {};
		setBounds(0,0,width,height);
		factor=takt*frequency;
		String visible$;
		String rayKey$;
		String rayName$;
		String color$;
		String shift$;
		String factor$;
		String format$;
		String symbol$;
		String position$;
		Ray ray;
		Core[] ca=tube.elementGet("ray.name");	
		Scale scale;
		if(ca!=null)
		for(Core c:ca){
		   	try{
		   		rayKey$=c.name;
		   	//	System.out.println("TubePanel:rayKey="+rayKey$);
		   		visible$=tube.getElementItemAt("ray.visible",rayKey$);
		   		if(!"true".equals(visible$))
		   			continue;
		   		rayName$=c.value;
		   		color$=tube.getElementItemAt("ray.color",rayKey$);
		   		shift$=tube.getElementItemAt("ray.shift",rayKey$);
		   		factor$=tube.getElementItemAt("ray.factor",rayKey$);
		   		format$=tube.getElementItemAt("ray.format",rayKey$);
		   		symbol$=tube.getElementItemAt("ray.symbol",rayKey$);
		   		visible$=tube.getElementItemAt("ray.visible",rayKey$);
		   		position$=tube.getElementItemAt("ray.position",rayKey$);
		   		//public Ray(String name$, String factor$,String shift$, String color$,String format$,String symbol$,String position$,String visible$){
		   		ray=new Ray(rayName$, factor$,shift$,  color$,format$,symbol$,position$,visible$);
		   		rays.add(ray);
		   		//ray.printSettings();
		   		if(tube.getElementItem("ray.scale", rayKey$)!=null) {
		   		scale=new Scale(tube,rayKey$);
		   		scales.add(scale);
		   		}
		   	}catch(Exception e){
		   		System.out.println("TubePanel:"+e.toString());
		   	}
		}
		if(diaPanel==null)
			diaPanel=new DiagrammPanel(entigrator,tube);
		else
			diaPanel.setTube(tube);
		}
	private void updateScales() {
		Core[] ca=tube.elementGet("ray.name");	
		Scale scale;
		String rayKey$=null;
		scales.clear();
		if(ca!=null)
		for(Core c:ca){
			rayKey$=c.name;
			if(tube.getElementItem("ray.scale", rayKey$)!=null) {
		   		scale=new Scale(tube,rayKey$);
		   		scales.add(scale);
		   		}
		}
	}
	@Override
    protected void paintComponent(Graphics  g) {
	  super.paintComponent(g); 
	  //System.out.println("TubePanel:paintComponent:look="+look$);
	  removeAll();
	   g.clearRect(0, 0, getSize().width, getSize().height);
      if(LOOK.equals(look$)) {
	    	g.setColor(Color.BLACK);
	    	//return;
      }
     
	   drawGrid(g);
	 
	   drawRays(g); 	
	 
	    legend(g);
	    if(tube!=null)
	       status$=tube.getElementItemAt("operator", "runstatus");
	    drawTime(g);
	    drawScales((Graphics2D)g);
        drawSliderMarker(g);
	}
	public void drawRays(Graphics g){
		//System.out.println("TubePanel:drawRays:look="+look$+"  LOOK="+LOOK);
		if(rays==null) {
			revalidate();
			repaint();
			return;
		}
		try {
			//System.out.println("TubePanel:drawRays:rays="+rays.size());	
		for(Ray r:rays) {
			//System.out.println("TubePanel:drawRays:ray="+r.name$);
			r.drawRay(g);
		}
		}catch(Exception e) {
			System.out.println("TubePanel:drawRays:"+e.toString());
		}
	}
	@Override
	public void revise(Entigrator entigrator,String locator$){
		try{
			//System.out.println("TubePanel:revise:locator="+locator$);
			startView=0;
			String start$=Locator.getProperty(locator$, Instrument.START_VIEW);
			try{startView=Double.parseDouble(start$);}catch(Exception e) {}
			tube=entigrator.getEntity(key$);
		//	System.out.println("TubePanel:revise:cos="+tube.getElementItemAt(OperatorHandler.OPERATOR, "cos")+"  sin="+tube.getElementItemAt(OperatorHandler.OPERATOR, "sin"));
			if(tube==null){
				System.out.println("TubePanel:revise:0:cannot find tube="+key$);
				return;
			}
			String mode$=UPDATE;
			if(locator$!=null)
				mode$=Locator.getProperty(locator$, MODE);
				if(RESET.equals(mode$)) {
						reset(entigrator); 	
				return;
				}
			Graphics g= getGraphics();
		//	System.out.println("TubePanel:revise:rays="+rays.size());
			   	try{
			   		for(Ray r:rays){
			   			r.update(tube);
			   		}
			   	}catch(Exception ee){
					System.out.println("TubePanel:revise:1:"+ee.toString());
				}
			 if(diaPanel==null)  
				 diaPanel=new DiagrammPanel(entigrator,tube);
			  diaPanel.revise(tube); 
			  
		}catch(Exception e){
			System.out.println("TubePanel:revise:"+e.toString());
		}
	}
	
	public void save(Entigrator entigrator,String locator$){
		try{
			String recordLabel$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String recordKey$=entigrator.getKey(recordLabel$);
			//System.out.println("TubePanel:save:record key="+recordKey$+"  label="+recordLabel$);
	        PrintWriter writer =null;
			String recordHome$=entigrator.getEntihome()+"/"+recordKey$;
			record=new File(recordHome$+"/"+recordKey$+".rec");
			record.createNewFile();
		    writer = new PrintWriter(new BufferedWriter(new FileWriter(record.getPath(), true)));
		    StringBuffer sb=new StringBuffer();
		    if(rays.size()<1) {
			   writer.close();
			   return;
		   }
		   Ray r0=rays.get(0);
		   int psize=r0.points.size();
		   //System.out.println("TubePanel:save:rays="+rays.size()+" points="+psize);
		   Dimension d=null;
		   for(int i=0;i<psize;i++) {
		      for(Ray r:rays) {
			   d=r.points.get(i);  
			   sb.append(d.height+";");
		   }
		      if( sb.length() > 0 )
		            sb.deleteCharAt( sb.length() - 1 );
			  writer.println(sb.toString());	
			  sb.delete(0, sb.length());
		   }
			writer.close();
			int height=getHeight();
			height=getHeight();
			int width=getWidth();
			tube.putElementItem("tube", new Core(null,"height",String.valueOf(height)));
			tube.putElementItem("tube", new Core(null,"width",String.valueOf(width)));
			String takt$=Locator.getProperty(locator$, Instrument.TAKT);
			tube.putElementItem("tube", new Core(null,Instrument.TAKT,takt$));
			String start$=Locator.getProperty(locator$, Instrument.START_VIEW);
			tube.putElementItem("tube", new Core(null,Instrument.START_VIEW,start$));
			String stop$=Locator.getProperty(locator$, Instrument.STOP);
			tube.putElementItem("tube", new Core(null,Instrument.STOP,stop$));
			tube.putElementItem("tube", new Core(null,"record",recordLabel$));
			tube.putElementItem("tube", new Core(null,"factor",String.valueOf(factor)));
			tube.saveXML(recordHome$+"/"+key$+".tube");
		    diaPanel.saveValues(entigrator, recordHome$+"/"+recordKey$+".dgr");
		}catch(Exception e){
			System.out.println("TubePanel:save:"+e.toString());
		}
	}
	public void reset (Entigrator entigrator){
	clearTime=0;
	tube=entigrator.getEntity(key$);
	passes=0;
	reset();
	}
	public void reset (){
		if(tube==null) {
			System.out.println("TubePanel:reset:tube is null");
			return;
		}
		tube=entigrator.getEntity(tube.getKey());
		//System.out.println("TubePanel:reset.BEGIN");
		xTime=0;
		reviseCount=0;
		ptime=0;
		if(rays!=null)
				for(Ray r:rays) {
					r.points.clear();
				//	System.out.println("TubePanel:reset:ray="+r.name$+"  points="+r.points.size());
		}
		//System.out.println("TubePanel:reset:0");
		
		updateScales();
		revalidate();
		repaint();
		//System.out.println("TubePanel:reset:1");
		if(diaPanel!=null)
			   diaPanel.reset();
		//System.out.println("TubePanel:reset:xTime="+xTime+"  reviseCount="+reviseCount);	
	}
	public Sack getTube(){
		return tube;
	}
	public double getFactor(){
		return factor;
	}
	public void setTube(Sack tube){
		if(tube==null) {
			System.out.println("TubePanel:setTube:tube is null");
			return;
		}
		//System.out.println("TubePanel:setTube:tube="+tube.getProperty("label"));	
		this.tube=tube;
		width=getWidth();
		key$=tube.getKey();
		setBounds(0,0,WIDTH,HIGTH);
		init(tube);
	}
	public void drawGrid(Graphics g){
		 Color screenColor = Color.decode("#007700");
		g.setColor(screenColor);
		if(LOOK.equals(look$)) {
			g.setColor(Color.white);
		}	
	 
	   int h=super.getHeight();
		  int w=super.getWidth();
		  g.fillRect(0, 0, w,h);
		  g.setColor(Color.DARK_GRAY);  
		  if(LOOK.equals(look$)) {
				g.setColor(Color.lightGray);
			}	
		  int cnt=h/10;
		  int cnt2=w/10;
	  for(int i=0; i< cnt+1;i++){
	   g.drawLine(0, i*10,w,i*10);
	  }
	  for(int i=1; i< cnt2;i++){
	      g.drawLine( i*10,0,i*10,h);
	  }
	}
	private Color getColor(String color$){
		Color color=Color.white;;
		if("white".equals(color$))
			color=Color.white;
		if("blue".equals(color$))
			color=Color.blue;
		if("red".equals(color$))
			color=Color.red;
		if("orange".equals(color$))
			color=Color.orange;
		if("magenta".equals(color$))
			color=Color.magenta;
		if("cyan".equals(color$))
			color=Color.cyan;
		return color;
	}
	class Ray{
		public  ArrayList<Dimension> points;
		public Color color=Color.white;;
		public double factor=1;
		public int shift=0;
		public int position=0;
		public String name$;
		public String format$;
		public String symbol$;
		public boolean visible;
		int offset=0;
		public int y;
		public Ray(String name$, String factor$,String shift$, String color$,String format$,String symbol$,String position$,String visible$){
			try{
			this.name$=name$;
			this.format$=format$;
			this.symbol$=symbol$;
			color=getColor(color$);
			factor=1;
			try {factor=Double.parseDouble(factor$);}catch(Exception ee) {}
			shift=100;
			try {shift=Integer.parseInt(shift$);}catch(Exception ee) {}
			position=0;
			try {position=Integer.parseInt(shift$);}catch(Exception ee) {}
			visible=true;
			if("false".equals(visible$))
				visible=false;
			points=new 	ArrayList<Dimension>();
			}catch(Exception e){
				 System.out.println("TubePanel:Ray:"+e.toString());
			}
		}
		public void setColor(Color color){
			this.color=color;
		}
		private void addPoint(int x,int y){
			points.add(new Dimension(x,y));
		}
		public  void clear(){
			points.clear();
		}
		private void update(Sack tube){
		 	try{
		 		//System.out.println("TubePanel:update:tube="+tube.getKey());
		 		String	time$=tube.getElementItemAt("operator",Instrument.TIME);
			   	String 	frequency$=tube.getElementItemAt("tube","frequency");
			   	double time=Double.parseDouble(time$);
			   	if(time<startView)
			   		return;
			   	int frequency=Integer.parseInt(frequency$);
			   	double xa=time*frequency;
			   	double sx=startView*frequency;
			   	double x=xa-sx;
			   	xTime=(int)x;
//			   	System.out.println("TubePanel:update:time"+time+" x="+x+ "  start view="+startView);
				String value$;
				double value;
		 	Core[] ca=tube.elementGet("ray.name");
			for(Core c:ca){
				//System.out.println("TubePanel:update:c.value="+c.value+" name="+name$);
			   		if(!name$.equals(c.value))
			   			continue;
			   		if(!"true".equals(tube.getElementItemAt("ray.visible", c.name)))
			   			return;
				    value$=tube.getElementItemAt(OperatorHandler.OPERATOR,name$);
				    //System.out.println("TubePanel:Ray:update::value="+value$);
				    try{
				      value=Double.parseDouble(value$);
				     }catch(NumberFormatException nfe ){
				    	 value=0;
				     }
				     y=(int)(-value*factor+shift);
			    	 // System.out.println("TubePanel:Point:value="+value+" y="+y+"  factor="+factor);
			    	  if(y>HIGTH) 
			    		  y=HIGTH;
			    	  if(y<-HIGTH) 
			    		  y=-HIGTH;
			    	//  System.out.println("TubePanel:Ray:update:time="+currentTime+"  y="+y);
			     addPoint(xTime, y);
		     			}	   		
			   	}catch(Exception e){
			   		System.out.println("TubePanel:update::"+e.toString());
			   	}
		}
		private void revise(Graphics g){
		 	if(g==null) {
			 		System.out.println("TubePanel:ray:revise:graphics is null");
			 		return;
		 	}
			if(tube==null) {
		 		System.out.println("TubePanel:ray:revise:tube is null");
		 		return;
		 	}
			try{
				//System.out.println("TubePanel:ray:revise:BEGIN");
		 		String value$;
				double value;
				 if(!visible)
	                return;
				  value$=tube.getElementItemAt(OperatorHandler.OPERATOR,name$);
				  value=0;
			      try{value=Double.parseDouble(value$);}catch(Exception e) {
					    	  System.out.println("TubePanel:revise:ray="+name$+" cannot parse value="+value$);  
			      }
			//	System.out.println("TubePanel:revise:Ray="+name$+"  value="+String.valueOf(value)+"  y="+y+ " ray points="+points.size());
			    y=(int)(-value*factor+shift);
				if(y>HIGTH) 
				  y=HIGTH;
				if(y<-HIGTH) 
				  y=-HIGTH;
			//	 System.out.println("TubePanel:revise:1:ray="+name$+" value="+value+" y="+y);
				addPoint(xTime, y);
			}catch(Exception e){
				   		System.out.println("TubePanel:ray:revise:"+e.toString());
				   	}
		}
		private void drawRay(Graphics g){
			int[] xa=new int[points.size()];
			int[] ya=new int[points.size()];
	        int n=points.size();
	       // System.out.println("TubePanel:Ray:drawRay:points="+n);
	        Dimension p;
	        for(int i=0;i<n;i++ )
	        {
	        	 p=points.get(i);
				 xa[i]=p.width;
				 ya[i]=p.height;
				// System.out.println("TubePanel:drawRay:xa=[i]"+xa[i]+" ya[i]="+ya[i]);
			}
	       // System.out.println("TubePanel:drawRay:0");	
	        g.setColor(color);
	       
	        if(LOOK.equals(look$)) {
	        	Graphics2D g2d = (Graphics2D) g;
	        	        g2d.setStroke(new BasicStroke(2));
						g2d.setColor(Color.black);
						g2d.drawPolyline(xa, ya, xa.length);
			}else	
			//System.out.println("TubePanel:drawRay:1:xa="+xa.length);	
				g.drawPolyline(xa, ya, xa.length);
				//System.out.println("TubePanel:drawRay:finish ray="+name$);
		}
		public void printSettings() {
			System.out.println("TubePanel:Ray:print settings:name="+name$
					+ "   factor="+factor
					+ "	  shift="+shift
					+ "	  position="+position
					+ "	  format="+format$
					+ "	  symbol="+symbol$
					+ "	  visible="+visible
					+ "   color="+color);
		}
	}
	private void legend(Graphics g){
		if(tube==null)
			return;
		Core[] ca=tube.elementGet("ray.visible");
		String ray$;
		int y=20;
		ArrayList<String>sl=new ArrayList<String>();
		if(ca!=null){
			for(Core c:ca)
				if("true".equals(c.value)){
					ray$=tube.getElementItemAt("ray.name", c.name);
					if(ray$!=null){
						sl.add(ray$);
					}
				}
		}
	 String[]sa=new String[sl.size()];
	 sl.toArray(sa);
	 if(sa.length<1)
		 return;
	 Arrays.sort(sa);
	 HashMap <String,Integer>t=new HashMap<String,Integer>();
	 String shift$;
	 Integer xpos= Integer.valueOf(5);
	 for(String s:sa){
		 String key$=tube.getElementItemAtValue("ray.name",s);
		 shift$=tube.getElementItemAt("ray.shift",key$);
		 xpos=t.get(shift$);
		 if(xpos==null){
			 xpos= Integer.valueOf(5);
			 t.put(shift$,xpos);
		 }
		 else{
			 xpos=xpos+s.length()*10+10 ;
			 t.put(shift$,xpos);
		 }
		 y=Integer.parseInt(shift$);
		 new Entry(s).draw(g, xpos, y);
	 }
	}
	private int[] splitLine(String line$){
		try{
			String[] sa=line$.split(";");
		   int [] ia=new int[ sa.length];
		  // System.out.println("TubePanel:splitLine:length="+sa.length);
		   for(int i=0;i<sa.length;i++)
			   try{   ia[i]= Integer.parseInt(sa[i]); }catch(Exception ee){} 
			return ia;     
		}catch(Exception e){
	   		System.out.println("TubePanel:splitLine"+e.toString());
	   		return null;
		}
	}
	public void showRecord(Entigrator entigrator,long  startTime,Sack diagramm,Sack[] gauges,Meter timer){
	 	try{
		   	init(tube);
			String record$=tube.getElementItemAt("tube","record");
			titledBorder.setTitle(record$);
			String key$=tube.getElementItemAt("tube","key");
			String rec$=entigrator.getEntihome()+"/"+key$+"/"+record$;
			Path path = Paths.get(rec$);
			long lineCount =Files.lines(path).count();
			String line$="";
			Core[] ca=tube.elementGet("ray.name");
			FileInputStream inputStream = null;
			Scanner sc = null;
		    inputStream = new FileInputStream(rec$);
		    sc = new Scanner(inputStream, "UTF-8");
		    int n=0;
		    int y;
		    int i=0;
		    int[] ia;
		   // long cnt=0;
			  String factor$=tube.getElementItemAt("tube", "factor");
			  double factor= Double.parseDouble(factor$);
			//  System.out.println("TubePanel:showRecord:factor="+factor);
		    while (sc.hasNextLine()) {
		    	line$ = sc.nextLine();
		    	ia=splitLine(line$);
                i=0; 
		    	int x=(int)(n*factor);
		    	for(Ray r:rays){
		    		y=ia[i];
		    		r.addPoint(x, y);
		    		i++;
				}
		    n++;	
		    }
		    inputStream.close();
		    sc.close();
		   	}catch(Exception e){
		   		System.out.println("TubePanel:showRecord:"+e.toString());
		   	}
	}
	
public void restorePoints(String recordPath$){
	 	try{
			String record$=tube.getElementItemAt("tube","record");
			titledBorder.setTitle(record$);
			String key$=tube.getElementItemAt("tube","key");
//		System.out.println("TubePanel:showRecord:ltube key="+key$);
			String line$="";
			int[] ia;
			Scanner sc = null;
			FileInputStream inputStream = new FileInputStream(recordPath$);
		    sc = new Scanner(inputStream, "UTF-8");
		    int x;
		    int y;
		    int i=0;
		    int cnt=0;
		  int max;
		  boolean flag=true;
		 // System.out.println("TubePanel:showRecord:1");
		    while (sc.hasNextLine()) {
		    	line$ = sc.nextLine();
		        ia=splitLine( line$);	
		        x=(int)(cnt*factor);
				cnt++;
				 max=ia.length;
				// System.out.println("TubePanel:restorePoints:cnt="+cnt);
				 i=0;
				for(Ray r:rays){
					if(i>=max)
						break;
					y=ia[i];
					i++;
					r.addPoint(x, y);
				}
		    }
		    inputStream.close();
		    sc.close();
		    if(diaPanel==null)  
				 diaPanel=new DiagrammPanel(entigrator,tube);
			  diaPanel.restoreValues(recordPath$);	
		   	}catch(Exception e){
		   		System.out.println("TubePanel:restorePoints:"+e.toString());
		   	}
	}
public void drawScales( Graphics2D g) {
	//System.out.println("TubePanel:drawScales:scales="+scales.size());
	int n=scales.size();
	//for(Scale s:scales)
	//	s.drawScale(g);
	for(int i=0;i<n;i++) {
	  try{	
		Scale s=scales.get(i);
		s.drawScale(g);
	  }catch(Exception e) {}
	}
}
public void drawTime(Graphics g) {
	try {
		//System.out.println("TubePanel:drawTime:runstatus="+status$);
		if(tube==null)
			return;
		Core[] ca=tube.elementGet("ray.name");
		String rayKey$=null;
		if(ca==null) {
			return;
		}
		for(Core c:ca) {
			if("t".equals(c.value))
				rayKey$=c.name;
		}
		int w=TubePanel.this.getWidth();
		g.setColor(Color.WHITE);
		 if(LOOK.equals(look$)) {
				g.setColor(Color.darkGray);
			}	
		    int shift=Integer.parseInt(tube.getElementItemAt("ray.shift", rayKey$));	
			int pos=Integer.parseInt(tube.getElementItemAt("ray.position", rayKey$));	
			double  scale=Double.parseDouble(tube.getElementItem("ray.scale", rayKey$).type);
			double frequency=Double.parseDouble(tube.getElementItemAt("tube", "frequency"));
			double takt=Double.parseDouble(tube.getElementItemAt("operator", "takt"));
			int lenght= (int)(scale*frequency);
			g.drawLine(w-pos-lenght, shift,w-pos,shift);
			g.drawLine(w-pos-lenght, shift+5,w-pos-lenght,shift-5);
			g.drawLine(w-pos, shift+5,w-pos,shift-5);
			String scale$=tube.getElementItemAt("ray.scale", rayKey$);
			g.drawString(String.valueOf(scale)+" "+scale$,w-pos+10,shift);	
	    if(!"reset".equals(status$))
	    	time$="";
		String time$=tube.getElementItemAt("operator", Instrument.TIME);
	    g.drawString("time="+time$,w-100,shift+30);	
	//	System.out.println("TubePanel:drawTime:time="+time$);
	}catch(Exception e) {
		//System.out.println("TubePanel:drawTime:"+e.toString());	
	}
}
	class Entry{
		public String entry$;
		public Color color;
		double norm=-1;
		String unit$;
		BigDecimal bd;
		public Entry(String entry$){
			this.entry$=entry$;
			String key$=tube.getElementItemAtValue("ray.name",entry$);
			color=getColor(tube.getElementItemAt ("ray.color", key$));
		}
		public void draw(Graphics g,int x ,int y){
			Font font = new Font("Serif", Font.BOLD, 12);
		  g.setFont(font);
		 g.setColor(color);
		 if(LOOK.equals(look$)) {
				g.setColor(Color.darkGray);
			}	
		  g.drawString(entry$,x,y);
		}
	} 
class Scale{
	public int y0=0;
	public int y1=0;
	public Color color=Color.WHITE;
	public String title$="";
	public int order=0;
	public int position=-1;
	public String value$;
	public String rayKey$=null;
	private Scale(Sack entity,String rayKey$) {
		try {
		//	System.out.println("TubePanel:Scale:rayKey="+rayKey$);	
		Core c=entity.getElementItem("ray.scale", rayKey$);
		title$=c.value;
	//	System.out.println("TubePanel:Scale:title="+title$);
		value$=c.type;
		double value=0;
		try { value=Double.parseDouble(c.type);}catch(Exception ee) {}
	//	System.out.println("TubePanel:Scale:value="+value);
		double factor=0;
		try { factor=Double.parseDouble(entity.getElementItemAt("ray.factor", rayKey$));}catch(Exception ee) {}
	//	System.out.println("TubePanel:Scale:factor=="+factor);
		c=entity.getElementItem("ray.shift", rayKey$);
		int shift=0;
		try { shift=Integer.parseInt(c.value);}catch(Exception ee) {}
	//	System.out.println("TubePanel:Scale:shift=="+shift);
		int hight=(int)(value*factor);
		y0=shift;
		y1=shift-hight;
		order=0;
		try{order=Integer.parseInt(c.type);}catch(Exception ee) {}
		String color$=entity.getElementItemAt("ray.color", rayKey$);
		color=getColor(color$);
		String position$=entity.getElementItemAt("ray.position", rayKey$);
		try{position=Integer.parseInt(position$);}catch(NumberFormatException nfe) {
			//System.out.println("TubePanel:Scale:1:"+nfe.toString());
		}
//		System.out.println("TubePanel:Scale:title="+title$+" position$="+position$+" position="+position+ "  y0="+y0+" y1="+y1);
		}catch(Exception e) {
			//System.out.println("TubePanel:Scale:"+e.toString());
		}
	}
	public void drawScale(Graphics2D g ) {
		int w=TubePanel.this.getWidth();
		int dx=position;
		g.setColor(color);
		 if(LOOK.equals(look$)) {
				g.setColor(Color.darkGray);
			}	
		//System.out.println("TubePanel:Scale:drawScale: dx="+dx+" y0="+y0+" y1="+y1+" width="+w+"  x="+(w-dx)+" color="+color);	
		g.drawLine(w-dx, y0,w-dx, y1);
		g.drawString(value$+" "+title$, w-dx, y1-3);
		g.drawLine(w-dx-2, y0,w-dx+2, y0);
		g.drawLine(w-dx-2, y1,w-dx+2, y1);
	}
}
@Override
public void associate(Entigrator entigrator, String locator$) {
	try {
	key$=Locator.getProperty(locator$, Entigrator.ENTITY_KEY);
	if(key$!=null) {
	   Sack tube=entigrator.getEntity(key$);
	   init(tube);
	}
	}catch(Exception e) {
		System.out.println("TubePanel:associate:"+e.toString());
	}
}
public void drawScreenMarker(int sliderPosition) {
	//System.out.println("TubePanel:drawScreenMarker:sliderPosition="+sliderPosition);
	this.sliderPosition=sliderPosition;
	repaint();
}
private int drawSliderMarker(Graphics g) {
	int w=TubePanel.this.getWidth();
	int h=TubePanel.this.getHeight();
	double k=sliderPosition/100.0;
	int position=(int)(k*w);
	g.setColor(Color.RED);
	g.drawLine(position, 0,position, h);
	return 0;
}
public String[] rayNameValues(int cnt) {
	Dimension point;
	double val=0;
	DecimalFormat decimalFormat;
	String line$;
	ArrayList<String> sl=new ArrayList<String>();
	
//	System.out.println("TubePanel:rayNameValues:rays="+rays.size()+"  cnt="+cnt);
	if(cnt<1)
		return null;
	for(Ray r:rays){
			try {
			    if(r.format$==null||r.format$.length()<1||"null".equals(r.format$))
			    	continue;
			if(cnt-2>r.points.size())
				break;
			int n=r.points.size();
			if(cnt>n-1)
				break;
     		point=r.points.get(cnt);
		    val=-(point.height-r.shift)/(r.factor+Double.MIN_VALUE);
		    decimalFormat=new DecimalFormat (r.format$);
		    line$=r.name$+"="+decimalFormat.format(val);
		   // System.out.println("TubePanel:rayNameValues:val="+val+" line="+line$+"  cnt="+cnt);
		    sl.add(line$);
	        }catch(Exception e) {
				System.out.println("TubePanel:rayNameValues:"+e.toString()+"  cnt="+cnt+" points="+r.points.size());
			}
	        }
	String[]sa=new String[sl.size()];
	sl.toArray(sa);
	Arrays.sort(sa);
	 if(diaPanel==null)  
		 diaPanel=new DiagrammPanel(entigrator,tube);
	return sa;
}
public String[] rayNameValues() {
	Dimension point;
	double val=0;
	DecimalFormat decimalFormat;
	String line$;
	ArrayList<String> sl=new ArrayList<String>();
	
	//System.out.println("TubePanel:rayNameValues:rays="+rays.size()+"  cnt="+cnt);
	
	for(Ray r:rays){
			try {
			    if(r.format$==null||r.format$.length()<1||"null".equals(r.format$))
			    	continue;
		
			int n=r.points.size();
		
     		point=r.points.get(n-1);
		    val=-(point.height-r.shift)/(r.factor+Double.MIN_VALUE);
		    decimalFormat=new DecimalFormat (r.format$);
		    line$=r.name$+"="+decimalFormat.format(val);
		   // System.out.println("TubePanel:rayNameValues:val="+val+" line="+line$+"  cnt="+cnt);
		    sl.add(line$);
	        }catch(Exception e) {
				System.out.println("TubePanel:rayNameValues:"+e.toString()+" points="+r.points.size());
			}
	        }
	String[]sa=new String[sl.size()];
	sl.toArray(sa);
	Arrays.sort(sa);
	 if(diaPanel==null)  
		 diaPanel=new DiagrammPanel(entigrator,tube);
	return sa;
}
public DiagrammPanel getDiagramm() {
	System.out.println("TubePanel:getDiagrmm:entity="+tube.getProperty("label"));
	if(diaPanel==null) { 
		diaPanel=new DiagrammPanel(entigrator,tube);
	}else {
		diaPanel.setTube(tube);
	}
	return diaPanel;
}
public static void main( String[] args) {
	double val=312.0;
	String format$="###.00";
	DecimalFormat decimalFormat=new DecimalFormat (format$);
	System.out.println(decimalFormat.format(val));
}
public int getReviseCount() {
	if(rays==null||rays.size()<1)
		return 0;
	return rays.get(0).points.size();
}
public int getXtime() {
	return xTime;
}
public void drawDiaLast() {
	if(diaPanel!=null)
		diaPanel.revise(tube);
}

@Override
public void revise(Entigrator entigrator) {
	//System.out.println("TubePanel:revise:BEGIN");	
	if(tube==null){
			System.out.println("TubePanel:revise:: tube is null");
			return;
		}
	try {
		//String 	ptime$=tube.getElementItemAt(OperatorHandler.OPERATOR,"time");
		String tubeKey$=tube.getKey();	
		tube=entigrator.getEntity(tubeKey$);
		if(tube==null) {
			System.out.println("TubePanel:revise::cannot get tube at key0"+tubeKey$);
			return;
		}
		//System.out.println("TubePanel:revise:0");
		String 	frequency$=tube.getElementItemAt("tube","frequency");
		int frequency=Integer.parseInt(frequency$);
	//	String 	time$=tube.getElementItemAt(OperatorHandler.OPERATOR,"time");
	   //	double time=Double.parseDouble(time$);
	   	String 	vtime$=tube.getElementItemAt(OperatorHandler.OPERATOR,"vtime");
	 //  	String stime$=tube.getElementItemAt(OperatorHandler.OPERATOR,"stime");
	   	double vtime=Double.parseDouble(vtime$);
	   
	    if(vtime<=0)
	    	vtime=Double.MIN_VALUE;
	   //System.out.println("TubePanel:revise:1");
	   	reviseCount++;
	    xTime=(int)((vtime-clearTime)*frequency);
	   //	System.out.println("TubePanel:revise::   xTime="+xTime+"  width="+getSize().width);
	    if(xTime>getSize().width-2)
	    	clearScreen();
	   	Graphics g= getGraphics();
	   	
	   	if(rays.size()>0) {
	   		 for(Ray r:rays){
	   		   // 	System.out.println("TubePanel:revise:r="+r.name$);
	   			try{
	   				r.revise(g);
	   				
	   				}catch(Exception ee) {
	   				System.out.println("TubePanel:revise:r:"+ee.toString());
	   			}
		  }
	   	}
	   	 else
	   		System.out.println("TubePanel:revise:no rays");
		}catch(Exception e) {
			System.out.println("TubePanel:revise:"+e.toString());	
		}
		 if(diaPanel==null)  
			 diaPanel=new DiagrammPanel(entigrator,tube);
		  diaPanel.revise(tube);
		 repaint();
}
@Override
public void revise(Entigrator entigrator,int cnt) {
 	//System.out.println("TubePanel:revise:cnt="+cnt); 
 	if(diaPanel!=null) {
 		diaPanel.last=false;
 		diaPanel.cnt=cnt;
 		diaPanel.repaint();
 	}else
 		System.out.println("TubePanel:revise::dia panel is null");
}
@Override
public void saveRecord(Entigrator entigrator,String recordHome$) {
	}
public void setBwLook(boolean bw) {
	if(bw)
		look$="bw";
	else
		look$="//bw";
}
public void clearScreen() {
	try {
	String vtime$=tube.getElementItemAt(OperatorHandler.OPERATOR, "vtime");
	reset();
	clearTime=Double.parseDouble(vtime$);
	}catch(Exception e) {
		System.out.println("TubePanel:clearScreen:"+e.toString());	
		clearTime=0;
	}
	
}
}

