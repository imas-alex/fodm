import javax.swing.JEditorPane;
import gdt.gui.facet.procedure.Procedure;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;

public class Implementation  implements Procedure {
private final static String ENTITY_KEY="_LRNhBnHgxfl1jFDFwRPiiuSQAmk";
public Implementation (){} 
@Override
public void exec(JMainConsole console, String locator$, JEditorPane reportPanel) {
     Entigrator entigrator=console.getEntigrator();
     String[] sa=entigrator.listEntities("tube");
     if(sa!=null)
        for(String s:sa){
    	 Sack tube=entigrator.getEntity(s);
    	 if(tube==null)
    		 continue;
    	 System.out.println(tube.getProperty("label"));
    	 tube.putAttribute(new Core("_E7vigOoKQqkPffBLgHOSq0iJsl4","icon","tube.png"));
    	 entigrator.putEntity(tube);
    	 
     }
     for(String s:sa){
    	 Sack tube=entigrator.getEntity(s);
    	 Core attribute=tube.getAttribute("icon");
    	 System.out.println(attribute.type);
     }
	}
}
