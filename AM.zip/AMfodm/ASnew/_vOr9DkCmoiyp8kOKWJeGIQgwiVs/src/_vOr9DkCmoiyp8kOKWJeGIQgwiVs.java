import gdt.base.store.Entigrator;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ZLaunchHandler;
import java.util.Hashtable;
import java.util.Properties;
import gdt.base.generic.Locator;
public class _vOr9DkCmoiyp8kOKWJeGIQgwiVs implements SegueController{
private final static String ENTITY_KEY="_vOr9DkCmoiyp8kOKWJeGIQgwiVs";
private _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.ZLaunchHandler zlaunchHandler;
public _vOr9DkCmoiyp8kOKWJeGIQgwiVs(){}
public Hashtable<String,Double>  stride(Hashtable<String,Double>  ins){ 
return zlaunchHandler. stride(ins);
} 
public void reset(){ 
zlaunchHandler.reset();
} 
public Hashtable<String,Double> getSettings(){ 
return zlaunchHandler.getSettings();
} 
public void putSettings(Hashtable<String,Double> settings){ 
zlaunchHandler.putSettings(settings); 
} 
public Hashtable<String,Double> getOuts(){ 
return zlaunchHandler.getOuts();
}
public double getClock(){
return zlaunchHandler.getClock();
}
public void setClock(double clock){ 
zlaunchHandler.setClock(clock); 
} 
public String[] listInputs(){ 
return zlaunchHandler.listInputs(); 
}
public String[] listOutputs(){ 
return zlaunchHandler.listOutputs(); 
}
public void setEntigrator(Entigrator entigrator){ 
 String entity$=entigrator.getLabel(ENTITY_KEY);
 Properties props=new Properties();
 props.put(Entigrator.ENTITY_LABEL, entity$);
 String locator$=Locator.toString(props);
zlaunchHandler=new ZLaunchHandler(entigrator,locator$);
zlaunchHandler.setEntigrator(entigrator);
} 
}
