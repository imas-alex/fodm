import javax.swing.JEditorPane;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.procedure.Procedure;
public class _YKAnRdWtfFpAEgma84sWT546GGo  implements Procedure {
private final static String ENTITY_KEY="_YKAnRdWtfFpAEgma84sWT546GGo";
public _YKAnRdWtfFpAEgma84sWT546GGo (){} 
@Override
public void exec(JMainConsole console, String locator$, JEditorPane reportPanel) {
System.out.println(ENTITY_KEY+":"+locator$);
try {
	Entigrator entigrator=console.getEntigrator();
	String[] sa=entigrator.listEntities();
	Sack entity=null;
	for(String s:sa) {
		entity=entigrator.getEntity(s);
		if(entity==null)
			continue;
		Core rec=entity.getElementItem("facet", "record");
		if(rec==null)
			continue;
		entigrator.assignProperty("entity", "record", s);
		entigrator.assignProperty( "record","true", s);
		entigrator.assignProperty( "folder","true", s);
		entigrator.reindexEntity(entity);
		System.out.println(ENTITY_KEY+":exec:entity="+entity.getProperty("label"));
	}
	
}catch(Exception e) {
	System.out.println(ENTITY_KEY+":exec:"+e.toString());
}
	}
}
