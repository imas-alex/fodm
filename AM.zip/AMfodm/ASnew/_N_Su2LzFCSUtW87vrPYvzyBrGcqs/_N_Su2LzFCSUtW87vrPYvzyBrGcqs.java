import java.io.File;
import java.io.FileOutputStream;
import java.util.logging.Logger;
import gdt.data.entity.EntityHandler;
import gdt.data.grain.Locator;
import gdt.data.store.Entigrator;
import gdt.data.grain.Sack;
public class _N_Su2LzFCSUtW87vrPYvzyBrGcqs {
private final static String ENTIHOME="/home/alexander/AC";
private final static String ENTITY_KEY="_N_Su2LzFCSUtW87vrPYvzyBrGcqs";
public void step(Entigrator entigrator){
try{
Sack entity=entigrator.getEntityAtKey(ENTITY_KEY);
String label$=entigrator.indx_getLabel(ENTITY_KEY);
// Put step code here
}catch(Exception e){
Logger.getLogger(getClass().getName());
}
}
public void reset(Entigrator entigrator){
try{
Sack entity=entigrator.getEntityAtKey(ENTITY_KEY);
String label$=entigrator.indx_getLabel(ENTITY_KEY);
// Put reset code here
}catch(Exception e){
Logger.getLogger(getClass().getName());
}
}
}
