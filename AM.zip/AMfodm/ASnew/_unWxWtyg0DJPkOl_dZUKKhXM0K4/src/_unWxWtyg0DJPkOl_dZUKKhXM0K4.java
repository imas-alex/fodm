import gdt.base.store.Entigrator;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VLaunchHandler;
import java.util.Hashtable;
import java.util.Properties;
import gdt.base.generic.Locator;
public class _unWxWtyg0DJPkOl_dZUKKhXM0K4 implements SegueController{
private final static String ENTITY_KEY="_unWxWtyg0DJPkOl_dZUKKhXM0K4";
private _E7vigOoKQqkPffBLgHOSq0iJsl4.base.facet.VLaunchHandler vlaunchHandler;
public _unWxWtyg0DJPkOl_dZUKKhXM0K4(){}
public Hashtable<String,Double>  stride(Hashtable<String,Double>  ins){ 
return vlaunchHandler. stride(ins);
} 
public void reset(){ 
vlaunchHandler.reset();
} 
public Hashtable<String,Double> getSettings(){ 
return vlaunchHandler.getSettings();
} 
public void putSettings(Hashtable<String,Double> settings){ 
vlaunchHandler.putSettings(settings); 
} 
public Hashtable<String,Double> getOuts(){ 
return vlaunchHandler.getOuts();
}
public double getClock(){
return vlaunchHandler.getClock();
}
public void setClock(double clock){ 
vlaunchHandler.setClock(clock); 
} 
public String[] listInputs(){ 
return vlaunchHandler.listInputs(); 
}
public String[] listOutputs(){ 
return vlaunchHandler.listOutputs(); 
}
public void setEntigrator(Entigrator entigrator){ 
 String entity$=entigrator.getLabel(ENTITY_KEY);
 Properties props=new Properties();
 props.put(Entigrator.ENTITY_LABEL, entity$);
 String locator$=Locator.toString(props);
vlaunchHandler=new VLaunchHandler(entigrator,locator$);
vlaunchHandler.setEntigrator(entigrator);
} 
}
