package gdt.base.store;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;

import gdt.base.generic.Locator;
public class IndexHandler implements PropertyChangeListener{
	final Logger LOGGER= Logger.getLogger(IndexHandler.class.getName());
	public static final String PROPERTY_INDEX="_0Hw7Cb9q5VrmwG6enFmb5GBKIXo";
	public static final String CONTAINER_PROPERTY_OWNERS="_A6nLHPcMALLI8jWAj4wPUuYOJOo";
	public static final String CONTAINER_PROPERTY_VALUES="_mVr_SNS5qWHZiO9qPAlAOfTWrMZQ";
	public static final String CONTAINER_ENTITIES="_xXsnV5R_SGxkuH_SpLJDeXCglybws";
	public static final String EVENT_SOURCE_INDEX_HANDLER="index handler";
	public static final String EVENT_INDEX_CHANGED="index changed";
	
	Sack index;
	String entihome$;
	SackCachedRepository indexCache;
	SackCachedRepository ownersCache;
	SackCachedRepository valuesCache;
	SackCachedRepository entitiesCache;
	
	boolean rebuild=false;
	boolean allStopped=false;
	boolean allStarted=false;
	String instance$=null;
	PropertyChangeSupport pcs;
	public IndexHandler(String entihome$, boolean rebuild) throws RuntimeException{
		//System.out.println("IndexHandler:BEGIN");
		this.entihome$=entihome$;
		pcs=new PropertyChangeSupport(this);
		indexCache=new SackCachedRepository(entihome$,"/",true);
		if(rebuild) {
		try {
			File indexFile=new File(entihome$+"/"+PROPERTY_INDEX);
			if(!indexFile.exists()) 
				index=makeNewIndex(entihome$);	
			else 
				index=Sack.readXml(entihome$+"/"+PROPERTY_INDEX);
		}catch(Exception e) {
			System.out.println("IndexHandler:"+e.toString());
		}
		
	    if(index==null) {
	    	System.out.println("IndexHandler:cannot get index="+entihome$+"/"+PROPERTY_INDEX);
	    	ownersCache.terminate();
	    	valuesCache.terminate();
	    	entitiesCache.terminate();
	    	return;
	    }else {
	    	rebuildIndex();
	    	 indexCache.put(index);
	    	
	    }
		}else {
			
			try{index=Sack.readXml(entihome$+"/"+PROPERTY_INDEX);}catch(Exception e) {} 
			if(index==null) {
				System.out.println("IndexHandler:cannot get index="+entihome$+"/"+PROPERTY_INDEX);
		    	ownersCache.terminate();
		    	valuesCache.terminate();
		    	entitiesCache.terminate();
		    	return;
			}
			indexCache.put(index);
		}
		indexCache.start();
		//indexCache=new SackCachedRepository(entihome$,"/",true);
		ownersCache=new SackCachedRepository(entihome$,CONTAINER_PROPERTY_OWNERS,true);
		//ownersCache.setInstance(instance$);
		ownersCache.load();
		ownersCache.start();
		valuesCache=new SackCachedRepository(entihome$,CONTAINER_PROPERTY_VALUES,true);
		//valuesCache.setInstance(instance$);
		valuesCache.load();
		valuesCache.start();
		entitiesCache=new SackCachedRepository(entihome$,CONTAINER_ENTITIES,false);
		//entitiesCache.setInstance(instance$);
		entitiesCache.addPropertyChangeListener(this);
		entitiesCache.start();
	}
private void put(Sack sack,String container$) {
	sack.setPath(entihome$+"/"+container$+"/data/"+sack.getKey());
	if(CONTAINER_PROPERTY_OWNERS.equals(container$)) {
		ownersCache.put(sack);
		//sack.store();
	}
	if(CONTAINER_PROPERTY_VALUES.equals(container$))
		valuesCache.put(sack);
	if(CONTAINER_ENTITIES.equals(container$)) {
		entitiesCache.put(sack);
		//entitiesCache.execRefresh(1);
		//sack.store();
	}
	if(PROPERTY_INDEX.equals(container$)) {
		indexCache.put(sack);
	}
}

public boolean saveEntity(Sack entity) {
	if(entity==null)
		return false;
	return true;
}
public boolean putEntity(Sack entity) {
	if(entity==null) {
		System.out.println("IndexHandler:putEntity:argument is null");
		return false;
	}
	//System.out.println("IndexHandler:putEntity="+entity.getProperty("label"));
    put(entity,CONTAINER_ENTITIES);
   // entity.store();
	return true;
	
}
public Sack reindexEntity(Sack entity) {
	if(entity==null) {
		System.out.println("IndexHandler:reindexEntity:argument is null");
		return entity;
	}
	Core[] ca=entity.elementGet("property");
	//System.out.println("IndexHandler:reindexEntity:entity="+entity.getProperty("label")+"ca="+  ca.length);
	if(ca!=null)
		for(Core c:ca)
			entity=assignProperty(c.type,c.value,entity.getKey());
	return entity;
}
public boolean deleteEntity(String entityKey$) {
	if(entityKey$==null) {
		return true;
	}
	try {
	Sack entity=getEntity(entityKey$);
	if(entity==null)
		return true;
	index.removeElementItem("label", entityKey$);
	Core[] ca=entity.elementGet("property");
	if(ca!=null)
	for(Core c:ca) {
		if("label".equals(c.type))
			continue;
		try {
		takeOffProperty(c.type,entityKey$);
		}catch(Exception ee ) {
			System.out.println("IndexHandler.deleteEntity: entity="+entityKey$+" property="+c.type+"   ee="+ee.toString());
		}
	}
	entitiesCache.delete(entityKey$);
	indexCache.put(index);
	}catch(Exception e) {
		System.out.println("IndexHandler:deleteEntity:"+e.toString());
	}
	return false;
}

public Sack getEntity(String  entityKey$) {
	if(entityKey$==null)
		return null;
	return get (entityKey$,CONTAINER_ENTITIES);	
}
public Core getEntityEntry(String  entityKey$) {
	return index.getElementItem("label", entityKey$);	
}
public String getEntihome() {
	return entihome$;
}
private Sack get(String sackKey$,String container$) {
	if(CONTAINER_PROPERTY_OWNERS.equals(container$))
		return ownersCache.get(sackKey$);
	if(CONTAINER_PROPERTY_VALUES.equals(container$))
		return valuesCache.get(sackKey$);
	if(CONTAINER_ENTITIES.equals(container$))
		return entitiesCache.get(sackKey$);
	if(PROPERTY_INDEX.equals(container$))
		return indexCache.get(sackKey$);
	return null;
}

public  String getLabel( String entityKey$){
	String label$=index.getElementItemAt("label",entityKey$);
	//System.out.println("IndexHandler:getLabel:entity key="+	entityKey$+" label="+label$);	
	return index.getElementItemAt("label",entityKey$);
}
public boolean labelExists(String entityLabel$) {
	Core[] ca=index.elementGet("label");
	if(ca==null)
		return false;
	for(Core c:ca)
		if(c.value.equals(entityLabel$))
			return true;
	return false;
}
public  String getKey( String entityLabel$){
	if(index==null)
		return null;
	Core[] ca=index.elementGet("label");
	if(ca==null)
		return null;
	String key$=null;
	ArrayList<String>sl=new ArrayList<String>();
	for(Core c:ca) {
		if(c.value==null) {
			//System.out.println("IndexHandler:getKey:remove wrong label="+c.name+" key is null");
			sl.add(c.name);
			continue;
		}
		if(c.value.equals(entityLabel$))
	      key$= c.name;
	}
	for(String s:sl)
		index.removeElementItem("label", s);
	return key$;
}

public void close() {
	try {
	indexCache.terminate();
	valuesCache.terminate();
	ownersCache.terminate();
	entitiesCache.terminate();
	indexCache.dump();
	valuesCache.dump();
	ownersCache.dump();
	entitiesCache.dump();
	}catch(Exception e) {
		System.out.println("IndexHandler:close:"+e.toString());
	}
}

public   Sack  makeNewIndex(String entihome$) {
	try {
		File entihome=new File(entihome$);
		if(entihome.exists()) {
			File oldIndex=new File(entihome$+"/"+PROPERTY_INDEX);
			oldIndex.delete();
		}else
		    entihome.mkdir();
		File owners=new File(entihome$+"/"+CONTAINER_PROPERTY_OWNERS+"/data");
		if(owners.exists())
			EntityToolset.deleteDirectory(owners);
		owners.mkdirs();
		File values=new File(entihome$+"/"+CONTAINER_PROPERTY_VALUES+"/data");
		if(values.exists())
			EntityToolset.deleteDirectory(values);
		values.mkdirs();
		File entities=new File(entihome$+"/"+CONTAINER_ENTITIES+"/data");
		if(!entities.exists())
		   entities.mkdirs();
		index=new Sack();

		index.setPath(entihome$+"/"+PROPERTY_INDEX);
		index.setKey(PROPERTY_INDEX);
		index.putAttribute(new Core(SackCachedRepository.RUNTIME,SackCachedRepository.TIMESTAMP,String.valueOf(System.currentTimeMillis())));
		index.store();
		System.out.println("IndexHandler:makeNewIndex:FINISH");
	    return index;
	}catch(Exception e) {
		System.out.println("IndexHandler:makeNewIndex:"+e.toString());
		return null;
	}
}

public static void main(String[] args) throws IOException {
	String entihome$="/home/alexander/AC 1122021";
	IndexHandler ies=new  IndexHandler(entihome$,false);
	ies.rebuildIndex();
}
	public void rebuildIndex() {
    	try {
    		rebuild=true;
    		System.out.println("IndexHandler::rebuildIndex:START");
    		pauseContainerServices(true);
    		int cnt=10;
    		while(!allStopped) {
    			Thread.sleep(100);
    			if(cnt++>10)
    				break;
    		}	
    	clearContainers(true);
    	remakeProperties();
    		//System.out.println("IndexHandler::rebuildIndex:3");
    		pauseContainerServices(false);
    		//System.out.println("IndexHandler::rebuildIndex:FINISH");
    	}catch(Exception e) {
    		LOGGER.severe(e.toString());
    		//System.out.println("IndexHandler::rebuildIndex:resume services");
    	}
    }
    private void clearContainers(boolean onDisk) {
    	try {
    		if(indexCache!=null)
    			indexCache.clear(onDisk);
    		if(ownersCache!=null)
    			ownersCache.clear(onDisk);
    		if(valuesCache!=null)
    		   valuesCache.clear(onDisk);
    	}catch(Exception e) {
    		LOGGER.severe(e.toString());
    	}
    }
    private void  remakeProperties() {
    	//System.out.println("IndexHandler:remakeProperties:BEGIN");
    	if(rebuild)
    	try {
			File indexFile=new File(entihome$+"/"+PROPERTY_INDEX);
			if(indexFile.exists())
				indexFile.delete();
				index=makeNewIndex(entihome$);	
		}catch(Exception e) {
			System.out.println("IndexHandler:"+e.toString());
		}
    	if(entitiesCache==null) {
    		entitiesCache=new SackCachedRepository(entihome$,CONTAINER_ENTITIES,false);
    	}
    	entitiesCache.load();
    	if(ownersCache==null) 
    	   ownersCache=new SackCachedRepository(entihome$,CONTAINER_PROPERTY_OWNERS,true);
    	if(valuesCache==null) 
		valuesCache=new SackCachedRepository(entihome$,CONTAINER_PROPERTY_VALUES,true);
		String[] sa=entitiesCache.getKeys();
		//System.out.println("IndexHandler:remakeProperties:sa="+sa.length);
		if(sa==null||sa.length<1) {
    		System.out.println("IndexHandler:remakeProperties:entityCache empty");
    		return ;
    	}
    	if(index==null) {
    		System.out.println("IndexHandler:remakeProperties:index is null");
    		return;
    	}
    	if(!index.existsElement("label"))
    		index.createElement("label");
    	else
    		index.clearElement("label");
    	if(!index.existsElement("property"))
    		index.createElement("property");
    	else
    		index.clearElement("property");
    	Sack entity;
    	String label$;
    	String type$;
    	Core lcore;
    	String pvalue$;
    	String[] pa;
    	ArrayList<String>sl=new ArrayList<String>();
    	for(String s:sa) {
    		entity=entitiesCache.get(s);
    		if(entity==null) {
    			System.out.println("IndexHandler:remakeProperties:cannot get entity ="+s);
    			continue;
    		}
    		label$=entity.getProperty(Entigrator.LABEL);
    		//System.out.println("IndexHandler:remakeProperties:entity ="+label$+"  key="+getKey(label$));
    		String newLabel$=label$;
    		String key$=getKey(label$);
    		if(key$!=null&&!"null".equals(key$))
    		{
    			newLabel$=label$+Identity.key().substring(0,4);
    			Core[]ca=entity.elementGet("property");
    			for(Core c:ca)
    				if(label$.equals(c.type)) {
    					c.type=newLabel$;
    					entity.putElementItem("property", c);
    					entitiesCache.put(entity);
    				}
    		}
    		type$=entity.getProperty("entity");
    		lcore=new Core(type$,s,newLabel$);
    		//System.out.println("IndexHandler:remakeProperties:entry type="+type$+" name="+s+" value="+newLabel$);
    		index.putElementItem("label", lcore);
    		//if(label$==null||type$==null)
    		if(label$==null||label$.startsWith("_"))
    		{
    			//System.out.println("IndexHandler:remakeProperties:put label="+label$+"  type="+type$);	
    			entity=assignProperty("suspicious",Locator.LOCATOR_TRUE,s);
    			//continue;
    		}else
    			entity=removeProperty("suspicious", s);
    		pa=entity.listProperties();
    		if(pa==null)
    			continue;
    		for(String p:pa) {
    			try {
    			if(!"label".equals(p)) {
    			   pvalue$=entity.getProperty(p);
    		//	   System.out.println("IndexHandler:remakeProperties:5");
    			if(assignProperty(p,pvalue$,s)==null)
    				System.out.println("IndexHandler:remakeProperties:cannot assignProperty="+p+"  to entity key="+s );
    			}
    			}catch(Exception e) {
    				System.out.println("IndexHandler:remakeProperties:assignProperty"+e.toString());	
    			}
    		}
      	}
    	if(indexCache!=null) {
    	   indexCache.put(index);
    	   indexCache.dump();
    	}else {
    	index.setPath(entihome$+"/"+PROPERTY_INDEX);
      	index.store();
    	}
      	rebuild=false;
      	close();
      	System.exit(0);
    }
    private Sack getValueMap(String property$) {
    	String valueKey$=index.getElementItemAt("property", property$);
    	Sack valueMap=null;
    	if(!"null".equals(valueKey$))
    	    valueMap=valuesCache.get(valueKey$);
    	if(valueMap==null) {
    	valueMap=new Sack();
    	valueMap.setPath(entihome$+"/"+CONTAINER_PROPERTY_VALUES+"/data/"+valueMap.getKey());
    	valueMap.putAttribute(new Core(null,"property",property$));
    	valueMap.putAttribute(new Core(null,"container",CONTAINER_PROPERTY_VALUES));
    	valueMap.createElement("value");
    	valuesCache.put(valueMap);
    	}
    	return valueMap;
    }
  
    public String[] listEntityTypes() {
    	ArrayList<String>sl=new ArrayList<String>();
    	String[] sa=index.elementListNames("label");
    	String type$;
    	for(String s:sa) {
    		type$=index.getElementItem("label", s).type;
    		if(!sl.contains(type$)) {
    			sl.add(type$);
    		}
    	}
    	sa=new String[sl.size()];
    	return sl.toArray(sa);
    }
    public String[] listValues(String property$) {
    	if("label".equals(property$)) {
    		return index.elementListValues("label");
    	}
    	if(index==null)
    		return null;
    	String valueMap$=index.getElementItemAt("property", property$);
    	if(valueMap$==null)
    		return null;
    	Sack valueMap=valuesCache.get(valueMap$);
    	if(valueMap==null)
    		return null;
    	return valueMap.elementListNames("value");
    }
    public String[] listProperties() {
    	try {
    	if(index==null) 
    		index=Sack.readXml(entihome$+"/"+PROPERTY_INDEX);
    	if(index==null) {
    		System.out.println("IndexHandler:listProperties:cannot read index");
    		return null;
    	}
    	String[]sa= index.elementListNames("property");
    	String[]pa=new String[sa.length+1];
    	for(int i=0;i<sa.length;i++)
    		pa[i]=sa[i];
    	pa[sa.length]="label";
    	return pa;
    	}catch(Exception e) {
    		System.out.println("IndexHandler:listProperties:"+e.toString());
    	}
    	return null;
    }
    public String[] listEntities(String property$,String value$) {
    	if(property$==null) {
    		return null;
    	}
    	if(value$==null) {
    		 System.out.println("IndexHandler:listEntities:property="+property$+" value="+value$);
    		return null;
    	}
        if("label".contentEquals(property$)) {
        	return new String[] {index.getElementItemAtValue("label", value$)};
        }
    	String valueMap$=index.getElementItemAt("property", property$);
    	if(valueMap$==null) {
    	  index=indexCache.get(PROPERTY_INDEX);
    	  if(index==null) {
    		  System.out.println("IndexHandler:listEntities:cannot get global index");
    		return null;
    	  }
    	  valueMap$=index.getElementItemAt("property", property$);
    	}
    	Sack valueMap=valuesCache.get(valueMap$);
    	if(valueMap==null) {
    		System.out.println("IndexHandler:listEntities:property="+property$+" value="+value$+"  value map is null");
    		return null;
    	}
    	String ownerMap$=valueMap.getElementItemAt("value", value$);
    	if(ownerMap$==null) {
    		System.out.println("IndexHandler:listEntities:property="+property$+" value="+value$+"  no owners");
    		return null;
    	}
    	Sack ownerMap=ownersCache.get(ownerMap$);
    	if(ownerMap!=null)
         return ownerMap.elementListNames("entity");
    	else {
    		System.out.println("IndexHandler:listEntities:property="+property$+" value="+value$+" owner map is null");
    		return null;
    	}
    }
    public boolean deleteUnusedProperty(String property$) {
    	String[] sa=listEntities(property$);
    	if(sa!=null&&sa.length>0)
    		return deleteProperty(property$);
    	return true;
    }
    public boolean deleteUnusedProperties() {
    	String[] pa=listProperties();
    	if(pa!=null)
    	for(String p:pa)	
    		deleteUnusedProperty(p);
    	return true;
    }
    public boolean deleteUnusedValues(String property$) {
    	String[] va=listValues(property$);
    	if(va!=null)
    	for(String v:va)	
    		deleteUnusedValue(property$,v);
    	return true;
    }
    public boolean deleteUnusedValue(String property$,String value$) {
    	String[] sa=listEntities(property$,value$);
    	if(sa!=null&&sa.length>0)
    		return true;
    	return  deleteValue(property$,value$);
    }
    public String[] listEntities() {
    	return index.elementListNames("label");
    }
    public String[] listEntities(String property$) {
    	if(property$==null) {
    		return null;
    	}
    	if("label".equals(property$))
    		return new String[] {index.getElementItemAt("label", property$)};
    	 String valueMap$=index.getElementItemAt("property", property$);
    	//System.out.println("IndexHandler:listEntities:property="+property$+" value map="+valueMap$);
    	 if(valueMap$==null)
    		 return null;
    	Sack valueMap;
     	valueMap=valuesCache.get(valueMap$);
    	 if(valueMap==null)
    		 return null;
    	String[] va=valueMap.elementListNames("value");
    	
    	if(va==null)
    		return null;
    	Sack ownerMap;
    	ArrayList<String> el=new ArrayList<String>();
    	for(String v:va) {
    		//System.out.println("IndexHandler:listEntities:value="+v+"  ownerMap="+valueMap.getElementItemAt("value",v));
    		ownerMap=ownersCache.get(valueMap.getElementItemAt("value",v));
    		if(ownerMap==null)
    			continue;
       		String[] ea=ownerMap.elementListNames("entity");
    		if(ea==null)
    			continue;
    		for(String e:ea) {
    			el.add(e);
    		}
    	}
    	String[]sa=new String[el.size()];
    	el.toArray(sa);
    	return sa;
    }
    public Sack takeOffProperty(String property$,String entityKey$) {
       	if(property$==null||entityKey$==null||"label".equals(property$))
    		return null;
    	Sack entity=entitiesCache.get(entityKey$);
    	if(entity==null)
    		return null;
    	Core pcore=entity.getPropertyEntry(property$);
    	if(pcore==null) {
       		return entity;
    	}
       	String value$=pcore.value;
       	entity.removeElementItem("property", pcore.name);
    	entitiesCache.put(entity);
    	
    	String ownMap$=pcore.name;
    	Sack ownMap=ownersCache.get(ownMap$);
    	if(ownMap==null) {
    		System.out.println("IndexHandler:takeOffProperty:cannot find owner map"+ownMap$);
    		deleteValue(property$,value$);
    	}else {
    		ownMap.removeElementItem("entity", entityKey$);
        	Core[] ca=ownMap.elementGet("entity");
        	if(ca!=null) {
        	if(ca.length<1) {
        		ownersCache.delete(ownMap$);
        		deleteValue(property$,value$);
        	}else
        		ownersCache.put(ownMap);
    	 }
    	}
    	return entity;
    }
    public boolean editProperty(String property$,String newProperty$) {
    	Core property=index.getElementItem("property", property$);
    	if(property==null)
    		return false;
    	String[] ea=listEntities(property$);
    	if(ea!=null) {
    		Sack entity;
    		for(String e:ea) {
    			//System.out.println("IndexHandler:editProperty:list:entity="+e);
    	       	entity=entitiesCache.get(e);
    	       	if(entity!=null) {
    	       		Core[] ca=entity.elementGet("property$");
    	       		if(ca!=null)
    	       			for(Core c:ca) {
    	       				if(property$.equals(c.type)) {
    	       					//System.out.println("IndexHandler:editProperty:entity="+e);
    	       					entity.removeElementItem("property", c.name);
    	       					c.type=newProperty$;
    	       					entity.putElementItem("property", c);
    	       					entitiesCache.put(entity);
    	       				}
    	       			}
    	       	}
    		}
    	}
    	//else
//    		System.out.println("IndexHandler:editProperty:list:cannot list entities");
    	index.removeElementItem("property", property$);
    	property.name=newProperty$;
    	index.putElementItem("property", property);
    	indexCache.put(index);
    	return true;
    }
    public boolean editValue(String property$,String value$,String newValue$) {
    	if(property$==null||value$==null||newValue$==null)
    		return false;
    	if(value$.equals(newValue$))
    		return true;
        String valueMap$=index.getElementItemAt("property", property$);
        if(valueMap$==null)
        	return false;
    	Sack valueMap=valuesCache.get(valueMap$);
    	if(valueMap==null)
    		return false;
    	Core value=valueMap.getElementItem("value", value$);
    	if(value==null)
    		return false;
    	String ownerMap$=value.value;
    	if(ownerMap$!=null) {
    		Sack ownerMap=ownersCache.get(ownerMap$);
    		if(ownerMap!=null) {
    			String[] ea=ownerMap.elementListNames("entity");
    			if(ea!=null) {
    				Sack entity;
    				Core pentry=new Core(property$,ownerMap$,newValue$);
    				for(String e:ea) {
    			         entity=entitiesCache.get(e);
    			         if(entity!=null) {
    			        	 entity.putElementItem("property", pentry);
    			        	 entitiesCache.put(entity);
    			         }
    				}
    			}
    			ownerMap.putAttribute(new Core(null,"value",newValue$));
    			ownersCache.put(ownerMap);
    		}
    	}
    	valueMap.putElementItem("value", new Core(null,newValue$,ownerMap$));
    	valueMap.removeElementItem("value", value$);
    	valuesCache.put(valueMap);
    	return true;
    }
    public boolean deleteProperty(String property$) {
    	if(property$==null)
    		return false;
        String[] ea=listEntities(property$);
        if(ea!=null) {
        	Sack entity;
        	for(String e:ea) {
               	entity=entitiesCache.get(e);
               	if(entity==null)
               		continue;
               	Core[] ca=entity.elementGet("property");
               	if(ca!=null)
               		for(Core c:ca) {
               			if(property$.equals(c.type)) {
               				//entity.removeElementItem("property", c.name);
               				entity=removeProperty(property$,e);
               				entitiesCache.put(entity);
               			}
               		}
        	  }
          }
        String valueMap$=index.getElementItemAt("property", property$);
        if(valueMap$==null) {
        	index.removeElementItem("property", property$);
        	indexCache.put(index);
        	return true;	
        }
    	Sack valueMap=valuesCache.get(valueMap$);
    	if(valueMap==null) {
    		index.removeElementItem("property", property$);
        	indexCache.put(index);
    		return true;
    	}
    	String[] oa=valueMap.elementListNames("value");
    	if(oa!=null){	
    	Sack ownerMap;
    	for(String o:oa) {
    	   ownerMap=ownersCache.get(o);
    	   if(ownerMap!=null) 
    		   ownersCache.delete(o);
  		   valueMap.removeElementItem("value", o);
    	}	
    	}
    	valuesCache.delete(valueMap$);
		index.removeElementItem("property", property$);
    	indexCache.put(index);
    	return true;
    }
    public boolean deleteValue(String property$,String value$) {
    	if(property$==null||value$==null)
    		return false;
        String[] ea=listEntities(property$,value$);
        if(ea!=null) {
        	Sack entity;
        	for(String e:ea) {
               	entity=entitiesCache.get(e);
               	if(entity==null)
               		continue;
               	Core[] ca=entity.elementGet("property");
               	if(ca!=null)
               		for(Core c:ca) {
               			if(property$.equals(c.type)&&value$.equals(c.value)) {
               				entity.removeElementItem("property", c.name);
               				entitiesCache.put(entity);
               			}
               		}
        	  }
          }
        String valueMap$=index.getElementItemAt("property", property$);
      // System.out.println("Indexhandler:deleteValue:property="+property$+" value="+value$+" value map="+valueMap$);
        if(valueMap$!=null) {
    	Sack valueMap=valuesCache.get(valueMap$);
    	if(valueMap!=null) {
    	String ownerMap$=valueMap.getElementItemAt("value", value$);
    	if(ownerMap$!=null)
    		ownersCache.delete(ownerMap$);
   		 valueMap.removeElementItem("value", value$);
   		 valuesCache.put(valueMap);
    	}else
    		 System.out.println("Indexhandler:deleteValue:cannot get value map="+valueMap$);	
        }
   		return true;
    }
   
   public Sack assignLabel(String label$,String entityKey$) {
	   //System.out.println("IndexHandler:assignLabel:entity="+entityKey$+" label="+label$);
	   if(entityKey$==null||label$==null) {
		   System.out.println("IndexHandler:assignLabel: wrong argument ");
       	return null;
	   }
	   Sack entity=entitiesCache.get(entityKey$);
       if(entity==null) {
    	   System.out.println("IndexHandler:assignLabel:cannot get entity="+entityKey$);
          	return null;  
       }
       entity.putElementItem("property", new Core("label",entityKey$,label$));
       putEntity(entity);
       String type$=entity.getProperty("entity");
       index.putElementItem("label", new Core(type$,entityKey$,label$));
       indexCache.put(index);
      return entity;
   }
  
   public boolean addPropertyValue(String property$,String value$) {
      if(property$==null||value$==null)
   		return false;
   	try {
   	Sack valMap=null;
   	String valMap$=index.getElementItemAt("property", property$);
   	if(valMap$!=null) { 
   		valMap=valuesCache.get(valMap$);
   	}
   	if(valMap==null)
        {
       	valMap=new Sack();
       	valMap.setPath(entihome$+"/"+CONTAINER_PROPERTY_VALUES+"/data/"+valMap.getKey());
       	valMap.createElement("value");
       	valMap.putAttribute(new Core(null,"property",property$));
        index.putElementItem("property", new Core(null,property$,valMap.getKey()));
        indexCache.put(index);
       }
	String ownMap$=valMap.getElementItemAt("value", value$);
	Sack ownMap=null;
	if(ownMap$!=null) {
		ownMap=ownersCache.get(ownMap$);
		if(ownMap!=null) {
			System.out.println("IndexHandler:addPropertyValue:successfully get ownMap="+ownMap.getKey());	
		return true;
		}else
			System.out.println("IndexHandler:addPropertyValue:wrong entry "+ownMap$);	
	}
    if(ownMap==null) {
    	ownMap=new Sack();
    	ownMap.setPath(entihome$+"/"+CONTAINER_PROPERTY_OWNERS+"/data/"+ownMap.getKey());
    	ownMap.putAttribute(new Core(null,"property",property$));
    	ownMap.putAttribute(new Core(null,"value",value$));
    	ownMap.putAttribute(new Core(null,"valmap",valMap.getKey()));
    	valMap.putElementItem("value", new Core(null,value$,ownMap.getKey()));
    	valuesCache.put(valMap);
    	ownersCache.put(ownMap);
    }
   return true;
   	}catch(Exception e) {
   		System.out.println("IndexHandler:addPropertyValue:property="+property$+"  value="+value$);
   		return false;
   	}
   }
   public boolean addProperty(String property$) {
	     Core core=index.getElementItem("property", property$);
	     if(core==null)
         index.putElementItem("property", new Core(null,property$,null));
	     return true;
   }
   public Sack assignProperty(String property$,String value$,String entityKey$) {
    //System.out.println("IndexHandler:assignProperty:property="+property$+" value="+value$+" entity key="+entityKey$);
	   if(property$==null||value$==null||entityKey$==null)
    		return null;
    	if("label".equals(property$))
    		return assignLabel(value$,entityKey$);
    	try {
    	Sack valMap=null;
    	String valMap$=index.getElementItemAt("property", property$);
    	//System.out.println("IndexHandler:assignProperty:property="+property$+"   valMap="+valMap$);
    	if(valMap$!=null)  
    		valMap=valuesCache.get(valMap$);
    	if(valMap==null)
         {
        	valMap=new Sack();
        	valMap.setPath(entihome$+"/"+CONTAINER_PROPERTY_VALUES+"/data/"+valMap.getKey());
        	valMap.createElement("value");
        	valMap.putAttribute(new Core(null,"property",property$));
        	valMap.store();
            index.putElementItem("property", new Core(null,property$,valMap.getKey()));
        }
        Sack ownMap=null;
    	String ownMap$=valMap.getElementItemAt("value", value$);
    	
    	if(ownMap$!=null)
    		ownMap=ownersCache.get(ownMap$);
        if(ownMap==null) {
        	ownMap=new Sack();
        	ownMap.setPath(entihome$+"/"+CONTAINER_PROPERTY_OWNERS+"/data/"+ownMap.getKey());
        	ownMap.createElement("entity");
        	ownMap.putAttribute(new Core(null,"property",property$));
        	ownMap.putAttribute(new Core(null,"value",value$));
        	ownMap.putAttribute(new Core(null,"valmap",valMap.getKey()));
        	//System.out.println("IndexHandler:assignProperty:ownerMap:2");
        	valMap.putElementItem("value", new Core(null,value$,ownMap.getKey()));
        	valuesCache.put(valMap);
        	//valMap.save();
        	valMap.store();
        	 }
        	ownMap.putElementItem("entity", new Core(null,entityKey$,null));
        	//System.out.println("IndexHandler:assignProperty:ownerMap created");
        	ownersCache.put(ownMap);
        	//ownMap.save();
        	ownMap.store();
        	//System.out.println("IndexHandler:assignProperty:ownerMap:4");   
        Sack entity=entitiesCache.get(entityKey$);
        if(entity!=null) {
        	if(!entity.existsElement("property"))
        		entity.createElement("property");
        	entity.removePropertyEntry(property$);
        	entity.putElementItem("property", new Core(property$,ownMap.getKey(),value$));
        	entitiesCache.put(entity);
        }
        return entity;
    	}catch(Exception e) {
    		System.out.println("IndexHandler:assignProperty:property="+property$+"  value="+value$);
    		return null;
    	}
    }
   public Sack removeProperty(String property$,String entityKey$) {
		   if(property$==null||entityKey$==null)
	    		return null;
	    	if("label".equals(property$))
	    		return null;
	    	try {
	    	Sack entity=entitiesCache.get(entityKey$);
		    if(entity!=null) {
		    	    Core[] ca=entity.elementGet("property");
		    	    for(Core c:ca) {
		    	    	if(property$.equals(c.type)) {
		    	    		Sack ownMap=ownersCache.get(c.name);
		    	    		if(ownMap!=null) {
		    	    			ownMap.removeElementItem("entity", entityKey$);
		    	    			ownersCache.put(ownMap);
		    	    		}
		    	    	entity.removeElementItem("property", c.name);
		    	    	entitiesCache.put(entity);
		    	    	}
		    	    }
		        }
		    return entity;
	    	}catch(Exception e) {
	    		System.out.println("IndexHandler:removeProperty:"+e.toString());
	    		return null;
	    	}
	    }
   public void pauseContainerServices(boolean pause) {
    	try {
    		if(indexCache!=null) {
    		if(pause)	
    		  indexCache.terminate();
    		else
    		indexCache.start();
    		}
    		if(ownersCache!=null) {
    			if(pause)	
    				ownersCache.terminate();
    	    	else
    	    		ownersCache.start();
    		}
    		if(valuesCache!=null) {
    			if(pause)	
    				valuesCache.terminate();
    	    	else
    	    		valuesCache.start();    			
    		
    		}
    		if(entitiesCache!=null) {
    			if(pause)	
    				entitiesCache.terminate();
    	    	else
    	    		entitiesCache.start();
    		
    		}
    	}catch(Exception e) {
    		LOGGER.severe(e.toString());
    	}
    }
   
public void stopRefresh() {
if(entitiesCache!=null)
	entitiesCache.execRefresh(2);
}
public void startRefresh() {
if(entitiesCache!=null)
	entitiesCache.execRefresh(1);
}  
public void setDelay(int delay) {
	indexCache.setDelay(delay);
	ownersCache.setDelay(delay);
	valuesCache.setDelay(delay);
	entitiesCache.setDelay(delay);
}
@Override
public void propertyChange(PropertyChangeEvent evt) {
	//System.out.println("IndexHandler:propertyChange:evt="+evt.getPropertyName());
	pcs.firePropertyChange(evt);	
} 
public void setPropertyChangeListener(PropertyChangeListener pcl) {
	pcs.addPropertyChangeListener(pcl);
}
}