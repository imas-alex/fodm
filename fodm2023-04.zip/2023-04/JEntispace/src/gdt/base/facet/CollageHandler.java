package gdt.base.facet;

import java.util.Properties;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;

public class CollageHandler extends FacetHandler{
	public static final String KEY="_V3la4lHnj_SbNbh5sLOLzxYKeRu4";	
	public static final String COLLAGE_FACET_NAME="Collage";
	public static final String COLLAGE_FACET_TYPE="collage";
	public static final String COLLAGE_FACET_CLASS="gdt.base.facet.CollageHandler";
	public CollageHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,COLLAGE_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,COLLAGE_FACET_CLASS);
		locator.put(FACET_TYPE,COLLAGE_FACET_TYPE);
		locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
		locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.CollageMaster");
		return Locator.toString(locator);
	}
	@Override
	public String getName() {
		return COLLAGE_FACET_NAME;
	}

	@Override
	public String getType() {
		return COLLAGE_FACET_TYPE;
	}
	@Override
	public String getFacetClass() {
		return COLLAGE_FACET_CLASS;
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
			return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
			return null;
	}
}
