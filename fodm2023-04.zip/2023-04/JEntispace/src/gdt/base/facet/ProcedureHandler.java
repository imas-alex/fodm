package gdt.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.util.Properties;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.FileTool;
public class ProcedureHandler extends FacetHandler{
	public static final String KEY="_LMKuj_Cx5WNeBYTVhBieTOLruqI";	
	public static final String PROCEDURE_FACET_NAME="Procedure";
	public static final String PROCEDURE_FACET_TYPE="procedure";
	public static final String PROCEDURE_FACET_CLASS="gdt.base.facet.ProcedureHandler";
	public ProcedureHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}
	
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return add(entigrator, entity);
	}
		
	public static Sack add(Entigrator entigrator, Sack entity) {
		try { 
            entity=FolderHandler.add(entigrator, entity);
	        entity=entigrator.assignProperty(PROCEDURE_FACET_TYPE,Locator.LOCATOR_TRUE,entity.getKey());
	        
	        String facetLocator$=classLocator();
	        facetLocator$=Locator.append(facetLocator$, Entigrator.ENTITY_LABEL, entity.getProperty(Entigrator.LABEL));
	        entity.putElementItem(FACET, new Core(ModuleHandler.SYSTEM,KEY,facetLocator$));
	        entigrator.putEntity(entity);
	        }catch(Exception e) {
	        	System.out.println("ProcedureHandler:add:"+e.toString());
	        }
		return entity;
	}

	
	public  static Sack delete (Entigrator entigrator, Sack entity) {
		try {
			 String path$=entigrator.getEntihome()+"/"+entity.getKey();
		     FileTool.delete(path$+"/src");
		     FileTool.delete(path$+"/bin");
		     File classpath=new File(".classpath");
		     if(classpath.exists())
		    	 classpath.delete();
		     File project=new File(".project");
		     if(project.exists())
		    	 project.delete();
		     
		     entity=entigrator.takeOffProperty(PROCEDURE_FACET_TYPE, entity.getKey());
		     entity.removeElementItem(FACET, KEY);
		     entigrator.putEntity(entity);
		}catch(Exception e) {
			System.out.println("ProcedureHandler:delete:"+e.toString());
		}
		return entity;
	}

	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,PROCEDURE_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_TRUE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_TRUE);
		locator.put(FACET_HANDLER_CLASS,PROCEDURE_FACET_CLASS);
		locator.put(FACET_TYPE,PROCEDURE_FACET_TYPE);
		locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
		locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.ProcedureMaster");
		return Locator.toString(locator);
	}

	@Override
	public String getKey() {
			return KEY;
	}
	@Override
	public String getName() {
		return PROCEDURE_FACET_NAME;
	}
	@Override
	public String getType() {
			return PROCEDURE_FACET_TYPE;
	}
	@Override
	public String getFacetClass() {
		return PROCEDURE_FACET_CLASS;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return null;
	}
	public static void main( String[] args) {
		try {
		String cmd = "gnome-terminal";
		 Runtime run = Runtime.getRuntime();
		 Process pr = run.exec(cmd);
		}catch(Exception e) {
			 System.err.println("An exception occurred: "+e.toString());
		}
	}
}
