package gdt.base.facet;

import java.awt.Dimension;
import java.util.Properties;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;

public class FrameHandler extends FacetHandler{
	public static final String KEY="_tGTjpJYtM_S57dSFqrBvnSriVLFI";	
	public static final String FRAME_FACET_NAME="Frame";
	public static final String FRAME_FACET_TYPE="Frame";
	public static final String FRAME_FACET_CLASS="gdt.base.facet.FrameHandler";
	public FrameHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}
	@Override
	public String getName() {
		return FRAME_FACET_NAME;
	}

	@Override
	public String getType() {
		return FRAME_FACET_TYPE;
	}

	@Override
	public String getFacetClass() {
		return FRAME_FACET_CLASS;
	}
	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
			return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
			return null;
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,FRAME_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,FRAME_FACET_CLASS);
		locator.put(FACET_TYPE,FRAME_FACET_TYPE);
		locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
		locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.FrameMaster");
		return Locator.toString(locator);
	}
	public Dimension getSize() {
		System.out.println("FrameHandler:getSize:locator="+locator$);
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			if(entity$==null)
				return null;
			Sack entity=entigrator.getEntityAtLabel(entity$);
			if(entity==null)
				return null;
			Core[] ca=entity.elementGet("perspective");
			if(ca==null)
				return null;
			System.out.println("FrameHandler:getSize:ca="+ca.length);
		}catch(Exception e) {
			System.out.println("FrameHandler:getSize:"+e.toString());	
		}
		return null;
	}
}
