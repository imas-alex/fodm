package gdt.gui.facet.procedure;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Properties;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JEditorPane;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.border.TitledBorder;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;
public class JProcedureConsole extends JGuiEditor {
	public static final String KEY="_j_S3FltUS8a_2Wn7BflwzWuR_SzG0";
	private static final long serialVersionUID = 1L;
	private	JEditorPane sourcePanel;
	private	JEditorPane reportPanel;
	private JSplitPane splitPane;
	public JProcedureConsole(JMainConsole console, String alocator$) {
		super(console, alocator$);
		locator$=Locator.append(locator$, JContext.DEFAULT_PARENT, JAdminPanel.KEY);
		//System.out.println("JProcedureConsole:locator="+locator$);
		sourcePanel = new JEditorPane();
		JScrollPane scrollPaneTop = new JScrollPane(sourcePanel);
		scrollPaneTop.setBorder(BorderFactory.createTitledBorder(BorderFactory
		        .createEtchedBorder(), "Java Source", TitledBorder.CENTER,
		        TitledBorder.TOP));
		reportPanel = new JEditorPane();
		JScrollPane scrollPaneBottom = new JScrollPane(reportPanel);
		scrollPaneBottom.setBorder(BorderFactory.createTitledBorder(BorderFactory
		        .createEtchedBorder(), "Report", TitledBorder.CENTER,
		        TitledBorder.TOP));
		setLayout(new BorderLayout(0, 0));
		splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,scrollPaneTop,scrollPaneBottom);
		splitPane.setDividerLocation(0.5);
		add(splitPane);
		entity$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
		entityKey$=console.getEntigrator().getKey(entity$);
		readSource();
	}
	private void readSource() {
		File source=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src/"+entityKey$+".java");
		 if(source.exists()){
	         try {  
			 FileInputStream fis = new FileInputStream(source);
	            InputStreamReader ins = new InputStreamReader(fis, "UTF-8");
	            BufferedReader rds = new BufferedReader(ins);
	            String ss ;
	            StringBuffer sbs=new StringBuffer();
		    	while((ss = rds.readLine()) != null){
		    	    sbs.append(ss+"\n");
		    	}
		    	rds.close();
		    	sourcePanel.setText(sbs.toString());
		    	fis.close();
	         }catch(Exception e) {
	        	 System.out.println("JProcedureConsole:"+e.toString());
	         }
		 }else {
			 sourcePanel.setText("Cannot read source="+source.getPath());
		 }
	}
	@Override
	public JMenu getContextMenu() {
    	//System.out.println("JItemsListPanel:getContextMenu:BEGIN");	
		JMenu menu=super.getContextMenu();
		menu.addSeparator();
		JMenuItem runItem = new JMenuItem("Run");
		runItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Thread proc=new Thread() {
						public void run() {
							try{
								entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
								entityKey$=console.getEntigrator().getKey(entity$);
							//	System.out.println("JProcedureConsole:run:class file="+console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin/"+entityKey$+".class");
								File procedureClass=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin/"+entityKey$+".class");
								if(!procedureClass.exists()) {
									System.out.println("JProcedureConsole:cannot find class file="+procedureClass.getPath());
								   return;
								}
							//	System.out.println("JProcedureConsole:run:procedure home="+console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin");
								File bin=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin");
								URL url=bin.toURI().toURL();
								URLClassLoader cl=new URLClassLoader(new URL[]{url});
								Class<?> cls =cl.loadClass(entityKey$);
								Object obj=cls.getDeclaredConstructor().newInstance();
					   			  Method method = obj.getClass().getDeclaredMethod("exec",JMainConsole.class,String.class,JEditorPane.class);
					  	 		  method.invoke(obj,console,locator$,reportPanel);
							}catch(Exception e){
								Logger.getLogger(getClass().getName()).severe(e.toString());
							}
						}
					};
					proc.start();
					}catch(Exception ee) {
						System.out.println("JProcedureConsole:run:"+ee.toString());
					}
			}
		} );
		menu.add(runItem);
		JMenuItem folderItem = new JMenuItem("Folder");
		folderItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try{
					//	System.out.println("FolderMaster:entityFacetsItemOnClick:locator="+locator$);
						String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
						Entigrator entigrator=console.getEntigrator();
						String entityKey$=entigrator.getKey(entityLabel$);
						File folder=new File(entigrator.getEntihome()+"/"+entityKey$);
						Desktop.getDesktop().open(folder);
						}catch(Exception ee){
							System.out.println("ProcedureConsole:entityFacetsItemOnClick:"+ee.toString());
						}
			}
		} );
		menu.add(folderItem);
		JMenuItem resetItem = new JMenuItem("Reset");
		resetItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int response = JOptionPane.showConfirmDialog(JProcedureConsole.this, "Really destroy procedure ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	  		    if (response == JOptionPane.YES_OPTION) {
				    createSource();
					readSource();
	  		    }
			}
		} );
		menu.add(resetItem);
		JMenuItem refreshItem = new JMenuItem("Refresh");
		refreshItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					readSource();
			}
		} );
		menu.add(refreshItem);
		   return menu;
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.facet.procedure.JProcedureConsole");
	    locator.put(Locator.LOCATOR_TITLE,"Procedure console");
		locator.put(INSTANCE, KEY);
		locator.put(IconLoader.ICON_FILE,"procedure.png");
	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(DEFAULT_PARENT, JAdminPanel.KEY);
		 return Locator.toString(locator);
	   }
	private void run(){
		try{
			entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			entityKey$=console.getEntigrator().getKey(entity$);
			File procedureClass=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin/"+entityKey$+".class");
			if(!procedureClass.exists()) {
				System.out.println("JProcedureConsole:cannot find class file="+procedureClass.getPath());
			   return;
			}
			console.getEntigrator().addURL(console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin");
			Class<?> cls =console.getEntigrator().getClass(entityKey$);
   		   Object obj=cls.getDeclaredConstructor().newInstance();
  		  Method method = obj.getClass().getDeclaredMethod("exec",JMainConsole.class,String.class,JEditorPane.class);
  		  method.invoke(obj,console,locator$,reportPanel);
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
	}
	private void createSource(){
		try{
//			System.out.println("JProcedurePanel:createSource.procedure key="+procedureKey$);
			File sourceHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src");
			if(!sourceHome.exists())
				sourceHome.mkdirs();
			File binHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin");
			if(!binHome.exists())
				binHome.mkdirs();
			File procedureJava=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src/"+entityKey$+".java");
			if(!procedureJava.exists())
				procedureJava.createNewFile();
			 FileOutputStream fos = new FileOutputStream(procedureJava, false);
			 Writer writer = new OutputStreamWriter(fos, "UTF-8");
			 writer.write("import javax.swing.JEditorPane;\n");
				writer.write("import gdt.gui.console.JMainConsole;\n");
				writer.write("import gdt.gui.facet.procedure.Procedure;\n");
				writer.write("public class " +entityKey$+"  implements Procedure {\n");
				writer.write("private final static String ENTITY_KEY=\""+entityKey$+"\";\n");
    			writer.write("public "+entityKey$+" (){} \n");
				writer.write("@Override\n");
				writer.write("public void exec(JMainConsole console, String locator$, JEditorPane reportPanel) {\n");
				writer.write("System.out.println(ENTITY_KEY+\":\"+locator$);\n");
		        writer.write("reportPanel.setText(locator$);\n");
				writer.write("	}\n");
				writer.write("}\n");
			 writer.close();   
			
		}catch(Exception e){
			Logger.getLogger(getClass().getName()).severe(e.toString());
		}
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
}

