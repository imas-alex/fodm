package gdt.gui.facet.collage;


import java.util.Properties;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JSetEditor;
public class JCollageEditor extends JSetEditor{
	
	JCollageDisplay collageDisplay;
	
	public JCollageEditor(JMainConsole console, String alocator$) {
		super(console, alocator$);
		JItemPanel[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa) {
				addItem(ip);
			}
	}
	private static final long serialVersionUID = 1L;
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.facet.collage.JCollageEditor");
	    locator.put(Locator.LOCATOR_TITLE,"Collage editor");
		locator.put(IconLoader.ICON_FILE,"collage.png");
	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(DEFAULT_PARENT, JAdminPanel.KEY);
		 return Locator.toString(locator);
	   }

	@Override
	public String reply(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getClassLocator() {
				return classLocator();
	}
	@Override
	protected void showSet() {
		try {
			String collageDisplay$=JCollageDisplay.classLocator();
			collageDisplay$=Locator.append(collageDisplay$, Entigrator.ENTITY_LABEL,entity$);
			collageDisplay=new JCollageDisplay(console,collageDisplay$);
				}catch(Exception e) {
					System.out.println("JCollageEditor:showRack:"+e.toString());
				}
	}
	@Override
	protected void toFront() {
		collageDisplay.toFront();
	}
	@Override
	protected void dispose() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void paste() {
	pasteToSet();
	rebuild(console);	
	}

	@Override
	protected void deleteItem(String item$) {
		// TODO Auto-generated method stub
		
	}
	}

