package gdt.gui.facet.rack;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;

import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class JRackDesign extends JDialog {
	String entity$;
	JMainConsole console;
	JComboBox<String> columnCbx;
	JComboBox<String> rowCbx;
	JRackFrame desktop;
	public JRackDesign(JMainConsole console,String locator$, JRackFrame desktop) {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				desktop.cancelGrid();
			}
		});
		this.console=console;
		this.desktop=desktop;
		setTitle("Rack design");
		setModal(true);
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {0, 0,1};
		gridBagLayout.rowHeights = new int[] {0, 0, 0,  2};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0,Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0,  Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel columnLbl = new JLabel(" Columns");
		GridBagConstraints gbc_lblColumn = new GridBagConstraints();
		gbc_lblColumn.insets = new Insets(5, 5, 5, 5);
		gbc_lblColumn.anchor=GridBagConstraints.CENTER;
		gbc_lblColumn.insets = new Insets(0, 0, 5, 0);
		gbc_lblColumn.gridx = 0;
		gbc_lblColumn.gridy = 0;
		getContentPane().add(columnLbl, gbc_lblColumn);
		
		columnCbx = new JComboBox<String>();
		columnCbx.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				setGrid();
			}
		});
		columnCbx.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		GridBagConstraints gbc_columnCbx = new GridBagConstraints();
		gbc_columnCbx.insets = new Insets(5, 5, 5, 5);
		gbc_columnCbx.fill = GridBagConstraints.HORIZONTAL;
		gbc_columnCbx.gridx = 1;
		gbc_columnCbx.gridy = 0;
		getContentPane().add(columnCbx, gbc_columnCbx);
		
		JLabel rowLbl = new JLabel(" Rows");
		GridBagConstraints gbc_lblRow = new GridBagConstraints();
		gbc_lblRow.insets = new Insets(5, 5, 5, 5);
		gbc_lblRow.anchor=GridBagConstraints.CENTER;
		gbc_lblRow.insets = new Insets(0, 0, 5, 0);
		gbc_lblRow.gridx = 0;
		gbc_lblRow.gridy = 1;
		getContentPane().add(rowLbl, gbc_lblRow);
		
		rowCbx = new JComboBox<String>();
		rowCbx.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				setGrid();
			}
		});
		rowCbx.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		GridBagConstraints gbc_rowCbx = new GridBagConstraints();
		gbc_rowCbx.insets = new Insets(5, 5, 5, 5);
		gbc_rowCbx.fill = GridBagConstraints.HORIZONTAL;
		gbc_rowCbx.gridx = 1;
		gbc_rowCbx.gridy = 1;
		getContentPane().add(rowCbx, gbc_rowCbx);
		
		JButton cancelBtn = new JButton("Cancel");
		cancelBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				desktop.cancelGrid();
				dispose();
			}
		});
		GridBagConstraints gbc_cancelBtn = new GridBagConstraints();
		gbc_cancelBtn.anchor=GridBagConstraints.LINE_END;
		gbc_cancelBtn.insets = new Insets(5, 5, 5, 5);
		gbc_cancelBtn.gridx = 0;
		gbc_cancelBtn.gridy = 2;
		getContentPane().add(cancelBtn, gbc_cancelBtn);
		
		JButton okBtn = new JButton("OK");
		okBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				desktop.cancelGrid();
				desktop.saveDesign();
				dispose();
			}
		});
		GridBagConstraints gbc_okBtn = new GridBagConstraints();
		gbc_okBtn.anchor=GridBagConstraints.LINE_START;
		gbc_okBtn.insets = new Insets(5, 5, 5, 5);
		gbc_okBtn.gridx = 1;
		gbc_okBtn.gridy = 2;
		getContentPane().add(okBtn, gbc_okBtn);
		pack();
		revalidate();
		repaint();
		init();
		//setGrid();
		desktop.setDrawgrid(true);
		
}
	private void setGrid() {
		String col$=(String)columnCbx.getSelectedItem();
		String row$=(String)rowCbx.getSelectedItem();
		int col=Integer.parseInt(col$);
		int row=Integer.parseInt(row$);
		desktop.setGrid(col, row);
	}
	private void init() {
		try {
		Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		Core grid=entity.getElementItem("rack.desktop", "grid");
		int col=Integer.parseInt(grid.type);
		int row=Integer.parseInt(grid.value);
		columnCbx.setSelectedIndex(col-1);
		rowCbx.setSelectedIndex(row-1);
		}catch(Exception e) {
			System.out.println("JGridDialog:init:"+e.toString());
		}
	}
}