package gdt.gui.facet.rack;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;

import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JInternalDisplay;

public class JRackArrangeElement extends JDialog{
	String desktop$;
	String item$;
	String locator$;
	JMainConsole console;
	JComboBox<String> columnCbx;
	JComboBox<String> rowCbx;
	JComboBox<String> widthCbx;
	JComboBox<String> heightCbx;
	JRackElement rackElement;
	public JRackArrangeElement(JMainConsole console,String locator$) {
		this.console=console;
		this.locator$=locator$;
		desktop$=Locator.getProperty(locator$, JInternalDisplay.INTERNAL_DISPLAY_DESKTOP);
		//System.out.println("JArrangeElement:locator="+locator$);
		setTitle("Arrange");
		setModal(true);
		item$=Locator.getProperty(locator$,JInternalDisplay.INTERNAL_DISPLAY_ITEM);
		//System.out.println("JArrangeElement:rack="+desktop$+" item="+item$+"  locator="+locator$ );		
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {0, 0,1};
		gridBagLayout.rowHeights = new int[] {0, 0, 0, 0,0,0, 2};
		gridBagLayout.columnWeights = new double[]{0.0, 0.0,Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0,0.0, 0.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel columnLbl = new JLabel(" Column");
		GridBagConstraints gbc_lblColumn = new GridBagConstraints();
		gbc_lblColumn.insets = new Insets(5, 5, 5, 5);
		gbc_lblColumn.anchor=GridBagConstraints.CENTER;
		gbc_lblColumn.insets = new Insets(0, 0, 5, 0);
		gbc_lblColumn.gridx = 0;
		gbc_lblColumn.gridy = 0;
		getContentPane().add(columnLbl, gbc_lblColumn);
		
		columnCbx = new JComboBox<String>();
		columnCbx.setModel(new DefaultComboBoxModel<String>(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		GridBagConstraints gbc_columnCbx = new GridBagConstraints();
		gbc_columnCbx.insets = new Insets(5, 5, 5, 5);
		gbc_columnCbx.fill = GridBagConstraints.HORIZONTAL;
		gbc_columnCbx.gridx = 1;
		gbc_columnCbx.gridy = 0;
		getContentPane().add(columnCbx, gbc_columnCbx);
		
		JLabel rowLbl = new JLabel(" Row");
		GridBagConstraints gbc_lblRow = new GridBagConstraints();
		gbc_lblRow.insets = new Insets(5, 5, 5, 5);
		gbc_lblRow.anchor=GridBagConstraints.CENTER;
		gbc_lblRow.insets = new Insets(0, 0, 5, 0);
		gbc_lblRow.gridx = 0;
		gbc_lblRow.gridy = 1;
		getContentPane().add(rowLbl, gbc_lblRow);
		
		rowCbx = new JComboBox<String>();
		rowCbx.setModel(new DefaultComboBoxModel<String>(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		GridBagConstraints gbc_rowCbx = new GridBagConstraints();
		gbc_rowCbx.insets = new Insets(5, 5, 5, 5);
		gbc_rowCbx.fill = GridBagConstraints.HORIZONTAL;
		gbc_rowCbx.gridx = 1;
		gbc_rowCbx.gridy = 1;
		getContentPane().add(rowCbx, gbc_rowCbx);
		
		JLabel widthLbl = new JLabel(" Width");
		GridBagConstraints gbc_lblWidth = new GridBagConstraints();
		gbc_lblWidth.insets = new Insets(5, 5, 5, 5);
		gbc_lblWidth.anchor=GridBagConstraints.CENTER;
		gbc_lblWidth.insets = new Insets(0, 0, 5, 0);
		gbc_lblWidth.gridx = 0;
		gbc_lblWidth.gridy = 2;
		getContentPane().add(widthLbl, gbc_lblWidth);
		
		widthCbx = new JComboBox<String>();
		GridBagConstraints gbc_widthCbx = new GridBagConstraints();
		gbc_widthCbx.insets = new Insets(5, 5, 5, 5);
		gbc_widthCbx.fill = GridBagConstraints.HORIZONTAL;
		gbc_widthCbx.gridx = 1;
		gbc_widthCbx.gridy = 2;
		getContentPane().add(widthCbx, gbc_widthCbx);
		
		JLabel heightLbl = new JLabel(" height");
		GridBagConstraints gbc_lblheight = new GridBagConstraints();
		gbc_lblheight.insets = new Insets(5, 5, 5, 5);
		gbc_lblheight.anchor=GridBagConstraints.CENTER;
		gbc_lblheight.insets = new Insets(0, 0, 5, 0);
		gbc_lblheight.gridx = 0;
		gbc_lblheight.gridy = 3;
		getContentPane().add(heightLbl, gbc_lblheight);
		
		heightCbx = new JComboBox<String>();
		GridBagConstraints gbc_heightCbx = new GridBagConstraints();
		gbc_heightCbx.insets = new Insets(5, 5, 5, 5);
		gbc_heightCbx.fill = GridBagConstraints.HORIZONTAL;
		gbc_heightCbx.gridx = 1;
		gbc_heightCbx.gridy = 3;
		getContentPane().add(heightCbx, gbc_heightCbx);
		
		JButton cancelBtn = new JButton("Cancel");
		cancelBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		GridBagConstraints gbc_columnBtn = new GridBagConstraints();
		gbc_columnBtn.anchor=GridBagConstraints.LINE_END;
		gbc_columnBtn.insets = new Insets(5, 5, 5, 5);
		gbc_columnBtn.gridx = 0;
		gbc_columnBtn.gridy = 4;
		getContentPane().add(cancelBtn, gbc_columnBtn);
		
		JButton okBtn = new JButton("OK");
		okBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				save();
				dispose();
			}
		});
		GridBagConstraints gbc_okBtn = new GridBagConstraints();
		gbc_okBtn.anchor=GridBagConstraints.LINE_START;
		gbc_okBtn.insets = new Insets(5, 5, 5, 5);
		gbc_okBtn.gridx = 1;
		gbc_okBtn.gridy = 4;
		getContentPane().add(okBtn, gbc_okBtn);
		init();
}
	private void init() {
		try {
			Sack rack=console.getEntigrator().getEntityAtLabel(desktop$);
			Core grid=rack.getElementItem("rack.desktop", "grid");
			int cols=Integer.parseInt(grid.type);
			int rows=Integer.parseInt(grid.value);
			String [] cla=new String[cols];
			String [] rwa=new String[rows];
			for(int i=0;i<cols;i++)
				cla[i]=String.valueOf(i+1);
			DefaultComboBoxModel<String> clmodel=new DefaultComboBoxModel<String>(cla);
			columnCbx.setModel(clmodel);
			DefaultComboBoxModel<String> wmodel=new DefaultComboBoxModel<String>(cla);
			widthCbx.setModel(wmodel);
			for(int i=0;i<rows;i++)
				rwa[i]=String.valueOf(i+1);
			DefaultComboBoxModel <String>rwmodel=new DefaultComboBoxModel<String>(rwa);
			rowCbx.setModel(rwmodel);
			DefaultComboBoxModel <String>hmodel=new DefaultComboBoxModel<String>(rwa);
			heightCbx.setModel(hmodel);
		//	System.out.println("JArrangeElement:init:item$="+item$);
			Core position= rack.getElementItem("rack.position", item$);
			 if(position!=null) {
				 JContext.selectCombo(columnCbx, position.type);
				 JContext.selectCombo(rowCbx, position.value);
			 }
			 Core area= rack.getElementItem("rack.area",item$);
			 if(area!=null) {
				 JContext.selectCombo(widthCbx, area.type);
				 JContext.selectCombo(heightCbx, area.value);
			 }
		}catch(Exception e) {
			System.out.println("JArrangeElement:init:"+e.toString());
		}
	}
	public void setRackElement(JRackElement rackElement) {
		this.rackElement=rackElement;
	}
	private void save() {
		try {
			Sack rack=console.getEntigrator().getEntityAtLabel(desktop$);
//			System.out.println("JArrangeElement:save:item="+item$+" context locator="+rack.getElementItemAt("set", item$));
			if(!rack.existsElement("rack.position"))
				rack.createElement("rack.position");
			if(!rack.existsElement("rack.area"))
				rack.createElement("rack.area");
			String column$=(String)columnCbx.getSelectedItem();
			String row$=(String)rowCbx.getSelectedItem();
			String width$=(String)widthCbx.getSelectedItem();
			String height$=(String)heightCbx.getSelectedItem();
			rack.putElementItem("rack.position", new Core(column$,item$,row$));
			rack.putElementItem("rack.area", new Core(width$,item$,height$));
			rackElement.getRackFrame().updateDesktop();
			console.getEntigrator().putEntity(rack);
		}catch(Exception e) {
			System.out.println("JRackArrangeElement:save:"+e.toString());
		}
	}
}
