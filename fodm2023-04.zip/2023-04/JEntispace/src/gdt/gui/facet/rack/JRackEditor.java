package gdt.gui.facet.rack;

import java.util.Properties;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JSetEditor;

public class JRackEditor extends JSetEditor{
	JMenuItem deleteItem;
	JMenuItem pasteItem;
	JRackDisplay rackDisplay;
	
	public JRackEditor(JMainConsole console, String alocator$) {
		super(console, alocator$);
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		JItemPanel[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa) {
				addItem(ip);
			}
	}
	private static final long serialVersionUID = 1L;
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.facet.rack.JRackEditor");
	    locator.put(Locator.LOCATOR_TITLE,"Rack editor");
		locator.put(IconLoader.ICON_FILE,"rack.png");
	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(DEFAULT_PARENT, JAdminPanel.KEY);
		 return Locator.toString(locator);
	   }

	@Override
	public String reply(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getClassLocator() {
				return classLocator();
	}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		return menu;
		}
@Override	
	public void showSet() {
		try {
			String rackDisplay$=JRackDisplay.classLocator();
			rackDisplay$=Locator.append(rackDisplay$, Entigrator.ENTITY_LABEL,entity$);
			rackDisplay=new JRackDisplay(console,rackDisplay$);
				}catch(Exception e) {
					System.out.println("JRackEditor:showRack:"+e.toString());
				}
	}
	public void paste() {
		try {
		  Core[] ca=SessionHandler.getSession(console.getEntigrator()).elementGet(SessionHandler.COPY);
		  if(ca==null||ca.length<1) {
			  System.out.println("JRackEditor:paste:no copies");
			  return;
		  }
 		Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		   if(!entity.existsElement("set"))
			   entity.createElement("set");
		 Core [] ca2=entity.elementGet("set"); 
		 //System.out.println("JRackEditor:paste:copies="+ca.length+" members="+ca2.length);
		 for(Core c:ca) {
//			 System.out.println("JRackEditor:paste:entity key="+c.name);
  			 String entityLocator$=console.getEntigrator().getEntityLocator(c.name);
			 entityLocator$=Locator.append(entityLocator$, JContext.CONTEXT_CLASS, "gdt.gui.entity.JEntityFacetList");
			 Core cc=new Core("Entity",Identity.key(),entityLocator$);
			 entity.putElementItem("set", cc);
		 }
		  console.getEntigrator().putEntity(entity);
		  clear();
		  JItemPanel[] ipa=getItems(console, locator$);
			if(ipa!=null)
				for(JItemPanel ip:ipa) {
					addItem(ip);
				}
		}catch(Exception e){
			System.out.println("JRackEditor:paste:"+e.toString());
		}
	}
	@Override
	protected void dispose() {
		rackDisplay.dispose();
	}
	@Override
	protected void toFront() {
		if(rackDisplay!=null)
			rackDisplay.toFront();
	}
	@Override
	public void deleteItem(String item$) {
		set.removeElementItem("set", item$);
		set.removeElementItem("rack.size", item$);
		set.removeElementItem("rack.position", item$);
		set.removeElementItem("rack.location", item$);
		set.removeElementItem("rack.area", item$);
		console.getEntigrator().putEntity(set);
	}}

