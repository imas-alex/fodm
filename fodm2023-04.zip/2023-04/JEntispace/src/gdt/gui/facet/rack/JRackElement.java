package gdt.gui.facet.rack;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JInternalDisplay;
import gdt.gui.generic.JSetElement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class JRackElement extends JInternalDisplay implements JSetElement{
private static final long serialVersionUID = 1L;
public static final String COLUMN="rack element column";
public static final String ROW="rack element row";
public static final String WIDTH="rack element width";
public static final String HEIGHT="rack element height";
public static final String ELEMENT_KEY="rack element height";
public static final String X="rack element x";
public static final String Y="rack element y";
public static final String W="rack element w";
public static final String H="rack element h";
public int column=1;
public int row=1;
public int width=1;
public int height=1;

public JRackElement(JMainConsole console,String locator$) {
		 super(console,locator$);
         String column$=Locator.getProperty(locator$, COLUMN);
         if(column$!=null)
        	 try {column=Integer.parseInt(column$);}catch(Exception e) {}
         String row$=Locator.getProperty(locator$, ROW);
         if(row$!=null)
        	 try {row=Integer.parseInt(row$);}catch(Exception e) {}
         String width$=Locator.getProperty(locator$, ROW);
         if(width$!=null)
        	 try {width=Integer.parseInt(width$);}catch(Exception e) {}
         String height$=Locator.getProperty(locator$, ROW);
         if(height$!=null)
        	 try {height=Integer.parseInt(height$);}catch(Exception e) {}
         addMouseListener(new MouseAdapter() {
    		@Override
    		public void mouseClicked(MouseEvent e) {
    			System.out.println("JRackElement:mouse click");
    			JRackFrame rackFrame=(JRackFrame)getDesktop();
    			rackFrame.updateDesktop();
    		}
    	});
	 }

public void setLayout(Sack rack) {
	try {
		Core position=new Core(String.valueOf(column),item$,String.valueOf(row));
		if(!rack.existsElement("rack.position"))
			rack.createElement("rack.position");
		rack.putElementItem("rack.position", position);
		Core area=new Core(String.valueOf(width),item$,String.valueOf(height));
		if(!rack.existsElement("rack.area"))
			rack.createElement("rack.area");
		rack.putElementItem("rack.area", area);
		console.getEntigrator().putEntity(rack);
	}catch(Exception e) {
		System.out.println("JRackElement:setLayout;"+e.toString());
	}
}

public JRackFrame getRackFrame() {
	return (JRackFrame)getDesktop();
}
public  String getLocator() {
	try {
		Properties locator=new Properties();
		if(desktop$!=null)
			locator.put(INTERNAL_DISPLAY_DESKTOP,desktop$);
		else
			return null;
		if(item$!=null)
		    locator.put(INTERNAL_DISPLAY_ITEM,item$);
		Sack rack=console.getEntigrator().getEntityAtLabel(desktop$);
		if(rack!=null) {
		locator$=rack.getElementItemAt("set", item$);
		System.out.println("JRackElement:getLocator:context locator="+locator$);
		Core position=rack.getElementItem("rack.position", item$);
		Core area=rack.getElementItem("rack.area", item$);
		if(position!=null) {
			if(position.type!=null)
		locator.put(COLUMN, position.type);
			if(position.value!=null)
		locator.put(ROW, position.value);
		}
		if(area!=null) {
			if(area.type!=null)
		locator.put(WIDTH, area.type);
			if(area.value!=null)
		locator.put(HEIGHT, area.value);
		}
		Core location=rack.getElementItem("rack.location", item$);
		if(location!=null) {
			if(location.type!=null)
		locator.put(X, location.type);
			if(location.value!=null)
		locator.put(Y, location.value);
		}
		
		Core size=rack.getElementItem("rack.size", item$);
		if(size!=null) {
		   if(size.type!=null)		
		locator.put(W, size.type);
		   if(size.value!=null)	
		locator.put(H, size.value);
		}
		}
		String appendix$=Locator.toString(locator);
		locator$=Locator.merge(locator$,appendix$);
	//	System.out.println("JRackElement:getLocator="+locator$);
		return locator$;
	}catch(Exception e) {
		System.out.println("JRackElement:getLocator;"+e.toString());
	}
	return null;
}
public void updateLocation(JRackFrame rackFrame) {
	try {
	Dimension frameSize=rackFrame.getSize();
	Sack rack=rackFrame.getEntity();
	Core grid=rack.getElementItem("rack.desktop", "grid");	
	int columnCount=Integer.parseInt(grid.type);
	int rowCount=Integer.parseInt(grid.value);
	int wcell=frameSize.width/columnCount;
	int hcell=frameSize.height/rowCount;
	int hpos=wcell*(column-1);
	int vpos=hcell*(row-1);
	int wsize=width*wcell;
	int hsize=height*hcell;
	if(!rack.existsElement("rack.location"))
		rack.createElement("rack.location");
	rack.putElementItem("rack.location",new Core(String.valueOf(hpos),item$,String.valueOf(vpos)));
	if(!rack.existsElement("rack.size"))
		rack.createElement("rack.size");
	rack.putElementItem("rack.size",new Core(String.valueOf(wsize),item$,String.valueOf(hsize)));
    console.getEntigrator().putEntity(rack);
	}catch(Exception e) {
		System.out.println("JRackElement:updateLocation;"+e.toString());
	}
}
@Override
public void putContext(JContext context ) {
    //	System.out.println("JInternalDisplay:putContext:container="+container$);
 	if(context==null)
    		return;
 	this.context=context;
 	context$=context.getInstance();
     getContentPane().removeAll();
    	    getContentPane().add(context,BorderLayout.CENTER);	
    		subtitle.setText(context.getSubtitle());
     	getContentPane().add(subtitle,BorderLayout.SOUTH);	
     	menu=getElementMenu(context);
 		JMenuBar menuBar = new JMenuBar();
     	setJMenuBar(menuBar);
 		
 		JMenuItem arrangeItem = new JMenuItem("Arrange");
 		arrangeItem.addActionListener(new ActionListener() {
 			@Override
 			public void actionPerformed(ActionEvent e) {
 				JRackArrangeElement arrangeDialog=new JRackArrangeElement(console,locator$);
 				arrangeDialog.setRackElement(JRackElement.this);
// 				System.out.println("JRackElement:arrange:locator="+locator$);
 			    arrangeDialog.setLocationRelativeTo(JRackElement.this);
 				arrangeDialog.pack();
 				arrangeDialog.revalidate();
 				arrangeDialog.repaint();
 				arrangeDialog.setVisible(true);
 			}
 				});
 		menu.add(arrangeItem);
 		menuBar.add(menu);
 		setTitle(context.getTitle());
 		setSubtitle(context.getSubtitle());
      	pack();		
 		invalidate();
 		validate();
 		repaint();
 		JRackFrame rackFrame=(JRackFrame)getDesktop();
 		if(rackFrame!=null)
     		rackFrame.updateDesktop();
   }
@Override
public void save() {
	try {
		JContext context=getContext();
		//System.out.println("JCollageElement:onContextChange:context="+context.getClass().getName());
		JRackFrame rackFrame=(JRackFrame)getDesktop();
		Sack rack=rackFrame.getEntity();
		Core c=rack.getElementItem("set", getItem());
		String contextClass$=Locator.getProperty(context.getLocator(),JContext.CONTEXT_CLASS);
		c.value=Locator.append(c.value, JContext.CONTEXT_CLASS, contextClass$);
		rack.putElementItem("set", c);
		console.getEntigrator().putEntity(rack);
		}catch(Exception e) {
			System.out.println("RackElement:save:"+e.toString());
		}	
}
@Override
public void restore() {
	try {
		//System.out.println("JCollageElement:onContextChange:context="+context.getClass().getName());
		JRackFrame rackFrame=(JRackFrame)getDesktop();
		Sack rack=rackFrame.getEntity();
		Core c=rack.getElementItem("set", getItem());
		JContext context=JContext.build(console, c.value);
		putContext(context);
		rackFrame.updateDesktop();
		}catch(Exception e) {
			System.out.println("JCollageElement:save:"+e.toString());
		}	
}
}
