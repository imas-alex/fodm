package gdt.gui.facet.rack;

import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JInternalDisplay;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class JRackFrame extends JDesktopPane {
	public static final String RACK_FRAME_CLASS="rack frame class";	
String entity$;
JMainConsole console;
String locator$;
int col=1;
int row=1;
Sack rack;
public JRackDisplay rackDisplay;
Hashtable<String, JRackElement> items=new Hashtable<String, JRackElement>(); 
	public   JRackFrame(JMainConsole console,String alocator$) {
		super();
		this.console=console;
	    locator$=alocator$;
		entity$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
//		System.out.println("JRackFrame:entity="+entity$);
		rack=console.getEntigrator().getEntityAtLabel(entity$);
	    this.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
	//			
			}
		});
	    addComponentListener(new ComponentAdapter() {
    		@Override
    		public void componentMoved(ComponentEvent e) {
    			System.out.println("JRackFrame:moved");
    		}
    		@Override
    		public void componentResized(ComponentEvent e) {
    			JRackFrame.this.setVisible(false);
    			updateDesktop();
    			JRackFrame.this.setVisible(true);
    		}
    	});
	    JRackElement []ida= getItems();
		if(ida!=null) {
		//	System.out.println("JRackFrame:ida="+ida.length);
			Core location;
			Core size;
			String item$;
			for(JRackElement id:ida) {
				add(id );  
			    id.setVisible(true);
			    item$=id.getItem();
			//    System.out.println("JRackFrame:item="+item$);
			    try {
			    location=rack.getElementItem("rack.location", item$);
			    int x=Integer.parseInt(location.type);
			    int y=Integer.parseInt(location.value);
			    size=rack.getElementItem("rack.size", item$);
			    int w=Integer.parseInt(size.type);
			    int h=Integer.parseInt(size.value);
			    id.setLocation(x, y);
			    id.setSize(w, h);
			  //  System.out.println("JRackFrame:item="+item$+" x="+x+" y="+y+" w="+w+" h="+h);
			    }catch(Exception ee) {
			    	System.out.println("JRackFrame:item="+item$+":"+ee.toString());
			    }
			}
		}
	resetGrid();
	}
	public void updateDesktop() {
		String[] sa=rack.elementListNames("set");
		if(sa!=null&&sa.length>0)
			for(String s:sa) {
			   updateElement(s);	
			}
		if(getDrawgrid())
			   drawGrid(col,row);
		saveLocation();
	}
	public void dispose() {
		JInternalFrame[] rea=getAllFrames();
		if(rea==null)
			return;
		for(JInternalFrame re:rea) {
			console.removeContainer((JRackElement)re);
			((JRackElement)re).dispose();
		}
		console.removeContainer(rackDisplay);
		rackDisplay.dispose();
	}
	private void relocateElement(String item$) {
		if(item$==null)
			return;
		JInternalFrame[] rea=getAllFrames();
		if(rea==null)
			return;
		String candidate$;
		for(JInternalFrame re:rea) {
			candidate$=((JRackElement)re).getItem();
		try {
			if(item$.equals(candidate$)) {
				Core location=rack.getElementItem("rack.location", item$);
				Core size=rack.getElementItem("rack.size", item$);
				int x=Integer.parseInt(location.type);
				int y=Integer.parseInt(location.value);
				int w=Integer.parseInt(size.type);
				int h=Integer.parseInt(size.value);
			    Point p=new Point(x,y);
			    Dimension dim=new Dimension(w,h);
			    re.setLocation(p);
			    re.setSize(dim);
			}
			}catch(Exception e) {
				System.out.println("JRackFrame:updateElement:item="+item$+": "+e.toString());
			}
			}
		}
	private void updateElement(String item$) {
		Dimension cellSize=getCellSize();
		try {
			if(!rack.existsElement("rack.location"))
				rack.createElement("rack.location");
			if(!rack.existsElement("rack.size"))
				rack.createElement("rack.size");
			if(!rack.existsElement("rack.position"))
				rack.createElement("rack.position");
			Core area=rack.getElementItem("rack.area", item$);
			if(area==null) {
				area=new Core("1",item$,"1");
				rack.putElementItem("rack.area", area);
			}
			int col=Integer.parseInt(area.type);
			int row=Integer.parseInt(area.value);
			int w=cellSize.width*(col);
			int h=cellSize.height*(row);
			
			rack.putElementItem("rack.size",new Core(String.valueOf(w),item$,String.valueOf(h)));
			
			Core position=rack.getElementItem("rack.position", item$);
			if(position==null) {
				position=new Core("1",item$,"1");
				rack.putElementItem("rack.position", position);
			}
			col=Integer.parseInt(position.type);
			row=Integer.parseInt(position.value);
			int x=cellSize.width*(col-1);
			int y=cellSize.height*(row-1);
			rack.putElementItem("rack.location",new Core(String.valueOf(x),item$,String.valueOf(y)));
	        console.getEntigrator().putEntity(rack);
	        relocateElement(item$);
		}catch(Exception e) {
			System.out.println("JRackFrame:updateElement:"+e.toString());
		}
	}
	private void saveLocation() {
		try {
		Dimension dim=getSize();
		Point point=getLocation();
		String x$=String.valueOf(point.x);
		String y$=String.valueOf(point.y);
		//System.out.println("JRackFrame:saveLocation:x="+x$+" y="+y$);
		String w$=String.valueOf(dim.width);
		String h$=String.valueOf(dim.height);
		Core location=new Core(x$,"location",y$);
		Core size=new Core(w$,"size",h$);
		rack.putElementItem("rack.desktop", location);
		rack.putElementItem("rack.desktop", size);
		}catch(Exception e) {
			System.out.println("JRackFrame:saveLocation:"+e.toString());
		}
	}
	public void addElement(JRackElement rackElement, int column,int row,int w,int h) {
		if(rackElement==null)
			return;
		try {
			if(!rack.existsElement("rack.position"))
				rack.createElement("rack.position");
			if(!rack.existsElement("rack.area"))
				rack.createElement("rack.area");
			String item$=rackElement.getItem();
			Core area =new Core(String.valueOf(column),item$,String.valueOf(row));
			Core position =new Core(String.valueOf(w),item$,String.valueOf(h));
			rack.putElementItem("rack.position", position);
			rack.putElementItem("rack.area", area);
			console.getEntigrator().putEntity(rack);
			items.put(item$, rackElement);
		}catch(Exception e) {
			System.out.println("JRackFrame:addElement:"+e.toString());
		}
	}
	private void relocate(String displayKey$) {
		Dimension cellSize=getCellSize();
		try {
			if(!rack.existsElement("rack.location"))
				rack.createElement("rack.location");
			if(!rack.existsElement("rack.size"))
				rack.createElement("rack.size");
			Core area=rack.getElementItem("rack.area", displayKey$);
			int col=Integer.parseInt(area.type);
			int row=Integer.parseInt(area.value);
			int w=cellSize.width*(col);
			int h=cellSize.height*(row);
			rack.putElementItem("rack.size",new Core(String.valueOf(w),displayKey$,String.valueOf(h)));
			
			Core position=rack.getElementItem("rack.position", displayKey$);
			col=Integer.parseInt(position.type);
			row=Integer.parseInt(position.value);
			int x=cellSize.width*(col-1);
			int y=cellSize.height*(row-1);
			rack.putElementItem("rack.location",new Core(String.valueOf(x),displayKey$,String.valueOf(y)));
	        console.getEntigrator().putEntity(rack);
		}catch(Exception e) {
			System.out.println("JRackFrame:relocate:"+e.toString());
		}
	}
	private Dimension getCellSize() {
		int fw=this.getWidth();
		int fh=this.getHeight();
		int col=1;
		int row=1;
		int w=fw;
		int h=fh;
		try {
			Core c=rack.getElementItem("rack.desktop", "grid");
			col=Integer.parseInt(c.type);
			row=Integer.parseInt(c.value);
			w=fw/col;
			h=fh/row;
		}catch(Exception e) {}
		return new Dimension(w,h);
	}
	public JMenu getContextMenu() {
        JMenu menu = new JMenu("Desktop");
        menu.addSeparator();
        JMenuItem designItem = new JMenuItem("Design");
        designItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//order();
				JRackDesign designDialog=new JRackDesign(console,locator$,JRackFrame.this );
				designDialog.setLocationRelativeTo(JRackFrame.this);
				designDialog.setVisible(true);
					}
				});
        menu.add(designItem);
        return menu;		
    }
	private JInternalDisplay [] getInternalDisplays() {
		try {
			//System.out.println("JRackFrame:getInternalDisplays:BEGIN");
			Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			Core [] pca=entity.elementGet("set");
			if(pca==null||pca.length<1)
				return null;
			//System.out.println("JRackFrame:getInternalDisplays:pca="+pca.length);
		    JContext context;
		    JInternalDisplay display;
		    ArrayList<JInternalDisplay>idl=new ArrayList<JInternalDisplay>();
		    int i=0;
		    for(Core c:pca) {
		    	//System.out.println("JRackFrame:getInternalDisplays:c.name="+c.name);
		    	context=JContext.build(console, c.value);
		    	if(context!=null) {
		    		//System.out.println("JRackFrame:getInternalDisplays:0");
		    		display=new JInternalDisplay(console,locator$);
		    		//System.out.println("JRackFrame:getInternalDisplays:container key="+display.getKey());
		    		display.putContext(context);
		    		idl.add(display);
		    	}
		    	//System.out.println("JRackFrame:getInternalDisplays:NEXT");
		    }
		    if(idl.size()>0) {
		    	JInternalDisplay []ida=new JInternalDisplay[ idl.size()];
		    	 idl.toArray(ida);
		    	 return ida;
		    }
		    
		}catch(Exception e) {
			System.out.println("JRackFrame:getInternalDisplays:"+e.toString());
		}
		return null;
	}
	private JRackElement [] getItems() {
		try {
			Sack rack=console.getEntigrator().getEntityAtLabel(entity$);
			Core [] pca=rack.elementGet("set");
			if(pca==null||pca.length<1)
				return null;
		    JContext context;
		    JRackElement item;
		    String item$=JRackElement.classLocator();
		    ArrayList<JRackElement>idl=new ArrayList<JRackElement>();
		    int i=0;
		   // String container$;
		    for(Core c:pca) {
		    	//System.out.println("JRackFrame:getInternalDisplays:c.name="+c.name);
		    	context=JContext.build(console, c.value);
		    	if(context!=null) {
		    		//System.out.println("JRackFrame:getInternalDisplays:0");
		    		item$=Locator.append(item$,JInternalDisplay.INTERNAL_DISPLAY_DESKTOP , entity$);
		    		item$=Locator.append(item$,JInternalDisplay.INTERNAL_DISPLAY_ITEM , c.name);
		    		item=new JRackElement(console,item$);
		    		item.putContext(context);
		    		try {
		    		String entity$=context.getEntity();
		    		Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    		String type$=entity.getProperty("entity");
		       	    ImageIcon icon =FacetMaster.getIcon(console, type$);
		       		if(icon!=null)
		       			item.setFrameIcon(icon);
		    		}catch(Exception ee) {}
		   		    		idl.add(item);
		    	}
		    	//System.out.println("JRackFrame:getInternalDisplays:NEXT");
		    }
		    if(idl.size()>0) {
		    	JRackElement []ida=new JRackElement[ idl.size()];
		    	 idl.toArray(ida);
		    	 return ida;
		    }
		    
		}catch(Exception e) {
			System.out.println("JRackFrame:getItems:"+e.toString());
		}
		return null;
	}
	
	public static String classLocator() {
		Properties locator=new Properties();
	    locator.put(RACK_FRAME_CLASS,"gdt.gui.facet.rack.JRackFrame");
	    locator.put(Locator.LOCATOR_TITLE,"Rack");
		locator.put(IconLoader.ICON_FILE,"rack.png");
	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		return Locator.toString(locator);
	}
	public String getLocator() {
		String  locator$ =classLocator();
		locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity$);
		return locator$;
	}
public void setGrid(int col,int row) {
	this.col=col;
	this.row=row;
	repaint();
	updateDesktop();
}
public void cancelGrid() {
 setDrawgrid(false);
}
private void resetGrid() {
	try {
	Core grid=rack.getElementItem("rack.desktop", "grid");	
	col=Integer.parseInt(grid.type);
	row=Integer.parseInt(grid.value);
	//drawGrid(col,row);
	}catch(Exception e) {
		System.out.println("JRackFrame:resetGrid:"+e.toString());
	}
}

public void drawGrid(int col,int row ) {
	try {
		
		if(!getDrawgrid())
			return;
		Dimension dim=this.getSize();
		System.out.println("JRackFrame:drawGrid:dim x="+dim.width+" y="+dim.height);
		int hpos=0;
		int hcell=dim.width/col;
		int vcell=dim.height/row;
//		System.out.println("JRackFrame:drawGrid:hcell="+hcell+" vcell="+vcell);
		int vpos=0;
		Graphics2D g=(Graphics2D)getGraphics();
		
		final float dash1[] = {10.0f};
	    final BasicStroke dashed =
	        new BasicStroke(1.0f,
	                        BasicStroke.CAP_BUTT,
	                        BasicStroke.JOIN_MITER,
	                        10.0f, dash1, 0.0f);
		g.setStroke(dashed);
	
		//columns
		for(int i=0;i<col;i++) {
			//System.out.println("JRackFrame:col="+i+" hpos="+hpos);
			g.drawLine(hpos, 0, hpos, dim.height);
			hpos=hpos+hcell;
		}
		//rows
		for(int i=0;i<col;i++) {
			g.drawLine(0, vpos, dim.width, vpos);
			vpos=vpos+vcell;
		}
	
	}catch(Exception e) {
		System.out.println("JRackFrame:drawGrid:"+e.toString());
	}
}
protected void paintComponent(Graphics g) {
	super.paintComponent(g);
//	System.out.println("JRackFrame:paintComponent:drawgrid="+getDrawgrid());
	if(getDrawgrid())
	   drawGrid(col,row);
	
}
public void setDrawgrid(boolean drawgrid) {
//	System.out.println("JRackFrame:setDrawgrid="+drawgrid);
	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
	if(drawgrid){
		entity.putElementItem("rack.desktop", new Core(null,"drawgrid",Locator.LOCATOR_TRUE));
	}else {
		entity.putElementItem("rack.desktop", new Core(null,"drawgrid",Locator.LOCATOR_FALSE));
		repaint();
	}
	console.getEntigrator().putEntity(entity);
}
public boolean getDrawgrid() {
	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
	String drawgrid$=entity.getElementItemAt("rack.desktop","drawgrid");
	if(Locator.LOCATOR_TRUE.equals(drawgrid$))
		return true;
	else
		return false;
}
public void saveDesign() {
	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
	entity.putElementItem("rack.desktop", new Core(String.valueOf(col),"grid",String.valueOf(row)));
	console.getEntigrator().putEntity(entity);
}
public Sack getEntity() {
	return rack;
}
}
