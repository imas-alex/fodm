package gdt.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Enumeration;
import java.util.Properties;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Logger;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.module.JModuleServicesList;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;

public class ModuleMaster extends FolderMaster{
	public static final String KEY="_vJhlWyxr4QmX3l6gffHeIpTn0Hs";
	public static final String NAME="Module";
	public static final String FACET_HANDLER_KEY="_cwP5HjsG5BZl9YLn7QSln4hTtug";	
	public ModuleMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return NAME;
	}
	@Override
	public String getType() {
		return "module";
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
	//	System.out.println("FolderMaster:getJAllFacetsItem:locator="+handlerLocator$);
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "module.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Modules");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
	    String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "module.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Module");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		if(entity$!=null)
			itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL,entity$);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		String moduleServices$=JModuleServicesList.classLocator();
		String parent$=console.saveContext();
		String entity$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
		moduleServices$=Locator.append(moduleServices$,Entigrator.ENTITY_LABEL, entity$);
		moduleServices$=Locator.append(moduleServices$,JContext.PARENT, parent$);
//		System.out.println("ModuleMaster:entityFacetsItemOnClick:parent="+parent$);
		JModuleServicesList moduleServices=new JModuleServicesList(console,moduleServices$);
		String container$=Locator.getProperty(locator$,JContextContainer.CONTAINER);
		JContextContainer container=null;
		if(container$!=null)
			container=console.getContextContainer(container$);
		if(container==null)
			console.replaceContext(ModuleMaster.this.context, moduleServices);
		else
		  container.putContext(moduleServices);	
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String moduleHandler$=ModuleHandler.classLocator();
			moduleHandler$=Locator.append(moduleHandler$, Entigrator.ENTITY_LABEL, entity$);
			ModuleHandler moduleHandler =new ModuleHandler(console.getEntigrator(),moduleHandler$);
			return moduleHandler;
		}catch(Exception e) {
			System.out.println("ModuleMaster:getFacetHandler:"+e.toString());
		}
		return null;
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		JPopupMenu popup=new JPopupMenu();
		JMenuItem newItem=new JMenuItem("New module");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				popup.setVisible(false);
				String textEditor$=JTextEditor.classLocator();
				textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New module");
				String facetList$=JEntityFacetList.classLocator();
				facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
				facetList$=Locator.append(facetList$,MASTER_CLASS,"gdt.gui.facet.ModuleMaster");
				facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
				//SessionHandler.putLocator(console.getEntigrator(),facetList$);
				textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
				JTextEditor textEditor=new JTextEditor(console,textEditor$);
				//console.replaceContext(textEditor);
				console.replaceContext(ModuleMaster.this.context, textEditor);
			}
		} );
		popup.add(newItem);
		return popup;
	}
	
	public static String classLocator() {
		 Properties locator=new Properties();
	     locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
	     locator.put(FacetHandler.FACET_MASTER_CLASS,"gdt.gui.facet.ModuleMaster");
	     locator.put(FacetHandler.FACET_HANDLER_CLASS,"gdt.base.facet.ModuleHandler");
	     locator.put(Locator.LOCATOR_TITLE,"Modules");
	     locator.put(MASTER_KEY,KEY);
	     locator.put(JContext.PARENT,ALL_FACETS_KEY);
	     locator.put( IconLoader.ICON_FILE, "module.png");
	     locator.put( IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	     locator.put(FacetHandler.FACET_TYPE,"module");
	     return Locator.toString(locator);
	}
	public static void rebuildModule(JMainConsole console, String moduleKey$) {
		try{
//			System.out.println("ModuleMaster:rebuildModule:module key="+moduleKey$);
			Sack module=console.getEntigrator().getEntity(moduleKey$);
			if(!module.existsElement("handler"))
				module.createElement("handler");
 		JarFile jarFile = new JarFile(console.getEntigrator().getEntihome()+"/"+moduleKey$+"/lib/"+moduleKey$+".jar") ;
 		String[] sa;
 		String handlerName$;
 		String handlerClass$=null;
 		Properties facetLocator=new Properties();
 		facetLocator.put(ModuleHandler.FACET_MODULE, moduleKey$);
	    Enumeration<JarEntry> e = jarFile.entries();
	    FacetHandler facetHandler=null;
	        while (e.hasMoreElements()) {
	            JarEntry jarEntry = e.nextElement();
	            try{ 
	             if (jarEntry.getName().contains("package-info"))
						continue;
	//             System.out.println("ModuleMaster:rebuildModule:jar entry="+jarEntry.getName());
	             if (jarEntry.getName().endsWith(".class")) {
	                handlerName$ = jarEntry.getName();
	                sa=handlerName$.split("/");
	                if(sa.length<3)
	                	continue;
             //       System.out.println("ModuleMaster:rebuildModule:sa["+i+"]="+sa[i]);
	                boolean checkHandler=sa[3].endsWith(".class")
	                		            &&(sa[1].equals("base"))
	                		            &&(sa[2].equals("facet"))
	                					&&(!sa[3].contains("$"))
	                					&&(sa[3].contains("Handler"));
	                if(checkHandler) {
	                	handlerClass$=moduleKey$+".base.facet."+sa[3].replace(".class", "");
	             //   	System.out.println("ModuleMaster:rebuildModule:handler class="+handlerClass$);
	                	facetHandler=FacetHandler.build( console.getEntigrator(),handlerClass$);
	                	if(facetHandler==null) {
	                		System.out.println("ModuleMaster:rebuildModule:cannot instantitate handler="+handlerClass$);
	                		continue;
	                	}
	                if(facetHandler.getKey()==null) {
	                	System.out.println("ModuleMaster:rebuildModule:no key in facet handler: name="+facetHandler.getName()); 	
	                    return;
	                }
	                if(facetHandler.getLocator()==null) {
	                	System.out.println("ModuleMaster:rebuildModule:facet handler: name="+facetHandler.getName()+": getLocator returns null");
	                	return;
	                }
                	module.putElementItem("handler", new Core(facetHandler.getName(),facetHandler.getKey(),facetHandler.getLocator()));
                	//System.out.println("ModuleMaster:rebuildModule:put facet handler: name="+facetHandler.getName()+" key="+facetHandler.getKey() +" locator="+facetHandler.getLocator());
	                }
	            }
	        }catch(Exception ee) {
	        	System.out.println("ModuleMaster:rebuildModule:entry="+jarEntry.getName()+";  "+ee.toString());
	        }
           }
	        console.getEntigrator().putEntity(module);
	        jarFile.close();
	    }catch(Exception e){
			Logger.getLogger(ModuleHandler.class.getName()).severe(e.toString());
		}
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		//System.out.println("ModuleMaster:createEntity:label="+entityLabel$);
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core(ModuleHandler.SYSTEM,getType(),classLocator()));
		entity.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","module.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		try {
		String path$=entigrator.getEntihome()+"/"+entity.getKey();
	    File folder=new File(path$);
	    if(!folder.exists())
	    	folder.mkdir();
	    String src$=entigrator.getEntihome()+"/"+entity.getKey()+"/src";
		File src=new File(src$);
		boolean res=src.mkdirs();
		String bin$=entigrator.getEntihome()+"/"+entity.getKey()+"/bin";
		File bin=new File(bin$);
		bin.mkdir();
		  String lib$=entigrator.getEntihome()+"/"+entity.getKey()+"/lib";
		  File lib=new File(lib$);
		  lib.mkdir();
		}catch(Exception e) {
			System.out.println("ModuleMaster:createEntity"+e.toString());
		}
		return entity;
	}	
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core(ModuleHandler.SYSTEM,KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core(ModuleHandler.SYSTEM,ModuleHandler.KEY,ModuleHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("ModuleMaster:addToSession:"+e.toString());
	    }
}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
}
