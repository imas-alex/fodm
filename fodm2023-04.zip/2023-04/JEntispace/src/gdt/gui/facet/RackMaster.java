package gdt.gui.facet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Properties;
import java.util.logging.Logger;
import javax.swing.JPopupMenu;
import gdt.base.facet.ModuleHandler;
import gdt.base.facet.RackHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.rack.JRackEditor;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JItemPanel;

public class RackMaster extends  FacetMaster{
	public static final String KEY="__Ss1OyKbgQoQrnguQCKCZHz3OVHY";
	public static final String NAME="Rack";
	public static final String FACET_HANDLER_KEY="_E05H1tPmmLCZ0N8x5POgqPNnsvc";	
	String entity$;
	String parent$;
	public RackMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
		entity$=Locator.getProperty(alocator$,Entigrator.ENTITY_LABEL);
		parent$=Locator.getProperty(alocator$,JContext.PARENT);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	     locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
	     locator.put(MASTER_CLASS,"gdt.gui.facet.RackMaster");
	     locator.put(FacetHandler.FACET_HANDLER_CLASS,RackHandler.RACK_FACET_CLASS);
	     locator.put(Locator.LOCATOR_TITLE,"Rack");
	     locator.put(MASTER_KEY,KEY);
	     locator.put(JContext.PARENT,ALL_FACETS_KEY);
	     locator.put( IconLoader.ICON_FILE, "rack.png");
	     locator.put( IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	     locator.put(FacetHandler.FACET_TYPE,RackHandler.RACK_FACET_TYPE);
	     return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "rack.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Racks");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		String entityLabel$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		  if(entityLabel$!=null)
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL,entityLabel$);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "rack.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Rack");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL,Locator.getProperty(locator$,Entigrator.ENTITY_LABEL));
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String rackHandler$=RackHandler.classLocator();
			rackHandler$=Locator.append(rackHandler$, Entigrator.ENTITY_LABEL, entity$);
			RackHandler rackHandler =new RackHandler(console.getEntigrator(),rackHandler$);
			return rackHandler;
		}catch(Exception e) {
			System.out.println("RackMaster:getFacetHandler:"+e.toString());
		}
		return null;
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return KEY;
	}

	@Override
	public String getName() {
		return "Rack";
	}
	@Override
	public String getType() {
		return "rack";
	}

	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		String rackEditor$=JRackEditor.classLocator();
		rackEditor$=Locator.merge(rackEditor$,locator$);
		rackEditor$=Locator.append(rackEditor$, Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
		  rackEditor$=Locator.append(rackEditor$,JContext.PARENT,parent$);
		JRackEditor rackEditor=new JRackEditor(console,rackEditor$);
		String container$=Locator.getProperty(locator$,JContextContainer.CONTAINER);
		JContextContainer container=null;
		if(container$!=null)
			container=console.getContextContainer(container$);
		if(container==null)
		  //console.replaceContext(rackEditor);
			console.replaceContext(RackMaster.this.context, rackEditor);
		else
		  container.putContext(rackEditor);	
	}

	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLocator() {
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String thisLocator$=classLocator();
		if(entity$!=null)
		   thisLocator$=Locator.append(thisLocator$,Entigrator.ENTITY_LABEL, entity$);
		return thisLocator$;
		}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		 Sack session=getSession(console,locator$);
	     Core masterEntry=new Core(ModuleHandler.SYSTEM,KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core(ModuleHandler.SYSTEM,RackHandler.KEY,RackHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("RackMaster:addToSession:"+e.toString());
	    }
	}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}


	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity.putElementItem("facet", new Core(ModuleHandler.SYSTEM,getType(),classLocator()));
		entigrator.assignProperty(entityKey$, "rack", Locator.LOCATOR_TRUE);
		entity.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","rack.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		return entity;
	}
	private void createSource(String entity$){
		try{
			System.out.println("RackMaster:createSource:rack="+entity$);
			String entityKey$=console.getEntigrator().getKey(entity$);
					File sourceHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src");
					if(!sourceHome.exists())
						sourceHome.mkdirs();
					File binHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin");
					if(!binHome.exists())
						binHome.mkdirs();
					File synch=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src/"+entityKey$+".java");
					if(!synch.exists())
						synch.createNewFile();
					 FileOutputStream fos = new FileOutputStream(synch, false);
					 Writer writer = new OutputStreamWriter(fos, "UTF-8");
						writer.write("import gdt.gui.console.JMainConsole;\n");
						writer.write("import gdt.gui.generic.JContext;\n");
						writer.write("public class " +entityKey$+"implements Synch {\n");
						writer.write("private final static String ENTITY_KEY=\""+entityKey$+"\";\n");
						writer.write("HashMap <String,PropertyChangeSupport> pcsMap=new HashMap <String,PropertyChangeSupport>();\n");
						writer.write("HashMap <String,PropertyChangeListener> pclMap=new HashMap <String,PropertyChangeListener>();\n");
						writer.write("public "+entityKey$+" (){} \n");
						writer.write("@Override\n");
						writer.write("public void synch(JMainConsole console, String locator$) {\n");
						writer.write("System.out.println(ENTITY_KEY+\":\"+locator$);\n");
				      	writer.write("	}\n");
				      	writer.write("@Override\n");
				      	writer.write("public void putPcl(NamedListener nl) {\n");
				      	writer.write("pcsMap.put(pcs.name$, pcs.pcs);}\n");
				      	writer.write("@Override\n");
				      	writer.write("public void putPcs(NamedPcs pcs) {\n");
				      	writer.write("pcsMap.put(pcs.name$, pcs.pcs);}\n");
				      	writer.write("@Override\n");
				      	writer.write("public void clear() {\n");
				      	writer.write("pcsMap.clear();\n");
				      	writer.write("pclMap.clear();\n");
				      	writer.write("	}\n");
				      	writer.write("@Override\n");
				      	writer.write("public void clear() {\n");
				      	writer.write("propertyChange(PropertyChangeEvent evt){\n");
				      	writer.write("System.out.println(ENTITY_KEY+\":\"+evt.getPropertyName());\n");
				      	writer.write("	}\n");
				      	writer.write("	}\n");
						writer.write("}\n");
					 writer.close();   
				}catch(Exception e){
					Logger.getLogger(getClass().getName()).severe(e.toString());
				}
	}
}
