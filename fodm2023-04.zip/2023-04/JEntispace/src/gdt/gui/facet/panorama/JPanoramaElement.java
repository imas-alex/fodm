package gdt.gui.facet.panorama;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JSetEditor;
import gdt.gui.generic.JSetElement;

public class JPanoramaElement extends JDisplay implements JSetElement{
private static final long serialVersionUID = 1L;
Sack panorama;
String item$;
public JPanoramaElement(JMainConsole console,String locator$) {
	 super(console);
	String	panorama$=Locator.getProperty(locator$, JPanoramaEditor.PANORAMA);
	panorama=console.getEntigrator().getEntityAtLabel(panorama$);
	item$=Locator.getProperty(locator$, JSetEditor.SET_ITEM);
   restore();
}

private void setDisplayMenu(){
	 JMenu menu=new JMenu ("Display");
	    menuBar.add(menu);
	    JMenuItem saveItem = new JMenuItem("Save");
		   saveItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				    save();
				}
			} );
			menu.add(saveItem);
		 JMenuItem restoreItem = new JMenuItem("Restore");
			   restoreItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					    restore();
					}
				} );
				menu.add(restoreItem);	
			JMenuItem panoramaItem = new JMenuItem("Panorama");
			 panoramaItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					//	JDisplay display=new JDisplay(console);
						String panoramaEditor$=JPanoramaEditor.classLocator();
						panoramaEditor$=Locator.append(panoramaEditor$, Entigrator.ENTITY_LABEL, panorama.getProperty("label"));
						JPanoramaEditor panoramaEditor=new JPanoramaEditor(console,panoramaEditor$);
						console.replaceContext(null, panoramaEditor);
						}
				} );
		menu.add(panoramaItem);	
}
@Override
public void putContext(JContext context) {
	super.putContext(context);
	setDisplayMenu();
	revalidate();
	repaint();
}

public void setPanorama(Sack  panorama) {
	this.panorama=panorama;
}

@Override
public void save() {
	try {
	JContext context=getContext();
//	System.out.println("JPanoramaElement:save:item="+item$+" panorama="+panorama.getProperty("label"));
	Core c=panorama.getElementItem("set",item$);
	if(c==null) {
		System.out.println("JPanoramaElement:save:not exists item="+item$);
	    return;
	}
	String contextClass$=Locator.getProperty(context.getLocator(),JContext.CONTEXT_CLASS);
	c.value=Locator.append(c.value, JContext.CONTEXT_CLASS, contextClass$);
	panorama.putElementItem("set", c);
	Dimension size=getSize();
	Point location=this.getLocation();
	if(!panorama.existsElement("panorama.size"))
		panorama.createElement("panorama.size");
	if(!panorama.existsElement("panorama.location"))
		panorama.createElement("panorama.location");
	panorama.putElementItem("panorama.size", new Core(String.valueOf(size.width),item$,String.valueOf(size.height)));
	panorama.putElementItem("panorama.location", new Core(String.valueOf(location.x),item$,String.valueOf(location.y)));
	console.getEntigrator().putEntity(panorama);
	}catch(Exception e) {
		System.out.println("JPanoramaElement:save:"+e.toString());
	}	
}	

public void setLocation() {
	Point point=new Point(0,0);
	Dimension size=new Dimension(300,200);
	try {
		Core sc=panorama.getElementItem("panorama.size", item$);
		int w=Integer.parseInt(sc.type);
		int h=Integer.parseInt(sc.value);
		size=new Dimension(w,h);
		
		Core lc=panorama.getElementItem("panorama.location", item$);
		int x=Integer.parseInt(lc.type);
		int y=Integer.parseInt(lc.value);
		point=new Point(x,y);
	}catch(Exception e) {
		System.out.println("JPanoramaElement:setLocation:"+e.toString());
	}
	setSize(size);
	setLocation(point);
}
@Override
public void restore() {
	try {
	JContext context= getItemContext(console,panorama,item$);
	putContext(context);
	setLocation();
	}catch(Exception e) {
		System.out.println("JPanoramaElement:restore:"+e.toString());
	}
}
@Override
public String getItem() {
	return item$;
}
}
