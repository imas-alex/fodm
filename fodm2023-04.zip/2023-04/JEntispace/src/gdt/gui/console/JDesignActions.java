package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.util.ArrayList;
import java.util.Properties;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
import gdt.gui.generic.JTextEditor;
	public class JDesignActions extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_KOPfYVpeBzH69TmP4wblBt_crfE";
	public static final String ADD_PROPERTY="add property";
	public static final String ADD_PROPERTY_TITLE="Add property";
	public static final String ADD_PROPERTY_INSTANCE="_gpNYwFP12qbC1CSAXbYrTUTtsV4";
	public static final String DELETE_PROPERTY="delete property";
	public static final String DELETE_PROPERTY_TITLE="Delete property";
	public static final String DELETE_PROPERTY_INSTANCE="__SCfjJqVw5LA4_7eKGDOzW4jgjjQ";
	public static final String EDIT_PROPERTY_TITLE="Edit property";
	public static final String EDIT_PROPERTY="edit property";
	public static final String EDIT_PROPERTY_INSTANCE="_pOr8uCbW2lmAoU0kiJwXR65ryVM";
	
	public static final String ADD_VALUE="add value";
	public static final String ADD_VALUE_TITLE="Add value";
	public static final String ADD_VALUE_INSTANCE="__S5zdWK3O2lyozi9Suz7MA7eUmFI";
	public static final String DELETE_VALUE="delete value";
	public static final String DELETE_VALUE_TITLE="Delete value";
	public static final String DELETE_VALUE_INSTANCE="_atugGlYhtcizgwjU43hqWoKwd5c";
	public static final String EDIT_VALUE_TITLE="Edit value";
	public static final String EDIT_VALUE="edit value";
	public static final String EDIT_VALUE_INSTANCE="_65preM13yAH8ZPCq5mGkFKtgNBU";
	public static final String ASSIGN_VALUE_LIST="assign value list";
	public static final String ASSIGN_VALUE_LIST_TITLE="Assign value to selection";
	public static final String ASSIGN_VALUE_INSTANCE="_bKgrUHdQowtqrJRVVZAUXNgq_ScA";
	public static final String TAKEOFF_VALUE_LIST="takeoff value list";
	public static final String TAKEOFF_VALUE_LIST_TITLE="Take off value from selection";
	public static final String TAKEOFF_VALUE_INSTANCE="_ccD0BVWsDVwiaDJdor8GXoDFOK8";
	public static final String CLEAR_VALUE="clear value";
	public static final String CLEAR_VALUE_TITLE="Delete unused values";
	public static final String CLEAR_VALUE_INSTANCE="_Tore88OO3pBhMYOHR2CEtXlMeQg";
	public static final String RELOAD_ACTION="Reload action";
	public static final String RELOAD_VALUE_INSTANCE="_L9_aYSpuJnO8CW4ra_Sp4IX4bt7w";
	String reply$;
	String property$;
	String value$;
	String mode$;
	String[] ea=null;
	String group$;

	public JDesignActions(JMainConsole console, String locator$) {
		super(console, locator$);
		//System.out.println("JDesignActions:this locator="+getLocator());
		Properties locator=Locator.toProperties(locator$);
		if(locator$!=null) {
		property$=locator.getProperty(JDesignPanel.PROPERTY);
		value$=locator.getProperty(JDesignPanel.VALUE);
		entity$=locator.getProperty(Entigrator.ENTITY_LABEL);
		group$=locator.getProperty(JDesignPanel.GROUP);
		mode$=locator.getProperty(JDesignPanel.MODE);
		String entities$=locator.getProperty(JDesignPanel.ENTITIES);
		if(entities$!=null)
			ea=Locator.toArray(entities$);
		}
		JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);
	}
		//System.out.println("JDesignActions:property=="+property$+"  value="+value$+ "  entity="+entity$);
	@Override
	public String getLocator() {
		   if(locator$==null)
		      locator$=classLocator();
		   else
			  locator$=Locator.merge(locator$, classLocator()); 
		   if(entity$!=null)
			   locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity$);
		   if(property$!=null)
			   locator$=Locator.append(locator$, JDesignPanel.PROPERTY, property$);
		   if(value$!=null)
			   locator$=Locator.append(locator$, JDesignPanel.VALUE, value$);
		   if(group$!=null)
			   locator$=Locator.append(locator$, JDesignPanel.GROUP, group$);
		 //  System.out.println("JDesignActions:getLocator:locator="+locator$);
		   return locator$;
	  }
	@Override
	public String getTitle() {
		return group$;
	}
	@Override
	public String getSubtitle() {
	 if(JDesignPanel.PROPERTY.equals(group$))	
		return property$;
	 if(JDesignPanel.VALUE.equals(group$))	
			return "Property="+property$+ ";  Value="+value$;
	 return null;
	}
	private class JDesignActionItem extends JItemPanel{
		String action$=null;
		public JDesignActionItem(JMainConsole console,JContext context, String locator$) {
			super(console,context, locator$);
			 action$=Locator.getProperty(locator$, JItemPanel.ITEM_ACTION);
		}
		private static final long serialVersionUID = 1L;
		@Override
		public void onClick(JMainConsole console, String thisLocator$) {
			if(ADD_PROPERTY.equals(action$)) {
				thisLocator$=JDesignActions.this.getLocator();
				String editorLocator$=JTextEditor.classLocator();
				editorLocator$=Locator.append(editorLocator$,JTextEditor.IN_TEXT, property$);
				editorLocator$=Locator.append(editorLocator$,JTextEditor.TEXT_TITLE, "Add property");
				editorLocator$=Locator.append(editorLocator$,Locator.LOCATOR_TITLE, "Add property");
				thisLocator$=Locator.append(thisLocator$, JDesignPanel.PROPERTY,property$);
				thisLocator$=Locator.append(thisLocator$, JItemPanel.ITEM_ACTION, ADD_PROPERTY);
				thisLocator$=Locator.append(thisLocator$, JDesignPanel.GROUP,JDesignPanel.PROPERTY);
//				System.out.println("JDesignActions:perform:add property:this locator="+thisLocator$);
				editorLocator$=Locator.append(editorLocator$,PARENT, Locator.getProperty(thisLocator$, JContext.INSTANCE));
				SessionHandler.putLocator(console.getEntigrator(),thisLocator$);
				JTextEditor textEditor=new JTextEditor(console,editorLocator$);
				console.replaceContext(JDesignActions.this,textEditor);
					return;
			}
			if(DELETE_PROPERTY.equals(action$)) {
				//System.out.println("JDesignActions:perform:delete property="+property$);
				int response = JOptionPane.showConfirmDialog(this, "Delete property="+property$+" ?", "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			   if (response == JOptionPane.YES_OPTION) { 
				console.getEntigrator().deleteProperty(property$);
			   }
			   handleDone();
			    return;
			}
			if(EDIT_PROPERTY.equals(action$)) {
			//	System.out.println("JDesignActions:onClick:edit property="+property$+"  instance="+instance$+" parent="+parent$);
				int response = JOptionPane.showConfirmDialog(this, "Edit property="+property$+" ?", "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			   if (response == JOptionPane.YES_OPTION) {
				   thisLocator$=JDesignActions.this.getLocator();
				   String editorLocator$=JTextEditor.classLocator();
				   editorLocator$=Locator.append(editorLocator$,JTextEditor.IN_TEXT, property$);
				   editorLocator$=Locator.append(editorLocator$,PARENT,JDesignActions.this.instance$);
				   editorLocator$=Locator.append(editorLocator$,Locator.LOCATOR_TITLE, "Edit property");
				   thisLocator$=Locator.append(thisLocator$, JItemPanel.ITEM_ACTION, EDIT_PROPERTY);
				   thisLocator$=Locator.append(thisLocator$, JDesignPanel.GROUP,JDesignPanel.PROPERTY);
				   thisLocator$=Locator.append(thisLocator$,JDesignPanel.PROPERTY,property$);
				   editorLocator$=Locator.append(editorLocator$,PARENT, JDesignActions.this.getInstance());
					SessionHandler.putLocator(console.getEntigrator(),thisLocator$);
					JTextEditor textEditor=new JTextEditor(console,editorLocator$);
					console.replaceContext(JDesignActions.this, textEditor);
			   }
				return;
			}
			if(ADD_VALUE.equals(action$)) {
				thisLocator$=JDesignActions.this.getLocator();
			    String editorLocator$=JTextEditor.classLocator();
				if(value$==null)
			        value$="new value";
				editorLocator$=Locator.append(editorLocator$,JTextEditor.IN_TEXT,  value$);
				 editorLocator$=Locator.append(editorLocator$,Locator.LOCATOR_TITLE, "Add value");
				 editorLocator$=Locator.append(editorLocator$,JTextEditor.TEXT_TITLE, "Add value");
				 thisLocator$=Locator.append(thisLocator$, JDesignPanel.VALUE,value$);
				 thisLocator$=Locator.append(thisLocator$, JItemPanel.ITEM_ACTION, ADD_VALUE);
				 thisLocator$=Locator.append(thisLocator$, JDesignPanel.GROUP,JDesignPanel.VALUE);
				 editorLocator$=Locator.append(editorLocator$,PARENT,JDesignActions.this.instance$);
				 SessionHandler.putLocator(console.getEntigrator(),thisLocator$);
				 JTextEditor textEditor=new JTextEditor(console,editorLocator$);
				 console.replaceContext(JDesignActions.this, textEditor);
				// System.out.println("JDesignActions:perform:add value:FINISH");
				return;
			
			}
			if(EDIT_VALUE.equals(action$)) {
				//System.out.println("JDesignActions:perform:edit value="+value$+" property="+property$);
				int response = JOptionPane.showConfirmDialog(this, "Edit value="+value$+" of property="+property$+" ?", "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				 if (response == JOptionPane.YES_OPTION) { 	 
					 thisLocator$=JDesignActions.this.getLocator();
					 String editorLocator$=JTextEditor.classLocator();
					   editorLocator$=Locator.append(editorLocator$,JTextEditor.IN_TEXT, value$);
					   editorLocator$=Locator.append(editorLocator$,PARENT,JDesignActions.this.instance$);
					   thisLocator$=JDesignActions.this.getLocator();
					   thisLocator$=Locator.append(thisLocator$, JItemPanel.ITEM_ACTION, EDIT_VALUE);
					   thisLocator$=Locator.append(thisLocator$, JDesignPanel.GROUP,JDesignPanel.VALUE);
					   thisLocator$=Locator.append(thisLocator$,REPLY,Locator.LOCATOR_TRUE);
					  SessionHandler.putLocator(console.getEntigrator(), thisLocator$);
					   JTextEditor textEditor=new JTextEditor(console,editorLocator$);
					   console.replaceContext(JDesignActions.this, textEditor);
				 	}
					return;	  
				}
			if(DELETE_VALUE.equals(action$)) {
				//System.out.println("JDesignActions:perform:delete value="+value$+"  property="+property$);
				int response = JOptionPane.showConfirmDialog(this, "Delete value="+value$+" of property="+property$+" ?", "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			   if (response == JOptionPane.YES_OPTION) { 
				console.getEntigrator().deleteValue(property$,value$);
			   }
			   handleDone();
				return;
			}
			if(CLEAR_VALUE.equals(action$)) {
				//System.out.println("JDesignActions:perform:delete value="+value$+"  property="+property$);
				int response = JOptionPane.showConfirmDialog(this, "Delete unused values of property="+property$+" ?", "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			   if (response == JOptionPane.YES_OPTION) { 
				console.getEntigrator().deleteUnusedValues(property$);
			   }
			   handleDone();
				return;
			}
			if(ASSIGN_VALUE_LIST.equals(action$)) {
				if(ea!=null) {
					//System.out.println("JDesignActions:onClick:assign property="+property$+" value="+value$);	
				    Entigrator entigrator=console.getEntigrator();
				    String entityKey$;
					for (String e:ea) {
						entityKey$=entigrator.getKey(e);
				    	//System.out.println("JDesignActions:perform:assign to value:label="+e+" key="+entityKey$);
				        entigrator.assignProperty(property$, value$, entityKey$);
					}
				}
				handleDone();
				return;
			}
			if(TAKEOFF_VALUE_LIST.equals(action$)) {
				int response = JOptionPane.showConfirmDialog(this, "Take off property  "+property$+"="+value$+" from selection ?", "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			   if (response == JOptionPane.YES_OPTION) {
				if(ea!=null) {
					//System.out.println("JDesignActions:perform:take off property="+property$+" to value="+value$+" ea="+ea.length);	
				    Entigrator entigrator=console.getEntigrator();
				    String entityKey$;
					for (String e:ea) {
						entityKey$=entigrator.getKey(e);
				    	//System.out.println("JDesignActions:perform:take off value:label="+e+" key="+entityKey$);
				    	entigrator.takeOffProperty(property$, entityKey$);
					}
				}
			   }
			   handleDone();
			   return;
			}
			if(RELOAD_ACTION.equals(action$)) {
				int response = JOptionPane.showConfirmDialog(this, "Reload index ?"+property$+"="+value$+" ?", "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			   if (response == JOptionPane.YES_OPTION) {
				if(value$==null)
					return;
					System.out.println("JDesignActions:perform:reload index: property="+property$+" to value="+value$);	
				    try {
					Entigrator entigrator=console.getEntigrator();
				   // String []ea=entigrator.listEntities();
					 String []ea=entigrator.listRawEntities();
				    if(ea==null||ea.length<1)
				    	return;
				    Sack entity;
				    String val$;
				    ArrayList<String>sl=new ArrayList<String>();
					for (String e:ea) {
						//entity=entigrator.getEntity(e);
						entity=entigrator.getRawEntity(e);
						if(entity==null) {
							System.out.println("JDesignActions:perform:reload index:cannot load entity="+e);
							continue;
						}
						
						val$=entity.getProperty(property$);
						if(value$.equals(val$)) {
							entigrator.putEntity(entity);
							sl.add(e);
						}
							//entigrator.reindexEntity(entity);
					}
					for(String s:sl) {
						entity=entigrator.getEntity(s);
						if(entity==null) {
							System.out.println("JDesignActions:perform:reload index:cannot get entity="+s);
							continue;
						}
						entigrator.reindexEntity(entity);
					}
				    }catch(Exception e) {
				    	System.out.println("JDesignActions:perform:reload index: property="+property$+"="+value$+" error="+e.toString());
				    }
				}
			   handleDone();
			   return;
			}
			JDesignPanel designPanel=new JDesignPanel(console,thisLocator$);
			console.replaceContext(JDesignActions.this, designPanel);
		}
		@Override
		public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
		}
	}
	@Override
	public String reply(JMainConsole console,String locator$) {
//		System.out.println("JDesignActions:reply:locator="+locator$);
		if(locator$==null) {
			return null;
		}
		Properties locator=Locator.toProperties(locator$);
		String action$=locator.getProperty(JItemPanel.ITEM_ACTION);
//		System.out.println("JDesignActions:reply:action="+action$+"  EDIT_PROPERTY="+EDIT_PROPERTY+ "JItemPanel.ITEM_ACTION="+JItemPanel.ITEM_ACTION);
		if(ADD_PROPERTY.equals(action$)) {
			String newProperty$=locator.getProperty(JTextEditor.OUT_TEXT);
			//System.out.println("JDesignActions:reply:add property="+newProperty$);
			if(newProperty$!=null) {
				//System.out.println("JDesignActions:reply:action="+action$);
				console.getEntigrator().addProperty(newProperty$);
				String thisLocator$=getLocator();
				thisLocator$=Locator.append(thisLocator$,JDesignPanel.PROPERTY, newProperty$);
				thisLocator$=Locator.append(thisLocator$, Locator.LOCATOR_SUBTITLE, newProperty$);
			//	System.out.println("JDesignActions:reply:this locator="+thisLocator$);
				SessionHandler.putLocator(console.getEntigrator(), thisLocator$);
				return thisLocator$;
			}
			return locator$; 
		}
			if(EDIT_PROPERTY.equals(action$)) {
				String newProperty$=locator.getProperty(JTextEditor.OUT_TEXT);
				String oldProperty$=locator.getProperty(JDesignPanel.PROPERTY);
				//System.out.println("JDesignActions:reply:edit property="+oldProperty$+"  new property="+newProperty$+" instance="+instance$);
				if(oldProperty$!=null&&newProperty$!=null) {
					 console.getEntigrator().editProperty(oldProperty$, newProperty$);
					 String thisLocator$=locator$;
					 thisLocator$=Locator.append(thisLocator$, Locator.LOCATOR_SUBTITLE, newProperty$);
					 thisLocator$=Locator.append(thisLocator$, JDesignPanel.PROPERTY, newProperty$);
					// System.out.println("JDesignActions:edit property:this locator="+thisLocator$);
					 SessionHandler.putLocator(console.getEntigrator(), thisLocator$);
					 return thisLocator$;
				}
				return locator$;
			}
			if(ADD_VALUE.equals(action$)) {
				property$=locator.getProperty(JDesignPanel.PROPERTY);
				String newValue$=locator.getProperty(JTextEditor.OUT_TEXT);
				//System.out.println("JDesignActions:reply:add value="+newValue$);
				if(newValue$!=null) {
					console.getEntigrator().addPropertyValue(property$,newValue$);
					String thisLocator$=getLocator();
					thisLocator$=Locator.append(thisLocator$,JDesignPanel.VALUE, newValue$);
					thisLocator$=Locator.append(thisLocator$, Locator.LOCATOR_SUBTITLE, newValue$);
					SessionHandler.putLocator(console.getEntigrator(), thisLocator$);
					return thisLocator$;
				}
				return locator$;
			}
			if(EDIT_VALUE.equals(action$)) {
					String newValue$=locator.getProperty(JTextEditor.OUT_TEXT);
				String oldValue$=locator.getProperty(JDesignPanel.VALUE);
				String property$=locator.getProperty(JDesignPanel.PROPERTY);
			//	System.out.println("JDesignActions:reply:edit value="+oldValue$+"  new value="+newValue$+" property="+property$);
				if(oldValue$!=null&&newValue$!=null) {
					 console.getEntigrator().editValue(property$,oldValue$, newValue$);
					 value$=newValue$;
					 String thisLocator$=locator$;
					 thisLocator$=Locator.append(thisLocator$, Locator.LOCATOR_SUBTITLE, newValue$);
					 thisLocator$=Locator.append(thisLocator$, JDesignPanel.VALUE, newValue$);
					// System.out.println("JDesignActions:edit property:this locator="+thisLocator$);
					 SessionHandler.putLocator(console.getEntigrator(), thisLocator$);
					 return thisLocator$;
				}
			}
			return locator$;
	}
	//Property
	JDesignActionItem  getAddPropertyItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,ADD_PROPERTY_TITLE);
		locator.put(IconLoader.ICON_FILE,"add.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,ADD_PROPERTY);
		locator.put(INSTANCE,ADD_PROPERTY_INSTANCE);
		locator.put(PARENT,KEY);
		String locator$=Locator.toString(locator);
		JDesignActionItem  addItem= new JDesignActionItem (console,this, locator$);
	return addItem;	
	}
	
	JDesignActionItem  getDeletePropertyItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,DELETE_PROPERTY_TITLE);
		locator.put(IconLoader.ICON_FILE,"delete.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,DELETE_PROPERTY);
		locator.put(INSTANCE,DELETE_PROPERTY_INSTANCE);
		locator.put(PARENT,KEY);
		String locator$=Locator.toString(locator);
		JDesignActionItem deleteItem= new JDesignActionItem(console, this,locator$);
	return deleteItem;	
	}
	JDesignActionItem  getEditPropertyItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,EDIT_PROPERTY_TITLE);
		locator.put(IconLoader.ICON_FILE,"edit.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,EDIT_PROPERTY);
		locator.put(INSTANCE,EDIT_PROPERTY_INSTANCE);
		locator.put(PARENT,KEY);
		String locator$=Locator.toString(locator);
		JDesignActionItem editItem= new JDesignActionItem(console,this, locator$);
	return editItem;	
	}
//Value
	JDesignActionItem  getAddValueItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,ADD_VALUE_TITLE);
		locator.put(Locator.LOCATOR_SUBTITLE,"Property="+property$+"  Value="+value$);
		locator.put(IconLoader.ICON_FILE,"add.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,ADD_VALUE);
		locator.put(INSTANCE,ADD_VALUE_INSTANCE);
		locator.put(PARENT,KEY);
		String locator$=Locator.toString(locator);
		JDesignActionItem  addItem= new JDesignActionItem (console,this, locator$);
	return addItem;	  
	}
	JDesignActionItem  getEditValueItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,EDIT_VALUE_TITLE);
		locator.put(IconLoader.ICON_FILE,"edit.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,EDIT_VALUE);
		locator.put(INSTANCE,EDIT_VALUE_INSTANCE);
		locator.put(PARENT,KEY);
		String locator$=Locator.toString(locator);
		JDesignActionItem editItem= new JDesignActionItem(console, this,locator$);
	return editItem;	
	}
	JDesignActionItem  getDeleteValueItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,DELETE_VALUE_TITLE);
		locator.put(IconLoader.ICON_FILE,"delete.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,DELETE_VALUE);
		locator.put(INSTANCE,DELETE_VALUE_INSTANCE);
		locator.put(PARENT,KEY);
		String locator$=Locator.toString(locator);
		JDesignActionItem deleteItem= new JDesignActionItem(console,this, locator$);
	return deleteItem;	
	}
	JDesignActionItem  getClearItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,CLEAR_VALUE_TITLE);
		locator.put(IconLoader.ICON_FILE,"broom.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,CLEAR_VALUE);
		locator.put(INSTANCE,CLEAR_VALUE_INSTANCE);
		locator.put(PARENT,KEY);
		String locator$=Locator.toString(locator);
		JDesignActionItem clearItem= new JDesignActionItem(console, this,locator$);
	return clearItem;	
	}
	JDesignActionItem  getAssignValueToListItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,ASSIGN_VALUE_LIST_TITLE);
		locator.put(IconLoader.ICON_FILE,"assignv.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,ASSIGN_VALUE_LIST);
		locator.put(INSTANCE,ASSIGN_VALUE_INSTANCE);
		locator.put(PARENT,KEY);
		
		String locator$=Locator.toString(locator);
		JDesignActionItem assignItem= new JDesignActionItem(console, this,locator$);
	return assignItem;	
	}
	JDesignActionItem  getTakeoffValueFromListItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,TAKEOFF_VALUE_LIST_TITLE);
		locator.put(IconLoader.ICON_FILE,"takeoffv.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,TAKEOFF_VALUE_LIST);
		locator.put(INSTANCE,TAKEOFF_VALUE_INSTANCE);
		locator.put(PARENT,KEY);
		String locator$=Locator.toString(locator);
		JDesignActionItem takeOffItem= new JDesignActionItem(console,this, locator$);
	return takeOffItem;	
	}
	JDesignActionItem  getReloadItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,"Reload");
		locator.put(IconLoader.ICON_FILE,"reload.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,RELOAD_ACTION);
		locator.put(INSTANCE,RELOAD_VALUE_INSTANCE);
		locator.put(PARENT,KEY);
		String locator$=Locator.toString(locator);
		JDesignActionItem takeOffItem= new JDesignActionItem(console,this, locator$);
	return takeOffItem;	
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
	//	System.out.println("JDesignActions:getItems:locator="+locator$);
		Properties locator=Locator.toProperties(locator$);
		property$=locator.getProperty(JDesignPanel.PROPERTY);
		value$=locator.getProperty(JDesignPanel.VALUE);
		String mode$=locator.getProperty(JDesignPanel.MODE);
		String entities$=locator.getProperty(JDesignPanel.ENTITIES);
		if(entities$!=null)
			ea=Locator.toArray(entities$);
		ArrayList< JItemPanel>ipl=new ArrayList< JItemPanel>();
		String group$=Locator.getProperty(locator$,JDesignPanel.GROUP );
		if(JDesignPanel.PROPERTY.equals(group$)) {
			JDesignActionItem addItem= getAddPropertyItem(console);
			JDesignActionItem deleteItem= getDeletePropertyItem(console);
			JDesignActionItem editItem= getEditPropertyItem(console);
			ipl.add(addItem);
			ipl.add(deleteItem);
			ipl.add(editItem);
			//System.out.println("JDesignActions:getItems="+ipl.size());
			JDesignActionItem[] ipa=new JDesignActionItem[ipl.size()];
			ipl.toArray(ipa);
			return ipa;
		}
		if(JDesignPanel.VALUE.equals(group$)) {
		//	System.out.println("JDesignActions:getItems:group="+group$+" property="+property$+" value="+value$+" mode="+mode$);
			JDesignActionItem addItem= getAddValueItem(console);
			JDesignActionItem deleteItem= getDeleteValueItem(console);
			JDesignActionItem editItem= getEditValueItem(console);
			JDesignActionItem clearItem= getClearItem(console);
			JDesignActionItem reloadItem= getReloadItem(console);
			
			ipl.add(addItem);
			ipl.add(deleteItem);
			ipl.add(editItem);
			ipl.add(clearItem);
			ipl.add(reloadItem);
			if(JDesignPanel.ASSIGN_MODE.equals(mode$)&&ea!=null) {
				//System.out.println("JDesignActions:getItems:assignMode:ea="+ea.length);
				JDesignActionItem assignItem= getAssignValueToListItem(console);
				JDesignActionItem takeoffItem= getTakeoffValueFromListItem(console);
				ipl.add(assignItem);
				ipl.add(takeoffItem);
			}
			JDesignActionItem[] ipa=new JDesignActionItem[ipl.size()];
			ipl.toArray(ipa);
			return sortItems(ipa);
		}
		return null;
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.console.JDesignActions");
	    locator.put(Locator.LOCATOR_TITLE,"Design actions");
		locator.put(DEFAULT_PARENT, JDesignPanel.KEY); 
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		System.out.println("JDesignActions:classLocator:locator="+Locator.toString(locator));
		 return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
}
