package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.util.ArrayList;
import java.util.Arrays;

import java.util.Properties;
import java.util.logging.Logger;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JComboBox;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JTextField;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.gui.entity.JListEntities;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JGuiEditor;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
public class JDesignPanel extends JGuiEditor {
	private static final long serialVersionUID = 1L;
	public static final String KEY="_QcvUyL65_AqUY1kw9ZDVSj_BeCU";
	public static final String VALUE_MODE="Auto value mode";
	public static final String PROPERTY_MODE="Auto property mode";
	public static final String ASSIGN_MODE="Assign mode";
	public static final String PROPERTY_NAME="property name";
	public static final String PROPERTY_VALUE="property value";
	public static final String CONTAINERS_LIST="containers list";
	public static final String CONTAINER_LABEL="container label";
	public static final String MODE="mode";
	public static final String PROPERTY="property";
	public static final String VALUE="value";
	public static final String ENTITIES_LIST="entitieslist";
	public static final String ENTITIES="entities";
	public static final String GROUP="group";
	public static final String PRESELECT="preselect";
	private String mode$=VALUE_MODE;
	private JTextField modeField;
	private JComboBox<String> propertyComboBox; 
	private JComboBox<String> valueComboBox;
	private JComboBox<String> entityComboBox;
	private Logger LOGGER =Logger.getLogger(JDesignPanel.class.getName());
    boolean debug=false;
    String adjustment$;
    String property$;
    String value$;
  
	public JDesignPanel(JMainConsole console,String locator$) {
		super(console,locator$);
		//System.out.println("JDesignPanel:locator="+locator$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{100, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0};
		setLayout(gridBagLayout);
		JLabel lblProperty = new JLabel("Property");
		lblProperty.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 String actionsLocator$=JDesignActions.classLocator();
				 actionsLocator$=Locator.append(actionsLocator$, GROUP, PROPERTY);
				 String instance$=getInstance();
				 String thisLocator$=getLocator();
				 thisLocator$=Locator.append(thisLocator$, INSTANCE, instance$);
				 SessionHandler.putLocator(console.getEntigrator(),thisLocator$);
				 actionsLocator$=Locator.append(actionsLocator$, PARENT,instance$ );
				 actionsLocator$=appendState(actionsLocator$);
				 JDesignActions designActions=new JDesignActions(console,actionsLocator$);
				 console.replaceContext(JDesignPanel.this,designActions);
			}
		});
		GridBagConstraints gbc_lblProperty = new GridBagConstraints();
		gbc_lblProperty.insets = new Insets(5, 5, 5, 5);
		gbc_lblProperty.gridx = 0;
		gbc_lblProperty.gridy = 0;
		gbc_lblProperty.anchor=GridBagConstraints.FIRST_LINE_START;
		add(lblProperty, gbc_lblProperty);
		propertyComboBox = new JComboBox<String>();

		GridBagConstraints gbc_propertyComboBox = new GridBagConstraints();
		gbc_propertyComboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_propertyComboBox.insets = new Insets(0, 0, 5, 5);
		gbc_propertyComboBox.gridx = 1;
		gbc_propertyComboBox.gridy = 0;
		gbc_propertyComboBox.anchor=GridBagConstraints.FIRST_LINE_START;
		add(propertyComboBox, gbc_propertyComboBox);

		JLabel lblValue = new JLabel("Value");
		GridBagConstraints gbc_lblValue = new GridBagConstraints();
		gbc_lblValue.insets = new Insets(5, 5, 5, 5);
		gbc_lblValue.gridx = 0;
		gbc_lblValue.gridy = 1;
		gbc_lblValue.anchor=GridBagConstraints.FIRST_LINE_START;
		lblValue.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
               String actionsLocator$=JDesignActions.classLocator();
			   actionsLocator$=Locator.append(actionsLocator$, GROUP, VALUE);
			   String instance$=getInstance();
			   String thisLocator$=getLocator();
			   thisLocator$=Locator.append(thisLocator$, INSTANCE, instance$);
				SessionHandler.putLocator(console.getEntigrator(),thisLocator$);
			   actionsLocator$=Locator.append(actionsLocator$, PARENT, instance$);
			   actionsLocator$=appendState(actionsLocator$);
			   JDesignActions designActions=new JDesignActions(console,actionsLocator$);
			   console.replaceContext(JDesignPanel.this,designActions);
			}
		});
		add(lblValue, gbc_lblValue);

		valueComboBox = new JComboBox<String>();
		GridBagConstraints gbc_valueComboBox = new GridBagConstraints();
		gbc_valueComboBox.insets = new Insets(0, 0, 5, 5);
		gbc_valueComboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_valueComboBox.gridx = 1;
		gbc_valueComboBox.gridy = 1;
		gbc_valueComboBox.anchor=GridBagConstraints.FIRST_LINE_START;
		add(valueComboBox, gbc_valueComboBox);
		
		JLabel lblEntity = new JLabel("Entity");
		lblEntity.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String listLocator$=JListEntities.classLocator();
				 String instance$=getInstance();
				 String thisLocator$=getLocator();
				 thisLocator$=Locator.append(thisLocator$, INSTANCE, instance$);
				 SessionHandler.putLocator(console.getEntigrator(),thisLocator$);
				 listLocator$=Locator.append(listLocator$, PARENT, instance$);
				 listLocator$=appendState(listLocator$);
				 JListEntities listEntities=new JListEntities(console,listLocator$);
				 console.replaceContext(JDesignPanel.this,listEntities);
			}
		});
		GridBagConstraints gbc_lblEntity = new GridBagConstraints();
		gbc_lblEntity.insets = new Insets(5, 5, 5, 5);
		gbc_lblEntity.gridx = 0;
		gbc_lblEntity.gridy = 2;
		gbc_lblEntity.anchor=GridBagConstraints.FIRST_LINE_START;
		add(lblEntity, gbc_lblEntity);

		entityComboBox = new JComboBox<String>();
		entityComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				entity$=(String)entityComboBox.getSelectedItem();
				DefaultComboBoxModel<String> model=new DefaultComboBoxModel <String>(new String[] {entity$});
				entityComboBox.setModel(model);
			}
		});
		
		GridBagConstraints gbc_entityComboBox = new GridBagConstraints();
		gbc_entityComboBox.insets = new Insets(0, 0, 5, 5);
		gbc_entityComboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_entityComboBox.gridx = 1;
		gbc_entityComboBox.gridy = 2;
		gbc_entityComboBox.anchor=GridBagConstraints.FIRST_LINE_START;
		add(entityComboBox, gbc_entityComboBox);
		
		JLabel lblMode = new JLabel("Mode");
		GridBagConstraints gbc_lblMode = new GridBagConstraints();
		gbc_lblMode.gridx = 0;
		gbc_lblMode.gridy = 3;
		gbc_lblMode.insets = new Insets(5, 5, 5, 5);
		gbc_lblMode.anchor=GridBagConstraints.FIRST_LINE_START;
		add(lblMode, gbc_lblMode);
		
		modeField = new JTextField();
		modeField.setFont(new Font("Dialog", Font.BOLD, 14));
		modeField.setEditable(false);
		GridBagConstraints gbc_modeField = new GridBagConstraints();
		gbc_modeField.insets = new Insets(0, 0, 5, 5);
		gbc_modeField.fill = GridBagConstraints.HORIZONTAL;
		gbc_modeField.gridx = 1;
		gbc_modeField.gridy = 3;
		add(modeField, gbc_modeField);
		modeField.setColumns(10);
		modeField.setText(mode$);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.weighty = 1.0;
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx =0;
		gbc_panel.gridy = 4;
		add(panel, gbc_panel);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		propertyComboBox.addItemListener(new ItemListener() {
		@Override
		public void itemStateChanged(ItemEvent e) {
				try{
					//System.out.println("JDesignPanel:property:itemStateChanged");
					property$=(String)propertyComboBox.getSelectedItem();
					JDesignPanel.this.locator$=Locator.append(JDesignPanel.this.locator$, PROPERTY, property$);
					updateLocator();
					//System.out.println("JDesignPanel:property:1:itemStateChanged");
					selectValues(property$);
				}catch(Exception ee){
					LOGGER.severe(ee.toString());
				}
			}
		 });
		valueComboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				try{
				   property$=(String)propertyComboBox.getSelectedItem();
				   value$=(String)valueComboBox.getSelectedItem();
				   JDesignPanel.this.locator$=Locator.append(JDesignPanel.this.locator$, VALUE, value$);
				   entity$=null;
				  // System.out.println("JDesignPanel:value chánged:property="+property$+" value="+value$+" mode="+mode$);
				   if(!ASSIGN_MODE.equals(mode$))
				      selectEntitiesAtValue( (String)propertyComboBox.getSelectedItem(),(String)valueComboBox.getSelectedItem());
				   updateLocator();
				}catch(Exception ee){
					LOGGER.severe(ee.toString());
				}
			}
		 });
		entityComboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				try{
					entity$=(String)entityComboBox.getSelectedItem();
					JDesignPanel.this.locator$=Locator.append(JDesignPanel.this.locator$, Entigrator.ENTITY_LABEL, entity$);
				   updateLocator();
				}catch(Exception ee){
					LOGGER.severe(ee.toString());
				}
			}
		 });
		property$=Locator.getProperty(locator$, PROPERTY);
		value$=Locator.getProperty(locator$, VALUE);
		entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		setSelector(property$,value$,entity$);
	}
	private String  appendState(String locator$) {
			//System.out.println("JDesignPanel:appendState:locator="+locator$);
		Properties locator=Locator.toProperties(locator$);
		try {
		if(propertyComboBox==null)
			return locator$;
		String property$=(String)propertyComboBox.getSelectedItem();
		if(property$!=null)
		 locator.put(PROPERTY, property$);
		String value$=(String)valueComboBox.getSelectedItem();
		if(value$!=null)
		   locator.put(VALUE, value$);
		//String entity$=(String)entityComboBox.getSelectedItem();
		if(entity$!=null)
		   locator.put(Entigrator.ENTITY_LABEL, entity$);
		locator.put(MODE, mode$);
		int cnt= entityComboBox.getItemCount();
        if(cnt>0) {
		String[] ea=new String[cnt];
	    // Get items
	    for (int i = 0; i < cnt; i++) 
	      ea[i] = (String)entityComboBox.getItemAt(i);
	    String ea$=Locator.toString(ea);
	    locator.put(ENTITIES, ea$);
	    }
		}catch(Exception e) {
			System.out.println("JDesignPanel:appendState:"+e.toString());
		}
		return Locator.toString(locator);
	}
	private void setSelector(String property$,String value$,String entity$){
		//System.out.println("JDesignPanel:setSelector:property="+property$+" value="+value$+" entity="+entity$);
		DefaultComboBoxModel<String> pComboBoxModel=new DefaultComboBoxModel<String>();
		String[] pa=null;
		if(property$==null&&value$==null)
			if(entity$!=null) {
				property$="label";
				value$=entity$;
			}
		if(console.getEntigrator()!=null) {
		 pa=console.getEntigrator().listProperties();
		 if(pa!=null) {
			 Arrays.sort(pa);
			 pComboBoxModel=new DefaultComboBoxModel<String>(pa);
		 }
		propertyComboBox.setModel(pComboBoxModel);
		if(property$!=null) {
			 int size=pComboBoxModel.getSize();
		 for(int i=0;i<size;i++) {
			 if(property$.equalsIgnoreCase((String)propertyComboBox.getItemAt(i))) {
				 propertyComboBox.setSelectedIndex(i);
		 }}}
		selectValues((String)propertyComboBox.getSelectedItem());
		if(value$!=null) {
			ComboBoxModel<String> vComboBoxModel=valueComboBox.getModel();
			 int size=vComboBoxModel.getSize();
		 for(int i=0;i<size;i++) {
			 if(value$.equalsIgnoreCase((String)valueComboBox.getItemAt(i))) {
				 valueComboBox.setSelectedIndex(i);
		 }}}
		if(property$!=null&&value$!=null) {
			selectEntitiesAtValue((String)propertyComboBox.getSelectedItem(),(String)valueComboBox.getSelectedItem());
		  if(entity$!=null) {
				ComboBoxModel<String> eComboBoxModel=entityComboBox.getModel();
				 int size=eComboBoxModel.getSize();
			 for(int i=0;i<size;i++) {
				 if(entity$.equalsIgnoreCase((String)entityComboBox.getItemAt(i))) {
					 entityComboBox.setSelectedIndex(i);
			 }}}
		}else
			 selectEntitiesAtValue( (String)propertyComboBox.getSelectedItem(),(String)valueComboBox.getSelectedItem());	
		}
	}
	private void  selectEntitiesAtValue(String property$,String value$) {
		    
		DefaultComboBoxModel<String> eComboBoxModel=new DefaultComboBoxModel<String>();
		String[] ka=console.getEntigrator().listEntities(property$,value$);
			if(ka!=null) {
				//System.out.println("JDesignPanel:selectEntitiesAtValue:ka="+ka.length);
				ArrayList<String>ll=new ArrayList<String>();
				String entityLabel$;
				for(String k:ka) {
					entityLabel$=console.getEntigrator().getLabel(k);
					if(entityLabel$!=null)
					  ll.add(entityLabel$);
				}
			String[]la=new String[ll.size()];
			ll.toArray(la);
			Arrays.sort(la);
			for(String l:la)
				eComboBoxModel.addElement(l);
			}
			entityComboBox.setModel(eComboBoxModel);
	}
	private void  selectValues(String property$) {
	try {
		//System.out.println("JDesignPanel:selectValues:property="+property$);
	DefaultComboBoxModel<String> vComboBoxModel=new DefaultComboBoxModel<String>();
	String[] va=console.getEntigrator().listValues((String)propertyComboBox.getSelectedItem());
	
	if(va!=null){
		Arrays.sort(va);
		vComboBoxModel=new DefaultComboBoxModel<String>(va);
	}else {
		System.out.println("JDesignPanel:selectValues:no values for property="+property$);
	}
	
	valueComboBox.setModel(vComboBoxModel);
		if(!ASSIGN_MODE.equals(mode$)) {
	   selectEntitiesAtValue( (String)propertyComboBox.getSelectedItem(),(String)valueComboBox.getSelectedItem());
	}
	}catch(Exception e) {
		System.out.println("JDesignPanel:selectValues:"+e.toString());
	}
	}
	
private void selectEntities(){
	//System.out.println("JDesignPanel:selectEntities:mode="+mode$);
	DefaultComboBoxModel<String> eComboBoxModel=new DefaultComboBoxModel<String>();
	String property$=(String)propertyComboBox.getSelectedItem()	;
	String value$=(String)valueComboBox.getSelectedItem();
	String[] eka=null;
	if(ASSIGN_MODE.equals(mode$)) 
		return;
	if(VALUE_MODE.equals(mode$)) 
	   eka=console.getEntigrator().listEntities(property$, value$);
	if(PROPERTY_MODE.equals(mode$)) {
		   eka=console.getEntigrator().listEntities(property$);
		  // System.out.println("JDesignPanel:selectEntities:eka="+eka.length);
	}
	if(eka==null) {
		entityComboBox.setModel(eComboBoxModel);
		return;
	}
		//System.out.println("JDesignPanel:valueComboBox:ka="+ka.length);
		ArrayList<String>ll=new ArrayList<String>();
		String label$;
		for(String ek:eka) {
			label$=console.getEntigrator().getLabel(ek);
			if(label$==null) {
			System.out.println("JDesignPanel:select entities:null label for ek="+ek);
			continue;
			}
				ll.add(console.getEntigrator().getLabel(ek));
		}
		String[]la=new String[ll.size()];
		ll.toArray(la);
		Arrays.sort(la);
		for(String l:la)
		eComboBoxModel.addElement(l);
		entityComboBox.setModel(eComboBoxModel);
}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		JMenuItem autoValueModeItem = new JMenuItem(VALUE_MODE);
		autoValueModeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mode$=VALUE_MODE;
				modeField.setText(mode$);
				selectEntities();
			}
			
		} );
		menu.add(autoValueModeItem);
		JMenuItem autoPropertyModeItem = new JMenuItem(PROPERTY_MODE);
		autoPropertyModeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mode$=PROPERTY_MODE;
				modeField.setText(mode$);
				selectEntities();
			}
		} );
		menu.add(autoPropertyModeItem);
		JMenuItem autoAssignModeItem = new JMenuItem(ASSIGN_MODE);
		autoAssignModeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mode$=ASSIGN_MODE;
				modeField.setText(mode$);
			}
    } );
		menu.add(autoAssignModeItem);
		menu.addSeparator();
		return menu;
	}
@Override
	public String getTitle() {
	return "Design";
	}
	@Override
	public String getSubtitle() {
		return console.getEntigrator().getEntihome();
	}
@Override
	public String getLocator() {
		String classLocator$=classLocator();
		locator$=Locator.merge( locator$,classLocator$);
		locator$=appendState(locator$);
	 	//System.out.println("JDesignPanel:getLocator:locator="+locator$);
		String instance$=getInstance();
		locator$=Locator.append(locator$, INSTANCE, instance$);
    	SessionHandler.putLocator(console.getEntigrator(), locator$);
		return locator$;
	  }
private void updateLocator() {
	try {
	 }catch(Exception e) {
		  System.out.println("JDesignPanel:updateLocator:"+e.toString());
	  }
}
public static String classLocator() {
	Properties locator=new Properties();
	 locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
    locator.put(CONTEXT_CLASS,"gdt.gui.console.JDesignPanel");
    locator.put(Locator.LOCATOR_TITLE,"Design");
    locator.put(IconLoader.ICON_FILE,"wrench.png");
	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	 locator.put(INSTANCE,KEY);
     locator.put(PARENT,gdt.gui.console.JAdminPanel.KEY);
	return Locator.toString(locator);
}
@Override
public String getClassLocator() {
	return classLocator();
}
@Override
public String reply(JMainConsole console, String locator$) {
	return null;
}
}
