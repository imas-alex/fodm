package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.ArrayList;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

public class JMainConsole implements PropertyChangeListener{
    public final static String ACTION_NEW_BASE="action new base";
    public static final String MAIN_CONTAINER_KEY="_ltq6dyhIi0i8YOPmph9TqLvPyoY";	
	JMainFrame mainFrame;
	Entigrator entigrator;
	PropertyChangeSupport pcs;
	HashMap<String,JContextContainer> containers=new HashMap<String,JContextContainer>();
	public JMainConsole() {
		mainFrame=new JMainFrame(this);
		mainFrame.setSize(new Dimension(300,300));
		pcs = new PropertyChangeSupport(this);
	}
		
	public Entigrator getEntigrator() {
		return entigrator;
	}
	public JMainFrame getMainFrame() {
		return mainFrame;
	}
	
	public void setEntigrator(String basePath$) {
		//System.out.println("JMainConsole:setEntigrator:base path="+basePath$);
		try {
		if(basePath$==null) {
			return;
		}
		//System.out.println("JMainConsole:setEntigrator:0"); 
		entigrator=new Entigrator(basePath$);
		if(entigrator==null)
			System.out.println("JMainConsole:setEntigrator:cannot set entitgrator path="+basePath$); 
		else {
			SessionHandler.clearFacets(entigrator);
			FacetMaster.setDefaultFacets(this);
			FacetMaster.setDefaultContexts(this);
			//System.out.println("JMainConsole:setEntigrator:default facets finished"); 
			try{FacetMaster.setModuleFacets(this);}catch(Exception ee) {
				System.out.println("JMainConsole:setEntigrator:cannot set module facets=  "+ee.toString()); 
			}
		//	System.out.println("JMainConsole:setEntigrator:module facets finished"); 
			entigrator.getEntityAtLabel("actual");
		}
		}catch(Exception e) {
			System.out.println("JMainConsole:setEntigrator:"+e.toString());	
		}
	}
    public static void main( String[] args) {
		EventQueue.invokeLater(new Runnable() {
		public void run() {
				try {
					final JMainConsole console = new JMainConsole();
					console.mainFrame.setVisible(true);
					console.mainFrame.addWindowListener(new java.awt.event.WindowAdapter() {
					    public void windowClosing(WindowEvent winEvt) {
			//		    	System.out.println("JMainConsole:closing");
					    	  Entigrator entigrator=console.getEntigrator();
					    	  if(entigrator!=null) { 
					    		  SessionHandler.clearInstances(console.getEntigrator());
					    		  JContext context=console.getContext();
					    	     if(context!=null)
						    	     SessionHandler.saveLocator(context.getLocator());
						    	//     SessionHandler.store(entigrator);
					    	     entigrator.close();
					    	   
					    	     JContextContainer [] da=console.getContainers();
					    	    // System.out.println("JMainConsole:closing:da="+da.length);
									for(JContextContainer d:da) {
										d.dispose();
									}
									   
					    	  console.mainFrame.dispose();
					    	  }else
					    		  System.out.println("JMainConsole:closing:entigrator is null"); 
					        System.exit(0);
					    }
					    public void windowActivated(WindowEvent e) {
					    
					    }
					    public void windowDeactivated(WindowEvent e){
					    
					    }
					});
					String path$=System.getProperty("user.home")+"/.entigrator/session";
					Sack session=null;
					File file=new File(path$);
					if(file.exists()) { 
					 try {    session=Sack.readXml(path$);}catch(Exception ee) {}
					}
				   String currentLocator$=null;
				   if(session!=null) {
					   String entihome$=session.getAttributeAt("entihome");
					   File entihome=new File(entihome$);
					   if(entihome$!=null&&entihome.exists()) {
						  console.setEntigrator(entihome$);
						  currentLocator$=SessionHandler.getCurrentLocator(console.getEntigrator());
						  currentLocator$=SessionHandler.restoreLocator();
						 // System.out.println("JMainConsole:run;current locator="+currentLocator$);
					   }
						  if(currentLocator$!=null) {
						 //  System.out.println("JMainConsole:run:current locator="+currentLocator$);
						JContext currentContext=JContext.build(console, currentLocator$);
							if(currentContext!=null)
								console.replaceContext(null,currentContext);
							else
								console.replaceContext(null,new JAdminPanel(console,null));
					   }
				   }else {
					  Entigrator entigrator=JBaseList.setDefaultBase();
					  String default$=entigrator.getEntihome();
					  entigrator.close();
				      console.setEntigrator(default$);
				      JAdminPanel adminPanel=new JAdminPanel(console,null);
				      console.replaceContext(null,adminPanel);
				   }
				} catch (Exception e) {
					//e.printStackTrace();
				}
			}
		});
	}
	
public void clearContext() {
	mainFrame.getContentPane().removeAll();
	mainFrame.clearContextMenu();
}
public JContext getContext() {
	int cnt=mainFrame.getContentPane().getComponentCount();
	if(cnt>1)
		return (JContext)mainFrame.getContentPane().getComponent(0);
	else
		return null;
}

public void replaceContext(JContext alt,JContext neu) {
	try {
		JContextContainer container=mainFrame.getContextContainer();
		if(alt!=null) {
			getEntigrator().removePropertyChangeListener(alt);
			container=getContextContainer(alt);
			if(container==null)
				container=mainFrame.getContextContainer();
		}
	getEntigrator().addPropertyChangeListener(neu);	
	container.putContext(neu);	
	}catch(Exception e) {
		System.out.println("JMainConsole:replaceContext:"+e.toString());	
	}
	}

public void refreshContexts(String[] contexts) {
	if(containers.isEmpty()||contexts==null||contexts.length<1) {
		System.out.println("JMainConsole:refreshContexts:NOP return");
		return;
	}
	 for(Entry<String, JContextContainer> entry: containers.entrySet()) {
		
		 JContext context=entry.getValue().getContext();
		 for(String s:contexts) {
			 System.out.println("JMainConsole:refreshContexts:request="+s+" candidate="+entry.getKey()); 
	      if(s.equals(context.getEntityKey())){
	           context.refresh();
	      }
		 }
	    }
}
public String putContainer(JContextContainer container) {
	String containerKey$=getContextContainerKey(container);
	if(containerKey$!=null)
		return containerKey$;
	containerKey$=Identity.key();
	containers.put(containerKey$, container);
	return containerKey$;
}
public JContextContainer getContextContainer(String containerKey$) {
	if(MAIN_CONTAINER_KEY.equals(containerKey$))
		return mainFrame.getContextContainer();
	if(containers==null)
		return mainFrame.getContextContainer();
	return containers.get(containerKey$);
}
public String getContextContainerKey(JContextContainer container) {
	if(containers==null)
		if(mainFrame.getContextContainer().equals(container))
			return MAIN_CONTAINER_KEY;

	 for(Entry<String, JContextContainer> entry: containers.entrySet()) {
	      if(entry.getValue() == container) {
	           return entry.getKey();
	      }
	    }
	 return null;
}

public boolean hasContainers() {
	if(containers==null)
		return false;
	if(containers.isEmpty())
		return false;
	return true;
}
public String [] listContainers() {
	if(!hasContainers())
		return null;
	ArrayList<String> sl=new ArrayList<String>();
for (HashMap.Entry<String, JContextContainer> entry: containers.entrySet())
    {
       sl.add(entry.getKey());
    }
	String[] sa=new String[sl.size()];
	sl.toArray(sa);
	return sa;	
}
public void removeContainer(String container$) {
	if(containers==null)
		return ;
	containers.remove(container$);
}
public void removeContainer(JContextContainer container) {
	if(containers==null||container==null)
		return ;
	String containerKey$=null;
	for (HashMap.Entry<String, JContextContainer> entry: containers.entrySet())
    {
       if(container.equals(entry.getValue())) {
    	   containerKey$=entry.getKey();
    	   break;
       }
    }
	if(containerKey$!=null)
	  containers.remove(containerKey$);
}
public JContextContainer[] getContainers() {
	if(containers==null)
		return null;
	ArrayList<JContextContainer> dl=new ArrayList<JContextContainer>();
	JContextContainer container;
	for (HashMap.Entry<String, JContextContainer> entry: containers.entrySet())
    {
       container=containers.get(entry.getKey());
       if(container!=null)
    	   dl.add(container);
    }
	JContextContainer[] da=new JContextContainer[dl.size()];
	dl.toArray(da);
	return da;
}
public String saveContext() {
	try {
		if(getContext()==null)
			return null;
		String currentLocator$=getContext().getLocator();
		if(currentLocator$!=null) {
			SessionHandler.putLocator(getEntigrator(), currentLocator$);
			return Locator.getProperty(currentLocator$, JContext.INSTANCE);
		}
	}catch(Exception e) {
		System.out.println("JMainConsole:saveContext:"+e.toString());
	}
	return null;
}

@Override
public void propertyChange(PropertyChangeEvent evt) {
	System.out.println("JMainConsole:propertyChange:evt name="+evt.getPropertyName()+" value="+evt.getNewValue().toString());   
	pcs.firePropertyChange(evt);
}
public JContext[] getContexts() {
	ArrayList<JContext>cl=new ArrayList<JContext>();
    JContext context;
    context=getContext();
    if(context!=null)
    	cl.add(context);
    JContextContainer[]ca=getContainers();
    if(ca!=null)
    	for(JContextContainer c:ca) {
    		context=c.getContext();
    		if(context!=null)
    			cl.add(context);
    	}
    JContext[]cna=new JContext[cl.size()];
    cl.toArray(cna);
	return cna;
}
public JContext[] getContexts(String entityKey$) {
	//System.out.println("JMainConsole:getContexts:entity key="+entityKey$);
    JContext context;
    JContextContainer[]ca=getContainers();
    ArrayList<JContext>cl=new ArrayList<JContext>();
//    System.out.println("JMainConsole:getContexts:ca="+ca.length);
    if(ca!=null)
    	for(JContextContainer c:ca) {
    		context=c.getContext();
    		String candidate$=context.getEntityKey();
    		//System.out.println("JMainConsole:getContexts:candidate="+candidate$);
    		if(entityKey$.equals(candidate$))
    			cl.add(context);
    	}
    JContext[]cna=new JContext[cl.size()];
    cl.toArray(cna);
    //System.out.println("JMainConsole:getContexts:cna="+cna.length);
	return cna;
}

public JContextContainer getContextContainer(JContext context) {
	if(context==null)
		return mainFrame.getContextContainer();
	if(containers==null||containers.size()<1)
		return mainFrame.getContextContainer();
	JContextContainer[]ca=getContainers();
    if(ca!=null)
    	for(JContextContainer c:ca) {
    		if(context.equals(c.getContext()))
    		   return c;
    	}
    return mainFrame.getContextContainer();
}
}

