package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.JPopupMenu;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.gui.facet.ModuleMaster;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
public class JAdminPanel extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_kQdGIn2X1Rd4VKa5E8cje4yvnzI";
	public JAdminPanel(JMainConsole console,String locator$) {
		super(console,locator$);
		nomenu=true;
		JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);
	}
	JItemPanel getDesignItem(JMainConsole console, JContext context,String locator$) {
		String itemLocator$=JDesignPanel.classLocator();
		JItemPanel item=new JDesignItem( console,context, itemLocator$);
		return item;
	}
	JItemPanel getHistoryItem(JMainConsole console, JContext context,String locator$) {
		String itemLocator$=JHistoryPanel.classLocator();
		JItemPanel item=new JHistoryPanelItem( console, context,itemLocator$);
		return item;
	}
	JItemPanel getDisplayItem(JMainConsole console,JContext context, String locator$) {
		String itemLocator$=JDisplayList.classLocator();
		JItemPanel item=new JDisplayListItem( console,context, itemLocator$);
		return item;
	}
	JItemPanel getSearchItem(JMainConsole console, JContext context,String locator$) {
		//System.out.println("JDesignActions:getSearchItem");
		String itemLocator$=JSearchPanel.classLocator();
		JItemPanel item=new JSearchItem( console, context,itemLocator$);
		return item;
	}
	JItemPanel getFacetsItem(JMainConsole console, JContext context,String locator$) {
		//System.out.println("JDesignActions:getSearchItem");
		String itemLocator$=JAllFacetsList.classLocator();
		JItemPanel item=new JFacetsItem( console, context,itemLocator$);
		return item;
	}
	JItemPanel getModulesItem(JMainConsole console, JContext context,String locator$) {
		String itemLocator$=ModuleMaster.classLocator();
		JItemPanel item=new JFacetsItem(console,context, itemLocator$);
		return item;
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console,String locator$) {
		ArrayList< JItemPanel>ipl=new ArrayList< JItemPanel>();
		JItemPanel dip=getDesignItem( console,this, locator$);
		ipl.add(dip);
		JItemPanel tip=getHistoryItem( console,this, JHistoryPanel.classLocator());
		ipl.add(tip);
		JItemPanel sip=getSearchItem( console, this,JSearchPanel.classLocator());
		ipl.add(sip);
		JItemPanel fi=getFacetsItem( console, this,JAllFacetsList.classLocator());
		ipl.add(fi);
		JItemPanel di=getDisplayItem( console,this, JDisplayList.classLocator());
		ipl.add(di);
		JItemPanel[] ipa=new JItemPanel[ipl.size()];
		ipl.toArray(ipa);
		return sortItems(ipa);
	}
	
	public class JDesignItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JDesignItem(JMainConsole console,JContext context, String locator$) {
			super(console,context, locator$);
		}
	@Override
	public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
		}
		@Override
	public void onClick(JMainConsole console, String locator$) {
			String thisInstance$=context.getInstance();
			String designLocator$=JDesignPanel.classLocator();
			designLocator$=Locator.append(designLocator$, PARENT, thisInstance$);
			JDesignPanel designPanel=new JDesignPanel(console,designLocator$);
			console.replaceContext(context,designPanel);
		}
	}
	public class JHistoryPanelItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JHistoryPanelItem(JMainConsole console,JContext context, String locator$) {
			super(console,context, locator$);
		}
	@Override
	public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
	}
	@Override
	public void onClick(JMainConsole console, String locator$) {
		String thisInstance$=console.saveContext();
		String historyLocator$=JHistoryPanel.classLocator();
		JHistoryPanel historyPanel=new JHistoryPanel(console,historyLocator$);
		console.replaceContext(JAdminPanel.this,historyPanel);
		}
	}
	public class JDisplayListItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JDisplayListItem(JMainConsole console,JContext context, String locator$) {
			super(console,context, locator$);
		}
		@Override
	public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
	}
	@Override
	public void onClick(JMainConsole console, String locator$) {
	//	System.out.println("JAdminPanel:display on click:locator="+locator$); 
		String displayListLocator$=JDisplayList.classLocator();
	    JDisplayList displayList=new JDisplayList(console,displayListLocator$);
	    console.replaceContext(JAdminPanel.this,displayList);
		}
	
	}
	public class JSearchItem extends JItemPanel{
		private static final long serialVersionUID = 1L;

		public JSearchItem(JMainConsole console,JContext context, String locator$) {
			super(console, context,JSearchPanel.classLocator());
			//System.out.println("JAdminPanel: search panel:locator="+locator$);
		}
		@Override
	   public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
		}
		@Override
		public void onClick(JMainConsole console, String locator$) {
			String searchLocator$=JSearchPanel.classLocator();
			String thisInstance$=context.getInstance();
			searchLocator$=Locator.append(searchLocator$, PARENT, thisInstance$);
			JSearchPanel searchPanel=new JSearchPanel(console,searchLocator$);
			console.replaceContext(context,searchPanel);
		}
		
	}
	public class JFacetsItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JFacetsItem(JMainConsole console,JContext context, String locator$) {
			super(console, context,JAllFacetsList.classLocator());
			//System.out.println("JAdminPanel: search panel:locator="+locator$);
		}
		@Override
	   public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
		}
		@Override
		public void onClick(JMainConsole console, String locator$) {
			//System.out.println("JAdminPanel: all facets:locator="+locator$);
			JAllFacetsList allFacetsList=new JAllFacetsList(console,locator$); 
			console.replaceContext(JAdminPanel.this,allFacetsList);
		}
	}
	@Override
	public String getLocator() {
		  return classLocator();
	  }
	@Override
	public String getTitle() {
		return "Admin";
	}
	@Override
	public String getInstance() {
		  return KEY;
	  }
public static String classLocator() {
	 Properties locator=new Properties();
     locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
     locator.put(CONTEXT_CLASS,"gdt.gui.console.JAdminPanel");
     locator.put(Locator.LOCATOR_TITLE,"Admin");
     locator.put(INSTANCE,gdt.gui.console.JAdminPanel.KEY);
     locator.put(PARENT,gdt.gui.console.JAdminPanel.KEY);
     locator.put(NON_REMOVABLE,Locator.LOCATOR_TRUE);
     return Locator.toString(locator);
}
@Override
public String getClassLocator() {
	return classLocator();
}
@Override
public String reply(JMainConsole console, String locator$) {
	return null;
}
@Override
public boolean handleDone() {
	return false;
}
}


