package gdt.gui.entity;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JDesignPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
import gdt.gui.generic.JTextEditor;
public class JDefaultServicesList extends JItemsListPanel{
	public static final String KEY="_HAz07cIpG5RWml0zHfLspBIgC_o";
	public final String EDIT_TITLE="Edit";
	public final String EDIT="edit";
	public final String DELETE_TITLE="Delete";
	public final String DELETE="delete";
	public final String RENAME_TITLE="Rename";
	public final String RENAME="rename";
	public final String REINDEX="reindex";
	public final String REINDEX_TITLE="Reindex";
	public final String LINK="link";
	public final String LINK_TITLE="Link";
	public final String CUSTOMER="customer";
	public final String CUSTOMER_TITLE="Customer";
	public final String COPY="copy";
	public final String COPY_TITLE="Copy";
	public final String CLONE="clone";
	public final String CLONE_TITLE="Clone";
	String property$;
	String value$;
	//String entity$;
	String entities$;
	String[] ea=null;
	public JDefaultServicesList(JMainConsole console, String alocator$) {
		super(console, alocator$);
		Properties locator=Locator.toProperties(alocator$);
		entity$=locator.getProperty(Entigrator.ENTITY_LABEL);
		parent$=locator.getProperty(PARENT);
		//container$=locator.getProperty(JContextContainer.CONTAINER);
		//System.out.println("JDefaultServicesList:entity="+entity$+" container="+container$+" parent="+parent$);
		if(entity$!=null) {
			locator$=Locator.append(locator$,Entigrator.ENTITY_LABEL ,entity$);
		}	
		else {
			System.out.println("JDefaultServicesList:entity is null in locator="+alocator$);
		}
		if(parent$!=null) {
			locator$=Locator.append(locator$,PARENT ,parent$);
		}	
		else {
			System.out.println("JDefaultServicesList:parent is null in locator="+alocator$);
		}
		JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);
	}
	public JDefaultServicesList(JMainConsole console) {
		super(console);
	}
	private static final long serialVersionUID = 1L;
	@Override
	public String getTitle() {
		return "Default entity services";
	}
	@Override
	public String getSubtitle() {
		return entity$;
	}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Select all");
		menu=removeItem(menu,"Unselect all");
		menu=removeItem(menu,"Delete");
		return menu;
		}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String alocator$) {
		//System.out.println("JDefaultServices:getItems:entity="+entity$);
		ArrayList< JItemPanel>ipl=new ArrayList< JItemPanel>();
		JEntityServiceItem editItem= getEditItem(console);
			
			ipl.add(editItem);
			JEntityServiceItem renameItem= getRenameItem(console);
			ipl.add(renameItem);
			JEntityServiceItem deleteItem= getDeleteItem(console);
			ipl.add(deleteItem);
			JEntityServiceItem indexItem= getIndexItem(console);
			ipl.add(indexItem);
			JEntityServiceItem linkItem= getLinkItem(console);
			ipl.add(linkItem);
			if(entity$!=null) {
				Sack entity =console.getEntigrator().getEntityAtLabel(entity$);	
				if(entity.existsElement("customer")) {
					JEntityServiceItem customerItem= getCustomerItem(console);
					ipl.add(customerItem);
			}
			}else {
				System.out.println("JDefaultServices:getItems:entity is null");
			}
			ipl.add(deleteItem);
			JEntityServiceItem copyItem= getCopyItem(console);
			ipl.add(copyItem);
			JEntityServiceItem cloneItem= getCloneItem(console);
			ipl.add(cloneItem);
			JEntityServiceItem[] ipa=new JEntityServiceItem[ipl.size()];
			ipl.toArray(ipa);	
		return sortItems(ipa);
	}
	
	@Override
	public String reply(JMainConsole console, String locator$) {
		System.out.println("JDefaultServices:reply:locator="+locator$);
		Properties locator=Locator.toProperties(locator$);
		String action$=locator.getProperty(ACTION);
		//System.out.println("JDefaultServices:reply:action="+action$);
		if(RENAME.equals(action$)) {
			String oldName$=locator.getProperty(Entigrator.ENTITY_LABEL);
			String newName$=locator.getProperty(JTextEditor.OUT_TEXT);
			Entigrator entigrator=console.getEntigrator();
			if(oldName$!=null) {
			String entityKey$=entigrator.getKey(oldName$);
			System.out.println("JDefaultServices:reply:rename:label old="+oldName$+"  new="+newName$+"  instance="+instance$);
			entigrator.assignLabel(newName$, entityKey$);
			String newLocator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, newName$);
			SessionHandler.putLocator(entigrator, newLocator$);
			setLocator(newLocator$);
			return  newLocator$;
			}else {
				System.out.println("JDefaultServices:reply:action="+action$+" old name is null");	
			}
		}
	return  locator$;
	}
	
	JEntityServiceItem getEditItem(	JMainConsole console) {
	//	System.out.println("JDefaultServices:getEditItem:locator:="+locator$);	
		Properties itemLlocator=new Properties();
			itemLlocator.put(Locator.LOCATOR_TITLE,EDIT_TITLE);
			itemLlocator.put(IconLoader.ICON_FILE,"edit.png");
			itemLlocator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
			itemLlocator.put(JItemPanel.ITEM_ACTION,EDIT);
			String itemLocator$=Locator.toString(itemLlocator);
			JEntityServiceItem editItem= new JEntityServiceItem(console,this, itemLocator$);
			return editItem;	
	}
	JEntityServiceItem getIndexItem(	JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,"Reindex");
		locator.put(IconLoader.ICON_FILE,"index.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,REINDEX);
		if(entity$!=null)
		   locator.put(Entigrator.ENTITY_LABEL,entity$);
		String locator$=Locator.toString(locator);
		JEntityServiceItem editItem= new JEntityServiceItem(console,this, locator$);
	return editItem;	
}
	JEntityServiceItem getDeleteItem(	JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,DELETE_TITLE);
		locator.put(IconLoader.ICON_FILE,"delete.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,DELETE);
		if(entity$!=null)
		locator.put(Entigrator.ENTITY_LABEL,entity$);
		if(property$!=null)
		locator.put(JDesignPanel.PROPERTY,property$);
		if(value$!=null)
		locator.put(JDesignPanel.VALUE,value$);
		String locator$=Locator.toString(locator);
		JEntityServiceItem deleteItem= new JEntityServiceItem(console,this, locator$);
	return deleteItem;	
}
	JEntityServiceItem getRenameItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,RENAME_TITLE);
		locator.put(IconLoader.ICON_FILE,"rename.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,RENAME);
		if(entity$!=null)
		locator.put(Entigrator.ENTITY_LABEL,entity$);
		String renameLocator$=Locator.toString(locator);
		JEntityServiceItem renameItem= new JEntityServiceItem(console,this, renameLocator$);
	return renameItem;	
}
	JEntityServiceItem getLinkItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,LINK_TITLE);
		locator.put(IconLoader.ICON_FILE,"link.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,LINK);
		if(entity$!=null)
		locator.put(Entigrator.ENTITY_LABEL,entity$);
		String linkLocator$=Locator.toString(locator);
		JEntityServiceItem linkItem= new JEntityServiceItem(console,this, linkLocator$);
	return linkItem;	
}
	JEntityServiceItem getCustomerItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,CUSTOMER_TITLE);
		locator.put(IconLoader.ICON_FILE,"include.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,CUSTOMER);
		if(entity$!=null)
		locator.put(Entigrator.ENTITY_LABEL,entity$);
		String customerLocator$=Locator.toString(locator);
		JEntityServiceItem customerItem= new JEntityServiceItem(console,this, customerLocator$);
	return customerItem;	
}
	JEntityServiceItem getCopyItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,COPY_TITLE);
		locator.put(IconLoader.ICON_FILE,"copy.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,COPY);
		if(entity$!=null)
		locator.put(Entigrator.ENTITY_LABEL,entity$);
		String linkLocator$=Locator.toString(locator);
		JEntityServiceItem linkItem= new JEntityServiceItem(console,this, linkLocator$);
	return linkItem;	
}
	JEntityServiceItem getCloneItem(JMainConsole console) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,CLONE_TITLE);
		locator.put(IconLoader.ICON_FILE,"clone.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(JItemPanel.ITEM_ACTION,CLONE);
		if(entity$!=null)
		locator.put(Entigrator.ENTITY_LABEL,entity$);
		String cloneLocator$=Locator.toString(locator);
		JEntityServiceItem cloneItem= new JEntityServiceItem(console,this, cloneLocator$);
	return cloneItem;	
}
	 public static String classLocator() {
			Properties locator=new Properties();
			locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
		    locator.put(CONTEXT_CLASS,"gdt.gui.entity.JDefaultServicesList");
		    locator.put(Locator.LOCATOR_TITLE,"Entity");
		    locator.put(IconLoader.ICON_FILE,"services.png");
		 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
			locator.put(DEFAULT_PARENT, JEntityFacetList.KEY);
			return Locator.toString(locator);
		} 
	private class JEntityServiceItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		String action$;
		public JEntityServiceItem ( JMainConsole console,JContext context, String locator$) {
			super(console,context, locator$);
			//System.out.println("JEntityServiceItem: locator="+locator$);
			action$=Locator.getProperty(locator$, JItemPanel.ITEM_ACTION);
			//System.out.println("JEntityServiceItem:action="+action$+"  entity="+entity$);
		}
		@Override
		public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
		}
		@Override
		public void onClick(JMainConsole console, String alocator$) {
			locator$=JDefaultServicesList.this.getLocator();
			
			//System.out.println("JDefaultServicesList:onClick:this locator="+locator$);
			if(EDIT.equals(action$)) {
				String editorLocator$=JEntityEditor.classLocator();
				String thisLocator$=JDefaultServicesList.this.getLocator();
				editorLocator$=Locator.append(editorLocator$,PARENT,getInstance());
				if(entity$!=null)
				   editorLocator$=Locator.append(editorLocator$,Entigrator.ENTITY_LABEL,entity$);
				SessionHandler.putLocator(console.getEntigrator(), thisLocator$);
				JEntityEditor entityEditor=new JEntityEditor(console,editorLocator$);
				console.replaceContext(JDefaultServicesList.this,entityEditor);
				}
			if(RENAME.equals(action$)) {
				String editorLocator$=JTextEditor.classLocator();
				editorLocator$=Locator.append(editorLocator$, JTextEditor.IN_TEXT,  Locator.getProperty(locator$, Entigrator.ENTITY_LABEL));
				locator$=Locator.append(locator$, ACTION, RENAME);
				locator$=Locator.append(locator$, JTextEditor.IN_TEXT, Locator.getProperty(locator$, Entigrator.ENTITY_LABEL));
				String parent$=Locator.getProperty(locator$,PARENT);
				if(parent$==null) {
					locator$=Locator.append(locator$, PARENT, JAdminPanel.KEY);
				}
				editorLocator$=Locator.append(editorLocator$,PARENT,Locator.getProperty(locator$, INSTANCE));
		//		System.out.println("JDefaultServicesList:onClick:locator="+locator$);
				SessionHandler.putLocator(console.getEntigrator(), locator$);
				JTextEditor  textEditor=new JTextEditor (console,editorLocator$);
				console.replaceContext(JDefaultServicesList.this, textEditor);
				}
			if(DELETE.equals(action$)) {
				Sack entity =console.getEntigrator().getEntityAtLabel(entity$);	
				String permanent$=entity.getAttributeAt(Sack.PERMANENT);
				if(Locator.LOCATOR_TRUE.equals(permanent$)) {
					JOptionPane.showMessageDialog(JDefaultServicesList.this, "Cannot delete permanent entity");
					return;
				}
				String question$="Delete entity=" +entity$+" ?";
				String[] sa= console.getEntigrator().listCustomers(entity);
				if(sa!=null)
				   question$="Delete entity=" +entity$+" having "+sa.length+" customers ?";
				int response = JOptionPane.showConfirmDialog(JDefaultServicesList.this, question$, "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			   if (response == JOptionPane.YES_OPTION) { 
				   console.getEntigrator().deleteEntity(console.getEntigrator().getKey(entity$));
				   String designPanel$=JDesignPanel.classLocator();
				   JDesignPanel designPanel=new JDesignPanel(console,designPanel$);
				   console.replaceContext(JDefaultServicesList.this, designPanel);
			   		}
				}
			if(REINDEX.equals(action$)) {
			//	System.out.println("JDefaultServicesList:onClick:reindex:entity="+entity$);
				Sack entity =console.getEntigrator().getEntityAtLabel(entity$);	
				console.getEntigrator().reindexEntity(entity);
			   }
			if(LINK.equals(action$)) {
				String linkList$=JCustomerList.classLocator();
				linkList$=Locator.merge(linkList$,locator$);
				linkList$=Locator.append(linkList$, Entigrator.ENTITY_LABEL, entity$);
				linkList$=Locator.append(linkList$,PARENT,getInstance());
				SessionHandler.putLocator(console.getEntigrator(), getLocator());
				JLinkList linkList=new JLinkList(console,linkList$);
				console.replaceContext(JDefaultServicesList.this, linkList);
			   }
			if(CUSTOMER.equals(action$)) {
				String customerList$=JCustomerList.classLocator();
				customerList$=Locator.merge(customerList$,locator$);
				customerList$=Locator.append(customerList$, Entigrator.ENTITY_LABEL, entity$);
				customerList$=Locator.append(customerList$,PARENT,getInstance());
				SessionHandler.putLocator(console.getEntigrator(), getLocator());
				JCustomerList customerList=new JCustomerList(console,customerList$);
				console.replaceContext(JDefaultServicesList.this, customerList);
			   }
			if(COPY.equals(action$)) {
				String entityKey= console.getEntigrator().getKey(entity$);
				SessionHandler.clearCopy(console.getEntigrator());
				SessionHandler.putCopiedEntity(console.getEntigrator(), entityKey);
			   }
			if(CLONE.equals(action$)) {
				Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
				Sack clone=console.getEntigrator().cloneEntity(entity);
				String cloneServices$=JDefaultServicesList.classLocator();
				cloneServices$=Locator.append(cloneServices$, Entigrator.ENTITY_LABEL, clone.getProperty("label"));
				JAdminPanel adminPanel=new JAdminPanel(console,null);
				String adminInstance$=adminPanel.getInstance();
				String adminLocator$=adminPanel.getLocator();
				SessionHandler.putLocator(console.getEntigrator(), adminLocator$);
				cloneServices$=Locator.append(cloneServices$, PARENT, adminInstance$);
				JDefaultServicesList cloneServices=new JDefaultServicesList(console,cloneServices$);
				console.replaceContext(JDefaultServicesList.this, cloneServices);
			   }
			}
		}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	
}
