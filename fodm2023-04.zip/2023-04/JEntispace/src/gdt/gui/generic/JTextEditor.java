package gdt.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
/*
 * This file is part of JEntigrator.

    JEntigrator is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    JEntigrator is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with JEntigrator.  If not, see <http://www.gnu.org/licenses/>.
 */
import java.util.Properties;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.gui.console.JMainConsole;
import gdt.gui.console.JSearchPanel;
import javax.swing.JEditorPane;

public class JTextEditor extends  JGuiEditor{
private static final long serialVersionUID = 1L;
public final static String IN_TEXT="in text";	
public final static String OUT_TEXT="out text";	
public final static String SUBTITLE="subtitle";	
public final static String KEY="_WY6LHBesSbcDFsE8799w6_TfF1Y";	
public final static String TEXT_TITLE="text title";	
private JEditorPane editorPane;
protected String inText$;
protected String outText$;
String parent$;
String parentLocator$;
boolean debug=false;
public JTextEditor(JMainConsole console) {
	super(console);
	setLayout(new BorderLayout());
    editorPane = new JEditorPane();
    editorPane.getDocument().addDocumentListener(new DocumentListener() {
		@Override
		public void changedUpdate(DocumentEvent arg0) {
		}
		@Override
		public void insertUpdate(DocumentEvent arg0) {
			updateParentLocator();
		}
		@Override
		public void removeUpdate(DocumentEvent arg0) {
			updateParentLocator();
		}
    });
	add(editorPane);
}
public JTextEditor(JMainConsole console,String locator$) {
	    super(console,locator$);
	   // System.out.println("JTextEditor:locator="+locator$);
	    parent$=Locator.getProperty(locator$, PARENT);
	    setLayout(new BorderLayout());
	    editorPane = new JEditorPane();
	    editorPane.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void changedUpdate(DocumentEvent arg0) {
				// System.out.println("TextEditor:editorPane:changedUpdate="+arg0.toString());
			}
			@Override
			public void insertUpdate(DocumentEvent arg0) {
				updateParentLocator();
			}
			@Override
			public void removeUpdate(DocumentEvent arg0) {
				updateParentLocator();
			}
	    });
		add(editorPane);
		inText$=Locator.getProperty(locator$,IN_TEXT);
		editorPane.setText(inText$);
	}
private void updateParentLocator() {
	parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(), parent$);
	if(parentLocator$!=null) {
        parentLocator$=Locator.append(parentLocator$, OUT_TEXT, editorPane.getText().strip());
        SessionHandler.putLocator(console.getEntigrator(),parentLocator$);
	}else
		System.out.println("JTextEditor:updateParentLocator:cannot get parent locator instance="+parent$);  
	//System.out.println("JTextEditor:updateParentLocator:parent locator="+parentLocator$);
}

@Override
	public String getLocator() {
		if(editorPane!=null)
		   locator$=Locator.append(locator$, OUT_TEXT, editorPane.getText());
		return locator$;
	}
	public static String classLocator() {
		Properties locator=new Properties();
		 locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.generic.JTextEditor");
	    locator.put(Locator.LOCATOR_TITLE,"Edit");
		 locator.put(IconLoader.ICON_FILE,"edit.png");
		 locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		 locator.put(INSTANCE,KEY);
		 locator.put(DEFAULT_PARENT,JSearchPanel.KEY);
		 return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
}
