package gdt.gui.generic;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import javax.swing.border.BevelBorder;
import gdt.base.generic.Locator;
import gdt.gui.console.JMainConsole;
import java.util.Properties;

public class JInternalDisplay extends JInternalFrame implements JContextContainer{
	private static final long serialVersionUID = 1L;
	public final static String RACK_LABEL="rack label";
	public final static String CONTEXT_LABEL="context label";
	public final static String INTERNAL_DISPLAY_ITEM="internal display item";
	public final static String INTERNAL_DISPLAY_DESKTOP="internal display desktop";
	public final static String INTERNAL_DISPLAY_TYPE="internal display type";
	public final static String INTERNAL_DISPLAY_CONTEXT="internal display context";
	protected JContext context;
    protected JMainConsole console;
    protected JMenu menu;
    protected JLabel subtitle;
    protected String desktop$;
    protected String item$;
    protected String context$;
    protected String locator$;
  
    public JInternalDisplay(JMainConsole console,String locator$) {
    	super();
    	this.console=console;
    	this.locator$=locator$;
    	item$=Locator.getProperty(locator$,INTERNAL_DISPLAY_ITEM );
    	desktop$=Locator.getProperty(locator$,INTERNAL_DISPLAY_DESKTOP );
    	//System.out.println("JInternalDisplay:display locator="+locator$);
    	subtitle = new JLabel();
    	subtitle.setPreferredSize(new Dimension(30,20));
    	subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
    	subtitle.setOpaque(true);
    	subtitle.setBackground(Color.BLACK);
    	subtitle.setForeground(Color.WHITE);
    	getContentPane().add(subtitle,BorderLayout.SOUTH);
        setVisible(true);
		setIconifiable(true);
		setMaximizable(true);
		setResizable(true);
		if(console!=null)
		 console.putContainer(this);
		addComponentListener(new ComponentAdapter() {
 		   public void componentResized(ComponentEvent e) {
		    	revalidate();
		    	repaint();
		    }
 		});
    }
    public static String classLocator() {
		Properties locator=new Properties();
		locator.put(JContextContainer.CONTAINER_TYPE,INTERNAL_DISPLAY_TYPE);
	    locator.put(JContext.CONTEXT_CLASS,"gdt.gui.generic.JInternalDisplay");
	    locator.put(Locator.LOCATOR_TITLE,"JInternalDisplay");
		return Locator.toString(locator);
	   }
    public String getLocator() {
    	locator$=classLocator();
    	if(item$!=null)
    		locator$=Locator.append(locator$, INTERNAL_DISPLAY_ITEM,item$);
    	if(desktop$!=null)
    		locator$=Locator.append(locator$, INTERNAL_DISPLAY_DESKTOP,desktop$);
    	if(context$!=null)
    			locator$=Locator.append(locator$,INTERNAL_DISPLAY_CONTEXT,context$);
    	return locator$;
    }
 
	@Override
	public JContext getContext() {
				return context;
	}
	
	 public String getItem() {
	    	return item$;
	    }
	 public JDesktopPane getDesktop() {
	    	return this.getDesktopPane();
	    }
	public void setItem(String key$) {
		item$=key$;
	}
	public void setDesktop(String key$) {
		desktop$=key$;
	}
	
	@Override
	public void setSubtitle(String subtitle$) {
		subtitle.setText(subtitle$);
	}
	@Override
	public JItemPanel getItemPanel() {
		return null;
	/*
		try {
		String locator$=getLocator();
	  //   System.out.println("JInternalDisplay:getItemPanel:locator="+locator$);
	   
		gdt.gui.facet.rack.JRackFrame parent=(gdt.gui.facet.rack.JRackFrame)getParent();
	   //  System.out.println("JInternalDisplay:getItemPanel:parent="+parent.getClass().getName());
	     JInternalDisplayItem  itemPanel=new JInternalDisplayItem (console,locator$);
	     itemPanel.rackDisplay=parent.rackDisplay;
	     return itemPanel;
	}catch(Exception e) {
		System.out.println("JInternalDisplay:getItemPanel:"+e.toString());
	   return null;
	}
	*/
	}
	class JInternalDisplayItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		//public JRackDisplay rackDisplay;
		public JInternalDisplayItem(JMainConsole console, String locator$) {
			super(console,getContext(), locator$);
		}
		@Override
		public String getLocator(){
			String itemLocator$=super.getLocator();
					return itemLocator$;
		}
		@Override
		public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
		}
		@Override
		public void onClick(JMainConsole console, String locator$) {
           /*
			if(rackDisplay!=null)
            	 rackDisplay.toFront();
        	 System.out.println("JInternalDisplay:toFront:parent="+this.getParent().getClass().getName());
        	 */  
		}
		}


	@Override
	public void putContext(JContext context) {
		// TODO Auto-generated method stub
		
	}
}		
	