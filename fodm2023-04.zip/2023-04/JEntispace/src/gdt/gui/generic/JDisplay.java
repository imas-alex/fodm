package gdt.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.border.BevelBorder;

import gdt.base.generic.EventHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JDisplayList;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.facet.rack.JRackFrame;

import javax.swing.JPanel;
import javax.swing.JPopupMenu;

public class JDisplay extends JDialog implements JContextContainer{
private static final long serialVersionUID = 1L;
public static final String DISPLAY_KEY="display key";    
 public static final String DISPLAY_WIDTH="display width";  
 public static final String DISPLAY_HEIGHT="display height";
 public static final String DISPLAY_WPOS="display wpos"; 
 public static final String DISPLAY_HPOS="display hpos"; 
 public static final String DISPLAY_LOCATOR="display locator"; 
 public static final String CONTEXT_INSTANCE="context instance";
 public static final String DISPLAY_TRUE="display true"; 
 public static final String DISPLAY="display"; 
	protected JContext context;
    protected JMainConsole console=null;
    protected JMenu menu;
    protected String locator$;
    JPanel contextPanel;
    protected JLabel subtitle;
    BorderLayout borderLayout=new BorderLayout(0, 0);
    protected JMenuBar menuBar = new JMenuBar();
    public JDisplay() {
    	super();
    	setTitle("Title");
    	setJMenuBar(menuBar);
    	menu=new JMenu("Context");
    	menuBar.add(menu);
    	getContentPane().setLayout(borderLayout);
    	subtitle = new JLabel();
    	subtitle.setText("Subtitle");
    	subtitle.setPreferredSize(new Dimension(30,20));
    	subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
    	subtitle.setOpaque(true);
    	subtitle.setBackground(Color.BLACK);
    	subtitle.setForeground(Color.WHITE);
    	getContentPane().add(subtitle);
    }
     public JDisplay(JMainConsole console) {
    	super();
    	this.console=console;
    	getContentPane().setLayout(borderLayout);
    	setJMenuBar(menuBar);
    	subtitle = new JLabel();
    	subtitle.setPreferredSize(new Dimension(30,20));
    	subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
    	subtitle.setOpaque(true);
    	subtitle.setBackground(Color.BLACK);
    	subtitle.setForeground(Color.WHITE);
    	subtitle.setVisible(true);
    	borderLayout.addLayoutComponent(subtitle,BorderLayout.SOUTH);
   		setSize(console.getMainFrame().getSize());
   		setLocationRelativeTo(console.getMainFrame());
		setVisible(true);
		if(locator$!=null) {
		context=JContext.build(console, locator$);
		if(context!=null) {
			borderLayout.addLayoutComponent(subtitle, BorderLayout.SOUTH);
			putContext(context);
			setSubtitle(context.getSubtitle());
		}
		}
    }
     public JDisplay(JMainConsole console,String locator$) {
     	super();
     	this.console=console;
     	this.locator$=locator$;
     	subtitle = new JLabel();
     	subtitle.setPreferredSize(new Dimension(30,20));
     	subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
     	subtitle.setOpaque(true);
     	subtitle.setBackground(Color.BLACK);
     	subtitle.setForeground(Color.WHITE);
     	setSize(console.getMainFrame().getSize());
   		setLocationRelativeTo(console.getMainFrame());
 		setVisible(true);
 		
 		if(locator$!=null) {
 		JContext context=JContext.build(console, locator$);
 		if(context!=null) {
 			putContext(context);
 		    subtitle.setText(context.getSubtitle());
 		}
 		}
     }
    public void putContext(JContext acontext ) {
    setTitle("Title");
   	this.context=acontext;
    if(context==null) {
   		System.out.println("JDisplay:putContext:context is null");
    	return ;
   	}
    try {
    	setJMenuBar(menuBar);
    	menu=context.getContextMenu();
    	if(menu!=null) {
    		menuBar.removeAll();
    		menuBar.add(menu);
        	menu=JContext.removeItem(menu,"Display");
        	menu.addSeparator();
        	}else {
        		 menu=new JMenu("Context");
        	}
            JMenuItem deleteItem = new JMenuItem("Dispose");
    		deleteItem.addActionListener(new ActionListener() {
    			@Override
    			public void actionPerformed(ActionEvent arg0) {
    				int response = JOptionPane.showConfirmDialog( JDisplay.this, "Finally delete display ?", "Confirm",JOptionPane.YES_NO_CANCEL_OPTION);
    			   if (response == JOptionPane.YES_OPTION) { 
    				  console.removeContainer(JDisplay.this); 
    				  dispose();
    				  Properties request=new Properties();
    				  String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			    	  if(entity$!=null) {
    				  request.put(EventHandler.REQUESTOR,entity$);
			    	  request.put(EventHandler.MESSAGE,JDisplayList.ITEM_DISPOSED);
			    	  String request$=Locator.toString(request);
			    	  console.getEntigrator().putRequest(request$);
			    	  }
    			   }
    			}
    				});
    		menu.add(deleteItem);	
    	
   // 	
   	setTitle(context.getTitle());
    getContentPane().removeAll();
    borderLayout=new BorderLayout(0, 0);
    getContentPane().setLayout(borderLayout);
     getContentPane().add(context,BorderLayout.CENTER);
     getContentPane().add(subtitle, BorderLayout.SOUTH);
     subtitle.setText(context.getSubtitle());
    getContentPane().getLayout().addLayoutComponent(BorderLayout.SOUTH, subtitle);
	subtitle.setVisible(true);
    setTitle(context.getTitle());
   //	System.out.println("JDisplay:putContext:context="+context.getClass().getName()+"  container="+context.getContainerKey());
	Sack session=SessionHandler.getSession(console.getEntigrator());
	console.getEntigrator().putEntity(session);
	revalidate();
	repaint();
	getLocator();
	//System.out.println("JDisplay:putContext:locator="+locator$);
    }catch(Exception e) {
    	System.out.println("JDisplay:putContext:"+e.toString());
    }
  }
   public void setSubtitle(String subtitle$) {
	    subtitle.setText(subtitle$);
  }
   public static String classLocator() {
		Properties locator=new Properties();
		locator.put(JContextContainer.CONTAINER_TYPE,DISPLAY);
	    locator.put(JContext.CONTEXT_CLASS,"gdt.gui.generic.JDisplay");
	    locator.put(Locator.LOCATOR_TITLE,"JDisplay");
		return Locator.toString(locator);
	   }
  public String getLocator() {
	  locator$=classLocator();
	  String contextLocator$=null;
	  if(context!=null) {
		 contextLocator$=context.getLocator(); 
		// System.out.println("JDisplay:getLocator:context locator="+contextLocator$ );
	     locator$=Locator.merge(locator$, contextLocator$);
	     String entity$=Locator.getProperty(contextLocator$,Entigrator.ENTITY_LABEL);
	    if(entity$!=null)
	     locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity$);
	    else {
	    	System.out.println("JDisplay:getLocator. no entity in context locator="); 	
	    }
	  }
	  Properties appendix=new Properties();
	  Dimension dim=getSize();
	  appendix.put(DISPLAY_WIDTH,  String.valueOf(dim.width));
	  appendix.put(DISPLAY_HEIGHT, String.valueOf(dim.height));
	  Point p=getLocation();
	  appendix.put(DISPLAY_WPOS, String.valueOf(p.x));
	  appendix.put(DISPLAY_HPOS, String.valueOf(p.y));
	  String appendix$=Locator.toString(appendix);
	  locator$=Locator.merge(locator$,appendix$);
	  return locator$;
  }
  public JContext getContext() {
	  return context;
  }
  public String getContentLocator() {
	  if(context!=null)
		  return context.getLocator();
	  int cnt=this.getContentPane().getComponentCount();
	  Component content;
	  if(cnt>0)
		  for(int i=0;i<cnt;i++) {
			  content=this.getContentPane().getComponent(i);
			  if(content instanceof JRackFrame)
				  return ((JRackFrame)content).getLocator();
			 // System.out.println("JDisplay:geContentLocator:i="+i+" component="+content.getClass().getName()); 
		  }
	  return null;
  }
  public JMenu getDisplayMenu() {
	  return menu;
  }
@Override
public JItemPanel getItemPanel() {
    // System.out.println("JDisplay:getItemPanel:locator="+locator$);
	String itemLocator$=JItemPanel.classLocator();
	String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	ImageIcon icon =null;
	if(entity$!=null) {
	 itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE , entity$);
	String entityKey$=console.getEntigrator().getKey(entity$);
	  String entityLocator$=console.getEntigrator().getEntityLocator(entityKey$);
//	  System.out.println("JDisplay:getItemPanel:entity locator="+entityLocator$);
	  String type$=Locator.getProperty(entityLocator$,Entigrator.ENTITY_TYPE);
//	  System.out.println("JDisplay:getItemPanel:type="+type$);
	  icon = FacetMaster.getIcon(console, type$);
	}
	JDisplayItem displayItem=new JDisplayItem(console,itemLocator$);
	if(icon!=null)
		displayItem.setIcon(icon);
	else
		System.out.println("JDisplay:getItemPanel:icon is null");
     return displayItem;
}
@Override
public String getItem() {
	// TODO Auto-generated method stub
	return null;
}
public class JDisplayItem extends JItemPanel {
	private static final long serialVersionUID = 1L;
	public JDisplayItem(JMainConsole console,JContext context, String locator$) {
		super(console,context, locator$);
	}
	public JDisplayItem(JMainConsole console, String locator$) {
		super(console,getContext(), locator$);
	}
	
	@Override
	public JPopupMenu getPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void onClick(JMainConsole console, String locator$) {
	JDisplay.this.toFront();
	}
	}
 }
