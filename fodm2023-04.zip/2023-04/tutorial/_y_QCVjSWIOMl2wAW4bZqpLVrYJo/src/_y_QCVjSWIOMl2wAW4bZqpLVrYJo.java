import javax.swing.JEditorPane;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.procedure.Procedure;
public class _y_QCVjSWIOMl2wAW4bZqpLVrYJo  implements Procedure {
private final static String ENTITY_KEY="_y_QCVjSWIOMl2wAW4bZqpLVrYJo";
public _y_QCVjSWIOMl2wAW4bZqpLVrYJo (){} 
@Override
public void exec(JMainConsole console, String locator$, JEditorPane reportPanel) {
System.out.println(ENTITY_KEY+":"+locator$);
reportPanel.setText(locator$);
	}
}
