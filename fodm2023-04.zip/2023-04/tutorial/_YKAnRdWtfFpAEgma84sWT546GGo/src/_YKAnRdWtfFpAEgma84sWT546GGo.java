import java.util.ArrayList;
import java.util.Arrays;
import java.awt.BufferCapabilities;
import javax.swing.JDesktopPane;
import javax.swing.JEditorPane;
import javax.swing.JFrame;  
import javax.swing.JInternalFrame;  
import javax.swing.JLabel;

import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.procedure.Procedure;  
public class _YKAnRdWtfFpAEgma84sWT546GGo  implements Procedure {
private final static String ENTITY_KEY="_YKAnRdWtfFpAEgma84sWT546GGo";
public _YKAnRdWtfFpAEgma84sWT546GGo (){} 

@Override
public void exec(JMainConsole console, String locator$, JEditorPane reportPanel) {
	try {
		String[]sa=console.getEntigrator().listEntities();
		String label$=null;
		ArrayList<String>sl=new ArrayList<String>();
		for(String s:sa) {
			label$=console.getEntigrator().getLabel(s);
		    if(label$!=null)
		    	sl.add(label$);
		}
		sa = new String[ sl.size()];
		sl.toArray(sa);
		StringBuffer sb =new  StringBuffer();
		Arrays.sort(sa);
		for(String s:sa ) {
			sb.append(s+"\n");
		}
		reportPanel.setText(sb.toString()); 
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+" :"+e.toString());
	}

}
}

