package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Properties;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
public class SignalHandler extends OperatorHandler{
	public static final String KEY="_Tm86AsaaaBQmcVfPXYVWSbFJzRs";
	int SINUS=0;
	int STEP=1;
	int RAMP=2;
	int CUSTOM=3;
	public SignalHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		String entity$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
		operatorKey$=entigrator.getKey(entity$);
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"Signal");
		locator.put(FACET_TYPE,"signal");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SignalHandler");
		locator.put(FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.SignalMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put( IconLoader.ICON_FILE, "signal.png");
		locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(OPERATOR,Locator.LOCATOR_TRUE);
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
		Sack operator=entigrator.getEntity(operatorKey$);
		String form$=operator.getElementItemAt("signal", "form");
		//System.out.println("SignalHandler:step:form="+form$);
		if(!operator.existsElement(OPERATOR))
			operator.createElement(OPERATOR);
		double delay=0;
		String delay$=operator.getElementItemAt("signal", "delay");
		try{ delay=Double.parseDouble(delay$);}catch(Exception e) {}
		double time=0;
		try{ time=Double.parseDouble(operator.getElementItemAt(OPERATOR, "time"));}catch(Exception e) {}
		if(time<delay) {
			operator.putElementItem(OPERATOR, new Core("output","out","0"));
		    return;
		}
		double stime=time-delay;
		if("sinus".equals(form$)) {
			double frequency=Double.parseDouble(operator.getElementItemAt("signal", "frequency"));
			double amplitude=Double.parseDouble(operator.getElementItemAt("signal", "amplitude"));
			double arg=2*Math.PI*frequency*stime;
			double out=amplitude*Math.sin(arg);
			//System.out.println("SignalHandler:step:stime="+stime+"  out="+out+" arg="+arg);
			operator.putElementItem(OPERATOR, new Core("output","out",String.valueOf(out)));
			entigrator.putEntity(operator);
		}
		if("step".equals(form$)) {
			operator.putElementItem(OPERATOR, new Core("output","out",operator.getElementItemAt("signal", "value")));
			entigrator.putEntity(operator);
		}
		if("ramp".equals(form$)) {
			double factor=Double.parseDouble(operator.getElementItemAt("signal", "factor"));
			double limit=Double.parseDouble(operator.getElementItemAt("signal", "limit"));
			double out=factor*stime;
			if(out>limit)
				out=limit;
			operator.putElementItem(OPERATOR, new Core("output","out",String.valueOf(out)));
			entigrator.putEntity(operator);
		}
		if("custom".equals(form$)) {
			StepHandler stepHandler=getStepHandler(entigrator);
			stepHandler.step(entigrator, null);
		}
		return ;
	}
	@Override
	public void reset(Entigrator entigrator, String locator$) {
		try {
			Sack entity=entigrator.getEntity(operatorKey$);
			if(entity!=null) {
				if(!entity.existsElement(OPERATOR))
					entity.createElement(OPERATOR);
				    entity.putElementItem(OPERATOR, new Core("output","out","0"));
				    entity.putElementItem(OPERATOR, new Core(null,"time","0"));
				    entigrator.putEntity(entity);
			}
		}catch(Exception e) {
			System.out.println("SignalHandler:reset:"+e.toString());
		}
	}
	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset(entigrator,locator$);
	}
	@Override
	public String[] listOutputs(Entigrator entigrator) {
		return new String[] {
				"out"
		};
	}
	@Override
	public String[] listInputs(Entigrator entigrator) {
		return null;
	}
	@Override
	public String getName() {
		return "Signal";
	}
	@Override
	public String getType() {
		return "signal";
	}
	@Override
	public String getFacetClass() {
		return "_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SignalHandler";
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return null;
	}
}
