package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
//классы модуля testbench
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Connection;
//классы базового модуля JEntigrator
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
public class PackHandler extends FacetHandler implements SegueController{
	public static final String KEY="_gP0DCWTI5CepEeXbf7k4Upcw2ac";
	public static final String PACK_FACET_TYPE="pack";
	public static final String PACK_FACET_NAME="Pack";
	public static final String PACK_FACET_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PackHandler";
	public static final String COMPONENT="component";
	Sack entity;
	Entigrator entigrator;
	double clock=0;
	Hashtable<String,Double > inCduVals;
	Hashtable<String,String[]>outToIns;
	Hashtable<String,String>inToOut;
	Hashtable<String,String>cduIn2eduOut;
	Hashtable<String,String>bondInMap;
	Hashtable<String,String>bondOutMap;
	Hashtable<String,EduHandler>edus;
	Hashtable<String, Double> outs;
	public PackHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		entity=entigrator.getEntityAtLabel(entity$);
		this.entigrator=entigrator;
		initEdus();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,PACK_FACET_NAME);
		locator.put(FACET_TYPE,PACK_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PackMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put( IconLoader.ICON_FILE, "pack.png");
		locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		return Locator.toString(locator);
	}
	public static String[] listOperatorOutputs(Entigrator entigrator,Sack entity) {
		try {
			//System.out.println("PackHandler:listOutputs:cdu="+cdu.getProperty("label"));
			ArrayList<String>sl=new ArrayList<String>();
			Core[]ca=entity.elementGet("operator");
			if(ca!=null) {
				for(Core c:ca) {
					if("out".equals(c.type))
						sl.add(c.name);
				}
			}
		String[] sa=new String[sl.size()];	
		sl.toArray(sa);
		return sa;
		}catch(Exception e) {
			System.out.println("PackHandler:listOutputs:"+e.toString());
		}
		return null;
	}
	public static String[] listOperatorInputs(Entigrator entigrator ,Sack cdu) {
		try {
			//System.out.println("PackHandler:listInputs:cdu="+cdu.getProperty("label"));
			ArrayList<String>sl=new ArrayList<String>();
			Core[]ca=cdu.elementGet("operator");
			//System.out.println("PackHandler:listInputs:ca="+ca.length);
			if(ca!=null) {
				for(Core c:ca) {
					if("in".equals(c.type))
						sl.add(c.name);
				}
			}
		String[] sa=new String[sl.size()];	
		sl.toArray(sa);
		return sa;
		}catch(Exception e) {
			System.out.println("PackHandler:listInputs:"+e.toString());
		}
		return null;
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	private void insertBonds(String eduName$,Hashtable<String,Double> cduIns,Hashtable<String,Double> eduIns ) {
		if(bondInMap==null)
		   bondInMap=new Hashtable<String,String>();
		if(eduName$==null) {
			System.out.println("PackHandler:insertBonds;edu name is null");
			return;
		}
		if(cduIns.isEmpty()) {
			System.out.println("PackHandler:insertBonds;cduIns is empty");
			return;
		}
		if(eduIns.isEmpty()) {
			System.out.println("PackHandler:insertBonds;edIns is empty");
			return;
		}
		Enumeration<String> en=bondInMap.keys();
		String bondIn$;
		String eduIn$;
		String[] sa;
		while(en.hasMoreElements()) {
			bondIn$=en.nextElement();
			eduIn$=bondInMap.get(bondIn$);
			sa=eduIn$.split(":");
			if(eduName$.equals(sa[0])) {
				double val=0;
				try {val=cduIns.get(bondIn$);}catch(Exception e) {}
				eduIns.put(sa[1], val);
			}
		}
	}
	private Hashtable<String,Double> getEdusOuts( ) {
		Hashtable<String,Double>  edusOuts=new Hashtable<String,Double> ();
		if(edus.isEmpty())
			return null;
		Enumeration <String>en=edus.keys();
		String edu$;
		EduHandler eduHandler;
		Hashtable<String,Double>eduOuts;
		while(en.hasMoreElements()) {
			eduHandler=edus.get(en.nextElement());
			edu$=eduHandler.getEntityName();
			eduOuts=eduHandler.getOuts();
			if(eduOuts!=null) {
				Enumeration<String> eno=eduOuts.keys();
				String outPin$;
				double outVal=0;
				while(eno.hasMoreElements()) {
					outPin$=eno.nextElement();
					outVal=eduOuts.get(outPin$);
					edusOuts.put(edu$+":"+outPin$, outVal);
				}
			}
		}
		//System.out.println("PackHandler:getEdusOuts");
		return edusOuts;
	}
	private Hashtable<String,Double> getBonds( ) {
		if(bondOutMap==null||bondOutMap.isEmpty()) {
			System.out.println("PackHandler:getBonds:bondOutMap is null or empty");
			return null;
		}
		Hashtable<String,Double> edusOuts=getEdusOuts();
		if(edusOuts==null) {
			System.out.println("PackHandler:getBonds:eduOuts is null");
			return null;
		}
		Hashtable<String,Double> outs=new Hashtable<String,Double>();
		Enumeration<String> en=bondOutMap.keys();
		String bondOut$;
		String edusKey$;
		String[] sa;
		while(en.hasMoreElements()) {
			bondOut$=en.nextElement();
			edusKey$=bondOutMap.get(bondOut$);
			//System.out.println("PackHandler:getBonds: bondOut="+bondOut$+"  edusKey="+edusKey$);
			double val=0;
			try {val=edusOuts.get(edusKey$);}catch(Exception e) {}
            outs.put(bondOut$, val);
			}
		//System.out.println("PackHandler:getBonds");
	return outs;
	}
	@Override
	public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
		try {clock=ins.get("clock");}catch(Exception e) {}
		double time=0;
		try {time =ins.get("time"); }catch(Exception ee) {}
		double open=1.0;
		//System.out.println("PackHandler:stride:open="+open);
		Enumeration<String> enh=edus.keys();
		//System.out.println("PackHandler:transition:pace=="+pace);
		Hashtable <String,Double>eduOuts=new Hashtable <String,Double>();
		//EduHandler.printHashtableDouble("PackHandler:stride:ins", ins);
		EduHandler eduHandler;
		double val=0;
		String eduName$=null;
		String[] ina;
		Hashtable <String,Double>eduIns;
		while(enh.hasMoreElements()) {
			    eduHandler=edus.get(enh.nextElement());
	    		//System.out.println("PackHandler:transition:edu handler ="+entigrator.getLabel(eduHandler.operatorKey$)); 
	    		 eduName$=eduHandler.getEntityName();
	    		 ina=eduHandler.listInputs();
	    	//	 System.out.println("PackHandler:transitionClock:edu name="+eduName$+" pace="+pace+" ina="+ina.length);
	    	     eduIns=new Hashtable <String,Double>();
	    		 eduIns.put("time", time);
	    		 String inKey$;
	    		 if(ina!=null) 
	    		    for(String in$:ina){
	    		      val=0;	
	    			  inKey$=eduName$+":"+in$;
	    			  try {val=inCduVals.get(inKey$);}catch(Exception ee) {}
	    			  eduIns.put(in$, val);
	    		}
	    		//System.out.println("PackHandler:transition:edu="+eduHandler.getEntityName());
	    		insertBonds(eduHandler.getEntityName(),ins, eduIns );
	    		//EduHandler.printHashtableDouble("eduIns", eduIns);
	    		eduIns.put("clock", clock);
	    		eduOuts=eduHandler.stride(eduIns);/////////
	    		//EduHandler.printHashtableDouble("eduOuts", eduOuts);
	    		Enumeration<String> eho=eduOuts.keys();
	    		String out$;
	    		 while(eho.hasMoreElements()) {
	    			 out$=eho.nextElement();
	    			 val=eduOuts.get(out$);
	    			 ina=null;
	    			 try{ina=outToIns.get(eduName$+":"+out$);}catch(Exception ee) {}
	    			 if(ina!=null)
	    				 for(String in$:ina) {
	    					 inCduVals.put(in$,val);
	    				 }
	    		 }
		 }
		
		Hashtable<String,Double> bondVals=getBonds();
		return bondVals;
	}
	private void reinit() {
		//System.out.println("PackHandler:reinit:BEGIN"); 
        double ehClock=0;
	    initEdus();
	    if(edus.isEmpty()) {
	    	System.out.println("PackHandler:reinit: edus is empty");
			return;
	    }
	    getClock();
		Enumeration<String> en=edus.keys();
		EduHandler eduHandler;
			inToOut=new Hashtable<String,String>(); 
			 String ekey$;
			 String[] ina;
			 String ename$;
			 String[] sa;
			 Connection[] ca=Connection.getConnections(entigrator, entity);
			 while (en.hasMoreElements()) {
	                ekey$ = en.nextElement();
		            eduHandler=edus.get(ekey$);
		            ename$=entigrator.getLabel(eduHandler.operatorKey$);
		            sa=eduHandler.listOutputs();
		            if(sa!=null&&ca!=null) {
		            	for(String s:sa) 
		            	   for(Connection c:ca){
		               		    if(ename$.equals(c.source$)&&s.equals(c.output$))
		               		    	inToOut.put(c.consumer$+":"+c.input$,c.source$+":"+c.output$);
		            	}
		            }
			 }
			// System.out.println("PackHandler:reinit: inToOut finish");
	  //init out to ins map
			 outToIns=new Hashtable<String,String[]>(); 
			 en = edus.keys();
			 while (en.hasMoreElements()) {
				 ekey$ = en.nextElement();
		         eduHandler=edus.get(ekey$);
		         ename$=entigrator.getLabel(eduHandler.operatorKey$);
		         sa=eduHandler.listOutputs();
		         if(sa!=null) {
		        	 Enumeration<String> eion = inToOut.keys();
		        	 String out$;
		        	 String in$;
		        	 String[] outa;
		        for(String s:sa) {
		        	ArrayList<String>sl=new ArrayList<String>();
		        	 while (eion.hasMoreElements()) {
		        		 in$=eion.nextElement();
		        		 out$=inToOut.get(in$);
		        		 outa=out$.split(":");
		        		 if(ename$.equals(outa[0])&&s.equals(outa[1]))
		        			 sl.add(in$);
		        	 }
		        	  ina=new String[sl.size()];
		        	  sl.toArray(ina);
		        	  outToIns.put(ename$+":"+s,ina );
		        }
		         }
			 }
			// System.out.println("PackHandler:reinit: outToIns finish");
			 inCduVals=new Hashtable<String,Double >();
			 cduIn2eduOut=new Hashtable<String,String >();
			 Core []coa=entity.elementGet("out");
			 if(coa!=null) {
				 String cduOutKey$;
				 String eduKey$;
				 for(Core c:coa) {
					 eduKey$=c.name;
					 cduOutKey$=c.type+":"+c.value;
					 ina=null;
					 try{ina=outToIns.get(cduOutKey$);}catch(Exception ee) {}
					 if(ina!=null&&ina.length>0)
						 cduIn2eduOut.put(ina[0], eduKey$); 
				 }
			 }
			 //System.out.println("PackHandler:reinit: inCduVals finish");
			 //init bond in map
			 bondInMap=new Hashtable<String,String>();
			 Core[] cina=entity.elementGet("in");
			 if(cina!=null)
				 for(Core c:cina)
					 bondInMap.put(c.name, c.type+":"+c.value);
			 //init bond out map
			 bondOutMap=new Hashtable<String,String>();
			 Core[] couta=entity.elementGet("out");
			 if(couta!=null)
				 for(Core c:couta) {
					 bondOutMap.put(c.name, c.type+":"+c.value);
					// System.out.println("PackHandler:reinit:bondOut:key="+c.name+"  value="+c.type+":"+c.value);
				 }
			// System.out.println("PackHandler:reinit: bondInMap finish");
	}
	@Override
	public void reset() {
		try {
			reinit();
		//	initEdus();
			inCduVals=new Hashtable<String,Double >(); 
			 Enumeration<String> ion = inToOut.keys();
			 String in$;
			 while(ion.hasMoreElements()) {
				 in$=ion.nextElement();
				 inCduVals.put(in$, 0.0);
			 }
			 Enumeration<String> en = edus.keys();
			 EduHandler eduHandler;
			 double eduClock=0;
			 while (en.hasMoreElements()) {
		            eduHandler=edus.get(en.nextElement());
		            eduHandler.reset();
		            eduClock=eduHandler.getClock();
		            if(eduClock<=0)
		            	continue;
		            if(clock==0)
		            	clock=eduClock;
		            else
		            	if(eduClock<clock)
		            		clock=eduClock;
			 }
		}catch(Exception e) {
			System.out.println("PackHandler:reset:"+e.toString());
		}
		}
	@Override
	public Hashtable<String, Double> getSettings() {
		return null;
	}

	@Override
	public void putSettings(Hashtable<String, Double> settings) {
	}

	@Override
	public Hashtable<String, Double> getOuts() {
		return getBonds();
	}
	@Override
	public double getClock() {
		return clock;
	}
	@Override
	public void setClock(double clock) {
		this.clock=clock;
	}
	@Override
	public String[] listInputs() {
		return listOperatorInputs(entigrator,entity);
	}
	public String[] listOutputs(String source$) {
		if(edus==null||edus.isEmpty())
			return null;
		Enumeration<String>en=edus.keys();
		ArrayList<String>sl=new ArrayList<String>();
		EduHandler eduHandler;
		String[] sa;
		while(en.hasMoreElements()) {
			eduHandler=edus.get(en.nextElement());
			if(source$.equals(entigrator.getLabel(eduHandler.operatorKey$))) {
			   sa=eduHandler.listOutputs();
			   if(sa!=null)
				   for(String s:sa) {
					   sl.add(s);
				   }
			   break;
			}
		}
		sa=new String[sl.size()];
		sl.toArray(sa);
		Arrays.sort(sa);
		return sa;
	}
	@Override
	public String[] listOutputs() {
		return listOperatorOutputs(entigrator,entity);
	}
	@Override
	public void setEntigrator(Entigrator entigrator) {
		this.entigrator=entigrator;
	}
	@Override
	public String getName() {
		return "Pack";
	}
	@Override
	public String getType() {
			return "pack";
	}
	@Override
	public String getFacetClass() {
		return "_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PackHandler";
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return null;
	}
	private  void initEdus() {
		try {
		edus=new Hashtable<String,EduHandler>();
		String[] sa= entity.elementListNames(COMPONENT);
		Sack edu;
		String eduHandler$=EduHandler.classLocator();
		EduHandler eduHandler;
		for(String s:sa) {
			edu=entigrator.getEntity(s);
			if(edu==null) {
				System.out.println("PackHandler:initEdus:cannot get edu at key="+s);
				continue;
			}
			eduHandler$=Locator.append(eduHandler$, Entigrator.ENTITY_LABEL, edu.getProperty("label"));
			eduHandler=new EduHandler(entigrator,eduHandler$);
			edus.put(edu.getProperty("label"), eduHandler);
		  }	
		}catch(Exception e) {
			 System.out.println("PackHandler:initEdus:"+e.toString());
		}
	}
	public String[] listConsumers() {
		if(edus==null||edus.isEmpty())
			return null;
		Enumeration<String> en=edus.keys();
		EduHandler eduHandler;
		ArrayList<String>sl=new ArrayList<String>();
		while(en.hasMoreElements()) {
			try {
			eduHandler=edus.get(en.nextElement());
			if(eduHandler!=null&&eduHandler.listInputs()!=null)
				sl.add(eduHandler.getEntityName());
			}catch(Exception e) {
				System.out.println("PackHandler:listConsumers:"+e.toString());
			}
		}
		String[]sa=new String[sl.size()];
		sl.toArray(sa);
		return sa;
	}
	public String[] listConsumerInputs(String consumer$) {
		if(edus==null||edus.isEmpty())
			return null;
		Enumeration<String>en=edus.keys();
		ArrayList<String>sl=new ArrayList<String>();
		EduHandler eduHandler;
		String[] sa;
		while(en.hasMoreElements()) {
			eduHandler=edus.get(en.nextElement());
			if(consumer$.equals(eduHandler.getEntityName())) {
			   sa=eduHandler.listInputs();
			   if(sa!=null)
				   for(String s:sa) {
					   sl.add(s);
				   }
			   break;
			}
		}
		sa=new String[sl.size()];
		sl.toArray(sa);
		Arrays.sort(sa);
		return sa;
	}
	private String[] listAllInternalInputs() {
		String[] sa=listConsumers();
		if(sa==null||sa.length<1)
		   return null;
		String[] ina;
		ArrayList<String>sl=new ArrayList<String>();
		for(String s:sa) {
			ina=listConsumerInputs(s);
			if(ina==null||ina.length<1)
				continue;
			for(String in$:ina) {
				sl.add(s+":"+in$);
			}
		}
		sa=new String[sl.size()];
		sl.toArray(sa);
		return sa;
	}
	public String[] listVacantInputs() {
		String[]  sa=listAllInternalInputs();
		if(sa==null|sa.length<1) {
			System.out.println("PackHandler:listVacantIninputs:no internal vacant inputs");
			return null;
		}
	//	System.out.println("PackHandler:listVacantOutputs:all internal outputs="+sa.length);
		Connection[] cona=Connection.getConnections(entigrator,entity);
		if(cona==null)
			return sa;
		ArrayList<String>sl=new ArrayList<String>();
		String[] ina=null;
		boolean used=false;
		for(String s:sa) {
			//System.out.println("PackHandler:listVacantOutputs:check output="+s);
			ina=s.split(":");
			used=false;
			for(Connection con:cona) {
				//System.out.println("PackHandler:listVacantOutputs:check unit="+c.type+" pin="+c.value);
				if( con.consumer$.equals(ina[0])
						&&con.input$.equals(ina[1])) {
				used=true;
				//System.out.println("PackHandler:listVacantOutputs:already used output="+s+" ");
				break;
				}
			}	
			if(used)
				continue;
			sl.add(s);
			}
	  sa=new String[sl.size()];
	  sl.toArray(sa);
	  return sa;
		}
	public String[] listVacantInputs(String consumer$) {
      String []sa= listVacantInputs();
      if(sa==null||sa.length<1) 
    	  return null;
 	  ArrayList<String>sl=new ArrayList<String>();
	  String[] ina;
	  for(String s:sa) {
		  ina=s.split(":");
		  if(consumer$.equals(ina[0]))
			  sl.add(ina[1]);
	  }
	  sa=new String[sl.size()];
	  sl.toArray(sa);
	  Arrays.sort(sa);
      return sa;
		}
	public String[] listSources() {
		if(edus==null||edus.isEmpty()) {
			System.out.println("PackHandler:pack handler:listSources:no edus");
			return null;
		}
		Enumeration<String> en=edus.keys();
		EduHandler eduHandler;
		ArrayList<String>sl=new ArrayList<String>();
		while(en.hasMoreElements()) {
			try {
			eduHandler=edus.get(en.nextElement());
			if(eduHandler!=null&&eduHandler.listInputs()!=null)
				sl.add(entigrator.getLabel(eduHandler.operatorKey$));
			}catch(Exception e) {
				System.out.println("PackHandler:listSorces:"+e.toString());
			}
		}
		String[]sa=new String[sl.size()];
		sl.toArray(sa);
		return sa;
	}
	private String[] listSourceOutputs(String source$) {
		if(edus==null||edus.isEmpty())
			return null;
		Enumeration<String>en=edus.keys();
		ArrayList<String>sl=new ArrayList<String>();
		EduHandler eduHandler;
		String[] sa;
		while(en.hasMoreElements()) {
			eduHandler=edus.get(en.nextElement());
			if(source$.equals(eduHandler.getEntityName())) {
			   sa=eduHandler.listOutputs();
			   if(sa!=null)
				   for(String s:sa) {
					   sl.add(s);
				   }
			   break;
			}
		}
		sa=new String[sl.size()];
		sl.toArray(sa);
		Arrays.sort(sa);
		return sa;
	}
	private String[] listAllInternalOutputs() {
		String[] sa=listSources();
		if(sa==null||sa.length<1)
		   return null;
		String[] outa;
		ArrayList<String>sl=new ArrayList<String>();
		for(String s:sa) {
			outa=listSourceOutputs(s);
			if(outa==null||outa.length<1)
				continue;
			for(String out$:outa) {
				sl.add(s+":"+out$);
			}
		}
		sa=new String[sl.size()];
		sl.toArray(sa);
		return sa;
	}
	public String[] listVacantOutputs() {
		String[]  sa=listAllInternalOutputs();
		if(sa==null|sa.length<1) {
			System.out.println("PackHandler:listVacantOutputs:no internal vacant outputs");
			return null;
		}
	//	System.out.println("PackHandler:listVacantOutputs:all internal outputs="+sa.length);
		Core[] sca=entity.elementGet("out");
		if(sca==null)
			return sa;
		ArrayList<String>sl=new ArrayList<String>();
		String[] outa=null;
		boolean used=false;
		for(String s:sa) {
			//System.out.println("PackHandler:listVacantOutputs:check output="+s);
			outa=s.split(":");
			used=false;
			for(Core c:sca) {
				//System.out.println("PackHandler:listVacantOutputs:check unit="+c.type+" pin="+c.value);
				if( c.type.equals(outa[0])
						&&c.value.equals(outa[1])) {
				used=true;
				//System.out.println("PackHandler:listVacantOutputs:already used output="+s+" ");
				break;
				}
			}	
			if(used)
				continue;
			sl.add(s);
			}
	  sa=new String[sl.size()];
	  sl.toArray(sa);
	  return sa;
		}
	public String[] listVacantOutputs(String source$) {
		String []sa= listVacantOutputs();
	      if(sa==null||sa.length<1)
	    	  return null;
		  ArrayList<String>sl=new ArrayList<String>();
		  String[] outa;
		  for(String s:sa) {
			  outa=s.split(":");
			  if(source$.equals(outa[0]))
				  sl.add(outa[1]);
		  }
		  sa=new String[sl.size()];
		  sl.toArray(sa);
		  Arrays.sort(sa);
	      return sa;
		}
}
