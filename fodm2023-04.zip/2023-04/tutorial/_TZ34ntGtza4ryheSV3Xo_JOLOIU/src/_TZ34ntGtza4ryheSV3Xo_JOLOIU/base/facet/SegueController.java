package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Hashtable;
import java.util.Properties;

import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
public interface SegueController {
   public static final String SEGUE_HANDLER="segue handler";
   public static final String SEGUE_INSTANCE="segue instance";
   public static final String SEGUE_CLASS="segue class";
   public Hashtable<String,Double>  stride(Hashtable<String,Double>  ins);
   public void reset();
   public Hashtable<String,Double> getSettings();
   public void putSettings(Hashtable<String,Double> settings);
   public Hashtable<String,Double> getOuts();
   public double getClock();
   public void setClock(double clock);
   public String[] listInputs();
   public String[] listOutputs();
   public void setEntigrator(Entigrator entigrator);
   static void createAdapter(Entigrator entigrator,String locator$)
   {
	   try{
		String adapterKey$=Locator.getProperty(locator$, Entigrator.ENTITY_KEY);
		String adapterHandler$=Locator.getProperty(locator$, SEGUE_HANDLER);
		String adapterInstance$=Locator.getProperty(locator$, SEGUE_INSTANCE);
		String adapterClass$=Locator.getProperty(locator$, SEGUE_CLASS);
//		System.out.println("SegueController: createAdapter:adapter key="+adapterKey$+"  handler="+adapterHandler$);
					File sourceHome=new File(entigrator.getEntihome()+"/"+adapterKey$+"/src");
					if(!sourceHome.exists())
						sourceHome.mkdirs();
					File binHome=new File(entigrator.getEntihome()+"/"+adapterKey$+"/bin");
					if(!binHome.exists())
						binHome.mkdirs();
					File adapterJava=new File(entigrator.getEntihome()+"/"+adapterKey$+"/src/"+adapterKey$+".java");
					if(adapterJava.exists())
						adapterJava.delete();
					adapterJava.createNewFile();
					FileOutputStream fos = new FileOutputStream(adapterJava, false);
					 Writer writer = new OutputStreamWriter(fos, "UTF-8");
					 writer.write("import gdt.base.store.Entigrator;\n");
					 writer.write("import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;\n");
					 writer.write("import "+adapterClass$+";\n");
					 writer.write("import java.util.Hashtable;\n");
					 writer.write("import java.util.Properties;\n");
					 writer.write("import gdt.base.generic.Locator;\n");
					 writer.write("public class "+adapterKey$+" implements SegueController{\n");
					 writer.write("private final static String ENTITY_KEY=\""+adapterKey$+"\";\n");
					 writer.write("private "+adapterClass$+" "+adapterInstance$+";\n");
					 writer.write("public "+adapterKey$+"(){}\n");
				 writer.write("public Hashtable<String,Double>  stride(Hashtable<String,Double>  ins){ \n"
					+"return "+adapterInstance$+". stride(ins);\n"	
					+ "} \n");		 
					 writer.write("public void reset(){ \n"
					+adapterInstance$+".reset();\n"		 
					 + "} \n");
					 writer.write("public Hashtable<String,Double> getSettings(){ \n"
					 +"return "+adapterInstance$+".getSettings();\n"
					 + "} \n");	
					 writer.write("public void putSettings(Hashtable<String,Double> settings){ \n"
					 +adapterInstance$+".putSettings(settings); \n"
									 + "} \n");			 
					 writer.write("public Hashtable<String,Double> getOuts(){ \n"
					 		+ "return "+adapterInstance$+".getOuts();\n"
					 		+ "}\n");
					 writer.write("public double getClock(){\n"
					 		+ "return "+adapterInstance$+".getClock();\n"
					 		+ "}\n");
					 writer.write("public void setClock(double clock){ \n"
							 +adapterInstance$+".setClock(clock); \n"
							 + "} \n");
					 writer.write("public String[] listInputs(){ \n"
					 		+"return "+adapterInstance$+".listInputs(); \n"
					 		+ "}\n");
					 writer.write("public String[] listOutputs(){ \n"
						 		+"return "+adapterInstance$+".listOutputs(); \n"
						 		+ "}\n");
					 writer.write("public void setEntigrator(Entigrator entigrator){ \n"
					 		//+adapterInstance$+".setEntigrator(entigrator); \n"
							+" String entity$=entigrator.getLabel(ENTITY_KEY);\n"
							+" Properties props=new Properties();\n"
							+" props.put(Entigrator.ENTITY_LABEL, entity$);\n"
							+" String locator$=Locator.toString(props);\n"
					 		+adapterInstance$+"=new "+adapterHandler$+"(entigrator,locator$);\n"	
					 		+adapterInstance$+".setEntigrator(entigrator);\n" 
					 		+ "} \n");
					 writer.write("}\n");
					 writer.close();   
					
				}catch(Exception e){
					System.out.println("SegueController:createAdapter:"+e.toString());
				}
   }
   public static void main(String[] args) throws IOException {
	   Properties props=new Properties();
	   props.put(SEGUE_HANDLER,"DcmHandler");
	   props.put(SEGUE_INSTANCE,"dcmHandler");
	   props.put(SEGUE_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DcmHandler");
	   props.put(Entigrator.ENTITY_KEY,"_SiEVwnHmcDPqowQd7tGe65IRRd4");
	   String locator$=Locator.toString(props);
	   System.out.println("SegueController:main:locator="+locator$);
	   String entihome$="/home/alexander/praxis/tutorial";
	   Entigrator entigrator=new Entigrator(entihome$);
	   SegueController.createAdapter(entigrator, locator$);
	}
}

