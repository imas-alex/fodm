package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BasicStroke;

import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;

import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.edu.JEduEditor;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.EventHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.FileTool;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;
import static java.util.Map.entry;

import java.awt.FontMetrics;


public class JPlotPanel  extends JGuiEditor implements PropertyChangeListener 
{
	private static final long serialVersionUID = 1L;
	private final String  QUADRANT="Quadrant";
	private final String  SURFACE="Surface";
	public  static final String  POINT_DISPLAY="point display";
	private static final Map<String,String> MESSAGE_TO_TYPE = Map.ofEntries(
	        entry("Bandwidth(closed)","bandwidth closed"),
	        entry("Bandwidth(open)","bandwidth open"),
	        entry("Step(closed)","step closed"),
	        entry("Step(open)","step open"),
	        entry("Hodograf","Hodograf")
	        );
	ArrayList<Ray>rays=new ArrayList<Ray>();
	ArrayList<Scale>scales=new ArrayList<Scale>();
	int maxY=0;
	int maxX=0;
	int width;
	Sack plot;
	File record;
	String visible$;
	String rayKey$;
	String rayName$;
	String color$;
	String factor$;
	Ray ray;
	Font defaultFont;
	Entigrator entigrator;
	Area area;
	double fx=0;
	double fy=0;
	boolean showPointer=false;
	String pointDisplay$;
	PointDisplay pointDisplay;
	Scale xscale;
	
	public JPlotPanel(JMainConsole console,String alocator$) {
		super(console,alocator$);
	//	System.out.println("JPlotPanel:locator="+locator$);
		instance$=getInstance();
		parent$=Locator.getProperty(alocator$, PARENT);
		if(parent$!=null)
		locator$=Locator.append(locator$, PARENT, parent$);
		try {
		String plot$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		//System.out.println("JPlotPanel:point display="+pointDisplay$);
		plot=console.getEntigrator().getEntityAtLabel(plot$);
		pointDisplay$=plot.getElementItemAt("plot","point.display");
				//Locator.getProperty(locator$,POINT_DISPLAY);
		entigrator=console.getEntigrator();
        area=new Area(plot);
		String [] sa=plot.elementListNames("scale.layout");
        if(sa!=null) {
        	Scale scale=null;
        	for(String s:sa) {
        		if("null".equals(s))
        			continue;
        		scale=new Scale(s);
        	    if(scale!=null&&scale.valid)
        	    	scales.add(scale);
        	    else
        	    	System.out.println("JPlotPanel:invalid scale="+s);
        	}
        }
        addMouseListener(new PlotMouseListener());
        init();
       
		}catch(Exception e) {
			System.out.println("JPlotPanel:"+e.toString());
		}
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,PlotMaster.KEY);
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(Locator.LOCATOR_TITLE,"Plot");
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.JPlotPanel");
		return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	private void showControl() {
		String[] sa=plot.elementListNames("customer");
		if(sa==null)
			return;
		String maker$=plot.getElementItemAt("customer", sa[0]);
		String eduLocator$=JEduEditor.classLocator();
		eduLocator$=Locator.append(eduLocator$,Entigrator.ENTITY_LABEL, maker$);
		 if(maker$!=null) {
	    	 eduLocator$=Locator.append(eduLocator$, Entigrator.ENTITY_LABEL, maker$);
		 }else {
			 System.out.println("JPlotPanel:showControl:no contol");
			 return;
		 }

		
		 JEduEditor eduEditor=new   JEduEditor (console,eduLocator$);
		 console.replaceContext(this,eduEditor);
	}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu.addSeparator();
		JMenuItem editorItem = new JMenuItem("Settings");
		editorItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				    String instance$=SessionHandler.putLocator(console.getEntigrator(), locator$);
			
				    String editorLocator$=JPlotEditor.classLocator();
				    editorLocator$=Locator.merge(editorLocator$,locator$);
				    editorLocator$=Locator.append(editorLocator$, PARENT, instance$);
				    if(entity$!=null)
				    	 editorLocator$=Locator.append(editorLocator$, Entigrator.ENTITY_LABEL, entity$);
					JPlotEditor plotEditor=new JPlotEditor(console,editorLocator$);
					console.replaceContext(JPlotPanel.this,plotEditor);
				}
			} );
		menu.add(editorItem);	
		JMenuItem controlItem = new JMenuItem("Control");
		controlItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				    showControl();
				}
			} );
		menu.add(controlItem);	
			JMenuItem saveItem = new JMenuItem("Save");
			saveItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					  save();
					}
				} );
			menu.add(saveItem);	
			JMenuItem exportItem = new JMenuItem("Export");
			exportItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					  try{
						 // System.out.println("JRecordViwer:export.BEGIN");
						  Rectangle componentRect = JPlotPanel.this.getBounds();
						    BufferedImage bufferedImage = new BufferedImage(componentRect.width, componentRect.height, BufferedImage.TYPE_INT_ARGB);
						    JPlotPanel.this.paint(bufferedImage.getGraphics());
						    File imageFile = new File(entigrator.getEntihome()+"/"+plot.getKey()+"/"+plot.getProperty("label")+".png");
						    ImageIO.write(bufferedImage, "png", imageFile );
						   // System.out.println("JRecordViwer:export.file="+imageFile.getPath());
					  }catch(Exception ee){
						  Logger.getLogger(getClass().getName()).severe(ee.toString());
					  }
					}
				} );
		menu.add(exportItem);
		JMenuItem folderItem = new JMenuItem("Folder");
		folderItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					 try{
						  File folder=new File(console.getEntigrator().getEntihome()+"/"+plot.getKey());
							Desktop.getDesktop().open(folder);
					  }catch(Exception ee){
						  Logger.getLogger(getClass().getName()).severe(ee.toString());
					  }
				}
			} );
		menu.add(folderItem);	
		//
		JMenu lookMenu=new JMenu("Look");
		JMenuItem bwItem = new JMenuItem("Black/white");
		bwItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  try{
				if(!plot.existsElement("plot"))
					plot.createElement("plot");
				plot.putElementItem("plot", new Core (null,"look","bw"));
				console.getEntigrator().putEntity(plot);
				String entityHome$=entigrator.getEntihome()+"/"+plot.getKey();
				File home=new File(entityHome$);
				String [] sa=home.list();
				String data$=null;
				for(String s:sa) {
					if(s.endsWith(".data")) {
						data$=entityHome$+"/"+s;
					}
				}
				if(data$!=null)
					pointDisplay.setDataPath(data$);
				init();
				revalidate();
				repaint();
				 
		       
			  }catch(Exception ee){
				  Logger.getLogger(getClass().getName()).severe(ee.toString());
			  }
			}
		} );
		lookMenu.add(bwItem);
		JMenuItem colorItem = new JMenuItem("Color");
		colorItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  try{
				  if(!plot.existsElement("plot"))
						plot.createElement("plot");
					plot.putElementItem("plot", new Core (null,"look","//bw"));
					console.getEntigrator().putEntity(plot);
					String entityHome$=entigrator.getEntihome()+"/"+plot.getKey();
					File home=new File(entityHome$);
					String [] sa=home.list();
					String data$=null;
					for(String s:sa) {
						if(s.endsWith(".data")) {
							data$=entityHome$+"/"+s;
						}
					}
					if(data$!=null)
						pointDisplay.setDataPath(data$);
					init();
					revalidate();
					repaint();
			  }catch(Exception ee){
				  Logger.getLogger(getClass().getName()).severe(ee.toString());
			  }
			}
		} );
		lookMenu.add(colorItem);
		menu.add(lookMenu);
		return menu;
		 }
	private   Color getColor(String color$){
		if("black".equals(color$))
			return Color.black;
		if("white".equals(color$))
			return Color.white;
		if("blue".equals(color$))
			return Color.blue;
		if("red".equals(color$))
			return Color.red;
		if("orange".equals(color$))
			return Color.orange;
		if("magenta".equals(color$))
			return Color.magenta;
		if("cyan".equals(color$))
			return Color.cyan;
		if("yellow".equals(color$))
			return Color.yellow;
		if("gray".equals(color$))
			return Color.gray;
		return Color.black;
	}
@Override
public String getTitle() {
	return Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
}
@Override
public String getSubtitle() {
	return Locator.getProperty(getLocator(),Entigrator.ENTITY_LABEL);
}
private  int getFontStyle(String style$){
		int style=Font.PLAIN;
		if("bold".equals(style$))
			style=Font.BOLD;
		if("italic".equals(style$))
			style=Font.ITALIC;
		return style;
	}
class PointValue{
	double x;
	double y;
	PointValue (double x,double y){
		this.x=x;
		this.y=y;
	}
}
class PointPosition{
	int x;
	int y;
	PointPosition (int x,int y){
		this.x=x;
		this.y=y;
	}
}
public  void init() {
	try {
	rays.clear();
	Core[] ca=plot.elementGet("ray.name");	
	if(ca==null) {
		System.out.println("JPlotPanel:init:wrong plot="+plot.getProperty("label"));
		return;
	}
	xscale=new Scale("xbase");
	//System.out.println("JPlotPanel:init:xscale="+xscale.name$);
	Ray ray;
	for(Core c:ca){
	   	try{
	   		ray=new Ray(c.value);
	   		rays.add(ray);
	   		ray.load();
	   	}catch(Exception e){
	   		System.out.println("JPlotPanel:init:"+e.toString());
	   	}
	}
	pointDisplay=new DefaultPointDisplay();
	if(pointDisplay$!=null)
	try {	
	Class<?> cls =getClass().getClassLoader().loadClass(pointDisplay$);
	pointDisplay=(PointDisplay)cls.getDeclaredConstructor().newInstance();
	if(pointDisplay!=null) {
		String entihome$=console.getEntigrator().getEntihome();
		String home$=entihome$+"/"+plot.getKey();
		File home=new File(home$);
		String [] sa=home.list();
		String data$=null;
		for(String s:sa) {
			if(s.endsWith(".data")) {
				data$=home$+"/"+s;
			}
		}
		if(data$!=null)
			pointDisplay.setDataPath(data$);
	}
	
	}catch(Exception ee) {
		System.out.println("JPlotPanel:init:cannot get point display="+pointDisplay$);		
	}
	
}catch(Exception ee) {
	System.out.println("JPlotPanel:init:"+ee.toString());
}
}
public static void makeData(Entigrator entigrator,String entity$) {
	try{
	String key$=entigrator.getKey(entity$);
	String data$=entigrator.getEntihome()+"/"+key$+"/data.plot";
//	System.out.println("JGraphPanel: makeData:data path="+data$);
	File data=new File(data$);
	if(!data.exists())
		data.createNewFile();
	 FileOutputStream fos = new FileOutputStream(data, false);
	 Writer writer = new OutputStreamWriter(fos, "UTF-8");
	 double cos;
	 double sin;
	 double angle;
	 String format$="0.####E0";
	 NumberFormat valFormat = new DecimalFormat(format$);
	 for (int i=-180;i<180;i++) {
		 angle=Math.toRadians(i);
		 cos=Math.cos(angle);
		 sin=Math.sin(angle);
		 writer.write(valFormat.format(angle)+";"+valFormat.format(cos)+";"+valFormat.format(sin)+"\n");
	 }
	 writer.close();
	 fos.close();
	}catch(Exception e){
   		System.out.println("JPlotPanel: makeData:"+e.toString());
   	}
}
public PointValue  getPointValue(String ray$,int cnt ) {
	try {
		if(rays.equals(null)||rays.size()<1)
			return null;
		for(Ray r:rays) {
			if(ray$.equals(r.name$)) {
				if(r.locations==null||r.locations.size()<1)
					return null;
				return r.locations.get(cnt);
			}
		}
	}catch(Exception e) {
		System.out.println("JPlotPanel: getPointValue:"+e.toString());
	}
	return null;
}
private void drawPointer(Graphics g) {
	
	((Graphics2D)g).setStroke(new BasicStroke(2));
	int r=10;
	try { r=Integer.parseInt(plot.getElementItemAt("canvas","pointer.size" ));}catch(Exception e) {}
	int style=Font.PLAIN;
	try { style=getFontStyle(plot.getElementItemAt("canvas","font.style" ));}catch(Exception e) {}
	Color color=Color.black;
	try { color=getColor(plot.getElementItemAt("canvas","font.color" ));}catch(Exception e) {}
	int size=14;
	try { size=Integer.parseInt(plot.getElementItemAt("canvas","font.size" ));}catch(Exception e) {}
	g.setColor(color);
	g.setFont(new Font("default",style,size));
    int dx=(int)(fx*(area.getAreaSize().width));
      int dy=(int)(fy*(area.getAreaSize().height));
      int x=area.getAreaCenter().x+dx;
      int y=area.getAreaCenter().y-dy;
    x = x-(r/2);
    y = y-(r/2);
    //System.out.println("JPlothPanel:drawPointer:x="+x+" y="+y); 
    //System.out.println("JPlothPanel:drawPointer:dx="+dx+" dy="+dy+"  dxmax="+(whm.width-whO.width)+"  ymax="+(whm.height-whO.height)+"  fx="+fx+" fy="+fy);
    g.drawOval(x, y, r, r);
    StringBuffer sb=new StringBuffer();
    String format$;
	NumberFormat scaleFormat;// = new DecimalFormat(format$);
	NamedPoint p;
	ArrayList <NamedPoint> pl=new ArrayList <NamedPoint>();
	int xx;
	int yy;
    if(scales!=null)
		for(Scale s:scales) {
			format$=s.format$;
			if(format$==null||"null".equals(format$))
				format$="0.###";
			if("Horizontal".equals(s.direction$)) {
				p=new NamedPoint(s.name$,format$,"h",s.getValue(x));
			    pl.add(p);
			}
			if("Vertical".equals(s.direction$)) {
				p=new NamedPoint(s.name$,format$,"v",s.getValue(y));
			    pl.add(p);
			}
			
		}
    String vals$=pointDisplay.pointsString(pl);
    FontMetrics fm = g.getFontMetrics();
    Rectangle2D rec = fm.getStringBounds(vals$, g);  
   // System.out.println("JPlothPanel:drawPointer:rec  w="+rec.getWidth()+" h="+rec.getHeight());
    g.setColor(Color.white);
    g.fillRect(x+20, y+20-(int)rec.getHeight(), (int)rec.getWidth()+10,(int)rec.getHeight()+10);
    g.setColor(color);
    g.drawString(vals$, x+20, y+20);

}

@Override	
protected void paintComponent(Graphics g) {
	//System.out.println("JPlotPanel:paintComponent:scales="+scales.size());
	try {
		
	//Dimension whO=area.getAreaSize();
	//Dimension whm=area.getMaximums();
	g.setColor(area.backcolor);
	//System.out.println("JGraphPanel:paintComponent:backcolor="+area.backcolor);
	Dimension sz=getSize();
	g.fillRect(0, 0,sz.width ,sz.height);
	((Graphics2D)g).setStroke(new BasicStroke(area.stroke));
	//System.out.println("JPlotPanel:init:rays="+rays.size());
	for(Ray r:rays) {
		//System.out.println("JGraphPanel:paint:ray="+r.name$);
		
		if(r.visible)
			r.draw((Graphics2D)g);
	}
	//System.out.println("JPlotPanel:painComponent:scales="+scales.size());
	
	if(showPointer)
		   //drawPointer(g,whO,whm);
		drawPointer(g);
	if(scales!=null)
		for(Scale s:scales) {
			try{s.draw((Graphics2D)g);}catch(Exception ee) {}
		}
	//int cnt=this.getParent().getComponentCount();
	
	//System.out.println("JPlotPanel:painComponent:component 1="+getParent().getComponent(1).getClass().getName());
	//System.out.println("JPlotPanel:painComponent:layout="+this.getLayout().toString());
	}catch(Exception e) {
		System.out.println("JPlotPanel:paintComponent"+e.toString());
	}
	
	
}
class Scale{
	String name$;
	String direction$;
	double mark;
	String unit$;
	int order;
	double max;
	double raster;
	String style$="linear";
	public boolean valid=false;
	int maxExp=0;
	int minExp=0;
	String format$=null;
	public Scale(String aname$) {
		//System.out.println("JPlotPanel:Scale:aname="+aname$);
		try {
			if("xbase".equals(aname$)) {
			Core[] ca=plot.elementGet("scale.layout");
			//System.out.println("JPlotPanel:Scale:ca="+ca.length);
			for (Core c:ca) {
				if("Horizontal".equals(c.type)&&"0".equals(c.value)) {
					this.name$=c.name;
					//System.out.println("JPlotPanel:Scale:this name="+this.name$);
				}
			}
		}else
			this.name$=aname$;
		//System.out.println("JPlotPanel:Scale:aname="+aname$+"  this name="+this.name$);
		Core layout=plot.getElementItem("scale.layout", this.name$);
		if(layout==null) {
			//System.out.println("JPlotPanel:Scale:cannot get core 'layout' in plot="+plot.getProperty("label")+"  element 'scale.layout'  layout="+ this.name$);	
			return;
		}
		direction$=layout.type;
		//System.out.println("JPlotPanel:Scale:aname="+aname$+"  this name="+this.name$+" direction="+direction$);
		order=Integer.parseInt(layout.value);
		Core markCore=plot.getElementItem("scale.mark", this.name$);
		unit$=markCore.type;
		//System.out.println("JPlotViewer:Scale:1");
		mark=Double.parseDouble(markCore.value);
		Core maxCore=plot.getElementItem("scale.max", this.name$);
		max=Double.parseDouble(maxCore.value);
		if(maxCore.type!=null&&!"null".equals(maxCore.type))
			format$=maxCore.type;
	//System.out.println("JPlotPanel:Scale:format="+format$);
		Core rasterCore=plot.getElementItem("scale.raster", this.name$);
		style$=rasterCore.type;
		//System.out.println("JPlotViewer:Scale:2");
		raster=Double.parseDouble(rasterCore.value);
		//System.out.println("JPlotPanel:Scale:3");
		if("logarithmic".equals(style$)) {
			double lgMax=Math.log10(max+Double.MIN_VALUE);
			maxExp=(int)lgMax;
			minExp=maxExp-(int)mark;
		}
		//System.out.println("JPlotPanel:Scale:FINISH");
		valid=true;	
		}catch(Exception e) {
			System.out.println("JPlotPanel:Scale:"+e.toString());
		}
	}
	private void drawLabel(Graphics2D g) {
	g.setColor(Color.BLACK);
	g.setFont(new Font("default", Font.BOLD, 12));
	//System.out.println("JGraphPanel:drawAxisLabels:direction="+direction$+" order="+order+" unit="+unit$);
	if("Horizontal".equals(direction$))
		g.drawString(name$+" "+unit$, area.getAreaCenter().x+area.getAreaSize().width+20, area.getAreaCenter().y+order*area.shift);
	if("Vertical".equals(direction$)) {
		int x= area.getAreaCenter().x-order*area.shift;
		int y=area.getAreaCenter().y-area.getAreaSize().height;
		
		drawVstring(g,name$,new Point(x,y));
		//drawVerticalArrowHead(g, center.x-order*area.shift, center.y-size.height);
		
	}
	}
	/*
	private void drawGrid(Graphics2D g,Dimension whO,Dimension whm) {
		//System.out.println("JPlotPanel:scale:drawGrid:style="+style$);
		if("linear".equals(style$))
			drawLinearGrid( g,whO,whm);
		if("logarithmic".equals(style$))
			drawLogarithmicGrid( g,whO,whm);
	}
	*/
	private void drawGrid(Graphics2D g) {
		//System.out.println("JPlotPanel:scale:drawGrid:style="+style$);
		if("linear".equals(style$))
			drawLinearGrid( g);
		if("logarithmic".equals(style$))
			drawLogarithmicGrid( g);
	}
	
private void drawLinearGrid(Graphics2D g) {
	try {
		int n=(int)(max/raster);
		g.setColor(Color.GRAY);
		g.setStroke(new BasicStroke(1));
		int linePos;
		int linePos2;
		if("Horizontal".equals(direction$)){
			double factor=area.getAreaSize().getWidth()/max;
           		for(int i=0;i<n;i++) {
    				linePos=(int)(raster*i*factor)+area.getAreaCenter().x;//whO.width;
    				linePos2=-(int)(raster*i*factor)+area.getAreaCenter().x;//whO.width;
    				g.drawLine(linePos, area.getAreaCenter().y, linePos,area.getAreaCenter().y-area.getAreaSize().height);
    				if("Surface".equals(area.area$)) {
    					g.drawLine(linePos, area.getAreaCenter().y-area.getAreaSize().height, linePos,area.getAreaCenter().y+area.getAreaSize().height); //whO.height+whm.height);
    					g.drawLine(linePos2,area.getAreaCenter().y-area.getAreaSize().height, linePos2,area.getAreaCenter().y+area.getAreaSize().height);//whO.height+whm.height);
     				}
           	}
		}
		if("Vertical".equals(direction$)){
			//double factor=whm.getHeight()/max;
			double factor=area.getAreaSize().height/max;
              		for(int i=0;i<n;i++) {
    				linePos=-(int)(raster*i*factor)+area.getAreaCenter().y;//whO.height;
    				linePos2=(int)(raster*i*factor)+area.getAreaCenter().y;
           			g.drawLine( area.getAreaCenter().x,linePos,area.getAreaSize().width+area.getAreaCenter().x,linePos);//whO.width, linePos);
           			if("Surface".equals(area.area$)) {
           				g.drawLine( area.getAreaCenter().x,linePos,-area.getAreaSize().width+area.getAreaCenter().x, linePos);
           			    g.drawLine(area.getAreaCenter().x,linePos2,-area.getAreaSize().width+area.getAreaCenter().x, linePos2);
           			    g.drawLine(area.getAreaCenter().x,linePos2,area.getAreaSize().width+area.getAreaCenter().x, linePos2);
           			}
           		}
           //	}
		}
	}catch(Exception e) {
		System.out.println("JPlotPanel:scale:drawGrid:"+e.toString());
	}
}

private void drawLogarithmicGrid(Graphics2D g) {
	try {
		double pointValue;
		double expValue;
		int grid=(int)raster;
		int pos=0;
		g.setColor(Color.GRAY);
    	g.setStroke(new BasicStroke(1));
		for(int i=0;i<maxExp-minExp;i++) {
		  	expValue=Math.pow(10, minExp+i);
		  	for(int j=0;j<grid;j++) {
		  		pointValue=expValue*(j);
		  		pos=getPos(pointValue);
		  		//System.out.println("JPlotPanel:scale:drawLogarithmicGrid:value="+pointValue+" inversion="+getValue(pos,whO,whm));
		  		if("Horizontal".equals(direction$))
		  		 g.drawLine(pos,area.getAreaCenter().y,pos,area.getAreaCenter().y-area.getAreaSize().height);
		  		if("Vertical".equals(direction$)) 
		  			g.drawLine(area.getAreaCenter().x,pos,area.getAreaCenter().x+area.getAreaSize().width,pos);	
		  	}
		}
	}catch(Exception e) {
		System.out.println("JPlotPanel:scale:drawLogarithmicGrid:"+e.toString());
	}
}
private void drawMarks(Graphics2D g) {
	//System.out.println("JPlotPanel:scale:drawMarks:style="+style$);
	
	if("linear".equals(style$))
		drawLinearMarks( g);
	if("logarithmic".equals(style$))
		drawLogarithmicMarks( g);
}

private void drawLinearMarks(Graphics2D g) {
	try {
		int n=(int)(max/mark);
		double factor;
		g.setFont(new Font("default", Font.BOLD, 14));
		g.setStroke(new BasicStroke(2));
		int markSize=2;
		String nMark$=null;
		int nPos=0;
		double nMark;
		int axisShift;
		Dimension size=area.getAreaSize();
		Point center=area.getAreaCenter();
		NumberFormat numberFormat=null;
		if(format$!=null)
			numberFormat=new DecimalFormat(format$);
		if("Horizontal".equals(direction$)){
			axisShift=center.y+order*area.shift;
			factor=size.getWidth()/max;
			//System.out.println("JPlotPanel:scale:drawMarks:factor="+factor);
			for(int i=0;i<n;i++) {
				nMark=mark*i;
				nPos=(int)(nMark*factor)+center.x;
				//System.out.println("JPlotPanel:scale:drawMarks:i="+i+" nPos="+nPos);
				if(numberFormat!=null)
					nMark$=numberFormat.format(nMark);
				else
					nMark$=String.valueOf(nMark);	
				g.drawLine(nPos, axisShift+markSize, nPos,axisShift-markSize);
				g.drawString(nMark$, nPos, axisShift+15);
				if("Surface".equals(area.area$)) {
					if(i==0)
						continue;
					nPos=(int)(-nMark*factor)+center.x;
					g.drawLine(nPos, axisShift+markSize, nPos,axisShift-markSize);
					g.drawString("-"+nMark$, nPos, axisShift+15);
				}
			}
		}
		if("Vertical".equals(direction$)){
			axisShift=center.x-order*area.shift;
			factor=size.getHeight()/max;
			int k=0;
			if("Surface".equals(area.area$))
				k=-n;
			//System.out.println("JPlotPanel:scale:drawMarks:VERTICAL");
			for(int i=k;i<n;i++) {
				nMark=mark*i;
				nPos=(int)(-nMark*factor)+center.y;
				//System.out.println("JPlotPanel:scale:drawMarks:i="+i+" nPos="+nPos);
				if(numberFormat!=null)
					nMark$=numberFormat.format(nMark);
				else
					nMark$=String.valueOf(nMark);	
				g.drawLine(axisShift-markSize,nPos ,axisShift+markSize, nPos);
				int sPos=(int)(nMark*factor)+center.y+20;
				//drawVstring( g,nMark$, new Point(center.x-10,nPos+20));
				drawVstring( g,nMark$, new Point(center.x-10,nPos));
			}
			
		}
	}catch(Exception e) {
		System.out.println("JPlotPanel:scale:drawMarks:"+e.toString());
	}
}
private void drawLogarithmicMarks(Graphics2D g) {
	int num=maxExp-minExp;
	int interval=0;
	int axisShift=0;
	int markSize=2;
	String mark$;
	int pos;
	for(int i=0;i<num;i++) {
		mark$=String.valueOf(Math.pow(10,(i+minExp)));	
		//System.out.println("JPlotPanel:scale:LogarithmicMarks:direction="+direction$+" pow="+(i+minExp));
		if("Horizontal".equals(direction$)) {
			//g.drawLine(gPos, axisShift+markSize, gPos,axisShift-markSize);
			interval=area.getAreaSize().width/num;
			 axisShift=area.getAreaCenter().y+order*area.shift;
			pos=area.getAreaCenter().x+interval*i;
			g.drawLine(pos, axisShift+markSize, pos,axisShift-markSize);
			g.drawString(mark$,pos, axisShift+15);
		//	System.out.println("JPlotPanel:scale:LogarithmicMarks:horizontal:pos="+pos+" i="+i);
		}
		if("Vertical".equals(direction$)) {
			 axisShift=area.getAreaCenter().x-order*area.shift;
			 interval=area.getAreaSize().height/num;
			pos=area.getAreaCenter().y-interval*i;
			g.drawLine(axisShift-markSize,pos,axisShift+markSize,pos);
			//area.drawHstring(g, mark$, interval*i,area.shift,whO);
			int y=-interval*i+area.getAreaCenter().y;
			int x=-area.shift+area.getAreaCenter().x;
			Point p=new Point(x,y);
			drawVstring(g, mark$, p);
			//  System.out.println("JPlotPanel:scale:LogarithmicMarks:vertical:pos="+pos+" i="+i);
		}
	}
}
public void draw(Graphics2D g) {
	g.setColor(area.frontcolor);
	g.setStroke(new BasicStroke(2));
	Point center=area.getAreaCenter();
	Dimension size=area.getAreaSize();
//	System.out.println("JPlotPanel:scale:draw:center x="+center.x+" y="+center.y+" size w="+size.width+" h="+size.height);
	//draw coordinate line
	if("Horizontal".equals(direction$)) {
		int left=center.x;
		if("Surface".equals(area.area$))
			left=center.x -size.width;
		g.drawLine( left , center.y+order*area.shift,  center.x +size.width, center.y+order*area.shift );
		//	g.drawLine( center.x +size.width , center.y+order*area.shift,  center.x +size.width, center.y+order*area.shift );
		drawHorizontalArrowHead(g, center.x +size.width, center.y+order*area.shift );
	}
	if("Vertical".equals(direction$)) {
		int bottom=center.y;
		if("Surface".equals(area.area$))
			bottom=center.y +size.height;
		g.drawLine( center.x , bottom,  center.x, center.y-size.height );
		drawVerticalArrowHead(g, center.x-order*area.shift, center.y-size.height);
	}
	   
	   drawGrid(g);
	   drawLabel(g);
	   drawMarks(g);
}

private void drawHorizontalArrowHead(Graphics2D g2 ,int x ,int y) {
	    Polygon arrowHead = new Polygon();
	   arrowHead.addPoint(x-10, y+5);
	   arrowHead.addPoint(x-10,y -5);
	   arrowHead.addPoint(x, y);
	   g2.fill(arrowHead);
	}
	private void drawVerticalArrowHead(Graphics2D g2 ,int x ,int y) {
	    Polygon arrowHead = new Polygon();
	   arrowHead.addPoint(x, y);
	   arrowHead.addPoint(x-5,y +10);
	   arrowHead.addPoint(x+5, y+10);
	   g2.fill(arrowHead);
	}

	public double getValue(int pos) {
		double interval=0;
		double mantissa=0;
		int expNum=0;
		double value=0;
		int sval=0;
		if("logarithmic".equals(style$)) {
			int num=maxExp-minExp;
			if("Horizontal".equals(direction$)) {
				interval=area.getAreaSize().width/(num+Double.MIN_VALUE);
				sval=pos-area.getAreaCenter().x;
			}
			if("Vertical".equals(direction$)) {
				interval=area.getAreaSize().height/(num+Double.MIN_VALUE);
				sval=area.getAreaCenter().y-pos;
			}
			
			expNum=(int)(sval/interval);
			mantissa=(sval-expNum*interval)/(interval);
			value=Math.pow(10,minExp+expNum+mantissa);
            return value;
		}
		if("linear".equals(style$)) {
			if("Horizontal".equals(direction$)) {
				int shift=pos-area.getAreaCenter().x;
				value=shift*max/area.getAreaSize().width;
			}
			if("Vertical".equals(direction$)) {
				int shift=area.getAreaCenter().y-pos;
				value=shift*max/area.getAreaSize().height;
			}
            return value;
		}
		return 0;
	}
	public int getPos(double value) {
		if(Math.abs(value)<Double.MIN_VALUE)
			value=Double.MIN_VALUE;
		int l=0;
		double shift=0;
		//System.out.println("JPlotViewer:Scale:getPos:whO x="+whO.width+"  y="+whO.height);
		if("linear".equals(style$)) {
			double factor=0;
		if("Horizontal".equals(direction$)) {
			 factor=area.getAreaSize().width/max;
			 shift=(value*factor);
			 l=area.getAreaCenter().x+(int)shift;
		}
		if("Vertical".equals(direction$)) { 
			 factor=area.getAreaSize().height/max;
		     shift=(value*factor);
		     l=area.getAreaCenter().y-(int)shift;
		}
		}
		//System.out.println("JPlotViewer:Scale:getPos:direction="+direction$+"  value="+value+" shift="+shift+"  position="+l);	
		if("logarithmic".equals(style$)) {
			double lgVal=Math.log10(value);
			int num=maxExp-minExp;
	//	System.out.println("JPlotViewer:Scale:getPos:val="+value+" lgVal="+lgVal+"  lgShift="+lgShift+" lgLen="+lgLen);
			if("Horizontal".equals(direction$)) {
				shift=area.getAreaSize().width*(lgVal-minExp)/(maxExp-minExp);
				l= (int)(area.getAreaCenter().x+(int)shift);
			}
			if("Vertical".equals(direction$)) { 
				shift=area.getAreaSize().height*(lgVal-minExp)/(maxExp-minExp);
				l= (int)(area.getAreaCenter().y-(int)shift);
			}
		}
		//System.out.println("JPlotViewer:Scale:getPos:value="+value+"  direction="+direction$+"  pos="+l);
		return l;
	}
	private void drawVstring(Graphics g,String s$,Point p) {
		Graphics2D g2d = (Graphics2D) g;
		AffineTransform old=g2d.getTransform();
		g2d.rotate(-Math.PI/2, p.x,p.y);
		g2d.drawString(s$,p.x, p.y);
	    g2d.setTransform(old);
    }
}
class Area{
	public String area$;
	int woffset;
	double wsize;
	int hoffset;
	double hsize;
	public int shift=10;
	boolean valid=false;
	int stroke=1;
	Color backcolor=Color.white;
	Color frontcolor=Color.black;
	int minX=0;
	int maxX=0;
	int minY=0;
	int maxY=0;
	public Area(Sack plot) {
	try {
		area$=plot.getElementItemAt("canvas", "area");
		Core vertical=plot.getElementItem(area$, "Vertical");
		hoffset=Integer.parseInt(vertical.type);
		hsize=Double.parseDouble(vertical.value);
		if(hsize>1)
			hsize=1;
		if(hsize<0.2)
			hsize=0.2;
		Core horizontal=plot.getElementItem(area$, "Horizontal");
		woffset=Integer.parseInt(horizontal.type);
		wsize=Double.parseDouble(horizontal.value);
		if(wsize>1)
			wsize=1;
		if(wsize<0.2)
			wsize=0.2;
		shift=Integer.parseInt(plot.getElementItemAt("canvas", "shift"));
		try{stroke=Integer.parseInt(plot.getElementItemAt("canvas", "stroke"));}catch(Exception e){}
		try{backcolor=getColor(plot.getElementItemAt("canvas", "backcolor"));}catch(Exception e){}
		try{frontcolor=getColor(plot.getElementItemAt("canvas", "frontcolor"));}catch(Exception e){}
		valid=true;
	}catch(Exception e) {
		System.out.println("JPlotView:area:"+e.toString());
	}
	}
	public Dimension  getAreaSize() {
		
		
		int w=(int)(JPlotPanel.this.getWidth()*wsize);
		int h=(int)(JPlotPanel.this.getHeight()*hsize);
//System.out.println("JPlotView:getOrigin:area="+area$+"  w="+w+"  h="+h);
		int wO=0;
		int hO=0;
		
		if(SURFACE.equals(area$)) {
			wO=w/2+woffset;
			hO=h/2-hoffset;
		}
		if(QUADRANT.equals(area$)) {
			wO=w-woffset;
			hO=h-hoffset;
		}
		
	//	System.out.println("JPlotView:getOriginSize:wO="+wO+" hO="+hO);
		return new Dimension(wO,hO);
	}
	public Point getAreaCenter() {
		int w=JPlotPanel.this.getWidth();
		int h=JPlotPanel.this.getHeight();

		int x=0;
		int y=0;
		if(SURFACE.equals(area$)) {
		//	int wO=w/2+woffset;
			x=woffset+w/2;
			//int hO=h/2-hoffset;
			y=hoffset +h/2; 
		}
		if(QUADRANT.equals(area$)) {
			x =woffset;
			y=h-hoffset;
		}
	//	System.out.println("JPlotPanel:getAreaCenter:w="+w+" h="+h+"  x="+x+" y="+y+"  woffset="+woffset+" hoffset="+hoffset);
		return new Point(x,y);
	}
	
	
	private void setHGraphics(Graphics2D g2, Point xy) {
		AffineTransform at = new AffineTransform();
		at.setToRotation(-Math.PI/2);
		//int hh=console.getFootSize();
		int hh=0;
		//at.translate(-whO.height-hh,whO.width);
		at.translate(xy.x,xy.y);
		//System.out.println("JPlotPanel:area: setHGraphics: dh="+console.getFootSize());
	    g2.setTransform(at);
	}
	private void setWGraphics(Graphics2D g2, Dimension whO) {
		 AffineTransform at = new AffineTransform();
		 int hh=0;
		    int cnt=getParent().getComponentCount();
			    if(cnt>1)
			        hh=getParent().getComponent(cnt-1).getHeight();
	    at.translate(whO.width,whO.height+hh);
		g2.setTransform(at);
	}
	private void setLimits() {
		//Dimension panelSize=getSize();
		Dimension areaSize=getAreaSize();
		Point center=getAreaCenter();
		//System.out.println("JPlotPanel:setLimits: x="+center.x+" y="+center.y+" w="+areaSize.width+" h="+areaSize.height);
		if(SURFACE.equals(area$)) {
			minX=center.x-areaSize.width;
			maxX=center.x+areaSize.width;
			maxY=center.y+areaSize.height;
			minY=center.y-areaSize.height;
		}
		if(QUADRANT.equals(area$)) {
			minX=center.x;
			maxX=center.x+areaSize.width;
			minY=center.y-areaSize.height;
			maxY=center.y;
		}
		 
	}
	public Dimension  getMaximums() {
		int w=JPlotPanel.this.getWidth();
		int h=JPlotPanel.this.getHeight();
		int wm=0;
		int hm=0;
		if(SURFACE.equals(area$)) {
			wm=(int)(wsize*w/2);
			hm=(int)(hsize*h/2);
		}
		if(QUADRANT.equals(area$)) {
			wm=(int)(wsize*(w-woffset));
			hm=(int)(hsize*(h-hoffset));
		}
		return new Dimension(wm,hm);
	}
	public boolean outOfScope(int x, int y) {
		setLimits();
		//System.out.println("JPlotPanel:outOfScope:x="+x+" y="+y+ " maxX="+maxX+" minX="+minX+" maxY="+maxY+" minY="+minY);	
		if(x<minX||x>maxX)
			return true;
		if(y<minY||y>maxY)
			return true;
		return false;
	}
	public Point getLimited(int x,int y) {
		setLimits();
		int xl=x;
		int yl=y;
		if(x<minX)
			xl=minX;
		if(x>maxX)
			xl=maxX;
		if(y<minY)
			yl=minY;
		if(y>maxY)
			yl=maxY;
		return new Point(xl,yl);
	}
/*
	public boolean outOfScopeOld(int x, int y) {
		int w=JPlotPanel.this.getWidth();
		int h=JPlotPanel.this.getHeight();
		Dimension max= getMaximums();
		
		
		if(SURFACE.equals(area$)) {
			int w0=w/2;
			int h0=h/2;
			//System.out.println("JPlotPanel:outOfScope:x="+x+" y="+y+ " w0="+w0+" h0="+h0+" wmax="+max.width+" hmax="+max.height);
			//System.out.println("JPlotPanel:outOfScope:left="+(w0-max.width)+" right="+(w0+max.width)+" top="+(h0-max.height)+" bottom="+(h0+max.height));
			if(x<w0-max.width||x>w0+max.width) {
				//System.out.println("JPlotPanel:outOfScope:TRUE");
				return true;
			}
			if(y<(h0-max.height)||y>h0+max.height) {
				//System.out.println("JPlotPanel:outOfScope:TRUE");
				return true;
			}
		}
		if(QUADRANT.equals(area$)) {
			Dimension whO= getAreaSize();
			//System.out.println("JPlotPanel:outOfScope:x="+x+" y="+y+ " whO.w="+whO.width+" whO.h="+whO.height+" wmax="+max.width+" hmax="+max.height);
			//System.out.println("JPlotPanel:outOfScope:left="+whO.width+" right="+(whO.width+max.width)+" top="+(whO.height-max.height)+" bottom="+whO.height);
			if(x<whO.width||x>whO.width+max.width) {
				//System.out.println("JPlotPanel:outOfScope:TRUE");
				return true;
			}
			if(y<(whO.height-max.height)||y>whO.height) {
				//System.out.println("JPlotPanel:outOfScope:TRUE");
				return true;
			}
		}
		//System.out.println("JPlotPanel:outOfScope:FALSE");
		return false;
	}
	*/
}

private void save() {
	try{
	
		Calendar cal = Calendar.getInstance();
	     cal.setTime(Date.from(Instant.now()));
	     String record$ = String.format(
	             "%1$tY-%1$tm-%1$td-%1$tk-%1$tS-%1$tp", cal);
	    PlotMaster plotMaster=new PlotMaster();
	    Sack record=plotMaster.createEntity(console.getEntigrator(), record$);
	    String sourceFolder$=entigrator.folderFile(plot.getKey()).getPath();
	    String targetFolder$=entigrator.folderFile(record.getKey()).getPath();
	    FileTool.copyAll(sourceFolder$,targetFolder$);
	    record.createElement("canvas");
	    Core[] ca=plot.elementGet("canvas");
	    for(Core c:ca)
	       record.putElementItem("canvas", c);
	    record.createElement(QUADRANT);
	    ca=plot.elementGet(QUADRANT);
	    for(Core c:ca)
	       record.putElementItem(QUADRANT, c);
	    ca=plot.elementGet(SURFACE);
	    record.createElement(SURFACE);
	    for(Core c:ca)
	       record.putElementItem(SURFACE, c);
	    
	    ca=plot.elementGet("ray.color");
	    record.createElement("ray.color");
	    for(Core c:ca)
	       record.putElementItem("ray.color", c);
	    
	    ca=plot.elementGet("ray.index");
	    record.createElement("ray.index");
	    for(Core c:ca)
	       record.putElementItem("ray.index", c);
	    ca=plot.elementGet("ray.name");
	    record.createElement("ray.name");
	    for(Core c:ca)
	       record.putElementItem("ray.name", c);
	    ca=plot.elementGet("ray.scale");
	    record.createElement("ray.scale");
	    for(Core c:ca)
	       record.putElementItem("ray.scale", c);
	    ca=plot.elementGet("ray.shift");
	    for(Core c:ca)
	       record.putElementItem("ray.shift", c);
	    ca=plot.elementGet("ray.symbol");
	    record.createElement("ray.symbol");
	    for(Core c:ca)
	       record.putElementItem("ray.symbol", c);
	    ca=plot.elementGet("ray.visible");
	    record.createElement("ray.visible");
	    for(Core c:ca)
	       record.putElementItem("ray.visible", c);
	    ca=plot.elementGet("scale.layout");
	    record.createElement("scale.layout");
	    for(Core c:ca)
	       record.putElementItem("scale.layout", c);
	    ca=plot.elementGet("scale.mark");
	    record.createElement("scale.mark");
	    for(Core c:ca)
	       record.putElementItem("scale.mark", c);
	    ca=plot.elementGet("scale.max");
	    for(Core c:ca)
	       record.putElementItem("scale.max", c);
	    ca=plot.elementGet("scale.raster");
	    record.createElement("scale.raster");
	    for(Core c:ca)
	       record.putElementItem("scale.raster", c);
	    entigrator.putEntity(record);
		}catch (Exception e) {
		 System.out.println("JPlotPanel: save:"+ e.toString());	
	}
	}

class Ray{
			ArrayList<PointValue> locations;
			public Color color=Color.black;
			public String name$;
			public String symbol$=null;
			public String subsymbol$=null;
			public String scale$;
			int index;
			boolean visible=false;
			public Ray(String name$){
				try{
				this.name$=name$;
				String ray$=plot.getElementItemAtValue("ray.name", name$);
				Core symbol=plot.getElementItem("ray.symbol", ray$);
				if(symbol!=null) {
					symbol$=symbol.type;
					subsymbol$=symbol.value;
				}
				scale$=plot.getElementItemAt("ray.scale", ray$);
				color=Color.black;
				String bw$=plot.getElementItemAt("plot","look");
				if(!"bw".equals(bw$))
				   try{color=getColor(plot.getElementItemAt("ray.color", ray$));}catch(Exception e) {}
				index=0;
				try{index=Integer.parseInt(plot.getElementItemAt("ray.index", ray$));}catch(Exception ee) {}
	              try{visible=Boolean.parseBoolean(plot.getElementItemAt("ray.visible", ray$));}catch(Exception ee) {}
				}catch(Exception e){
					//System.out.println("JPlotViewer:Ray:name="+name$+" factor="+factor$+" color="+color$);
					System.out.println("JPlotPanel:Ray:"+e.toString());
				}
			}
			public  void clear(){
				locations.clear();
			}
			
		public void draw(Graphics2D g) {
				//System.out.println("JPlotPanel:Ray:draw="+name$+" locations="+locations.size());
			try {
				int stroke=2;
				String stroke$=plot.getElementItemAt("canvas", "stroke");
				if(stroke$!=null)
					try {stroke=Integer.parseInt(stroke$); }catch(Exception ee) {}
				g.setStroke(new BasicStroke(stroke));
				g.setColor(color);
				//System.out.println("JPlotPanel:Ray:draw:whOx="+whO.width+"  whOy="+whO.height+"  whm.x="+whm.width+" whm.y="+whm.height);
			if(locations==null||locations.size()<1) {
				//System.out.println("JPlotPanel:Ray:draw:empty locations");
				return;
			}
				int i=0;
				ArrayList<PointPosition>ppl=new ArrayList<PointPosition>();
				int x;
				int y;
				Scale yscale=new Scale(scale$);
			//	System.out.println("JPlotPanel:Ray:draw:BEGIN:i="+i);
				int[] xa=new int[0];
				int[] ya=new int[0];
				PointPosition pp;
				for(PointValue l:locations) {
					x=xscale.getPos(l.x);
					y=yscale.getPos(l.y);
					Point p=area.getLimited(x, y);
					pp=new PointPosition(p.x,p.y);
					if(!ppl.contains(pp))
					ppl.add(pp);
					
				}
				//System.out.println("JPlotPanel:Ray:draw:ppl="+ppl.size());
				xa=new int [ppl.size()];
				ya=new int [ppl.size()];
				for(PointPosition pp1:ppl) {
					xa[i]=pp1.x;
					ya[i]=pp1.y;
					i++;
				}
				// System.out.println("JPlotPanel:Ray:symbol="+symbol$+" subsymbol="+subsymbol$+"  xs="+xs+" ys="+ys);
				g.drawPolyline(xa,ya,xa.length);
				  if(symbol$!=null) {
					    int m=xa.length-1;
					    if(m>0)
						 g.drawString(symbol$+subsymbol$, xa[m]+5, ya[m]);
					 }
			}catch(Exception e) {
				System.out.println("JPlotPanel:Ray:draw:"+e.toString());
			}
			}
		
		public void load() {
			//System.out.println("JPlotPanel:Ray:load");
				try {
					String entihome$=console.getEntigrator().getEntihome();
					String home$=entihome$+"/"+plot.getKey();
					File home=new File(home$);
					String [] sa=home.list();
					String data$=null;
					for(String s:sa) {
						if(s.endsWith(".data")) {
							data$=home$+"/"+s;
						}
					}
	//				System.out.println("JPlotPanel:Ray:load:data="+data$);
					if(data$==null) {
						System.out.println("JPlotPanel:Ray:load:cnnot find data file");
						return;
					}
					if(locations==null)
						locations=new ArrayList<PointValue>();
					else
						locations.clear();
					BufferedReader br = new BufferedReader(new FileReader(data$));
					double yval;
					double xval;
					double yloc;
					double xloc;
					String line$;
					PointValue rl;
					//System.out.println("JPlotPanel:Ray:load:name=" +name$+" index="+index);
				while ((line$ = br.readLine()) != null) {
						//System.out.println("JPlotPanel:Ray:load:line="+line$);
						sa=line$.split(";");
	                     xval=0;
	                     yval=0;
	                     try{xval=Double.parseDouble(sa[0]);}catch(Exception e) {}
	                     if(sa.length>index) 
	                    	 try{yval=Double.parseDouble(sa[index+1]);}catch(Exception e) {}
	                   //  System.out.println("JPlotPanel:Ray:load:i="+i+" xval="+xval+" yval="+yval+" xmax="+xscale.max);
	                    // System.out.println("JPlotPanel:Ray:load:xval="+xval+" yval=="+yval);
	                     rl=new PointValue(xval,yval);	 
	                     locations.add(rl);
					}
					br.close();
				}catch(Exception e) {
					System.out.println("JPlotPanel:Ray:load:"+e.toString());
				}
			}
	}
	
class PlotMouseListener extends MouseAdapter {
	public void mouseClicked(MouseEvent evt) {
    	Point point=evt.getPoint();
        //System.out.println("JPlotPanel:mouse x="+point.x+"  y="+point.y);
        Component root=SwingUtilities.getRoot(JPlotPanel.this);
    	 if (evt.getButton() == MouseEvent.BUTTON1){
            showPointer=true;
         } else if (evt.getButton() == MouseEvent.BUTTON3) {
        	  showPointer=false;
        	  root.revalidate();
              root.repaint();
        	  return;
         } 
        int x=point.x;
        int y=point.y;
        int r=3;
        x = x-(r/2);
        y = y-(r/2);
        Point center=area.getAreaCenter();
        Dimension whm=area.getMaximums();
        fx=(point.x-center.x)/(whm.width+Double.MIN_VALUE);
        fy=-(center.y-point.y)/(-whm.height+Double.MIN_VALUE);
        root.revalidate();
        root.repaint();
    }
    }
	@Override
public String reply(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public void refresh() {
	//	System.out.println("JPlotPanel:refresh:locator="+locator$);
		super.refresh();
        init();
		revalidate();
		repaint();
	}
	@Override	
public String getEntityKey() {
	if(plot!=null)
		return plot.getKey();
	return null;
}
	@Override
public void propertyChange(PropertyChangeEvent evt) {
		try {
		String locator$=EventHandler.getLocator(console.getEntigrator());
		String requestor$=Locator.getProperty(locator$, EventHandler.REQUESTOR);
		String message$=Locator.getProperty(locator$, EventHandler.MESSAGE);
		System.out.println("JPlotPanel:propertyChange:requestor="+requestor$+"  message="+message$);
		Core[] ca=plot.elementGet("customer");
		if(ca==null||ca.length<1) {
			System.out.println("JPlotPanel:propertyChange:no custemers:plot="+plot.getProperty("label"));
			return;
		}
		boolean relevant=false;
		for(Core c:ca){
			if(c.name.equals(requestor$)) {
				relevant=true;
				break;
			}
			if(!relevant) {
				System.out.println("JPlotPanel:propertyChange:not relevant:plot="+plot.getProperty("label"));
				return;
			}
		}
		String plotType$=plot.getProperty("plot type");
		String messageType$=MESSAGE_TO_TYPE.get(message$);
		if(messageType$==null) {
			System.out.println("JPlotPanel:propertyChange:message type is null:plot="+plot.getProperty("label"));
			return;
		}
		if(!messageType$.equals(plotType$)) {
			System.out.println("JPlotPanel:propertyChange:messageType="+messageType$+" not equils plot type="+plotType$+" in plot="+plot.getProperty("label"));
			return;
		}
		init();
		revalidate();
		repaint();
		System.out.println("JPlotPanel:propertyChange:done:plot="+plot.getProperty("label"));
		}catch(Exception e) {
			System.out.println("JPlotPanel:propertyChange:"+e.toString());
		}
	}
	}
	
    

