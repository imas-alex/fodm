package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.JContext;

import gdt.gui.generic.JGuiEditor;

import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.BoxLayout;
import javax.swing.SwingConstants;

public class JTubeEditor extends  JGuiEditor{
	public static final String ACTION_CREATE_TUBE="action create tube";
	public static final String ACTION_SET_DISPLAY_TUBE="action set display tube";
	public static final String ACTION_NEW_ENTITY="action new entity tube";
	public static final String TUBE_FACET_TYPE="tube";
	public static final String TUBE_FACET_NAME="Tube";
	public static final String MOTOR_MASTER_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.JTubeMaster";
	public static final String KEY="_BR_DxnRhrkDQ298yNs7lH9JWMeU";
	private String entityKey$;
	private String entityLabel$;
	private Sack entity;
	protected JMenu menu;
	protected boolean ignoreOutdate=false;
	protected Entigrator entigrator;
	JTextField txtFrequency;
	JComboBox<String> cbxRaySelector;
	JComboBox<String>  cbxRayColor;
	JComboBox<String> cbxRayVisible;
	JTextField txtRayFactor; 
	JTextField txtRayShift;
	JTextField txtRayScale;
	JTextField txtRaySymbol;
	JTextField txtRayPosition;
	JTextField txtRayFormat;
	JButton btnDelete;
	JButton btnSave;
	boolean set=true;
	private JPanel tubePanel;
	private JPanel diagrammPanel;
	private JComboBox<String>  cbxVectorName;
	private JComboBox <String> cbxVectorColor;
	private JComboBox <String> cbxVectorVisible;
	private JLabel lblVectorFactor;
	private JTextField txtVectorFactor;
	private JLabel lblX;
	private JComboBox <String> cbxX;
	private JLabel lblY;
	private JComboBox <String> cbxY;
	private JComboBox <String> cbxR;
	private JButton btnDeleteVector;
	private JButton btnSaveVector;
	private JPanel panel;
	
	 public JTubeEditor(JMainConsole console,String alocator$) {
		 super(console,alocator$);
		 instance$=getInstance();
			parent$=Locator.getProperty(alocator$, PARENT);
			if(parent$!=null)
			locator$=Locator.append(locator$, PARENT, parent$);
		 addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				initSettings();
			}
		});
		 setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		 tubePanel = new JPanel();
		 tubePanel.setBorder(new TitledBorder(null, "Tube", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
		 add(tubePanel);
			  GridBagLayout gbl_tubePanel = new GridBagLayout();
			  gbl_tubePanel.columnWidths = new int[]{81, 136, 0};
			  gbl_tubePanel.rowHeights = new int[]{22, 25, 25, 25, 19, 19, 19, 19, 19, 19, 25, 0};
			  gbl_tubePanel.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
			  gbl_tubePanel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
			  tubePanel.setLayout(gbl_tubePanel);
				
					  JLabel lblFrequency = new JLabel("Frequency");
					  GridBagConstraints gbc_lblFrequency = new GridBagConstraints();
					  gbc_lblFrequency.anchor = GridBagConstraints.NORTHWEST;
					  gbc_lblFrequency.insets = new Insets(0, 0, 5, 5);
					  gbc_lblFrequency.gridx = 0;
					  gbc_lblFrequency.gridy = 0;
					  tubePanel.add(lblFrequency, gbc_lblFrequency);
				
				txtFrequency =new JTextField("1");
				txtFrequency.setColumns(12);
				GridBagConstraints gbc_txtFrequency = new GridBagConstraints();
				gbc_txtFrequency.anchor = GridBagConstraints.WEST;
				gbc_txtFrequency.fill=GridBagConstraints.HORIZONTAL;
				gbc_txtFrequency.insets = new Insets(0, 0, 5, 0);
				gbc_txtFrequency.gridx = 1;
				gbc_txtFrequency.gridy = 0;
				tubePanel.add( txtFrequency, gbc_txtFrequency);
		 
				JLabel lblRayOperator = new JLabel("Name");
				GridBagConstraints gbc_lblRayOperator = new GridBagConstraints();
				gbc_lblRayOperator.anchor = GridBagConstraints.WEST;
				gbc_lblRayOperator.insets = new Insets(0, 0, 5, 5);
				gbc_lblRayOperator.gridx = 0;
				gbc_lblRayOperator.gridy = 1;
				tubePanel.add(lblRayOperator, gbc_lblRayOperator);
			    
				cbxRaySelector = new JComboBox<String> ();
				cbxRaySelector.addActionListener(new ActionListener () {
				public void actionPerformed( ActionEvent evt  ){
					    JComboBox<String> cb = (JComboBox) evt.getSource();
						String  ray$ = (String)cb.getSelectedItem();
						initSettings(ray$);
						   }
					});
				cbxRaySelector.setEditable(true);
				cbxRaySelector.setPreferredSize(new Dimension(136, 25));
				GridBagConstraints gbc_cbxRaySelector = new GridBagConstraints();
				gbc_cbxRaySelector.anchor = GridBagConstraints.WEST;
				gbc_cbxRaySelector.insets = new Insets(0, 0, 5, 0);
				gbc_cbxRaySelector.gridx = 1;
				gbc_cbxRaySelector.gridy = 1;
				tubePanel.add( cbxRaySelector, gbc_cbxRaySelector);
						
			    JLabel lblRayColor = new JLabel("Color");
			    GridBagConstraints gbc_lblRayColor = new GridBagConstraints();
			    gbc_lblRayColor.anchor = GridBagConstraints.WEST;
			    gbc_lblRayColor.insets = new Insets(0, 0, 5, 5);
			    gbc_lblRayColor.gridx = 0;
			    gbc_lblRayColor.gridy = 2;
			    tubePanel.add(lblRayColor, gbc_lblRayColor);
				
				cbxRayColor = new JComboBox();
				cbxRayColor.setModel(new DefaultComboBoxModel(new String[] {"white", "black", "blue", "red", "orange", "magenta", "cyan"}));
				cbxRayColor.setPreferredSize(new Dimension(136, 25));
				GridBagConstraints gbc_cbxRayColor = new GridBagConstraints();
				gbc_cbxRayColor.fill = GridBagConstraints.HORIZONTAL;
				gbc_cbxRayColor.anchor = GridBagConstraints.WEST;
				gbc_cbxRayColor.insets = new Insets(0, 0, 5, 0);
				gbc_cbxRayColor.gridx = 1;
				gbc_cbxRayColor.gridy = 2;
				tubePanel.add( cbxRayColor, gbc_cbxRayColor);
				
				JLabel lblRayVisible = new JLabel("Visible");
				GridBagConstraints gbc_lblRayVisible = new GridBagConstraints();
				gbc_lblRayVisible.anchor = GridBagConstraints.WEST;
				gbc_lblRayVisible.insets = new Insets(0, 0, 5, 5);
				gbc_lblRayVisible.gridx = 0;
				gbc_lblRayVisible.gridy = 3;
				tubePanel.add(lblRayVisible, gbc_lblRayVisible);
				
				cbxRayVisible = new JComboBox();
				cbxRayVisible.setModel(new DefaultComboBoxModel(new String[] {"false", "true"}));
				cbxRayVisible.setPreferredSize(new Dimension(136, 25));
				GridBagConstraints gbc_cbxRayVisible = new GridBagConstraints();
				gbc_cbxRayVisible.fill = GridBagConstraints.HORIZONTAL;
				gbc_cbxRayVisible.anchor = GridBagConstraints.WEST;
				gbc_cbxRayVisible.insets = new Insets(0, 0, 5, 0);
				gbc_cbxRayVisible.gridx = 1;
				gbc_cbxRayVisible.gridy = 3;
				tubePanel.add( cbxRayVisible, gbc_cbxRayVisible);
				
				JLabel lblRayFactor = new JLabel("Factor");
				GridBagConstraints gbc_lblRayFactor = new GridBagConstraints();
				gbc_lblRayFactor.anchor = GridBagConstraints.WEST;
				gbc_lblRayFactor.insets = new Insets(0, 0, 5, 5);
				gbc_lblRayFactor.gridx = 0;
				gbc_lblRayFactor.gridy = 4;
				tubePanel.add(lblRayFactor, gbc_lblRayFactor);
			  
				txtRayFactor = new JTextField();
				txtRayFactor.setColumns(12);
				GridBagConstraints gbc_txtRayFactor = new GridBagConstraints();
				gbc_txtRayFactor.fill = GridBagConstraints.HORIZONTAL;
				gbc_txtRayFactor.anchor = GridBagConstraints.WEST;
				gbc_txtRayFactor.insets = new Insets(0, 0, 5, 0);
				gbc_txtRayFactor.gridx = 1;
				gbc_txtRayFactor.gridy = 4;
				tubePanel.add( txtRayFactor, gbc_txtRayFactor);
				
				JLabel lblRayShift = new JLabel("Shift");
				GridBagConstraints gbc_lblRayShift = new GridBagConstraints();
				gbc_lblRayShift.anchor = GridBagConstraints.WEST;
				gbc_lblRayShift.insets = new Insets(0, 0, 5, 5);
				gbc_lblRayShift.gridx = 0;
				gbc_lblRayShift.gridy = 5;
				tubePanel.add(lblRayShift, gbc_lblRayShift);
				
				txtRayShift = new JTextField();
				txtRayShift.setColumns(12);
				GridBagConstraints gbc_txtRayShift = new GridBagConstraints();
				gbc_txtRayShift.fill = GridBagConstraints.HORIZONTAL;
				gbc_txtRayShift.anchor = GridBagConstraints.WEST;
				gbc_txtRayShift.insets = new Insets(0, 0, 5, 0);
				gbc_txtRayShift.gridx = 1;
				gbc_txtRayShift.gridy = 5;
				tubePanel.add( txtRayShift, gbc_txtRayShift);
			  //scale
				JLabel lblRayScale = new JLabel("Scale");
				GridBagConstraints gbc_lblRayScale = new GridBagConstraints();
				gbc_lblRayScale.anchor = GridBagConstraints.WEST;
				gbc_lblRayScale.insets = new Insets(0, 0, 5, 5);
				gbc_lblRayScale.gridx = 0;
				gbc_lblRayScale.gridy = 6;
				tubePanel.add(lblRayScale, gbc_lblRayScale);
			  	
				txtRayScale = new JTextField();
				txtRayScale.setColumns(12);
				GridBagConstraints gbc_txtRayScale = new GridBagConstraints();
				gbc_txtRayScale.fill = GridBagConstraints.HORIZONTAL;
				gbc_txtRayScale.anchor = GridBagConstraints.WEST;
				gbc_txtRayScale.insets = new Insets(0, 0, 5, 0);
				gbc_txtRayScale.gridx = 1;
				gbc_txtRayScale.gridy = 6;
				tubePanel.add( txtRayScale, gbc_txtRayScale);
			  
			  	JLabel lblRaySymbol = new JLabel("Symbol");
			  	GridBagConstraints gbc_lblRaySymbol = new GridBagConstraints();
			  	gbc_lblRaySymbol.anchor = GridBagConstraints.WEST;
			  	gbc_lblRaySymbol.insets = new Insets(0, 0, 5, 5);
			  	gbc_lblRaySymbol.gridx = 0;
			  	gbc_lblRaySymbol.gridy = 7;
			  	tubePanel.add(lblRaySymbol, gbc_lblRaySymbol);
			  
			      txtRaySymbol = new JTextField();
			      txtRaySymbol.setColumns(12);
			      GridBagConstraints gbc_txtRaySymbol = new GridBagConstraints();
			      gbc_txtRaySymbol.fill = GridBagConstraints.HORIZONTAL;
			      gbc_txtRaySymbol.anchor = GridBagConstraints.WEST;
			      gbc_txtRaySymbol.insets = new Insets(0, 0, 5, 0);
			      gbc_txtRaySymbol.gridx = 1;
			      gbc_txtRaySymbol.gridy = 7;
			      tubePanel.add( txtRaySymbol, gbc_txtRaySymbol);
			  
			  JLabel lblRayPosition = new JLabel("Position");
			  GridBagConstraints gbc_lblRayPosition = new GridBagConstraints();
			  gbc_lblRayPosition.anchor = GridBagConstraints.WEST;
			  gbc_lblRayPosition.insets = new Insets(0, 0, 5, 5);
			  gbc_lblRayPosition.gridx = 0;
			  gbc_lblRayPosition.gridy = 8;
			  tubePanel.add(lblRayPosition, gbc_lblRayPosition);
			  
			  txtRayPosition = new JTextField();
			  txtRayPosition.setColumns(12);
			  GridBagConstraints gbc_txtRayPosition = new GridBagConstraints();
			  gbc_txtRayPosition.fill = GridBagConstraints.HORIZONTAL;
			  gbc_txtRayPosition.anchor = GridBagConstraints.WEST;
			  gbc_txtRayPosition.insets = new Insets(0, 0, 5, 0);
			  gbc_txtRayPosition.gridx = 1;
			  gbc_txtRayPosition.gridy = 8;
			  tubePanel.add( txtRayPosition, gbc_txtRayPosition);
			  
  			 btnSave = new JButton("Save");
  			 btnSave.addActionListener(new ActionListener() {
  			 	public void actionPerformed(ActionEvent e) {
  			       String ray$=(String)cbxRaySelector.getSelectedItem();
  			 		saveSettings(ray$);
  			 		initSettings();
  			 		//initSettings(ray$);
  			 	}
  			 });
  			 
  			  JLabel lblRayFormat = new JLabel("Format");
  			  GridBagConstraints gbc_lblRayFormat = new GridBagConstraints();
  			  gbc_lblRayFormat.anchor = GridBagConstraints.WEST;
  			  gbc_lblRayFormat.insets = new Insets(0, 0, 5, 5);
  			  gbc_lblRayFormat.gridx = 0;
  			  gbc_lblRayFormat.gridy = 9;
  			  tubePanel.add(lblRayFormat, gbc_lblRayFormat);
  			 
  			 txtRayFormat = new JTextField();
  			 txtRayFormat.setColumns(12);
  			 GridBagConstraints gbc_txtRayFormat = new GridBagConstraints();
  			 gbc_txtRayFormat.fill = GridBagConstraints.HORIZONTAL;
  			 gbc_txtRayFormat.anchor = GridBagConstraints.WEST;
  			 gbc_txtRayFormat.insets = new Insets(0, 0, 5, 0);
  			 gbc_txtRayFormat.gridx = 1;
  			 gbc_txtRayFormat.gridy = 9;
  			 tubePanel.add( txtRayFormat, gbc_txtRayFormat);
  			 
  			     btnDelete = new JButton("Delete");
  			     btnDelete.addActionListener(new ActionListener() {
  			 	public void actionPerformed(ActionEvent e) {
  			 	    deleteRay((String)cbxRaySelector.getSelectedItem());
  			 	}
  			 });
  			     GridBagConstraints gbc_btnDelete = new GridBagConstraints();
  			     gbc_btnDelete.anchor = GridBagConstraints.WEST;
  			     gbc_btnDelete.insets = new Insets(0, 5, 5, 5);
  			     gbc_btnDelete.gridx = 0;
  			     gbc_btnDelete.gridy = 10;
  			     tubePanel.add( btnDelete, gbc_btnDelete);
  			 GridBagConstraints gbc_btnSave = new GridBagConstraints();
  			 gbc_btnSave.insets = new Insets(0, 5, 5, 5);
  			 gbc_btnSave.anchor = GridBagConstraints.WEST;
  			 gbc_btnSave.gridx = 1;
  			 gbc_btnSave.gridy = 10;
  			 tubePanel.add( btnSave, gbc_btnSave);
  			 
  			 diagrammPanel = new JPanel();
  			 diagrammPanel.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Diagramm", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
  			 add(diagrammPanel);
  			 GridBagLayout gbl_diagrammPanel = new GridBagLayout();
  			 gbl_diagrammPanel.rowHeights = new int[] {2, 0, 0, 0, 0, 0, 0, 0};
  			 gbl_diagrammPanel.columnWidths = new int[] {2};
  			 gbl_diagrammPanel.columnWeights = new double[]{1.0, 1.0};
  			 gbl_diagrammPanel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0,0.0, 1.0};
  			 diagrammPanel.setLayout(gbl_diagrammPanel);
  			 
  			 JLabel lblVectorName = new JLabel("Vector");
  			 lblVectorName.setVerticalAlignment(SwingConstants.TOP);
  			 GridBagConstraints gbc_lblVectorName = new GridBagConstraints();
  			 gbc_lblVectorName.anchor = GridBagConstraints.NORTHWEST;
  			 gbc_lblVectorName.insets = new Insets(0, 5, 5, 5);
  			 gbc_lblVectorName.gridx = 0;
  			 gbc_lblVectorName.gridy = 0;
  			 diagrammPanel.add(lblVectorName, gbc_lblVectorName);
  			 
  			 cbxVectorName = new JComboBox();
  			 cbxVectorName.addActionListener(new ActionListener() {
  			 	public void actionPerformed(ActionEvent evt) {
  			 		JComboBox cb = (JComboBox) evt.getSource();
					String  vname$ = (String)cb.getSelectedItem();
					initVector(vname$);
  			 	}
  			 });
  			 cbxVectorName.setPreferredSize(new Dimension(136, 25));
  			 cbxVectorName.setEditable(true);
  			 GridBagConstraints gbc_cbxVectorName = new GridBagConstraints();
  			 gbc_cbxVectorName.insets = new Insets(0, 0, 5, 0);
  			 gbc_cbxVectorName.fill = GridBagConstraints.HORIZONTAL;
  			 gbc_cbxVectorName.gridx = 1;
  			 gbc_cbxVectorName.gridy = 0;
  			 diagrammPanel.add(cbxVectorName, gbc_cbxVectorName);
  			 
  			 JLabel lblVectorColor = new JLabel("Color");
  			 GridBagConstraints gbc_lblVectorColor = new GridBagConstraints();
  			 gbc_lblVectorColor.anchor = GridBagConstraints.LINE_START;
  			 gbc_lblVectorColor.insets = new Insets(0, 5, 5, 5);
  			 gbc_lblVectorColor.gridx = 0;
  			 gbc_lblVectorColor.gridy = 1;
  			 diagrammPanel.add(lblVectorColor, gbc_lblVectorColor);
  			 
  			 cbxVectorColor = new JComboBox();
  			 cbxVectorColor.setModel(new DefaultComboBoxModel(new String[] {"white", "black", "blue", "red", "orange", "magenta", "cyan"}));
			
  			 cbxVectorColor.setPreferredSize(new Dimension(136, 25));
  			 cbxVectorColor.setEditable(false);
  			 GridBagConstraints gbc_cbxVectorColor = new GridBagConstraints();
  			 gbc_cbxVectorColor.insets = new Insets(3, 0, 5, 0);
  			 gbc_cbxVectorColor.fill = GridBagConstraints.HORIZONTAL;
  			 gbc_cbxVectorColor.gridx = 1;
  			 gbc_cbxVectorColor.gridy = 1;
  			 diagrammPanel.add(cbxVectorColor, gbc_cbxVectorColor);
  			 
  			 
  			JLabel lblVectorVisible = new JLabel("Visible");
			GridBagConstraints gbc_lblVectorVisible = new GridBagConstraints();
			gbc_lblVectorVisible.anchor = GridBagConstraints.WEST;
			gbc_lblVectorVisible.insets = new Insets(0, 5, 5, 5);
			gbc_lblVectorVisible.gridx = 0;
			gbc_lblVectorVisible.gridy = 2;
			diagrammPanel.add(lblVectorVisible, gbc_lblVectorVisible);
			
			cbxVectorVisible = new JComboBox();
			cbxVectorVisible.setModel(new DefaultComboBoxModel(new String[] {"false", "true"}));
			
			GridBagConstraints gbc_cbxVectorVisible = new GridBagConstraints();
			gbc_cbxVectorVisible.fill = GridBagConstraints.HORIZONTAL;
			gbc_cbxVectorVisible.anchor = GridBagConstraints.LINE_START;
			gbc_cbxVectorVisible.insets = new Insets(0, 0, 5, 0);
			gbc_cbxVectorVisible.gridx = 1;
			gbc_cbxVectorVisible.gridy = 2;
			diagrammPanel.add( cbxVectorVisible, gbc_cbxVectorVisible);
  			 
  			 
  			 lblVectorFactor = new JLabel("Factor");
  			 GridBagConstraints gbc_lblRayFactor_1 = new GridBagConstraints();
  			 gbc_lblRayFactor_1.anchor = GridBagConstraints.LINE_START;
  			 gbc_lblRayFactor_1.insets = new Insets(0, 5, 5, 5);
  			 gbc_lblRayFactor_1.gridx = 0;
  			 gbc_lblRayFactor_1.gridy = 3;
  			 diagrammPanel.add(lblVectorFactor, gbc_lblRayFactor_1);
  			 
  			 txtVectorFactor = new JTextField();
  			 txtVectorFactor.setColumns(12);
  			 GridBagConstraints gbc_txtVectorFactor = new GridBagConstraints();
  			 gbc_txtVectorFactor.insets = new Insets(0, 0, 5, 0);
  			 gbc_txtVectorFactor.fill = GridBagConstraints.HORIZONTAL;
  			 gbc_txtVectorFactor.gridx = 1;
  			 gbc_txtVectorFactor.gridy = 3;
  			 diagrammPanel.add(txtVectorFactor, gbc_txtVectorFactor);
  			 
  			 lblX = new JLabel("X");
  			 lblX.setHorizontalAlignment(SwingConstants.LEFT);
  			 GridBagConstraints gbc_lblX = new GridBagConstraints();
  			 gbc_lblX.anchor = GridBagConstraints.LINE_START;
  			 gbc_lblX.insets = new Insets(0, 5, 5, 5);
  			 gbc_lblX.gridx = 0;
  			 gbc_lblX.gridy = 4;
  			 diagrammPanel.add(lblX, gbc_lblX);
  			 
  			 cbxX = new JComboBox();
  			 cbxX.setPreferredSize(new Dimension(136, 25));
  			 cbxX.setEditable(false);
  			 GridBagConstraints gbc_cbxX = new GridBagConstraints();
  			 gbc_cbxX.insets = new Insets(0, 0, 5, 0);
  			 gbc_cbxX.fill = GridBagConstraints.HORIZONTAL;
  			 gbc_cbxX.gridx = 1;
  			 gbc_cbxX.gridy = 4;
  			 diagrammPanel.add(cbxX, gbc_cbxX);
  			 
  			 lblY = new JLabel("Y");
  			 GridBagConstraints gbc_lblY = new GridBagConstraints();
  			 gbc_lblY.anchor = GridBagConstraints.LINE_START;
  			 gbc_lblY.insets = new Insets(0, 5, 5, 5);
  			 gbc_lblY.gridx = 0;
  			 gbc_lblY.gridy = 5;
  			 diagrammPanel.add(lblY, gbc_lblY);
  			 
  			 cbxY = new JComboBox();
  			 cbxY.setPreferredSize(new Dimension(136, 25));
  			 cbxY.setEditable(false);
  			 GridBagConstraints gbc_cbxY = new GridBagConstraints();
  			 gbc_cbxY.insets = new Insets(0, 0, 5, 0);
  			 gbc_cbxY.fill = GridBagConstraints.HORIZONTAL;
  			 gbc_cbxY.gridx = 1;
  			 gbc_cbxY.gridy = 5;
  			 diagrammPanel.add(cbxY, gbc_cbxY);
  			 
  			 JLabel lblR = new JLabel("Relation");
  			 GridBagConstraints gbc_lblR = new GridBagConstraints();
  			 gbc_lblR.anchor = GridBagConstraints.LINE_START;
  			 gbc_lblR.insets = new Insets(0, 5, 5, 5);
  			 gbc_lblR.gridx = 0;
  			 gbc_lblR.gridy = 6;
  			 diagrammPanel.add(lblR, gbc_lblR);
  			 
  			 cbxR = new JComboBox();
  			 cbxR.setPreferredSize(new Dimension(136, 25));
  			 cbxY.setEditable(false);
  			 GridBagConstraints gbc_cbxR = new GridBagConstraints();
  			 gbc_cbxR.insets = new Insets(0, 0, 5, 0);
  			 gbc_cbxR.fill = GridBagConstraints.HORIZONTAL;
  			 gbc_cbxR.gridx = 1;
  			 gbc_cbxR.gridy = 6;
  			 diagrammPanel.add(cbxR, gbc_cbxR);
  			 
  			 
  			 
  			 btnDeleteVector = new JButton("Delete");
  			 btnDeleteVector.setHorizontalAlignment(SwingConstants.RIGHT);
  			 btnDeleteVector.addActionListener(new ActionListener() {
  			 	public void actionPerformed(ActionEvent arg0) {
  			 		deleteVector();
  			 	}
  			 });
  			 GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
  			 gbc_btnNewButton.anchor = GridBagConstraints.NORTHEAST;
  			 gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
  			 gbc_btnNewButton.gridx = 0;
  			 gbc_btnNewButton.gridy = 7;
  			 diagrammPanel.add(btnDeleteVector, gbc_btnNewButton);
  			 
  			 btnSaveVector = new JButton("Save");
  			 btnSaveVector.addActionListener(new ActionListener() {
  			 	public void actionPerformed(ActionEvent e) {
  			 		saveVector();
  			 		String relative$=(String)cbxR.getSelectedItem();
  			 		entity.putElementItem("tube", new Core(null,"relative",relative$));
  			 		entigrator.putEntity(entity);
  			 	}
  			 });
  			 GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
  			 gbc_btnNewButton_1.insets = new Insets(0, 5, 5, 0);
  			 gbc_btnNewButton_1.anchor = GridBagConstraints.NORTHWEST;
  			 gbc_btnNewButton_1.gridx = 1;
  			 gbc_btnNewButton_1.gridy = 7;
  			 diagrammPanel.add(btnSaveVector, gbc_btnNewButton_1);
  			 
  			 panel = new JPanel();
  			 GridBagConstraints gbc_panel = new GridBagConstraints();
  			 gbc_panel.insets = new Insets(0, 0, 0, 5);
  			 gbc_panel.fill = GridBagConstraints.BOTH;
  			 gbc_panel.gridx = 0;
  			 gbc_panel.gridy = 8;
  			 diagrammPanel.add(panel, gbc_panel);
  			
		 Properties locator=Locator.toProperties(locator$);
		 entityLabel$=locator.getProperty(Entigrator.ENTITY_LABEL);
		 entigrator=console.getEntigrator();
		 entityKey$=entigrator.getKey(entityLabel$);
		 entity=entigrator.getEntity(entityKey$);
		initSettings();
		initVectorXY();
		initVectorNames();
		}
 public static String classLocator() {
			Properties locator=new Properties();
			locator.put(FacetHandler.FACET_KEY,KEY);
			locator.put(FacetHandler.FACET_NAME,TUBE_FACET_NAME);
			locator.put(FacetHandler.FACET_TYPE,TUBE_FACET_TYPE);
			locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
			locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
			locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.JTubeMaster");
			locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
			locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube.JTubeEditor");
			return Locator.toString(locator);
		}	
private void initSettings(String ray$){
	try{
		String key$=entity.getElementItemAtValue("ray.name",ray$);
		txtRayShift.setText("0");
		String shift$=entity.getElementItemAt("ray.shift",key$);
		if(shift$!=null)
			txtRayShift.setText(shift$);
		txtRayFactor.setText("1");
		String color$=entity.getElementItemAt("ray.color",key$);
	//	System.out.println("JTubeEditor:initSettings2:color="+entity.getElementItemAt("ray.color",key$) );
		int cnt=cbxRayColor.getModel().getSize();
		int ind=0;
		for(int i=0;i<cnt;i++){
		//	System.out.println("JTubeEditor:initSettings2:color="+cbxRayColor.getItemAt(i)+ "  i="+i);
			if(((String)cbxRayColor.getItemAt(i)).equalsIgnoreCase(color$))
				ind=i;
	}
	cbxRayColor.setSelectedIndex(ind);
	String visible$=entity.getElementItemAt("ray.visible",key$);
		//	System.out.println("JTubeEditor:initSettings2:color="+entity.getElementItemAt("ray.color",key$) );
			 cnt=cbxRayVisible.getModel().getSize();
			 ind=0;
		for(int i=0;i<cnt;i++){
			//	System.out.println("JTubeEditor:initSettings2:color="+cbxRayColor.getItemAt(i)+ "  i="+i);				if(((String)cbxRayVisible.getItemAt(i)).equalsIgnoreCase(visible$))
				ind=i;
		}
		cbxRayVisible.setSelectedIndex(ind);
		String factor$=entity.getElementItemAt("ray.factor",key$);
		if(factor$!=null)
			txtRayFactor.setText(factor$);
		txtRayScale.setText(null);
		txtRaySymbol.setText(null);
		Core scale=entity.getElementItem("ray.scale",key$);
		if(scale!=null) {
			txtRayScale.setText(scale.type);
			txtRaySymbol.setText(scale.value);
			
		}
		String position$=entity.getElementItemAt("ray.position", key$);
		txtRayPosition.setText(position$);
		String format$=entity.getElementItemAt("ray.format", key$);
		txtRayFormat.setText(format$);	
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(":2:"+e.toString());
	}
}
private void saveSettings(String ray$){
	try{
		entity.putElementItem("tube",new  Core(null,"frequency",txtFrequency.getText()));
		String key$=entity.getElementItemAtValue("ray.name",ray$);
		if(key$==null)
			key$=Identity.key();
		if(!entity.existsElement("ray.name"))
			entity.createElement("ray.name");
		entity.putElementItem("ray.name",new  Core(null,key$,(String)cbxRaySelector.getSelectedItem() ));
		if(!entity.existsElement("ray.shift"))
			entity.createElement("ray.shift");
		entity.putElementItem("ray.shift",new  Core(null,key$,txtRayShift.getText() ));
		if(!entity.existsElement("ray.factor"))
			entity.createElement("ray.factor");
		entity.putElementItem("ray.factor",new  Core(null,key$,txtRayFactor.getText() ));
		if(!entity.existsElement("ray.color"))
			entity.createElement("ray.color");
		entity.putElementItem("ray.color",new  Core(null,key$,(String)cbxRayColor.getSelectedItem() ));
		if(!entity.existsElement("ray.visible"))
			entity.createElement("ray.visible");
		entity.putElementItem("ray.visible",new  Core(null,key$,(String)cbxRayVisible.getSelectedItem() ));
		entity.putElementItem("operator",new  Core("input",ray$,"0" ));
		String scale$=txtRayScale.getText();
		String symbol$=txtRaySymbol.getText();
		if(scale$!=null&&scale$.length()>0) {
			if(!entity.existsElement("ray.scale"))
				entity.createElement("ray.scale");
			entity.putElementItem("ray.scale", new Core(scale$,key$,symbol$));
		}
		String position$=txtRayPosition.getText();
		if(position$!=null) {
			if(!entity.existsElement("ray.position"))
				entity.createElement("ray.position");
			entity.putElementItem("ray.position", new Core((String)cbxRaySelector.getSelectedItem(),key$,position$));
		}
		String format$=txtRayFormat.getText();
		if(format$!=null) {
			if(!entity.existsElement("ray.format"))
				entity.createElement("ray.format");
			entity.putElementItem("ray.format", new Core((String)cbxRaySelector.getSelectedItem(),key$,format$));
		}
		entigrator.putEntity(entity);
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
}
private void initSettings(){
	try{
		//System.out.println("JTubeEditor:initSettings:frequency="+entity.getElementItemAt("operator","frequency") );
	   txtFrequency.setText(entity.getElementItemAt("tube","frequency"));
	   Core [] ca=entity.elementGet("ray.name");
	   if(ca==null||ca.length<1){
		   System.out.println("JTubeEditor:initSettings:no rays");
		   return;
	   }
	    	String[] sa=new String[ca.length];
	    	for(int i=0;i<ca.length;i++)
	    		sa[i]=ca[i].value;
	    	Arrays.sort(sa);
	    	DefaultComboBoxModel model=new DefaultComboBoxModel(sa);
	    	cbxRaySelector.setModel(model);
	    	initSettings(sa[0]);
	    	ArrayList<String>sl=new ArrayList<String>();
	    	sl.add("None");
	    	ca=entity.elementGet("v.name");
	    if(ca!=null) {
	    	for(Core c:ca) 
	    		sl.add(c.value);
	    	}
	    	sa=new String[sl.size()];
	    	sl.toArray(sa);
	    	DefaultComboBoxModel<String> rmodel=new DefaultComboBoxModel<String>(sa);
	    	cbxR.setModel(rmodel);
	    	String relative$=entity.getElementItemAt("tube", "relative");
	    	selectCombo(cbxR,relative$);
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(":1:"+e.toString());
	}
}
private void deleteRay(String ray$){
	try{
		int response = JOptionPane.showConfirmDialog(this, "Delete selected ray  ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		    if (response != JOptionPane.YES_OPTION) 
		    	return;
		//System.out.println("JTubeEditor:deleteRay:ray="+ray$);
    Core [] ca=entity.elementGet("ray.name");
    //System.out.println("JTubeEditor:deleteRay:ca="+ca.length);
    for(Core c:ca){
    	//  System.out.println("JTubeEditor:deleteRay:c.value="+c.value+ "  c.name="+c.name);
    	if(ray$.equals (c.value)){
    		String key$=c.name;
    		//System.out.println("JTubeEditor:deleteRay:key="+key$);
    		entity.removeElementItem("ray.name",key$ );
    		entity.removeElementItem("ray.shift",key$ );
    		entity.removeElementItem("ray.factor",key$ );
    		entity.removeElementItem("ray.color",key$ );
    		entity.removeElementItem("ray.position",key$ );
    		entity.removeElementItem("ray.format",key$ );
    		entity.removeElementItem("ray.scale",key$ );
    		entity.removeElementItem("ray.visible",key$ );
    		entity.removeElementItem("operator",ray$ );
    		entigrator.putEntity(entity);
    		initSettings();
    	}
    }
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
}
@Override
public String getClassLocator() {
	return classLocator();
}

private void initVectorXY() {
	Core[] rnames=entity.elementGet("ray.name");
	//String x$=(String)cbxX.getSelectedItem();
	if(rnames!=null) {
		ArrayList<String>sl=new ArrayList<String>();
		for(Core c:rnames) {
			if(c.value!=null
					&&!c.value.startsWith("_")
					&&!c.value.startsWith("-")
					&&!c.value.startsWith("."))
           sl.add(c.value);
           String[] sa=new String[sl.size()];
           sl.toArray(sa);
           Arrays.sort(sa);
           DefaultComboBoxModel<String> xmodel=new DefaultComboBoxModel<String>(sa);
           cbxX.setModel(xmodel);
           DefaultComboBoxModel<String> ymodel=new DefaultComboBoxModel<String>(sa);
           cbxY.setModel(ymodel);
		}
		String vname$=(String)cbxVectorName.getSelectedItem();
		if(vname$!=null) {
			String v$=entity.getElementItemAtValue("v.name", vname$);
			Core v=entity.getElementItem("v.xy", v$);
			if(v.type!=null)
				selectCombo(cbxX,v.type);
			if(v.value!=null)
				selectCombo(cbxY,v.value);
		}
	}
}
private void initVectorNames() {
	Core[] ca=entity.elementGet("v.name");
	 DefaultComboBoxModel<String> vmodel=new DefaultComboBoxModel<String>();
	if(ca!=null) {
		ArrayList<String>sl=new ArrayList<String>();
		for(Core c:ca) {
			if(c.value!=null)
				sl.add(c.value);
		}
		String[]sa=new String[sl.size()];
		sl.toArray(sa);
		Arrays.sort(sa);
		vmodel=new DefaultComboBoxModel<String>(sa);
	}
	cbxVectorName.setModel(vmodel);
	String vname$=(String)cbxVectorName.getSelectedItem();
	initVector(vname$);
}
private void initVector(String vname$) {
	String vkey$=entity.getElementItemAtValue("v.name", vname$);
	if(vkey$==null)
		return;
	Core c=entity.getElementItem("v.name", vkey$);
	if(c!=null) {
		selectCombo(cbxVectorVisible,c.type);
	}
	c=entity.getElementItem("v.xy", vkey$);
	if(c!=null) {
		selectCombo(cbxX,c.type);
		selectCombo(cbxY,c.value);
	}
	c=entity.getElementItem("v.fc", vkey$);
	if(c!=null) {
		txtVectorFactor.setText(c.type);
		selectCombo(cbxVectorColor,c.value);
	}
}
private void saveVector() {
	String vname$=(String)cbxVectorName.getSelectedItem();
	if(vname$==null)
		return;
	String vkey$=entity.getElementItemAtValue("v.name", vname$);
	if(vkey$==null)
		vkey$=Identity.key();
	Core vname=entity.getElementItem("v.name", vkey$);
	if(vname==null)
		vname=new Core((String)cbxVectorVisible.getSelectedItem(),vkey$,vname$);
	else {
		vname.type=(String)cbxVectorVisible.getSelectedItem();
	    vname.value=vname$;
	}
	if(!entity.existsElement("v.name"))
		entity.createElement("v.name");
	entity.putElementItem("v.name", vname);
	String x$=(String)cbxX.getSelectedItem();
	String y$=(String)cbxY.getSelectedItem();
	if(!entity.existsElement("v.xy"))
		entity.createElement("v.xy");
	entity.putElementItem("v.xy", new Core(x$,vkey$,y$));
	
	String f$=txtVectorFactor.getText();
	String c$=(String)cbxVectorColor.getSelectedItem();
	if(!entity.existsElement("v.fc"))
		entity.createElement("v.fc");
	entity.putElementItem("v.fc", new Core(f$,vkey$,c$));
	console.getEntigrator().putEntity(entity);
	initVectorNames();
}
private void deleteVector() {
	String vname$=(String)cbxVectorName.getSelectedItem();
	if(vname$==null)
		return;
	int response = JOptionPane.showConfirmDialog(this, "Delete vector '"+vname$+"' ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	    if (response == JOptionPane.YES_OPTION) { 
	String vkey$=entity.getElementItemAtValue("v.name", vname$);
	if(vkey$==null)
		return;
	entity.removeElementItem("v.name", vkey$);
	entity.removeElementItem("v.xy", vkey$);
	entity.removeElementItem("v.fc", vkey$);
	console.getEntigrator().putEntity(entity);
	initVectorNames();
	    }
}
@Override
public String reply(JMainConsole console, String locator$) {
	return null;
}

/*
@Override
public boolean handleDone() {
	String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
	JDisplay display=getDisplay();
	if(parentLocator$==null) {
		System.out.println("JTubeEditor:handleDone:parent is null:locator="+locator$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String facetList$=JEntityFacetList.classLocator();
		facetList$=Locator.append(facetList$, Entigrator.ENTITY_LABEL, entity$);
		JEntityFacetList facetList=new JEntityFacetList(console,facetList$);
		 if(display==null)
		    	replace(console, facetList);
		    else
		    	display.putContext(facetList);
		    return true;
	}
	JContext.displayInstance(console, parent$,display);
	return true;
}
*/
}
