package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Properties;
import javax.swing.JPopupMenu;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.RecordHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.TubeHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.record.JRecordViewer;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JItemPanel;

public class RecordMaster extends FacetMaster{
	public static final String KEY="_y_eGMLU_SkF2xSPGNmktuiDap5S4";
	public static final String NAME="Record";
	public RecordMaster() {
		super();
	}
	public RecordMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	@Override
	public String getKey() {
			return KEY;
	}
	@Override
	public String getName() {
			return NAME;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.RecordMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,RecordHandler.RECORD_FACET_CLASS);
	    locator.put(HANDLER_KEY,RecordHandler.KEY);
	    locator.put(Locator.LOCATOR_TITLE,"Record");
	    locator.put(MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "record.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
	    locator.put(FacetHandler.FACET_TYPE,RecordHandler.RECORD_FACET_TYPE);
	    return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
	//	System.out.println("RecordMaster:getJEntityFacetsItem:locator="+handlerLocator$);
		String display$=Locator.getProperty(handlerLocator$, JContext.DISPLAY);
		String itemLocator$=JItemPanel.classLocator();
		String masterLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, masterLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		if(display$!=null)
			itemLocator$=Locator.append(itemLocator$,JContext.DISPLAY,display$);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= RecordHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new TubeHandler(console.getEntigrator(),handlerLocator$); 
	}
	
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
//			System.out.println("RecordMaster:entityFacetsItemOnClick:locator="+locator$);
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
//			System.out.println("RecordMaster:entityFacetsItemOnClick:entity label="+entityLabel$);
			String parentLocator$=context.getLocator();
			String parentInstance$=context.getInstance();
			SessionHandler.putLocator(console.getEntigrator(), parentLocator$);
			String recordViewer$=JRecordViewer.classLocator();
			recordViewer$=Locator.merge(recordViewer$,locator$);
			recordViewer$=Locator.append(recordViewer$,Entigrator.ENTITY_LABEL, entityLabel$);
			recordViewer$=Locator.append(recordViewer$,JContext.PARENT, parentInstance$);
			JRecordViewer  recordViewer=new JRecordViewer(console,recordViewer$);	
			console.replaceContext(context,recordViewer);
		}catch(Exception e) {
			System.out.println("RecordMaster:entityFacetsItemOnClick:"+e.toString());	
		}
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		return null;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String alocator$) {
		return null;
	}
	@Override
	public String getType() {
		return "record";
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",getType(),classLocator()));
		entity.putAttribute(new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU","icon","record.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		return entity;
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",RecordHandler.KEY,RecordHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("RecordMaster:addToSession:"+e.toString());
	    }
}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
}
