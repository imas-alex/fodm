package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.signal;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import java.awt.GridBagConstraints;
import javax.swing.JComboBox;
import java.awt.Insets;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Properties;


public class JSignalEditor extends JGuiEditor{
	public static final String KEY="_KPs8CvP5JHjF1iXE6Ma_8b1LOj0";
	JComboBox<String> cbxForm;
	JLabel lblPar0;
	JTextField txtPar1;
	JLabel lblPar1;
	JTextField txtPar0;
	
	JTextField txtDelay;
	public JSignalEditor(JMainConsole console,String alocator$) {
		super(console,alocator$);
		instance$=getInstance();
		parent$=Locator.getProperty(alocator$, PARENT);
		if(parent$!=null)
		locator$=Locator.append(locator$, PARENT, parent$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0,0,1};
		gridBagLayout.rowHeights = new int[]{0,0,0,0,1};
		gridBagLayout.columnWeights = new double[]{0.0,0.0,1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0.0,0.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblDelay = new JLabel("Delay");
		GridBagConstraints gbc_lblDelay = new GridBagConstraints();
		gbc_lblDelay.anchor = GridBagConstraints.LINE_START;
		gbc_lblDelay.insets = new Insets(5, 5, 5, 5);
		gbc_lblDelay.gridx = 0;
		gbc_lblDelay.gridy = 0;
		add(lblDelay, gbc_lblDelay);
		
		txtDelay = new JTextField();
		txtDelay.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String delay$=txtDelay.getText();
	    		entity.putElementItem("signal", new Core(null,"delay",delay$));	
				 console.getEntigrator().putEntity(entity);
				 }
			
	      });
		txtDelay.setColumns(10);
		GridBagConstraints gbc_txtDelay = new GridBagConstraints();
		gbc_txtDelay.insets = new Insets(5, 5, 5, 5);
		gbc_txtDelay.gridx = 1;
		gbc_txtDelay.gridy = 0;
		add(txtDelay, gbc_txtDelay);
		
		JLabel lblForm = new JLabel("Form");
		GridBagConstraints gbc_lblForm = new GridBagConstraints();
		gbc_lblForm.anchor = GridBagConstraints.LINE_START;
		gbc_lblForm.insets = new Insets(0, 5, 5, 5);
		gbc_lblForm.gridx = 0;
		gbc_lblForm.gridy = 1;
		add(lblForm, gbc_lblForm);
		
		 cbxForm = new JComboBox<String>();
		 cbxForm.addItemListener(new ItemListener() {
			    public void itemStateChanged(ItemEvent arg0) {
			    	String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    	txtPar1.setVisible(false);
			    	txtPar0.setVisible(true);
			    	lblPar1.setVisible(false);
			    	int index=cbxForm.getSelectedIndex();
			    	initPars(index);
			        switch(index) {
			       case 0:{
			    	   lblPar0.setText("Frequency");
			    	   txtPar1.setVisible(true);
			    	   lblPar1.setVisible(true);
			    	   lblPar1.setText("Amplitude");
			    	   entity.putElementItem("signal", new Core(null,"form","sinus"));
			    	   break;
			       		}
			       case 1:{
			    	   lblPar0.setText("Value"); 
			    	   entity.putElementItem("signal", new Core(null,"form","step"));
			    	   break;
			       }
			       case 2:{
			    	   lblPar0.setText("Factor"); 
			    	   txtPar1.setVisible(true);
			    	   lblPar1.setVisible(true);
			    	   lblPar1.setText("Limit");
			    	   entity.putElementItem("signal", new Core(null,"form","ramp"));
			    	   break;
			       }
			       case 3:{
			    	   lblPar0.setText(""); 
			    	   txtPar0.setVisible(false);
			    	   entity.putElementItem("signal", new Core(null,"form","custom"));
			    	   break;
			       }
			       }
			       console.getEntigrator().putEntity(entity);
			    }
			    
			});
		cbxForm.setModel(new DefaultComboBoxModel<String>(new String[] {"Sinus", "Step", "Ramp", "Custom"}));
		GridBagConstraints gbc_cbxForm = new GridBagConstraints();
		gbc_cbxForm.insets = new Insets(0, 5, 5, 5);
		gbc_cbxForm.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxForm.gridx = 1;
		gbc_cbxForm.gridy = 1;
		add(cbxForm, gbc_cbxForm);
		
		lblPar0 = new JLabel("Frequency");
		GridBagConstraints gbc_lblPar0 = new GridBagConstraints();
		gbc_lblPar0.insets = new Insets(0, 5, 5, 5);
		gbc_lblPar0.gridx = 0;
		gbc_lblPar0.gridy = 2;
		add(lblPar0, gbc_lblPar0);
		
		txtPar0 = new JTextField();
		txtPar0.setColumns(10);
		GridBagConstraints gbc_txtPar0 = new GridBagConstraints();
		gbc_txtPar0.insets = new Insets(0, 5, 5, 5);
		gbc_txtPar0.gridx = 1;
		gbc_txtPar0.gridy = 2;
		add(txtPar0, gbc_txtPar0);
		txtPar0.addCaretListener(new CaretListener() {
				@Override
				public void caretUpdate(CaretEvent e) {
					String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    	String par$=txtPar0.getText();
			    	
			    	int index=cbxForm.getSelectedIndex();
			    	switch (index) {
			    	case 0:{
			    		entity.putElementItem("signal", new Core(null,"frequency",par$));	
			    		break;   	}
			    	case 1:{
			    		entity.putElementItem("signal", new Core(null,"value",par$));	
			    		break;   	}
			    	case 2:{
			    		entity.putElementItem("signal", new Core(null,"factor",par$));	
			    		break;   	}
			    		}
						 console.getEntigrator().putEntity(entity);
					 }
				
		      });
		lblPar1 = new JLabel("Amplitude");
		GridBagConstraints gbc_lblPar1 = new GridBagConstraints();
		gbc_lblPar1.insets = new Insets(0, 5, 0, 5);
		gbc_lblPar1.gridx = 0;
		gbc_lblPar1.gridy = 3;
		add(lblPar1, gbc_lblPar1);
		
		txtPar1 = new JTextField();
		txtPar1.setColumns(10);
		GridBagConstraints gbc_txtPar1 = new GridBagConstraints();
		gbc_txtPar1.insets = new Insets(0, 5, 0, 5);
		gbc_txtPar1.gridx = 1;
		gbc_txtPar1.gridy = 3;
		add(txtPar1, gbc_txtPar1);
		txtPar1.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String par$=txtPar1.getText();
		    	int index=cbxForm.getSelectedIndex();
		    	switch (index) {
		    	case 0:{
		    		entity.putElementItem("signal", new Core(null,"amplitude",par$));	
		    		break;   	}
		    	case 1:{
		    		break;   	}
		    	case 2:{
		    		entity.putElementItem("signal", new Core(null,"limit",par$));	
		    		break;   	}
		    		}
					 console.getEntigrator().putEntity(entity);
				 }
	      });
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
    	if(!entity.existsElement("signal")) {
    		entity.createElement("signal");
    	entity.putElementItem("signal", new Core(null,"form","sinus"));
    	console.getEntigrator().putEntity(entity);
    	}
    	String form$=entity.getElementItemAt("signal", "form");
    	selectCombo(cbxForm, form$);	
    	initPars(cbxForm.getSelectedIndex()); 
	}
	private void initPars(int index) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		txtDelay.setText(entity.getElementItemAt("signal", "delay"));
    	switch(index) {
		case 0:{
			txtPar0.setText(entity.getElementItemAt("signal", "frequency"));
			txtPar1.setText(entity.getElementItemAt("signal", "amplitude"));
			break;
		}
		case 1:{
			txtPar0.setText(entity.getElementItemAt("signal", "value"));
			break;
		}
		case 2:{
			txtPar0.setText(entity.getElementItemAt("signal", "factor"));
			txtPar1.setText(entity.getElementItemAt("signal", "limit"));
			break;
		}
		}
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,"Signal");
		locator.put(FacetHandler.FACET_TYPE,"signal");
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.JSignalMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.signal.JSignalEditor");
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.SignalMaster");
		
		return Locator.toString(locator);
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	/*
	@Override
	public boolean handleDone() {
		String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
		JDisplay display=getDisplay();
		if(parentLocator$==null) {
			System.out.println("JSignalEditor:handleDone:parent is null:locator="+locator$);
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String facetList$=JEntityFacetList.classLocator();
			facetList$=Locator.append(facetList$, Entigrator.ENTITY_LABEL, entity$);
			JEntityFacetList facetList=new JEntityFacetList(console,facetList$);
			 if(display==null)
			    	replace(console, facetList);
			    else
			    	display.putContext(facetList);
			    return true;
		}
		JContext.displayInstance(console, parent$,display);
		return true;
	}
	*/
}
