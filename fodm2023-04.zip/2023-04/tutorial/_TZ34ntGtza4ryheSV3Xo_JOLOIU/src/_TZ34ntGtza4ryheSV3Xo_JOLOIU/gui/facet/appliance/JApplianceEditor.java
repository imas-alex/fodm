package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.appliance;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Logger;

import javax.swing.JMenu;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JGuiEditor;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;

import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.BoxLayout;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.awt.Dimension;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.Instant;

import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.ApplianceHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.GaugeHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.RecordHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.TubeHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.RecordMaster;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.gauge.Meter;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube.DiagrammPanel;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube.JDiagrammDialog;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube.TubePanel;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Connection;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Instrument;

import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JSlider;
public class JApplianceEditor extends JGuiEditor  {
	private static final long serialVersionUID = 1L;
	public static final String APPLIANCE_FACET_TYPE="appliance";
	public static final String APPLIANCE_FACET_NAME="Appliance";
	public static final String APPLIANCE_FACET_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.appliance.JApplianceEditor";
	public static final String KEY="_ZT6gV7FOdH42yyTd4KSwrtKkrw4";
	public static final String CREATOR="creator";
	public static final String RUNSTATE="runstate";
	public static final int START=0;
	public static final int RUN=1;
	public static final int PAUSE=2;
	public static final int FINISH=3;
	private Logger LOGGER=Logger.getLogger(JApplianceEditor.class.getName());
	private String entityLabel$;
	private Sack entity;
	protected JMenu menu;
	protected Entigrator entigrator;
	private JComboBox<String> cbxComponent;
	private JList<String> listComponents;
	private boolean stop=false;
	private boolean restart=false;
	 JComboBox <String>cbxSource;
		JTabbedPane tabbedPane;
		JComboBox <String>cbxOutput;
		JTable  tblConnect; 
		JComboBox <String>cbxConsumer ;
		JComboBox <String>cbxInput;
		JComboBox <String>cbxControl;
		 JButton  btnAddConnection;
		 JPanel screen ;
		 JPanel dashboard;
		 Meter	timer;
		  JTextField txtTakt;
		  JTextField txtStopTime;
		  JTextField txtStop;
		  JTextField txtStart;
		  JTextField txtTime;
		  JTextField txtStartView;
		  JTextField txtTimeFormat;
		  JSlider slider ;
		 boolean measure;
		 boolean recordMode;
		 boolean busySlider;
		 Sack candidate;
	     ApplianceHandler applianceHandler;
	     TubePanel  tubePanel;
	     private JTextField rayValues;
		 JDiagrammDialog dialog;
		 JButton start;
		 JButton pause;
		 JButton reset;
		 JButton store;
		 int steps=0;
		 public JApplianceEditor() {
			 super();
		 }
	public JApplianceEditor(JMainConsole console, String alocator$) {
	      super(console,alocator$);
	    //  System.out.println("JApplianceEditor:locator="+locator$);
	      instance$=getInstance();
			parent$=Locator.getProperty(alocator$, PARENT);
			if(parent$!=null)
			locator$=Locator.append(locator$, PARENT, parent$);
	      entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		  entity=console.getEntigrator().getEntityAtLabel(entityLabel$);
	      entigrator=console.getEntigrator();
	      applianceHandler=new ApplianceHandler(entigrator,locator$);
	    //  System.out.println("JApplianceEditor:1");		
		  tubePanel=new TubePanel(console.getEntigrator(),null);
		  Sack tube=getComponent("tube");
		  if(tube!=null)
			  tubePanel.setTube(tube);
	      setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		  tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		  tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) { 
			try{
				JTabbedPane sourceTabbedPane = (JTabbedPane) e.getSource();
		        int index = sourceTabbedPane.getSelectedIndex();
		       // System.out.println("Tab changed to: " + sourceTabbedPane.getTitleAt(index));
				String title$= sourceTabbedPane.getTitleAt(index);
		        if("Commutator".equals(title$)){
		        	stop=true;
		        	initSources();
		        	initOutput((String)cbxSource.getSelectedItem());
		        	initConsumers();
		        	initInput((String)cbxConsumer.getSelectedItem());
		        	initConnectionButtons();
		        	replaceTable();
		        }
		        if("Console".equals(title$)){
		        	initTuner();
		        	JApplianceEditor.this.pause.setEnabled(false);
					JApplianceEditor.this.start.setEnabled(true);
					JApplianceEditor.this.reset.setEnabled(true);
					JApplianceEditor.this.store.setEnabled(false);
					JApplianceEditor.this.slider.setEnabled(false);
		        }
		        if("Tuner".equals(title$)){
		        	stop=true;
		        	initTuner();
		        }
		        if("Assembler".equals(title$)){
		        	updateComponents();
		        	stop=true;
		        }
		     
			}catch(Exception ee){}
			}
		});
		  add(tabbedPane);
		JPanel collector = new JPanel();
		tabbedPane.addTab("Assembler", null, collector, null);
		GridBagLayout gbl_collector=new GridBagLayout();
		collector.setLayout(gbl_collector);
	    GridBagConstraints gbc_controls = new GridBagConstraints();
		gbc_controls.fill = GridBagConstraints.BOTH;
				gbc_controls.weightx = 0.1;
				gbc_controls.gridwidth = 3;
				gbc_controls.gridx =0;
				gbc_controls.gridy = 0;
		  JPanel controls = new JPanel();	
		  controls.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		  controls.setLayout(new GridBagLayout());
		  collector.add(controls, gbc_controls);
		  
		  JLabel lblComponent = new JLabel("Component");
		  GridBagConstraints gbc_lblComponent = new GridBagConstraints();
		  gbc_lblComponent.insets = new Insets(0, 0, 5, 5);
			gbc_lblComponent.weightx = 0.0;
			gbc_lblComponent.weighty = 0.0;
			gbc_lblComponent.gridwidth = 1;
			gbc_lblComponent.gridx = 0;
			gbc_lblComponent.gridy = 0;
		  controls.add(lblComponent, gbc_lblComponent);

		 cbxComponent = new JComboBox<String>();
		 cbxComponent.setModel(new DefaultComboBoxModel<String>(new String[] {""}));
		 GridBagConstraints gbc_cbxComponent = new GridBagConstraints();
		 gbc_cbxComponent.insets=new Insets(3, 3, 5, 5);
			gbc_cbxComponent.fill = GridBagConstraints.HORIZONTAL;
			gbc_cbxComponent.weightx = 0.5;
			gbc_cbxComponent.weightx = 0.1;
			gbc_cbxComponent.gridwidth = 1;
			gbc_cbxComponent.gridx = 1;
			gbc_cbxComponent.gridy = 0;
		  controls.add(cbxComponent, gbc_cbxComponent);
	
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addComponent();
			}
			});
		 GridBagConstraints gbc_btnAdd = new GridBagConstraints();
		 gbc_btnAdd.insets = new Insets(0, 0, 0, 5);
		gbc_btnAdd.gridx = 2;
		gbc_btnAdd.gridy = 0;
		  controls.add(btnAdd, gbc_btnAdd);
	  GridBagConstraints gbc_list = new GridBagConstraints();
			gbc_list.fill = GridBagConstraints.BOTH;
					gbc_list.weightx = 0.5;
					gbc_list.weighty = 0.5;
					gbc_list.ipady = 40;      //make this component tall
					gbc_list.weightx = 0.0;
					gbc_list.gridwidth = 3;
					gbc_list.gridx =0;
					gbc_list.gridy = 1;
		
			listComponents = new JList<String>();
			listComponents.setBorder(new CompoundBorder(null, new BevelBorder(BevelBorder.LOWERED, null, null, null, null)));
			listComponents.setLayout(new GridBagLayout());
			listComponents.addMouseListener( new MouseAdapter() {
			   
				public void mousePressed(MouseEvent e) {
			        if ( SwingUtilities.isRightMouseButton(e) ) {      
			          	listComponents.setSelectedIndex(listComponents.locationToIndex(e.getPoint()));
			            JPopupMenu menu = new JPopupMenu();
			            JMenuItem itemOpen = new JMenuItem("Open");
			            itemOpen.addActionListener(new ActionListener() {
			                public void actionPerformed(ActionEvent e) {
			             try{   	
			              String servicesLocator$=JEntityFacetList.classLocator();
			              String operLabel$=listComponents.getSelectedValue();
			              Sack oper=console.getEntigrator().getEntityAtLabel(operLabel$);
			              if(oper==null) {
			            	  System.out.println("JApplianceEditor:cannot find entity="+operLabel$);
			            	  return;
			              }
			              servicesLocator$=Locator.append(servicesLocator$, Entigrator.ENTITY_LABEL, listComponents.getSelectedValue());
			              JEntityFacetList entityFacetList=new JEntityFacetList(console,servicesLocator$);
						//  JDisplay display=new JDisplay(console,entityFacetList);
			              JDisplay display=new JDisplay(console);
						  display.setLocationRelativeTo(JApplianceEditor.this);
						  display.setVisible(true);
						  display.putContext(entityFacetList);
						  display.pack();
						  display.revalidate();
						  display.repaint();
						  entityFacetList.rebuild(console);
	
			             }catch(Exception ee){
			            	 LOGGER.severe(ee.toString());
			             }
		                }
			            });
			            menu.add(itemOpen);
			            JMenuItem itemRemove = new JMenuItem("Remove");
			            itemRemove.addActionListener(new ActionListener() {
			                public void actionPerformed(ActionEvent e) {
			                	int response = JOptionPane.showConfirmDialog(collector, "Delete selected components  ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					  		    if (response == JOptionPane.YES_OPTION) 
					  		    	removeComponent(listComponents.getSelectedValue());
			                }
			            });
			            menu.add(itemRemove);
			            JMenuItem itemCancel = new JMenuItem("Cancel");
			            itemCancel.addActionListener(new ActionListener() {
			                public void actionPerformed(ActionEvent e) {
			                }
			            });
			            menu.add(itemCancel);
						String operLabel$=listComponents.getSelectedValue();
		           		String operKey$=entigrator.getKey(operLabel$);
						Sack oper=entigrator.getEntity(operKey$);
						if(oper==null) {
							System.out.println("JApplianceEditor:cannot find entity="+ operLabel$);
						}else {
						if("tube".equals(oper.getProperty("entity"))) {
							String hide$=oper.getElementItemAt("tube", "hide");
							if("true".equals(hide$)) {
								JMenuItem itemShow = new JMenuItem("Show");
					            itemShow.addActionListener(new ActionListener() {
					                public void actionPerformed(ActionEvent e) {
					                	oper.putElementItem("tube", new Core(null,"hide","false"));
					                	entigrator.putEntity(oper);
					                	rebuildInstruments();
					                }
					            });
					            menu.add(itemShow);
							}else {
								JMenuItem itemHide = new JMenuItem("Hide");
					            itemHide.addActionListener(new ActionListener() {
					                public void actionPerformed(ActionEvent e) {
					                	oper.putElementItem("tube", new Core(null,"hide","true"));
					                	entigrator.putEntity(oper);
					                	rebuildInstruments();
					                }
					            });
					            menu.add(itemHide);
							}
						}
						}
			            menu.show(listComponents, e.getPoint().x, e.getPoint().y);            
			        }
			    }
			});
		collector.add(listComponents, gbc_list);
		 
		JPanel connector = new JPanel();
		tabbedPane.addTab("Commutator", null, connector, null);

		GridBagLayout gbl_connector=new GridBagLayout();
		gbl_connector.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0};
		gbl_connector.columnWeights = new double[]{1.0, 0.0, 0.0};
		 connector.setLayout( gbl_connector);
		 
		    GridBagConstraints gbc_outputs = new GridBagConstraints();
		    gbc_outputs.insets = new Insets(0, 0, 5, 5);
			gbc_outputs.fill = GridBagConstraints.HORIZONTAL;
			gbc_outputs.weightx = 0.2;
			gbc_outputs.gridwidth = 3;
			gbc_outputs.gridx =0;
			gbc_outputs.gridy = 0;
			
			  JPanel out = new JPanel();	
			  out.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Out", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
			  GridBagLayout gbl_out = new GridBagLayout();
			  out.setLayout(gbl_out);
			  connector.add(out, gbc_outputs);
			  
			  JLabel lblSource = new JLabel("Source");
			  GridBagConstraints gbc_lblSource = new GridBagConstraints();
			  gbc_lblSource.insets = new Insets(0, 0, 5, 5);
				gbc_lblSource.weightx = 0.5;
				gbc_lblSource.weightx = 0.0;
				gbc_lblSource.gridwidth = 1;
				gbc_lblSource.gridx = 0;
				gbc_lblSource.gridy = 0;
				gbc_lblSource.anchor=GridBagConstraints.LAST_LINE_START;
				out.add(lblSource, gbc_lblSource);
			
			 cbxSource = new JComboBox<String>();
			 cbxSource.addActionListener(new ActionListener() {
			 	public void actionPerformed(ActionEvent e) {
			 		 JComboBox<String> comboBox = (JComboBox<String>) e.getSource();
		           String source$=(String) comboBox.getSelectedItem();
		           initOutput(source$);
		           initConnectionButtons(); 
			 	}
			 });
			
			 GridBagConstraints gbc_cbxSource = new GridBagConstraints();
			   gbc_cbxSource.insets=new Insets(3, 3, 5, 3);
				gbc_cbxSource.fill = GridBagConstraints.HORIZONTAL;
				gbc_cbxSource.weightx = 0.5;
				gbc_cbxSource.weighty = 0.1;
				gbc_cbxSource.gridwidth = 1;
				gbc_cbxSource.gridx = 1;
				gbc_cbxSource.gridy = 0;
				gbc_cbxSource.anchor=GridBagConstraints.LINE_START;
			    out.add(cbxSource, gbc_cbxSource);
			    
			    JLabel lblOutput = new JLabel("Output");
				  GridBagConstraints gbc_lblOutput  = new GridBagConstraints();
				  gbc_lblOutput.insets = new Insets(0, 0, 5, 5);
				  gbc_lblOutput .weightx = 0.0;
					gbc_lblOutput .weighty = 0.0;
					gbc_lblOutput .gridwidth = 1;
					gbc_lblOutput.gridx = 0;
					gbc_lblOutput.gridy = 1;
					gbc_lblOutput.anchor= GridBagConstraints.LINE_START;
				  out.add(lblOutput, gbc_lblOutput);
				
				 cbxOutput = new JComboBox<String>();
				 cbxOutput.addActionListener(new ActionListener() {
				 	public void actionPerformed(ActionEvent e) {
				 		initConnectionButtons();
				 	}
				 });
				 GridBagConstraints gbc_cbxOutput = new GridBagConstraints();
				 gbc_cbxOutput.insets=new Insets(3, 3, 5, 3);
					gbc_cbxOutput.fill = GridBagConstraints.HORIZONTAL;
					gbc_cbxOutput.weightx = 1.0;
					gbc_cbxOutput.gridx = 1;
					gbc_cbxOutput.gridy = 1;
				    out.add(cbxOutput, gbc_cbxOutput);
				
				    JPanel in = new JPanel();	
					  in.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "In", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
					  in.setLayout(new GridBagLayout());
					  GridBagConstraints gbc_inputs = new GridBagConstraints();
					  gbc_inputs.insets = new Insets(0, 0, 5, 5);
						gbc_inputs.fill = GridBagConstraints.BOTH;
						gbc_inputs.weightx = 0.2;
						gbc_inputs.gridwidth = 3;
						gbc_inputs.gridx =0;
						gbc_inputs.gridy = 1;
					  connector.add(in, gbc_inputs);
					  
					  JLabel lblConsumer = new JLabel("Consumer");
					  GridBagConstraints gbc_lblConsumer = new GridBagConstraints();
						gbc_lblConsumer.weightx = 0.5;
						gbc_lblConsumer.weightx = 0.0;
						gbc_lblConsumer.gridwidth = 1;
						gbc_lblConsumer.gridx = 0;
						gbc_lblConsumer.gridy = 0;
					  in.add(lblConsumer, gbc_lblConsumer);
					  
					 cbxConsumer = new JComboBox<String>();
					 cbxConsumer.addActionListener(new ActionListener() {
						 	public void actionPerformed(ActionEvent e) {
						 		 JComboBox<String> comboBox = (JComboBox) e.getSource();
					           String consumer$=(String) comboBox.getSelectedItem();
					           initInput(consumer$);
					       	initConnectionButtons(); 
						 	}
						 });
						
					 GridBagConstraints gbc_cbxConsumer = new GridBagConstraints();
					   gbc_cbxConsumer.insets=new Insets(3,3,3,3);
						gbc_cbxConsumer.fill = GridBagConstraints.HORIZONTAL;
						gbc_cbxConsumer.weightx = 0.5;
						gbc_cbxConsumer.weighty = 0.1;
						gbc_cbxConsumer.gridwidth = 1;
						gbc_cbxConsumer.gridx = 1;
						gbc_cbxConsumer.gridy = 0;
					    in.add(cbxConsumer, gbc_cbxConsumer);
					    
					    JLabel lblInput = new JLabel("Input");
						  GridBagConstraints gbc_lblInput  = new GridBagConstraints();
						  gbc_lblInput .weightx = 0.5;
							gbc_lblInput .weightx = 0.0;
							gbc_lblInput .gridwidth = 1;
							gbc_lblInput.gridx = 0;
							gbc_lblInput.gridy = 1;
						  in.add(lblInput, gbc_lblInput);
						
						 cbxInput = new JComboBox();
						 cbxInput.addActionListener(new ActionListener() {
						 	public void actionPerformed(ActionEvent e) {
						 		initConnectionButtons();
						 	}
						 });
						 GridBagConstraints gbc_cbxInput = new GridBagConstraints();
						 gbc_cbxInput.insets=new Insets(3,3,3,3);
							gbc_cbxInput.fill = GridBagConstraints.HORIZONTAL;
							gbc_cbxInput.weightx = 0.5;
							gbc_cbxInput.weightx = 0.1;
							gbc_cbxInput.gridwidth = 1;
							gbc_cbxInput.gridx = 1;
							gbc_cbxInput.gridy = 1;
						    in.add(cbxInput, gbc_cbxInput);

						    JPanel edit = new JPanel();	
							 edit.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Connection", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 255)));
							 GridBagConstraints gbc_edit = new GridBagConstraints();
							 gbc_edit.insets = new Insets(0, 0, 5, 5);
								gbc_edit.fill = GridBagConstraints.BOTH;
								gbc_edit.weightx = 0.2;
								gbc_edit.gridwidth = 3;
								gbc_edit.gridx =0;
								gbc_edit.gridy = 2;
							  connector.add(edit, gbc_edit);
							
							   btnAddConnection = new JButton("Add");
							  btnAddConnection.addActionListener(new ActionListener() {
							  	public void actionPerformed(ActionEvent e) {
							  	  String source$=(String)cbxSource.getSelectedItem();
							  	 String output$=(String)cbxOutput.getSelectedItem();
							  	 String consumer$=(String)cbxConsumer.getSelectedItem();
							  	 String input$=(String)cbxInput.getSelectedItem();
							  	 Connection connection=new Connection(entity,source$,output$,consumer$, input$);
							  	 if(!connection.alreadyInserted(entity)){
							  		 entity=connection.insert(entity);entigrator.putEntity(entity);
							  		 entigrator.putEntity(entity);
							  		
							  		 initConnectionButtons();
							  		replaceTable();
							  	 }
							  	 
							  	}
							  });
							  GridBagConstraints gbc_addConnection= new GridBagConstraints();
							  gbc_addConnection.weightx = 0.5;
							  gbc_addConnection.weightx = 0.0;
							  gbc_addConnection.gridwidth = 1;
							  gbc_addConnection.gridx = 1;
							 gbc_addConnection.gridy = 0;
							 edit.add(btnAddConnection, gbc_addConnection);
							 
							  JButton btnClear = new JButton("Clear");
							  btnClear.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										int response = JOptionPane.showConfirmDialog(collector, "Delete all connections' ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
							  		    if (response == JOptionPane.YES_OPTION) {
							  		    	    entity.clearElement("connection");
						            	    	entigrator.putEntity(entity);
						            	    	replaceTable();
								            	initConnectionButtons();
						            	    }
									}
									});
							 GridBagConstraints gbc_btnClear = new GridBagConstraints();
							 gbc_btnClear.insets = new Insets(0, 0, 0, 5);
					 			gbc_btnClear.gridx = 0;
								gbc_btnClear.gridy = 0;
							edit.add(btnClear, gbc_btnClear);

							JScrollPane scrConnect=new JScrollPane();
							 GridBagConstraints gbc_scrConnect = new GridBagConstraints();
							 gbc_scrConnect.insets = new Insets(0, 0, 0, 5);
							 gbc_scrConnect.fill = GridBagConstraints.BOTH;
							 gbc_scrConnect.gridx = 0;
							 gbc_scrConnect.gridy = 3;
							 gbc_scrConnect.gridwidth=3;
							 connector.add(scrConnect, gbc_scrConnect);
							 
							 tblConnect = new JTable();
							 tblConnect.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
							   tblConnect.setModel(new DefaultTableModel(
							  	new Object[][] {
							  	},
							  	new String[] {
							  		"Source", "Output", "Consumer", "Input"
							  	}
							  ));
							   JTableHeader header = tblConnect.getTableHeader();
							   header.addMouseListener(new MouseAdapter() {
								    @Override
								    public void mouseClicked(MouseEvent e) {
								        int col =tblConnect.columnAtPoint(e.getPoint());
								        Connection [] cona=Connection.getConnections(entigrator,entity);
								        cona=Connection.sortConnections(cona, col);
								        replaceTable(cona);
								    }
								});
							   final JPopupMenu popupMenu = new JPopupMenu();
						      JMenuItem deleteItem = new JMenuItem("Delete");
						        deleteItem.addActionListener(new ActionListener() {
						            @Override
						            public void actionPerformed(ActionEvent e) {
						            	if(tblConnect.getSelectedRow()<0){
						            		JOptionPane.showMessageDialog(collector, "No selection");
						            		return;
						            	}
						            	
						            	int response = JOptionPane.showConfirmDialog(collector, "Delete selected connections' ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
							  		    if (response == JOptionPane.YES_OPTION) {
						            	     String[] sa=new String[4];
						            		     int row=tblConnect.getSelectedRow();
						            	     sa[0]=(String)tblConnect.getModel().getValueAt(row, 0);
						            	     sa[1]=(String)tblConnect.getModel().getValueAt(row, 1);
						            	     sa[2]=(String)tblConnect.getModel().getValueAt(row, 2);
						            	     sa[3]=(String)tblConnect.getModel().getValueAt(row, 3);
						            	    String connKey$=Connection.getKey(sa, entity);
						            	    if(connKey$!=null){
						            	    	entity.removeElementItem("connection",connKey$);
						            	    	entigrator.putEntity(entity);
						            	    }
						            	replaceTable();
						            	initConnectionButtons();
						            }}
						        });
						        popupMenu.add(deleteItem);
						        tblConnect.setComponentPopupMenu(popupMenu);
							   scrConnect.setViewportView(tblConnect);
						
						JPanel aConsole = new JPanel();
						tabbedPane.addTab("Console", null, aConsole, null);
						aConsole.setLayout(new BoxLayout(aConsole, BoxLayout.Y_AXIS));
						
					    screen = new JPanel();
						screen.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
						screen.setLayout(new BoxLayout(screen, BoxLayout.X_AXIS));
						aConsole.add(screen);
						screen.add(tubePanel);
						dashboard=new JPanel();
						dashboard.setMaximumSize(new Dimension(2000, 200));
									
						dashboard.setLayout(new BoxLayout(dashboard, BoxLayout.X_AXIS));
						timer = new Meter();    // Construct the drawing canvas
						timer.setPreferredSize(timer.getPreferredSize());				       
						timer.setTitle("Timer");
						timer.setVar(Instrument.TIME);
						timer.setUnit("s");
						
						double stopTime=100;
					     try{	 stopTime=Double.parseDouble(entity.getElementItemAt("tuner","stop" ));}catch(Exception e){}
						timer.setValueMaximum(stopTime);
						double time=0;
						  try{	 time=Double.parseDouble(entity.getElementItemAt("tuner",Instrument.TIME ));}catch(Exception e){}
						  try{ timer.setValue(time);
						  		timer.setMiddle(false);
						  }catch(Exception e){}
						dashboard.add(timer);
						aConsole.add(dashboard);
						JPanel desk = new JPanel();
						desk.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
						aConsole.add(desk);
						desk.setLayout(new BoxLayout(desk, BoxLayout.X_AXIS));
						
						start = new JButton("Start");
						start.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								stop=false;
								restart=false;
								//start();
								new PlayThread().start();
								
							}
						});
						desk.add(start);
						
						pause = new JButton("Pause");
						pause.setEnabled(false);
						pause.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								//stop();
								stop=true;
								int pos = (int)slider.getValue();
					            handleSlider(pos);
							}
						});
						desk.add(pause);
						
						reset = new JButton("Reset");
						reset.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								restart=true;
								stop=true;
								entity.putElementItem(OperatorHandler.OPERATOR, new Core(null,"time","0"));
								entigrator.putEntity(entity);
								steps=0;
								System.out.println("JApplianceEditor:reset click");
								new PlayThread().start();
								stop=true;
							}
						});
						desk.add(reset);
						
						store = new JButton("Store");
						store.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								store();
							}
						});
						desk.add(store);
						
						slider = new JSlider();
						slider.addMouseListener(new MouseAdapter() {
							@Override
							public void mouseReleased(MouseEvent e) {
							  int pos=slider.getValue();
							 try {
							  tubePanel.drawScreenMarker(pos);
							  Sack tube=tubePanel.getTube();
							  String freq$=tube.getElementItemAt("tube", "frequency");
							  int freq=Integer.parseInt(freq$);
							  String takt$=entity.getElementItemAt("tuner",Instrument.TAKT);
							  double takt=Double.parseDouble(takt$);
							  int w=tubePanel.getWidth();
							  int index= (int)(w*pos/(100*takt*freq));
							  reviseInstruments(index);
						//	  System.out.println("JApplianceEditor:slider:index="+index);
							  if(dialog!=null)
								  dialog.toFront();
							  }catch(Exception ee) {
								  System.out.println("JApplianceEditor:slider:"+ee.toString());
							  }
							}
						});
						slider.addChangeListener(new ChangeListener() {
							public void stateChanged(ChangeEvent e) {
								if (slider.getValueIsAdjusting()) {
						        	int pos = (int)slider.getValue();
						            handleSlider(pos);
						        }    
							}
						});
						desk.add(slider);
					
						JPanel panel = new JPanel();
						aConsole.add(panel);
						panel.setMaximumSize(new Dimension(10000,50));
						GridBagLayout gbl_panel = new GridBagLayout();
						gbl_panel.columnWeights = new double[]{0.0, 0.0,0.0, Double.MIN_VALUE};
						gbl_panel.rowWeights = new double[]{0.0};
						panel.setLayout(gbl_panel);
						txtStart = new JTextField();
						txtStart.setText("Start");
						txtStart.setHorizontalAlignment(SwingConstants.LEFT);
						txtStart.setEditable(false);
						GridBagConstraints gbc_txtStart = new GridBagConstraints();
						gbc_txtStart.insets = new Insets(0, 0, 0, 5);
						gbc_txtStart.gridx = 0;
						gbc_txtStart.gridy = 0;
						panel.add(txtStart, gbc_txtStart);
						txtStart.setColumns(8);
						//textField.setMaximumSize(new Dimension(100,50));
						
						txtStop = new JTextField();
						txtStop.setText("Stop");
						txtStop.setEditable(false);
						txtStop.setHorizontalAlignment(SwingConstants.LEFT);
						GridBagConstraints gbc_txtStop = new GridBagConstraints();
						gbc_txtStop.insets = new Insets(0, 0, 0, 5);
						gbc_txtStop.gridx = 1;
						gbc_txtStop.gridy = 0;
						panel.add(txtStop, gbc_txtStop);
						txtStop.setColumns(8);
						//textField.setMaximumSize(new Dimension(100,50));
						
						txtTime = new JTextField();
						txtTime.setText("Time=0");
						txtTime.setEditable(false);
						txtTime.setHorizontalAlignment(SwingConstants.LEFT);
						GridBagConstraints gbc_txtTime = new GridBagConstraints();
						gbc_txtTime.insets = new Insets(0, 0, 0, 5);
						gbc_txtTime.gridx = 2;
						gbc_txtTime.gridy = 0;
						txtTime.setColumns(12);
						panel.add(txtTime, gbc_txtTime);
						
						rayValues = new JTextField();
						rayValues.setEditable(false);
						GridBagConstraints gbc_rayValues = new GridBagConstraints();
						gbc_rayValues.gridx = 3;
						gbc_rayValues.gridy = 0;
						gbc_rayValues.fill=GridBagConstraints.HORIZONTAL;
						panel.add(rayValues, gbc_rayValues);
						rayValues.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
						JPanel tuner = new JPanel();
						tabbedPane.addTab("Tuner", null, tuner, null);
						 GridBagLayout gbl_tuner = new GridBagLayout();
						 gbl_tuner.columnWeights = new double[]{0.0, 1.0};
						 gbl_tuner.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0,0.0,1.0};
						 GridBagConstraints gbc_tuner = new GridBagConstraints();
						 tuner.setLayout(gbl_tuner);
						 JLabel lblTakt = new JLabel("Takt(s)");
						 		 GridBagConstraints gbc_lblTakt = new GridBagConstraints();
						 		 gbc_lblTakt.insets = new Insets(5, 5, 5, 5);
						 		 gbc_lblTakt.gridy = 0;
						 		 gbc_lblTakt.gridx = 0;
						 		 gbc_lblTakt.anchor=GridBagConstraints.LINE_START;
						 		  tuner.add(lblTakt, gbc_lblTakt);
					 		
						 		 txtTakt= new JTextField();
						 		 txtTakt.setColumns(12);
						 		GridBagConstraints gbc_txtTakt = new GridBagConstraints();
						 		gbc_txtTakt.insets = new Insets(0, 0, 5, 5);
						 		gbc_txtTakt.gridx = 1;
						 		gbc_txtTakt.gridy = 0;
						 		gbc_txtTakt.anchor=GridBagConstraints.LINE_START;
						 		tuner.add(txtTakt, gbc_txtTakt);
						 		JLabel lblStopTime = new JLabel("Stop(s)");
						 		  GridBagConstraints gbc_lblStopTime = new GridBagConstraints();
						 		  gbc_lblStopTime.insets = new Insets(5, 5, 5, 5);
						 		  gbc_lblStopTime.gridx =0;
						 		  gbc_lblStopTime.gridy = 1;
							 	 gbc_lblStopTime.anchor=GridBagConstraints.LINE_START;
						 		  tuner.add(lblStopTime,gbc_lblStopTime);
						 		
						 		txtStopTime= new JTextField();
						 		txtStopTime.setColumns(12);
						 		GridBagConstraints gbc_txtStopTime = new GridBagConstraints();
						 		gbc_txtStopTime.insets = new Insets(0, 0, 5, 5);
						 		gbc_txtStopTime.gridx = 1;
						 		gbc_txtStopTime.gridy = 1;
						 		gbc_txtStopTime.anchor=GridBagConstraints.LINE_START;
						 		tuner.add(txtStopTime,gbc_txtStopTime);
						 	
						 		 JLabel lblStartView = new JLabel("Start view(s)");
						 		  GridBagConstraints gbc_lblStartView = new GridBagConstraints();
						 		  gbc_lblStartView.insets = new Insets(5, 5, 5, 5);
						 		  gbc_lblStartView.gridx =0;
						 		  gbc_lblStartView.gridy = 2;
							 	 gbc_lblStartView.anchor=GridBagConstraints.LINE_START;
						 		  tuner.add(lblStartView,gbc_lblStartView);
						 		
						 		txtStartView= new JTextField();
						 		txtStartView.setColumns(12);
						 		GridBagConstraints gbc_txtStartView = new GridBagConstraints();
						 		gbc_txtStartView.insets = new Insets(0, 0, 5, 5);
						 		gbc_txtStartView.gridx = 1;
						 		gbc_txtStartView.gridy = 2;
						 		gbc_txtStartView.anchor=GridBagConstraints.LINE_START;
						 		tuner.add(txtStartView,gbc_txtStartView);
						 		
						 		 JLabel lblTimeFormat = new JLabel("Time format");
						 		  GridBagConstraints gbc_lblTimeFormat = new GridBagConstraints();
						 		  gbc_lblTimeFormat.insets = new Insets(5, 5, 5, 5);
						 		  gbc_lblTimeFormat.gridx =0;
						 		  gbc_lblTimeFormat.gridy = 3;
							 	 gbc_lblTimeFormat.anchor=GridBagConstraints.LINE_START;
						 		  tuner.add(lblTimeFormat,gbc_lblTimeFormat);
						 		
						 		txtTimeFormat= new JTextField();
						 		txtTimeFormat.setColumns(12);
						 		GridBagConstraints gbc_txtTimeFormat = new GridBagConstraints();
						 		gbc_txtTimeFormat.insets = new Insets(0, 0, 5, 5);
						 		gbc_txtTimeFormat.gridx = 1;
						 		gbc_txtTimeFormat.gridy = 3;
						 		gbc_txtTimeFormat.anchor=GridBagConstraints.LINE_START;
						 		tuner.add(txtTimeFormat,gbc_txtTimeFormat);
	
						 		JButton btnSave = new JButton("Save");
						 		btnSave.addActionListener(new ActionListener() {
						 			public void actionPerformed(ActionEvent e) {
						 				if(!entity.existsElement("tuner"))
						 					entity.createElement("tuner");
						 				   saveTuner();
						 			}
						 		});
						 		GridBagConstraints gbc_btnSave = new GridBagConstraints();
						 		gbc_btnSave.insets = new Insets(5, 5, 5, 5);
						 		gbc_btnSave.gridx = 1;
						 		gbc_btnSave.gridy = 6;
						 		gbc_btnSave.anchor=GridBagConstraints.LINE_START;
						 		tuner.add(btnSave, gbc_btnSave);
						 		
						 		JButton btnReset = new JButton("Reset");
						 		btnReset.addActionListener(new ActionListener() {
						 			public void actionPerformed(ActionEvent e) {
						 				int response = JOptionPane.showConfirmDialog(JApplianceEditor.this, "Remove all settings  ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
							  		    if (response == JOptionPane.YES_OPTION) { 
							  		    	entity.removeElement("tuner");
							  		    	entity.removeElement("component");
							  		    	entity.removeElement("consumer");
							  		    	entity.removeElement("source");
							  		    	console.getEntigrator().putEntity(entity);
							  		    }
						 			}
						 		});
						 		GridBagConstraints gbc_btnRest = new GridBagConstraints();
						 		gbc_btnRest.insets = new Insets(5, 5, 5, 5);
						 		gbc_btnRest.gridx = 0;
						 		gbc_btnRest.gridy = 6;
						 		tuner.add(btnReset, gbc_btnRest);
						 		
						 		JPanel filler = new JPanel();
						 		GridBagConstraints gbc_filler = new GridBagConstraints();
						 		gbc_filler.gridx = 0;
						 		gbc_filler.gridy =7;
						 		gbc_filler.fill=GridBagConstraints.VERTICAL;
						        tuner.add(filler,gbc_filler);
								tabbedPane.setSelectedIndex(0);
								instantiate();
								addComponentListener(new ResizeListener());
	//
//System.out.println("JApplianceEditor:constructor:FINISH");						
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,APPLIANCE_FACET_NAME);
		locator.put(FacetHandler.FACET_TYPE,APPLIANCE_FACET_TYPE);
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.appliance.JApplianceEditor");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.appliance.JApplianceEditor");
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.ApplianceMaster");
		
		return Locator.toString(locator);
	}
	private void instantiate() {
	try {
		 updateComponents();
	  	 rebuildInstruments();
	  	 initTuner();
	}catch(Exception e) {
		System.out.println("JApplianceEditor:instantiate:"+e.toString());
	}
	}
	@Override
	public String getTitle() {
		String label$=null;
       try{  label$= entity.getProperty("label");}catch(Exception e){}
		return "Appliance :"+label$;
	}
	@Override
	public String getSubtitle() {
		return entityLabel$;
	}
	
	private void refreshComponents() {
		try {
		Core[]  ca=entity.elementGet("component");
		//System.out.println("JApplianceEditor:refreshComponents:ca="+ca.length);
		ArrayList<String>ll=new ArrayList<String>();
		if(ca!=null)
			for(Core c:ca)
			  if(c.value!=null)	
				   ll.add(c.value);
		String[] la=new String[ll.size()];
		//System.out.println("JApplianceEditor:refreshComponents:la="+la.length);
		ll.toArray(la);
		Arrays.sort(la);
		//System.out.println("JApplianceEditor:refreshComponents:1");
		DefaultListModel<String> listModel=new DefaultListModel<String>();
		for(int i=0;i<la.length;i++)
		  listModel.add(i,la[i]);
		if(listComponents!=null)
		  listComponents.setModel(listModel);
		initConsumers();
		initSources();
		Sack component=null;
		for(Core c:ca) {
			component=entigrator.getEntity(c.name);
			if(component==null) {
				System.out.println("JApplianceEditor:refreshComponents:cannot get component:key="+c.name);
				continue;
			}
			entigrator.link(entity, component);
		}
		}catch(Exception e) {
			System.out.println("JApplianceEditor:refreshComponents:"+e.toString());
		}
	}
	private void updateComponents(){
		//System.out.println("JApplianceEditor:updateComponents:BEGIN");  
	try {
		if(entity==null) {
			System.out.println("JApplianceEditor:updateComponents:entity is null");
		  return;
		}
		 String[] allOperators=entigrator.listEntities(OperatorHandler.OPERATOR);
		//System.out.println("JApplianceEditor:updateComponents:operators="+allOperators.length);
		 String[] components=entity.elementListNames("component");
		 ArrayList<String>cl=new    ArrayList<String>();
		 if(allOperators!=null) {
			 boolean found;	 
		 for(String o:allOperators) {
			 found=false; 
			 if(components!=null)
				 for(String c:components) {
				     if(o.equals(c)){
					   found=true;
					   break;
				     }
				 }
			 if(!found)
				 cl.add(o);
		 }
		 }
		// System.out.println("JApplianceEditor:updateComponents:cl="+cl.size());
		 refreshComponents();
		 DefaultComboBoxModel<String> cbxComponentModel=new  DefaultComboBoxModel<String>();
		 if(cl!=null) {	
			 String component$;
			 ArrayList<String>cnl=new ArrayList<String>();
			 for(String c:cl) {
           		 component$=entigrator.getLabel(c);
           		 if(component$!=null)
           			 cnl.add(component$);
			 }
		//	 System.out.println("JApplianceEditor:updateComponents:cnl="+cnl.size());	 
		 String[] cka=new String[cnl.size()];
		 cnl.toArray(cka);
		 Arrays.sort(cka);
		 cbxComponentModel=new  DefaultComboBoxModel(cka);
		 }
		if(cbxComponent!=null) 
		   cbxComponent.setModel(cbxComponentModel); 
		// System.out.println("JApplianceEditor:updateComponents:FINISH"); 
	}catch(Exception e) {
		System.out.println("JApplianceEditor:updateComponents:"+e.toString());  
	}
	}
private void initSources(){
	locator$=Locator.append(locator$, ApplianceHandler.SELECT, ApplianceHandler.SOURCES);
	applianceHandler.setOperators(entigrator, locator$);
	String[]sa=applianceHandler.listOperators(console.getEntigrator(), locator$);	
	DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String> ();
	cbxSource.setModel(model);
  if(sa!=null)
           model=new DefaultComboBoxModel<String> (sa);	
  else
	  System.out.println("JApplianceEditor:no sources:locator="+locator$); 
   cbxSource.setModel(model);
}
private void initConsumers(){
	locator$=Locator.append(locator$, ApplianceHandler.SELECT, ApplianceHandler.CONSUMERS);
	applianceHandler.setOperators(entigrator, locator$);
	String[]sa=applianceHandler.listOperators(console.getEntigrator(), locator$);
    if(sa!=null) {
    	DefaultComboBoxModel<String>  model=new DefaultComboBoxModel<String> (sa);		
        cbxConsumer.setModel(model);
    }else {
    	DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String> ();
    	cbxConsumer.setModel(model);
    }
}
private void initOutput(String source$) {
	initPinout(source$,ApplianceHandler.OUTPUT);
}
private void initInput(String consumer$) {
	initPinout(consumer$,ApplianceHandler.INPUT);
}
private void initPinout(String operator$,String select$){
	//System.out.println("JApplianceEditor:initPinout:operator="+ operator$);
	try {
	DefaultComboBoxModel<String> model= new DefaultComboBoxModel<String> ();
	Properties operatorLocator=new Properties();
	operatorLocator.put(Entigrator.ENTITY_LABEL, operator$);
	operatorLocator.put(ApplianceHandler.SELECT, select$);
	String operatorLocator$=Locator.toString(operatorLocator);
	String[] sa=applianceHandler.listPinout(entigrator, operatorLocator$);
	if(sa!=null) {
		model= new DefaultComboBoxModel<String>(sa);
	}
	if(ApplianceHandler.OUTPUT.equals(select$))
	    cbxOutput.setModel(model);
	if(ApplianceHandler.INPUT.equals(select$))
	    cbxInput.setModel(model);
	}catch(Exception ee){
		 Logger.getLogger(getClass().getName()).severe(ee.toString());
	}
	}
	private void initConnectionButtons(){
//		System.out.println("JApplianceEditor:initConnectioButtons:BEGIN");
	try {
		String consumer$=(String)cbxConsumer.getSelectedItem();
	  	 String input$=(String)cbxInput.getSelectedItem();
	  	 String source$=(String)cbxSource.getSelectedItem();
	  	 String output$=(String)cbxOutput.getSelectedItem();
	   Connection connection=new Connection(entity,source$,output$,consumer$, input$);
	//   System.out.println("JApplianceEditor:initConnectioButtons:inserted="+connection.alreadyInserted(entity)+" correct="+connection.isCorrect());
	   if(connection.isCorrect()&&
			  ! connection.alreadyInserted(entity)) {
		   btnAddConnection.setEnabled(true);
		   if(consumer$.equals(source$))
		   	 btnAddConnection.setEnabled(false);
	   }
	   else
		   btnAddConnection.setEnabled(false);
	}catch(Exception e) {
		System.out.println("JApplianceEditor:initConnectioButtons:"+e.toString());
	}
	}
	protected void replaceTable(	Connection[] cona ){
		try{
			if(cona==null) {
				System.out.println("JApplianceEditor:replaceTable:no connections");
				return;
			}
			DefaultTableModel model=(DefaultTableModel) tblConnect.getModel();
			while(model.getRowCount()>0)
				model.removeRow(0);
			for(Connection c:cona){
				model.addRow(new String[]{c.source$,c.output$,c.consumer$,c.input$});
			}
			 tblConnect.setModel(model);
		}catch(Exception e){
			LOGGER.severe(e.toString());
		}
	}
	protected void replaceTable(){
	//	System.out.println("JApplianceEditor:replaceTable:BEGIN");
		try{
			DefaultTableModel model=(DefaultTableModel) tblConnect.getModel();
			while(model.getRowCount()>0)
				model.removeRow(0);
		Connection[]     cona=Connection.getConnections(entigrator,entity);
		if(cona==null) {
			System.out.println("JApplianceEditor:replaceTable:no connections");
			return;
		}
		//System.out.println("JApplianceEditor:replaceTable:cona="+cona.length);		
			for(Connection c:cona){
				model.addRow(new String[]{c.source$,c.output$,c.consumer$,c.input$});
			//	System.out.println("JApplianceEditor:replaceTable:   "+c.source$+"  "+c.output$+" "+c.consumer$+"  "+c.input$);		
			}
			 tblConnect.setModel(model);
			 tblConnect.repaint();
		}catch(Exception e){
			LOGGER.severe(e.toString());
		}
	}
	private void removeComponent(String compName$){

		System.out.println("JApplianceEditor:removeComponent:compName="+compName$);
		try{
			String compKey$=entity.getElementItemAtValue("component", compName$);
		//	System.out.println("JApplianceEditor:removeComponent:compKey="+compKey$);
			if(compKey$==null) {
				System.out.println("JApplianceEditor:removeComponent:cannot find key for component="+compName$);
				return;
			}
				entity.removeElementItem("component",compKey$);
				entigrator.putEntity(entity);
				Core[] soa=entity.elementGet("source");
			ArrayList<String >sl=new ArrayList<String>();
			if(soa!=null)
				for(Core c:soa)
					if(compName$.equals(c.type))
						sl.add(c.name);

			if(sl.size()>0)
				for(String s:sl)
					entity.removeElementItem("source",s);
			entigrator.putEntity(entity);
			//remove consumer  junctions
			Core[] coa=entity.elementGet("consumer");
			ArrayList<String >nl=new ArrayList<String>();
			if(coa!=null)
				for(Core c:coa)
					if(compName$.equals(c.type))
						nl.add(c.name);

			if(nl.size()>0)
				for(String s:nl)
					entity.removeElementItem("consumer",s);
			entigrator.putEntity(entity);
			//remove connections
			Core[] ta=entity.elementGet("connection");
			if(ta!=null){
				ArrayList<String >tl=new ArrayList<String>();
				for(Core t:ta){
				    for(String s:sl)
				         if(t.type.equals(s))
				        	 tl.add(t.name);
				    for(String s:nl)
				         if(t.value.equals(s))
				        	 tl.add(t.name);
				}
				for(String t:tl)
					entity.removeElementItem("connection",t);
			}
			updateComponents();
			//remove link
			Sack component=entigrator.getEntity(compKey$);
			if(component!=null) {
				System.out.println("JApplianceEditor:remove component "+compName$); 
				entigrator.unlink(entity, component);
			}
		}catch(Exception e){
			LOGGER.severe(e.toString());
		}
	}
private void rebuildInstruments(){
	try {
	timer.setValue(0);
	dashboard.removeAll();
    dashboard.add(timer);
    String [] ca=entity.elementListNames("component");
    if(ca!=null) {
    	//System.out.println("JApplianceEditor: rebuild components:ca="+ca.length);
		Sack component;
		for(String c:ca) {
		   	component=entigrator.getEntity(c);
		   	System.out.println("JApplianceEditor: rebuild components:c="+c);
		   	if(component!=null) {
		   		if("tube".equals(component.getProperty("entity"))) {
		   			try {
		   			String tubeLocator$=TubeHandler.classLocator();
		   			tubeLocator$=Locator.append(tubeLocator$,Entigrator.ENTITY_KEY, c);
		   			tubePanel.associate(entigrator, tubeLocator$);
		   			}catch(Exception e) {
		   				System.out.println("JApplianceEditor: rebuild components:cannot instantiate tube="+c); 
		   			}
		   		}
		   		if("gauge".equals(component.getProperty("entity"))) {
		   			try {
		   			String gaugeLocator$=GaugeHandler.classLocator();
		   			gaugeLocator$=Locator.append(gaugeLocator$,Entigrator.ENTITY_KEY, c);
		   			Meter gauge=new Meter(entigrator,gaugeLocator$);
		   			gauge.associate(entigrator, gaugeLocator$);
		   			dashboard.add(gauge);
		   			}catch(Exception e) {
		   				System.out.println("JApplianceEditor: rebuild components:cannot instantiate gauge="+c); 
		   			}
		   			//break;
		   		}
		   	}else {
		   	 	System.out.println("JApplianceEditor: rebuild components:cannot get component at key="+c);
		   	}
		}
    }
	}catch(Exception ee) {
		System.out.println("JApplianceEditor: rebuild components:"+ee.toString());
	}
    }

private void resetInstruments(){
	tubePanel.reset();
	timer.reset(console.getEntigrator());
	try {
		int cnt=dashboard.getComponentCount();
		Component component;
		if(cnt>1)
			for(int i=1;i<cnt;i++) {
				component=dashboard.getComponent(i);
				if(component instanceof Instrument) {
					((Instrument)component).reset(console.getEntigrator());
					((Instrument)component).revise(console.getEntigrator());
				}
			}
		}catch(Exception e) {
			System.out.println("JApplianceEditor:resetInstruments:"+e.toString());
		}
}
private void reviseInstruments(int index){
	System.out.println("JApplianceEditor:reviseInstruments:index="+index+ " steps="+steps);
	if(index>steps-1)
		return;
	try {	
		tubePanel.revise(console.getEntigrator(),index);
	}catch(Exception e) {
		System.out.println("JApplianceEditor:refviseInstruments:tube:"+e.toString());
	}
	try {
	int cnt=dashboard.getComponentCount();
	//System.out.println("JApplianceEditor:refviseInstruments:component count="+cnt);
	Component component;
	if(cnt>1)
		for(int i=0;i<cnt;i++) {
			component=dashboard.getComponent(i);
		//	System.out.println("JApplianceEditor:refviseInstruments:component="+component.getClass().getName());
			if(component instanceof Instrument)
				((Instrument)component).revise(console.getEntigrator(),index);
		}
	}catch(Exception e) {
		System.out.println("JApplianceEditor:refviseInstruments:"+e.toString());
	}
}
private void reviseInstruments(){
	//System.out.println("JApplianceEditor:reviseInstruments: steps="+steps);
	try {	
		tubePanel.revise(console.getEntigrator());
	}catch(Exception e) {
		System.out.println("JApplianceEditor:refviseInstruments:tube:"+e.toString());
	}
	try {
	int cnt=dashboard.getComponentCount();
	//System.out.println("JApplianceEditor:refviseInstruments:component count="+cnt);
	Component component;
	if(cnt>1)
		for(int i=0;i<cnt;i++) {
			component=dashboard.getComponent(i);
		//	System.out.println("JApplianceEditor:refviseInstruments:component="+component.getClass().getName());
			if(component instanceof Instrument)
				((Instrument)component).revise(console.getEntigrator());
		}
	}catch(Exception e) {
		System.out.println("JApplianceEditor:refviseInstruments:"+e.toString());
	}
	
}
private void reviseInstruments(int index,double takt){
//	System.out.println("JApplianceEditor:reviseInstruments:index="+index);
	Sack tube=tubePanel.getTube();
	try {	
	if(index<0) {
	//System.out.println("JApplianceEditor:refviseInstruments:1");
		tubePanel.revise(console.getEntigrator());
	}
	else {
		//System.out.println("JApplianceEditor:refviseInstruments:2");
		tubePanel.revise(console.getEntigrator(),index);
	}
	}catch(Exception e) {
		System.out.println("JApplianceEditor:refviseInstruments:tube:"+e.toString());
	}
	try {
	int cnt=dashboard.getComponentCount();
	//System.out.println("JApplianceEditor:refviseInstruments:component count="+cnt);
	Component component;
	if(cnt>1)
		for(int i=0;i<cnt;i++) {
			component=dashboard.getComponent(i);
		//	System.out.println("JApplianceEditor:refviseInstruments:component="+component.getClass().getName());
			if(component instanceof Instrument)
				if(index<0)
				   ((Instrument)component).revise(console.getEntigrator());
				else
					((Instrument)component).revise(console.getEntigrator(),index);
		}
	}catch(Exception e) {
		System.out.println("JApplianceEditor:refviseInstruments:"+e.toString());
	}
	
}

private void reset(){
	steps=0;
	String stop$=entity.getElementItemAt("tuner","stop");
	String start$=entity.getElementItemAt("tuner",Instrument.START_VIEW);
    updateComponents();
    rebuildInstruments();
	tubePanel.reset();
	applianceHandler.reset(entigrator, null);
	resetInstruments();
	txtStart.setText("Start="+start$);
	txtStop.setText("Stop="+stop$);
	txtTime.setText("Time=0");
	rayValues.setText(null);
	repaint();
}
class PlayThread extends Thread{
	public void run(){
		try {
//			System.out.println("JApplianceEditor:play thread BEGIN");
			if(entity==null) {
				System.out.println("JApplianceEditor:play:appliance is null");
			return;
			}
			Sack tube=tubePanel.getTube();
			if(tube==null) {
				System.out.println("JApplianceEditor:play:tube is null");
			return;
			}
			String stop$=entity.getElementItemAt("tuner", "stop");
			timer.setFormat(txtTimeFormat.getText());
			String takt$=entity.getElementItemAt(OperatorHandler.OPERATOR,Instrument.TAKT);
			double takt=1;
			try { takt=Double.parseDouble(takt$);}catch(Exception ee) {}
			String time$=entity.getElementItemAt(OperatorHandler.OPERATOR, Instrument.TIME);
			String format$=entity.getElementItemAt("tuner", "format");
			if(format$==null)
				format$="0.####E0";
			NumberFormat timeFormat = new DecimalFormat(format$);
			if(time$==null) {
				time$="0";
				entity.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TIME,"0"));
			}
			if(JApplianceEditor.this.restart) {
				JApplianceEditor.this.stop=true;
				time$="0";
			}
			double time=Double.MIN_VALUE;
			try { time=Double.parseDouble(time$);}catch(Exception ee) {}
			double stop=0;
			try { stop=	Double.parseDouble(stop$);}catch(Exception ee) {}
		//	System.out.println("JApplianceEditor:play:preloop:takt="+takt+"  start="+start+" time="+time+"  stop="+stop);
			JApplianceEditor.this.start.setEnabled(false);
			JApplianceEditor.this.pause.setEnabled(true);
			JApplianceEditor.this.reset.setEnabled(true);
			JApplianceEditor.this.store.setEnabled(false);
			JApplianceEditor.this.slider.setEnabled(false);
  		  //before loop
			//System.out.println("JApplianceEditor:play:restart="+restart);
			if(JApplianceEditor.this.restart) {
				//System.out.println("JApplianceEditor:play restart:before loop");
				timer.setValue(0);
				steps=0;
				applianceHandler.reset(entigrator, null);
				entity.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TIME,"0"));
				//reset();
				revalidate();
				repaint();
				JApplianceEditor.this.restart=false;
				JApplianceEditor.this.start.setEnabled(true);
				JApplianceEditor.this.pause.setEnabled(false);
				JApplianceEditor.this.reset.setEnabled(false);
				JApplianceEditor.this.store.setEnabled(false);
				JApplianceEditor.this.slider.setEnabled(false);
				resetInstruments();
				return;
			}
			//System.out.println("JApplianceEditor:play:begin loop");
			//console.getEntigrator().stopRefresh();
			while(time<stop) {
  		    	//System.out.println("JApplianceEditor:play loop:time=="+time+" stop="+stop);
  		    	if(JApplianceEditor.this.stop) 
					break;  
  		    	applianceHandler.step(console.getEntigrator(), locator$);
  		    	time=0;
  		        time$=entity.getElementItemAt(OperatorHandler.OPERATOR, Instrument.TIME);
  		        try {time=Double.parseDouble(time$);}catch(Exception ee) {}
  		      //System.out.println("JApplianceEditor:play:loop::time="+time+"  steps="+steps);
  		    	double vtime=0;
  		        String vtime$=entity.getElementItemAt(OperatorHandler.OPERATOR, Instrument.VIEW_TIME);
  		        try {vtime=Double.parseDouble(vtime$);}catch(Exception ee) {}
  		      txtTime.setText("Time="+timeFormat.format(time));
  		        if(vtime<Double.MIN_VALUE) {
  		    		continue;
  		    	}
				timer.setValue(vtime);	 
				int cnt=0;
				if(steps>0)
					 cnt=steps-1;
				reviseInstruments();
				String[] sa=tubePanel.rayNameValues(cnt);
				StringBuffer sb=new StringBuffer();
					for(String s:sa)
						sb.append(s+"  ");
				rayValues.setText(sb.toString());
				steps++;
				}
			// view
			JApplianceEditor.this.pause.setEnabled(false);
			JApplianceEditor.this.start.setEnabled(false);
			JApplianceEditor.this.reset.setEnabled(true);
			JApplianceEditor.this.store.setEnabled(true);
			JApplianceEditor.this.slider.setEnabled(true);
			//System.out.println("JApplianceEditor:play:cnt="+cnt);
			JApplianceEditor.this.stop=false;
			if(JApplianceEditor.this.restart) {
				//System.out.println("JApplianceEditor:play restart");
				timer.setValue(0);
				txtTime.setText("Time=0");
				entity.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TIME,"0"));
				reset();
				revalidate();
				repaint();
				JApplianceEditor.this.restart=false;
				JApplianceEditor.this.pause.setEnabled(false);
				JApplianceEditor.this.start.setEnabled(true);
				JApplianceEditor.this.reset.setEnabled(false);
				JApplianceEditor.this.store.setEnabled(false);
				JApplianceEditor.this.slider.setEnabled(false);
			}else {
				//pause
			//	System.out.println("JApplianceEditor:play: pause");
				JApplianceEditor.this.stop=false;
				JApplianceEditor.this.pause.setEnabled(false);
				JApplianceEditor.this.start.setEnabled(true);
				JApplianceEditor.this.reset.setEnabled(true);
				JApplianceEditor.this.store.setEnabled(true);
				JApplianceEditor.this.slider.setEnabled(true);
			}
			if(tubePanel!=null)
				 tubePanel.drawDiaLast();
			//console.getEntigrator().startRefresh();
		    //System.out.println("JApplianceEditor:play:2:"); 
		}catch(Exception e) {
			System.out.println("JApplianceEditor:play: "+e.toString()); 
			//console.getEntigrator().startRefresh();
		}
	}
}
private void addComponent(){
	 String label$=(String) cbxComponent.getSelectedItem();
	// System.out.println("JApplianceEditor: addComponent:label="+ label$);
	 if(label$!=null){
		 String key$=entigrator.getKey(label$);
		// System.out.println("JApplianceEditor: addComponent:check key="+ key$);
		 if(key$==null) {
			 System.out.println("JApplianceEditor: addComponent:no key for label="+label$);
			 return;
		 }
		 try{
			 if(entity.getElementItem("component", key$)!=null) {
				 System.out.println("JApplianceEditor: addComponent:already added component label="+label$); 
				 return;
			 }
			 entity.putElementItem("component", new Core("null",key$,label$));
			 Sack component=entigrator.getEntity(key$);
			 if(component==null) {
				 System.out.println("JApplianceEditor: addComponent:cannot get component label="+label$); 
				 return;
			 }
			 //sources
			 String[] oa=component.listItemsAtType("operator","out");
			 if(oa!=null&&oa.length>0){
				 if(!entity.existsElement("source"))
					 entity.createElement("source");
				 for(String o:oa)
					 entity.putElementItem("source",new Core(component.getProperty("label"),Identity.key(),o));
			 }
          //consumers
					 String[] ia=component.listItemsAtType("operator","in");
			 if(ia!=null&&ia.length>0){
				 if(!entity.existsElement("consumer"))
					 entity.createElement("consumer");
				 for(String i:ia)
					 entity.putElementItem("consumer",new Core(component.getProperty("label"),Identity.key(),i));
			   }
			
		  entigrator.putEntity(entity);
		  rebuildInstruments();
		  updateComponents();
	 }catch(Exception e){
		 System.out.println("JApplianceEditor: addComponent:"+ e.toString());
	 		}
	}
}
private void initTuner(){
	try{
		if(entity==null) {
		System.out.println("JApplianceEditor: initTuner:entity is null");
		return;
		}
		String takt$=entity.getElementItemAt("tuner",Instrument.TAKT);
		String qfactor$=entity.getElementItemAt("tuner","qfactor");
		String stop$=entity.getElementItemAt("tuner","stop");
		String start$=entity.getElementItemAt("tuner",Instrument.START_VIEW);
		String format$=entity.getElementItemAt("tuner","format");
		if(takt$==null)
			takt$="0.0";
		if(qfactor$==null)
			qfactor$="1";
		if(stop$==null)
			stop$="1.0";
		if(start$==null)
			stop$="0";
		txtTakt.setText(takt$);
	//	txtQfactor.setText(qfactor$);
		txtStopTime.setText(stop$);
		txtStartView.setText(start$);
		txtStart.setText("Start="+start$);
		txtStop.setText("Stop="+stop$);
		txtTimeFormat.setText(format$);
	}catch(Exception e){
		 System.out.println("JApplianceEditor: initTuner:"+ e.toString());
	}
}
private void saveTuner(){
	try{
		String takt$=txtTakt.getText();
		String stop$=txtStopTime.getText();
		String start$=txtStartView.getText();
		try{
			Double.parseDouble(takt$);
			entity.putElementItem("tuner", new Core("tuner",Instrument.TAKT,takt$));
		}catch(NumberFormatException e ) {
			JOptionPane.showMessageDialog(this, "Takt must be double");
		}
		try{
			Double.parseDouble(stop$);
			entity.putElementItem("tuner", new Core("tuner","stop",stop$));
		}catch(NumberFormatException e ) {
			JOptionPane.showMessageDialog(this, "Stop must be double");
		}
		try{
			Double.parseDouble(start$);
			entity.putElementItem("tuner", new Core("tuner",Instrument.START_VIEW,start$));
		}catch(NumberFormatException e ) {
			JOptionPane.showMessageDialog(this, "Start viewm must be double");
		}
		entity.putElementItem("tuner", new Core("tuner","format",txtTimeFormat.getText()));
		entigrator.putEntity(entity);
	}catch(Exception e){
		 System.out.println("JApplianceEditor: iniTuner:"+ e.toString());
	}
}
private void store(){
	try{
	String recordLocator$=RecordHandler.classLocator();
	Calendar cal = Calendar.getInstance();
    cal.setTime(Date.from(Instant.now()));
    String record$ = String.format(
             "%1$tY-%1$tm-%1$td-%1$tk-%1$tS-%1$tp", cal);
    RecordMaster recordMaster=new RecordMaster(console,null);
    Sack record=recordMaster.createEntity(console.getEntigrator(), record$);
    record=entigrator.assignProperty("record", "true",record.getKey());
    String recordLabel$=record.getProperty("label");
    recordLocator$=Locator.append(recordLocator$, Entigrator.ENTITY_LABEL, recordLabel$);
    String takt$=entity.getElementItemAt("tuner",Instrument.TAKT);
	recordLocator$=Locator.append(recordLocator$, Instrument.TAKT, takt$);
	String stop$=entity.getElementItemAt("tuner",Instrument.STOP);
	recordLocator$=Locator.append(recordLocator$, Instrument.STOP, stop$);
	String start$=entity.getElementItemAt("tuner",Instrument.START_VIEW);
	recordLocator$=Locator.append(recordLocator$, Instrument.START_VIEW, start$);
	//System.out.println("JApplianceEditor: store:record locator="+recordLocator$);
	tubePanel.save(entigrator, recordLocator$);	
	record.createElement("record");
	String format$=entity.getElementItemAt("tuner", "format");
	record.putElementItem("record", new Core(null,"format",format$));
	record.putElementItem("record", new Core(null,"takt",takt$));
	record.putElementItem("record", new Core(null,"steps",String.valueOf(steps)));
	record.putElementItem("record", new Core(null,"all steps",String.valueOf(applianceHandler.getSteps())));
	entigrator.putEntity(record);
	Component[] ca=dashboard.getComponents();
	for(Component c:ca) {
		if(c instanceof Meter) {
			if( c.equals(timer)) {
				String timerLocator$=Locator.append(recordLocator$,Meter.SAVE_MODE, Meter.ONLY_VALUES);
				timer.save(entigrator,timerLocator$);
			}else {
				((Meter)c).save(entigrator, recordLocator$);
			}
		}
	}
	}catch (Exception e) {
	 System.out.println("JApplianceEditor: store:"+ e.toString());	
}
}
 Sack getGraph(){
	 if(entity==null) {
		 System.out.println("JApplianceEditor:getGraph:entity is null");
		 return null;
	}
	String[] sa=entity.elementListNames("component");
	if(sa==null) {
		 System.out.println("JApplianceEditor:getGraph:no components in entity="+entity.getProperty("label"));
		 return null;
	}
	Sack graph=null;
	for(String s:sa){
		graph=entigrator.getEntity(s);
		if(graph==null)
			continue;
		if("graph".equals(graph.getProperty("entity"))){
			return graph;
		}
	}
	return null;
}
Sack getComponent(String component$) {
	if(entity==null) {
	   System.out.println("JApplianceEditor:getComponent:entity is null");
	   return null;
   }
   if(component$==null) {
	   System.out.println("JApplianceEditor:getComponent:argument is null");
	   return null;
   }
	String[] sa=entity.elementListNames("component");
    if(sa==null) {
    	System.out.println("JApplianceEditor:getComponent:no components in entity="+entity.getProperty("label"));
 	   return null;
    }
	Sack candidate=null;
	for(String s:sa){
		//System.out.println("JApplianceEditor:getComponent:s="+s);
		candidate=entigrator.getEntity(s);
		if(candidate==null) {
			//System.out.println("JApplianceEditor:getComponent:cannot find sack "+s); 	
			continue;
		}
		if(component$.equals(candidate.getProperty("entity"))){
			//System.out.println("JApplianceEditor:getComponent:return component="+candidate.getProperty("label"));
			return candidate;
		}
	}
	//System.out.println("JApplianceEditor:getComponent:component null");
	return null;
}
 Sack[] getGauges(){
	 //System.out.println("JApplianceEditor:getGauges:BEGIN");	
	   String[] sa=entity.elementListNames("component");
		ArrayList<Sack> gl=new ArrayList<Sack>();
		Sack candidate=null;
		for(String s:sa){
			 //System.out.println("JApplianceEditor:getGauges:s="+s);	
			 candidate=entigrator.getEntity(s);
			 if(candidate==null)
					continue;
			//System.out.println("JApplianceEditor:getGauges:try candidate="+candidate.getProperty("label"));	
			if("gauge".equals(candidate.getProperty("entity"))){
				try {
				setGaugeValueName(candidate );
				//System.out.println("JApplianceEditor:getGauges:next gauge");	
				gl.add(candidate);
				}catch(Exception e) {
					System.out.println("JApplianceEditor:getGauges:gauge="+candidate.getProperty("label")+" err="+e.toString());	
				}
			}
			//System.out.println("JApplianceEditor:getGauges:next component");	
		}
		Sack[] ga=new Sack[gl.size()];
	//	 System.out.println("JApplianceEditor:getGauges:"+ga.length);
		return gl.toArray(ga);
	}
 void  setGaugeValueName(Sack gauge ){
	 // get consumer key
	 String gauge$=gauge.getProperty("label");
	 Core[] ca=entity.elementGet("consumer");
	 String consumer$=null;
	 for( Core c:ca){
		 if(gauge$.equals(c.type)&&"in".equals(c.value)){
			 consumer$=c.name;
			 break;
		 }
	 }
	 String source$=null;
	 ca=entity.elementGet("connection");
	 for( Core c:ca){
		 if(consumer$.equals(c.value)){
			 source$=c.type;
			 break;
		 }
	 }
	 String name$=entity.getElementItemAt("source", source$);
	 gauge.putElementItem("operator",new  Core("parameter","name",name$));
	 entigrator.putEntity(gauge);
 }
 @Override
 public JMenu getContextMenu() {
	menu=super.getContextMenu();
 	menu.addSeparator();
 					JMenuItem diaItem = new JMenuItem("Diagramm");
 					diaItem.addActionListener(new ActionListener() {
 						@Override
 						public void actionPerformed(ActionEvent e) {
 							if(dialog==null)
 							   dialog=new JDiagrammDialog();
 							try {
 							   DiagrammPanel diaPanel=tubePanel.getDiagramm();
 							 // System.out.println("JApplianceEditor:diagramm:"+diaPanel.toString());
 							if(diaPanel!=null) {
 							  dialog.addDiagrammPanel(diaPanel);
 							  dialog.setSize(new Dimension(200,200));
 							  dialog.setLocationRelativeTo(listComponents);
 							  dialog.setVisible(true);
 							}
 							}catch(Exception ee) {
 								System.out.println("JApplianceEditor:diagramm:"+ee.toString());
 							}
 						}
 					} );
 					menu.add(diaItem);
 				JMenu lookMenu=new JMenu("Look");
		JMenuItem bwItem = new JMenuItem("Black/white");
		bwItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  try{
				  tubePanel.setBwLook(true); 
				tubePanel.repaint();
			  }catch(Exception ee){
				  Logger.getLogger(getClass().getName()).severe(ee.toString());
			  }
			}
		} );
		lookMenu.add(bwItem);
		JMenuItem colorItem = new JMenuItem("Color");
		colorItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  try{
			  tubePanel.setBwLook(false); 
			  tubePanel.repaint();
			  }catch(Exception ee){
				  Logger.getLogger(getClass().getName()).severe(ee.toString());
			  }
			}
		} );
		lookMenu.add(colorItem);
		menu.add(lookMenu);
 		 return menu;
 	 }
@Override
public String getClassLocator() {
	return classLocator();
}
private void handleSlider(int pos) {
	         tubePanel.drawScreenMarker(pos);
	         if(steps<1)
	    		return;
	    	int x=tubePanel.getWidth()*pos/100;
			int xTime=tubePanel.getXtime();
	    	double factor=x/(xTime+Double.MIN_VALUE);
			int cnt= (int)(factor*steps);
			int n=dashboard.getComponentCount();
			for(int i=0;i<n;i++) {
			     ((Meter)dashboard.getComponent(i)).showValue(cnt);
			}
			String[] sa=tubePanel.rayNameValues(cnt);
			String takt$=entity.getElementItemAt("operator", "takt");
			double takt=Double.parseDouble(takt$);
			double time=cnt*takt;
			int allSteps=applianceHandler.getSteps();
			double gtime=(allSteps-steps+cnt)*takt;
			//System.out.println("JApplianceEditor:slider pos="+pos+"  x="+x+"  cnt="+cnt+" xTime="+xTime+" takt="+takt$+" vtime="+time+" gtime="+gtime);
			String format$=entity.getElementItemAt("tuner", "format");
			if(format$==null)
				format$="0.####E0";
			NumberFormat timeFormat = new DecimalFormat(format$);
		    txtTime.setText("Time="+timeFormat.format(gtime));
		    StringBuffer sb=new StringBuffer();
			for(String s:sa)
				sb.append(s+"  ");
			rayValues.setText(sb.toString());
			tubePanel.repaint();
			tubePanel.revise(entigrator, cnt);
		    double maxTime=(steps)*takt;
		    //System.out.println("JRecordViwer:handle slider :cnt="+cnt+"  time="+time+" max time="+maxTime);
		    timer.setFormat(format$);
		    timer.setValueMaximum(maxTime);
		    timer.setValue(time);
		}
class ResizeListener extends ComponentAdapter {
    public void componentResized(ComponentEvent e) {
    	if(steps<1)
    		return;
    	int pos = (int)slider.getValue();
		handleSlider(pos);
    }
}
/*
@Override
public boolean handleDone() {
//	String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
	JDisplay display=getDisplay();
	String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	String facetList$=JEntityFacetList.classLocator();
	facetList$=Locator.append(facetList$, Entigrator.ENTITY_LABEL, entity$);
	JEntityFacetList facetList=new JEntityFacetList(console,facetList$);
	if(display==null)
    	replace(console, facetList);
    else
    	display.putContext(facetList);
	return true;
}
*/
@Override
public String reply(JMainConsole console, String locator$) {
	return null;
}
}
