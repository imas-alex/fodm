package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.gauge;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;

import javax.swing.UIManager;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube.JTubeEditor;
import javax.swing.JButton;
public class JGaugeEditor   extends  JGuiEditor {
	private static final long serialVersionUID = 1L;
	public static final String ACTION_NEW_ENTITY="action new entity";
	public static final String ACTION_DISPLAY_ENTITY="action display entity";
	public static final String LEFT=  "Left                 ";
	public static final String MIDDLE="Middle               ";
	public static final String LEFT_NULL="left";
	public static final String MIDDLE_NULL="middle";
	public static final String GAUGE_FACET_TYPE="gauge";
	public static final String GAUGE_FACET_NAME="Gauge";
	public static final String GAUGE_MASTER_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.JGaugeMaster";
	public static final String KEY="_qZ_SyoKP2g5wLzDFkEMTu9x5F9RA";
	protected Logger LOGGER=Logger.getLogger(JTubeEditor.class.getName());
	protected String entihome$;
	protected String entityKey$;
	protected String entityLabel$;
	protected String requesterAction$;
	protected Entigrator entigrator;
	protected Sack entity;
	private JTextField txtTitle;
	private JTextField txtVar;
	private JTextField txtUnit;
	private JTextField txtFormat;
	private JTextField txtMax;
	private JComboBox <String>cbxNull;
	private JTextArea textArea;
	private JButton btnSave;
	String entity$; 
	public JGaugeEditor(JMainConsole console,String alocator$) {
		super(console,alocator$);
		instance$=getInstance();
		parent$=Locator.getProperty(alocator$, PARENT);
		if(parent$!=null)
		locator$=Locator.append(locator$, PARENT, parent$);
		String entityLabel$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
		if(entityLabel$!=null&&entity$==null) 
			entity$=entityLabel$;
		locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity$);
		//	System.out.println("GaugeEditor:constructor:locator="+locator$);
			GridBagLayout gridBagLayout = new GridBagLayout();
			gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0,0.0,0.0,1.0};
			gridBagLayout.columnWeights = new double[]{Double.MIN_VALUE, 1.0};
			setLayout(gridBagLayout);
			
			JLabel tLabel = new JLabel("Title");
			GridBagConstraints gbc_lblTitle = new GridBagConstraints();
			gbc_lblTitle.insets = new Insets(5, 5, 5, 5);
			gbc_lblTitle.gridx = 0;
			gbc_lblTitle.gridy = 0;
			gbc_lblTitle.anchor=GridBagConstraints.LINE_START;
			add(tLabel, gbc_lblTitle);
			
			txtTitle = new JTextField();
			txtTitle.setColumns(12);
			GridBagConstraints gbc_txtTitle = new GridBagConstraints();
			gbc_txtTitle.insets = new Insets(5, 0, 5, 0);
			gbc_txtTitle.gridx = 1;
			gbc_txtTitle.anchor=GridBagConstraints.LINE_START;
			gbc_txtTitle.gridy = 0;
			add(txtTitle, gbc_txtTitle);

			JLabel varLabel = new JLabel("Variable");
			GridBagConstraints gbc_lblVar = new GridBagConstraints();
			gbc_lblVar.insets = new Insets(5, 5, 5, 5);
			gbc_lblVar.gridx = 0;
			gbc_lblVar.gridy = 1;
			gbc_lblVar.anchor=GridBagConstraints.LINE_START;
			add(varLabel, gbc_lblVar);
			
			txtVar = new JTextField();
			txtVar.setColumns(12);
			GridBagConstraints gbc_txtVar = new GridBagConstraints();
			gbc_txtVar.insets = new Insets(5, 0, 5, 0);
			gbc_txtVar.gridx = 1;
			gbc_txtVar.anchor=GridBagConstraints.LINE_START;
			gbc_txtVar.gridy = 1;
			add(txtVar, gbc_txtVar);
			
			JLabel lblUnit = new JLabel("Unit");
			GridBagConstraints gbc_lblUnit = new GridBagConstraints();
			gbc_lblUnit.insets = new Insets(5, 5, 5, 5);
			gbc_lblUnit.gridx = 0;
			gbc_lblUnit.gridy = 2;
			gbc_lblUnit.anchor=GridBagConstraints.LINE_START;
			add(lblUnit, gbc_lblUnit);
			
			txtUnit = new JTextField();
			txtUnit.setColumns(12);
			GridBagConstraints gbc_txtUnit = new GridBagConstraints();
			gbc_txtUnit.insets = new Insets(5, 0, 5, 0);
			gbc_txtUnit.gridx = 1;
			gbc_txtUnit.anchor=GridBagConstraints.LINE_START;
			gbc_txtUnit.gridy = 2;
			add(txtUnit, gbc_txtUnit);
			
			JLabel lblFormat = new JLabel("Format");
			GridBagConstraints gbc_lblFormat = new GridBagConstraints();
			gbc_lblFormat.insets = new Insets(5, 5, 5, 5);
			gbc_lblFormat.gridx = 0;
			gbc_lblFormat.gridy = 3;
			gbc_lblFormat.anchor=GridBagConstraints.LINE_START;
			add(lblFormat, gbc_lblFormat);
			
			txtFormat = new JTextField();
			txtFormat.setColumns(12);
			GridBagConstraints gbc_txtFormat = new GridBagConstraints();
			gbc_txtFormat.insets = new Insets(5, 0, 5, 0);
			gbc_txtFormat.gridx = 1;
			gbc_txtFormat.anchor=GridBagConstraints.LINE_START;
			gbc_txtFormat.gridy = 3;
			add(txtFormat, gbc_txtFormat);
			
			JLabel lblMax = new JLabel("Maximum");
			GridBagConstraints gbc_lblMax = new GridBagConstraints();
			gbc_lblMax.insets = new Insets(5

, 5, 5, 5);
			gbc_lblMax.gridx = 0;
			gbc_lblMax.gridy = 4;
			gbc_lblMax.anchor=GridBagConstraints.LINE_START;
			add(lblMax, gbc_lblMax);
			
			txtMax = new JTextField();
			txtMax.setColumns(12);
			GridBagConstraints gbc_txtMax = new GridBagConstraints();
			gbc_txtMax.insets = new Insets(0, 0, 5, 0);
			gbc_txtMax.anchor=GridBagConstraints.LINE_START;
			gbc_txtMax.gridx = 1;
			gbc_txtMax.gridy = 4;
			add(txtMax, gbc_txtMax);
					
			JLabel lblNull = new JLabel("Null position");
			GridBagConstraints gbc_lblNull = new GridBagConstraints();
			gbc_lblNull.insets = new Insets(5, 5, 5, 5);
			gbc_lblNull.gridx = 0;
			gbc_lblNull.gridy = 5;
			gbc_lblNull.anchor=GridBagConstraints.LINE_START;
			add(lblNull, gbc_lblNull);
			
			cbxNull = new JComboBox();
			cbxNull.setModel(new DefaultComboBoxModel(new String[] {LEFT,MIDDLE}));
			GridBagConstraints gbc_cbxNull = new GridBagConstraints();
			gbc_cbxNull.insets = new Insets(0, 0, 5, 5);
			gbc_cbxNull.anchor=GridBagConstraints.LINE_START;
			gbc_cbxNull.gridx = 1;
			gbc_cbxNull.gridy = 5;
			add(cbxNull, gbc_cbxNull);

			btnSave = new JButton("Save");
			btnSave.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					save();
				}
			});
			GridBagConstraints gbc_btnSave = new GridBagConstraints();
			gbc_btnSave.insets = new Insets(0, 0, 0, 5);
			gbc_btnSave.gridx = 1;
			gbc_btnSave.gridy = 6;
			gbc_btnSave.anchor=GridBagConstraints.LINE_START;
			add(btnSave, gbc_btnSave);
			
			textArea = new JTextArea();
			textArea.setBackground(UIManager.getColor("Panel.background"));
			textArea.setEnabled(false);
			textArea.setEditable(false);
			GridBagConstraints gbc_textArea = new GridBagConstraints();
			gbc_textArea.insets = new Insets(0, 0, 5, 0);
			gbc_textArea.fill = GridBagConstraints.BOTH;
			gbc_textArea.gridx = 1;
			gbc_textArea.gridy = 7;
			//gbc_textArea.gridwidth=2;
			add(textArea, gbc_textArea);
	       instantiate(console,locator$);
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,GAUGE_FACET_NAME);
		locator.put(FacetHandler.FACET_TYPE,GAUGE_FACET_TYPE);
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.JGaugeMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.gauge.JGaugeEditor");
		return Locator.toString(locator);
	}
	public void instantiate(JMainConsole console, String locator$) {
		this.console=console;
		try{
		Properties locator=Locator.toProperties(locator$);
		entigrator=console.getEntigrator();
		entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		entity=entigrator.getEntityAtLabel(entityLabel$);
		String title$=entity.getElementItemAt("gauge", "title");
		String var$=entity.getElementItemAt("gauge", "variable");
		String unit$=entity.getElementItemAt("gauge", "unit");
		String nullpos$=entity.getElementItemAt("gauge", "nullpos");
		String maximum$=entity.getElementItemAt("gauge", "maximum");
		String format$=entity.getElementItemAt("gauge", "format");
		txtTitle.setText(title$);
		txtVar.setText(var$);
		txtUnit.setText(unit$);
		txtMax.setText(maximum$);
		txtFormat.setText(format$);
		if(LEFT_NULL.equals(nullpos$))
			cbxNull.setSelectedIndex(0);
		else
			cbxNull.setSelectedIndex(1);
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
	}
	private void save() {
		String title$=txtTitle.getText();
		String var$=txtVar.getText();
		String unit$=txtUnit.getText();
		String maximum$=txtMax.getText();
		String format$=txtFormat.getText();
		int i=cbxNull.getSelectedIndex();
		double max=1;
		try {max=Double.parseDouble(maximum$);}catch(Exception e) {}
		if(!entity.existsElement("gauge"))
			entity.createElement("gauge");
		entity.putElementItem("gauge", new Core(null,"title",title$));
		entity.putElementItem("gauge", new Core(null,"variable",var$));
		entity.putElementItem("gauge", new Core(null,"unit",unit$));
		entity.putElementItem("gauge", new Core(null,"format",format$));
		entity.putElementItem("gauge", new Core(null,"maximum",String.valueOf(maximum$)));
		if(i==0)
			entity.putElementItem("gauge", new Core(null,"nullpos",LEFT_NULL));
		else
			entity.putElementItem("gauge", new Core(null,"nullpos",MIDDLE_NULL));
		entigrator.putEntity(entity);
	}
	
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	/*
	@Override
	public boolean handleDone() {
				String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
		JDisplay display=getDisplay();
	
		if(parentLocator$==null) {
			System.out.println("JGaugeEditor:handleDone:parent is null:locator="+locator$);
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String facetList$=JEntityFacetList.classLocator();
			facetList$=Locator.append(facetList$, Entigrator.ENTITY_LABEL, entity$);
			JEntityFacetList facetList=new JEntityFacetList(console,facetList$);
			  if(display==null)
			    	replace(console, facetList);
			    else
			    	display.putContext(facetList);
			    return true;
			
		}
		JContext.displayInstance(console, parent$,display);
		return true;
		
		
	}
	*/
}
