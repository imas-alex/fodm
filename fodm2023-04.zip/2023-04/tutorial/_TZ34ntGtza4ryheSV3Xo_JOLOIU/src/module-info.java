/**
 * 
 */
/**
 * @author alexander
 *
 */
module _TZ34ntGtza4ryheSV3Xo_JOLOIU {
		exports _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.record;
		exports _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot;
		exports _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
		exports _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet;
		exports _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic;
		exports _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.gauge;
		exports _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.signal;
		exports _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube;
		exports _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.appliance;

		requires JEntispace;
		requires java.desktop;
		requires java.logging;
}