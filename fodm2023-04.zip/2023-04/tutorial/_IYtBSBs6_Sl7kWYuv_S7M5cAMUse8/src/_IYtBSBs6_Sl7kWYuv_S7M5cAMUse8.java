import gdt.base.store.Entigrator;
public class _IYtBSBs6_Sl7kWYuv_S7M5cAMUse8 implements StepHandler{
private final static String ENTITY_KEY="_IYtBSBs6_Sl7kWYuv_S7M5cAMUse8";
public _IYtBSBs6_Sl7kWYuv_S7M5cAMUse8(){} 
public void step(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reset(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reinit(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
}
