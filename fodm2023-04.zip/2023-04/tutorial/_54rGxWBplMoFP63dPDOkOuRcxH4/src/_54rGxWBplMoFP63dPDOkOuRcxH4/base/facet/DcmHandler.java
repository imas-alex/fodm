package _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Hashtable;
import java.util.Properties;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
public class DcmHandler extends FacetHandler implements SegueController{
	public static final String KEY="_srjIMtx5Q9KEFfMe6x33F0kEhOE";
	//rated parameters
	double P = 0;
	double U = 0;
	double N = 0;
	double R = 0;
	double L = 0;
	double J = 0;
	double Eta =0;
	double Ktg =0;
	//secondary parameters
	double I=0;
	double W=0;
	double M=0;
	double Ke=0;
	double Kt=0;
	//calculated parameters
	double A=0;
	double B=0;
	double C=0;
	double D=0;
	double E=0;
	double preferredClock=0;
	double clock=0;
	//vars
	double i=0;
	double w=0;
	double m=0;
	Sack entity;
	public DcmHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		String entity$=Locator.getProperty(alocator$,Entigrator.ENTITY_LABEL);
		entity=entigrator.getEntityAtLabel(entity$);
//		System.out.println("DcmHandler:entity ="+entity$);
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,"Dcm");
		locator.put(FacetHandler.FACET_TYPE,"dcm");
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_HANDLER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DcmHandler");
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.DcmMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
		locator.put( IconLoader.ICON_FILE, "dcm.png");
		locator.put( IconLoader.ICON_CONTAINER,"_54rGxWBplMoFP63dPDOkOuRcxH4");
		return Locator.toString(locator);
	}
	@Override
	public void reset() {
		try {
			P = 0;
			try {P=Double.parseDouble(entity.getElementItemAt("dcm", "P"));}catch(Exception ee) {}
			U = 0;
			try {U=Double.parseDouble(entity.getElementItemAt("dcm", "U"));}catch(Exception ee) {}
			N = 0;
			try {N=Double.parseDouble(entity.getElementItemAt("dcm", "N"));}catch(Exception ee) {}
			R = 0;
			try {R=Double.parseDouble(entity.getElementItemAt("dcm", "R"));}catch(Exception ee) {}
			L = 0;
			try {L=Double.parseDouble(entity.getElementItemAt("dcm", "L"));}catch(Exception ee) {}
			J = 0;
			try {J=Double.parseDouble(entity.getElementItemAt("dcm", "J"));}catch(Exception ee) {}
			Eta = 0;
			try {Eta=Double.parseDouble(entity.getElementItemAt("dcm", "Eta"));}catch(Exception ee) {}
			//Ktg = 0;
			//try {Ktg=Double.parseDouble(entity.getElementItemAt("dcm", "Ktg"));}catch(Exception ee) {}
			I = P/(Eta*U/100);
			entity.putElementItem("dcm", new Core(null,"I",String.valueOf(I)));
			W= 2*Math.PI*N /60;
			entity.putElementItem("dcm", new Core(null,"W",String.valueOf(W)));
			M = P/W;
			entity.putElementItem("dcm", new Core(null,"M",String.valueOf(M)));
			Kt = M/I;
			entity.putElementItem("dcm", new Core(null,"Kt",String.valueOf(Kt)));
			Ke = (U - R*I)/W;
			entity.putElementItem("dcm", new Core(null,"Ke",String.valueOf(Ke)));
			try{A=1/L;}catch(Exception ee) {}
			entity.putElementItem("dcm", new Core(null,"A",String.valueOf(A)));
			try{B=R/L;}catch(Exception ee) {}
			entity.putElementItem("dcm", new Core(null,"B",String.valueOf(B)));
			try{C=Ke/L;}catch(Exception ee) {}
			entity.putElementItem("dcm", new Core(null,"C",String.valueOf(C)));
			try{D=Kt/J;}catch(Exception ee) {}
			entity.putElementItem("dcm", new Core(null,"D",String.valueOf(D)));
			try{E=1/J;}catch(Exception ee) {}
			entity.putElementItem("dcm", new Core(null,"E",String.valueOf(E)));
			
			entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","w","0"));
			entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","i","0"));
			entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","m","0"));
			entity.putElementItem(OperatorHandler.OPERATOR, new Core("in","mc","0"));
			entity.putElementItem(OperatorHandler.OPERATOR, new Core("in","ud","0"));
			entigrator.putEntity(entity);
			preferredClock=1/(1000*B);
			clock=1/(1000*B);
			w=0;
			i=0;
			if(!entity.existsElement("dcm"))
				entity.createElement("dcm");
			entity.putElementItem("dcm", new Core(null,"I",String.valueOf(I)));
			entity.putElementItem("dcm", new Core(null,"W",String.valueOf(W)));
			entity.putElementItem("dcm", new Core(null,"M",String.valueOf(M)));
			entity.putElementItem("dcm", new Core(null,"Ke",String.valueOf(Ke)));
			entity.putElementItem("dcm", new Core(null,"Kt",String.valueOf(Kt)));
			entity.putElementItem("dcm", new Core(null,"A",String.valueOf(A)));
			entity.putElementItem("dcm", new Core(null,"B",String.valueOf(B)));
			entity.putElementItem("dcm", new Core(null,"C",String.valueOf(C)));
			entity.putElementItem("dcm", new Core(null,"D",String.valueOf(D)));
			entity.putElementItem("dcm", new Core(null,"E",String.valueOf(E)));
			entigrator.putEntity(entity);
			entity.printElement("dcm");
		}catch(Exception e) {
			System.out.println("DcmHandler:reset:"+e.toString());
		}
	}
	@Override
	public String[] listOutputs() {
		return new String[] {
				"i",
				"m",
				"w"
				};
	}
	@Override
	public String[] listInputs() {
		return new String[] {
				"ud",
				"mc"
				};
	}
	@Override
	public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
		Hashtable<String, Double> outs=new Hashtable<String, Double>();
		try {
		double clock=ins.get("clock");
		double ud=0;
		try{ud=ins.get("ud");}catch(Exception ee) {}
		double mc=0;
		try{mc=ins.get("mc");}catch(Exception ee) {}
		double di=(A*ud-B*i-C*w)*clock;
		i=i+di;
		m=Kt*i;
		double dw=(D*i-E*mc)*clock;
		w=w+dw;
		outs.put("i", i);
		outs.put("w", w);
		outs.put("m", m);
		return outs;
		}catch(Exception e) {
			System.out.println("DcmHandler:stride:"+e.toString());
			return null;
		}
	}
	@Override
	public Hashtable<String, Double> getSettings() {
		Hashtable<String, Double> outs=new Hashtable<String, Double>();
		outs.put("U", U);
		outs.put("P", P);
		outs.put("N", N);
		outs.put("R", R);
		outs.put("L", L);
		outs.put("J", J);
		outs.put("Eta", Eta);
		outs.put("Ktg", Ktg);
		outs.put("I", I);
		outs.put("W", W);
		outs.put("M", M);
		outs.put("Ke", Ke);
		outs.put("Kt", Kt);
		outs.put("A", A);
		outs.put("B", B);
		outs.put("C", C);
		outs.put("D", D);
		outs.put("E", E);
		outs.put("preferredClock", preferredClock);
		return outs;
	}
	@Override
	public void putSettings(Hashtable<String, Double> settings) {
	}
	@Override
	public Hashtable<String, Double> getOuts() {
		Hashtable<String, Double> outs=new Hashtable<String, Double>();
		outs.put("i", i);
		outs.put("w", w);
		outs.put("m", m);
		return outs;
	}
	@Override
	public double getClock() {
		return clock;
	}
	@Override
	public void setClock(double clock) {
		this.clock=clock;
	}
	@Override
	public void setEntigrator(Entigrator entigrator) {
		this.entigrator=entigrator;
	}
	@Override
	public String getName() {
		return "Dcm";
	}
	@Override
	public String getType() {
		return "dcm";
	}
	@Override
	public String getFacetClass() {
		return classLocator();
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return null;
	}
}
