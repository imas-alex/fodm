package _54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.TubeHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.EduMaster;
import _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.Ac3dcHandler;
import _54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.ac3dc.JAc3dcEditor;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;

public class Ac3dcMaster extends FacetMaster{
	public static final String KEY="_UlyKiDUQPF1V1Yy1TxA8g_lij5g";
	public Ac3dcMaster() {
		super();
	}
	public Ac3dcMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.Ac3dcMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.Ac3dcHandler");
	    locator.put(HANDLER_KEY,"_g1tRDc6GPVZKAJcUdehclol5nOI");
	    locator.put(Locator.LOCATOR_TITLE,"Ac3dc");
	    locator.put(MASTER_KEY,"_UlyKiDUQPF1V1Yy1TxA8g_lij5g");
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "ac3dc.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_54rGxWBplMoFP63dPDOkOuRcxH4");
	    locator.put(FacetMaster.MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.Ac3dcMaster");
	    locator.put(FacetHandler.FACET_TYPE,"ac3dc");
	    return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String masterLocator$=classLocator();
		String display$=Locator.getProperty(handlerLocator$, JContext.DISPLAY);
		itemLocator$=Locator.merge(itemLocator$, masterLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		if(display$!=null)
		   itemLocator$=Locator.append(itemLocator$,JContext.DISPLAY, display$);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= Ac3dcHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new Ac3dcHandler(console.getEntigrator(),handlerLocator$); 
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return "Ac3dc";
	}
	@Override
	public String getType() {
		return "ac3dc";
	}
	
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			//System.out.println("SignalMaster:entityFacetsItemOnClick:alocator="+alocator$);
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String parentInstance$=context.getInstance();
			String parentLocator$=context.getLocator();
			SessionHandler.putLocator(console.getEntigrator(), parentLocator$);
			String ac3dcEditor$=JAc3dcEditor.classLocator();
			ac3dcEditor$=Locator.merge(ac3dcEditor$,locator$);
			ac3dcEditor$=Locator.append(ac3dcEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			ac3dcEditor$=Locator.append(ac3dcEditor$,JContext.PARENT, parentInstance$);
			JAc3dcEditor ac3cdEditor=new JAc3dcEditor(console,ac3dcEditor$);
			console.replaceContext(context,ac3cdEditor);
		}catch(Exception e) {
			System.out.println("Ac3dcMaster:entityFacetsItemOnClick:"+e.toString());	
		}
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		final String itemLocator$=alocator$;
		JPopupMenu popup=new JPopupMenu();
		JMenuItem newItem=new JMenuItem("New ac3dc");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("SignalMaster:allFacetsItemPopup:new entity:locator="+itemLocator$);
				popup.setVisible(false);
				String textEditor$=JTextEditor.classLocator();
				textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New ac3dc");
				String facetList$=JEntityFacetList.classLocator();
				facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
				facetList$=Locator.append(facetList$,MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.Ac3dcMaster");
				facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
				SessionHandler.putLocator(console.getEntigrator(),facetList$);
				textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
				JTextEditor textEditor=new JTextEditor(console,textEditor$);
				//console.replaceContext(textEditor);
				console.replaceContext(Ac3dcMaster.this.context, textEditor);
			}
		} );
		popup.add(newItem);
		return popup;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_54rGxWBplMoFP63dPDOkOuRcxH4",KEY,classLocator()); 
	     //System.out.println("Ac3dcMaster:addToSession:master entry: type="+masterEntry.type+" name="+masterEntry.name+" value="+masterEntry.value);
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_54rGxWBplMoFP63dPDOkOuRcxH4",Ac3dcHandler.KEY,Ac3dcHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("Ac3dcMaster:addToSession:"+e.toString());
	    }
}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
	
	
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
//		System.out.println("Ac3dcMaster:createEntiy:label="+entityLabel$);
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_54rGxWBplMoFP63dPDOkOuRcxH4",getType(),EduMaster.classLocator()));
		entity.putElementItem("facet", new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU","edu",classLocator()));
		entity.putAttribute(new Core("_54rGxWBplMoFP63dPDOkOuRcxH4","icon","ac3dc.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty( "operator","true", entity.getKey());
		entity=entigrator.assignProperty( "edu","true", entity.getKey());
		String ac3dcHandler$=Ac3dcHandler.classLocator();
		ac3dcHandler$=Locator.append(ac3dcHandler$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
		System.out.println("Ac3dcMaster:createEntiy:entity key="+entityKey$);
		Properties adapterLocator=new Properties();
		entityKey$=entigrator.getKey(entityLabel$);
	    adapterLocator.put(Entigrator.ENTITY_KEY, entityKey$);
	    adapterLocator.put(SegueController.SEGUE_HANDLER, "Ac3dcHandler");
	    adapterLocator.put(SegueController.SEGUE_INSTANCE, "ac3dcHandler");
	    adapterLocator.put(SegueController.SEGUE_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.Ac3dcHandler");
	    String adapterLocator$=Locator.toString(adapterLocator);
	  //  System.out.println("Ac3dcMaster:createEntiy:adapter locator="+adapterLocator$);
	    SegueController.createAdapter(entigrator,adapterLocator$ );
		return entity;
	}
}
