package _54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.drive;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;

import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DriveHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JGuiEditor;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class JDriveEditor extends JGuiEditor{
	public static final String KEY="_Ey7gFOp0w41JLK_SLio5JGdzkpmQ";
	private static final long serialVersionUID = 1L;
	private JComboBox<String> cbxMotor;
	private JComboBox<String> cbxRectifier;
	String motor$;
	String rectifier$;
	double ucLimit=0;
	double iaLimit=0;
	Entigrator entigrator;
	Sack entity;
	DriveHandler driveHandler;
	private JTextField txtUcmax;
	private JTextField txtIamax;
	public JDriveEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		driveHandler=new DriveHandler(console.getEntigrator(),locator$);
		driveHandler.setEntigrator(console.getEntigrator());
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] {0, 0, 2};
		gridBagLayout.rowHeights = new int[] {0, 0, 0, 0, 4};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblMotor= new JLabel("Motor");
		lblMotor.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try{   	
		              String servicesLocator$=JEntityFacetList.classLocator();
		              String motor$=(String)cbxMotor.getSelectedItem();
		              Sack motor=console.getEntigrator().getEntityAtLabel(motor$);
		              if(motor==null) {
		            	  System.out.println("JDriveEditor:cannot find entity="+motor$);
		            	  return;
		              }
		              servicesLocator$=Locator.append(servicesLocator$, Entigrator.ENTITY_LABEL, motor$);
		              JEntityFacetList entityFacetList=new JEntityFacetList(console,servicesLocator$);
					  JDisplay display=new JDisplay(console);
					  display.putContext(entityFacetList);
					  display.setLocationRelativeTo(JDriveEditor.this);
					  display.setVisible(true);
					  display.pack();
					  display.revalidate();
					  display.repaint();
					  entityFacetList.rebuild(console);
		             }catch(Exception ee){
		            	 System.out.println("JDriveEditor:"+e.toString());
		             }
			}
		});
		GridBagConstraints gbc_lblMotor = new GridBagConstraints();
		gbc_lblMotor.anchor = GridBagConstraints.LINE_START;
		gbc_lblMotor.insets = new Insets(5, 5, 5, 5);
		gbc_lblMotor.gridx = 0;
		gbc_lblMotor.gridy = 0;
		add(lblMotor, gbc_lblMotor);
		
		cbxMotor = new JComboBox<String>();
		cbxMotor.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				String motor$=(String)cbxMotor.getSelectedItem();
				if(!entity.existsElement("drive"))
		    		entity.createElement("drive");
	    		entity.putElementItem("drive", new Core(null,"motor",motor$));	
				console.getEntigrator().putEntity(entity);
				driveHandler.reset();
			}
		});
		GridBagConstraints gbc_cbxMotor = new GridBagConstraints();
		gbc_cbxMotor.insets = new Insets(5, 5, 5, 5);
		gbc_cbxMotor.anchor = GridBagConstraints.LINE_START;
		gbc_cbxMotor.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxMotor.gridx = 1;
		gbc_cbxMotor.gridy = 0;
		add(cbxMotor, gbc_cbxMotor);
		
		JLabel lblRectifier = new JLabel("Rectifier");
		lblRectifier.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
//				System.out.println("JDriveEditor:rectifier="+cbxRectifier.getSelectedItem());
				 try{   	
		              String servicesLocator$=JEntityFacetList.classLocator();
		              String rectifier$=(String)cbxRectifier.getSelectedItem();
		              Sack rectifier=console.getEntigrator().getEntityAtLabel(rectifier$);
		              if(rectifier==null) {
		            	  System.out.println("JDriveEditor:cannot find entity="+rectifier$);
		            	  return;
		              }
		              servicesLocator$=Locator.append(servicesLocator$, Entigrator.ENTITY_LABEL, rectifier$);
		              JEntityFacetList entityFacetList=new JEntityFacetList(console,servicesLocator$);
					  JDisplay display=new JDisplay(console);
					  display.setLocationRelativeTo(JDriveEditor.this);
					  display.setVisible(true);
					  display.pack();
					  display.revalidate();
					  display.repaint();
					  entityFacetList.rebuild(console);
		             }catch(Exception ee){
		            	 System.out.println("JDriveEditor:"+e.toString());
		             }
			}
		});
		GridBagConstraints gbc_lblRectifier = new GridBagConstraints();
		gbc_lblRectifier.anchor = GridBagConstraints.EAST;
		gbc_lblRectifier.insets = new Insets(5, 5, 5, 5);
		gbc_lblRectifier.gridx = 0;
		gbc_lblRectifier.gridy = 1;
		add(lblRectifier, gbc_lblRectifier);
		
		cbxRectifier = new JComboBox<String>();
		cbxRectifier.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				String rectifier$=(String)cbxRectifier.getSelectedItem();
				if(!entity.existsElement("drive"))
		    		entity.createElement("drive");
	    		entity.putElementItem("drive", new Core(null,"rectifier",rectifier$));	
				console.getEntigrator().putEntity(entity);
				driveHandler.reset();
			}
		});
		GridBagConstraints gbc_cbxRectifier = new GridBagConstraints();
		gbc_cbxRectifier.insets = new Insets(5, 5, 5, 5);
		gbc_cbxRectifier.fill = GridBagConstraints.HORIZONTAL;
		gbc_cbxRectifier.gridx = 1;
		gbc_cbxRectifier.gridy = 1;
		add(cbxRectifier, gbc_cbxRectifier);
		
		JLabel lblUcmax = new JLabel("Ucmax");
		GridBagConstraints gbc_lblUcmax = new GridBagConstraints();
		gbc_lblUcmax.anchor = GridBagConstraints.LINE_START;
		gbc_lblUcmax.insets = new Insets(5, 5, 5, 5);
		gbc_lblUcmax.gridx = 0;
		gbc_lblUcmax.gridy = 2;
		add(lblUcmax, gbc_lblUcmax);
		
		txtUcmax = new JTextField();
		txtUcmax.setColumns(10);
		txtUcmax.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String u$=txtUcmax.getText();
		    	if(!entity.existsElement("drive"))
		    		entity.createElement("drive");
	    		entity.putElementItem("drive", new Core(null,"Ucmax",u$));	
				console.getEntigrator().putEntity(entity);
				driveHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtUcmax = new GridBagConstraints();
		gbc_txtUcmax.insets = new Insets(5, 5, 5, 5);
		gbc_txtUcmax.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtUcmax.gridx = 1;
		gbc_txtUcmax.gridy = 2;
		add(txtUcmax, gbc_txtUcmax);
		
		
		JLabel lblIamax = new JLabel("Iamax");
		GridBagConstraints gbc_lblIamax = new GridBagConstraints();
		gbc_lblIamax.anchor = GridBagConstraints.LINE_START;
		gbc_lblIamax.insets = new Insets(5, 5, 5, 5);
		gbc_lblIamax.gridx = 0;
		gbc_lblIamax.gridy = 3;
		add(lblIamax, gbc_lblIamax);
		
		txtIamax = new JTextField();
		txtIamax.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String i$=txtIamax.getText();
		    	if(!entity.existsElement("drive"))
		    		entity.createElement("drive");
	    		entity.putElementItem("drive", new Core(null,"Iamax",i$));	
				console.getEntigrator().putEntity(entity);
				driveHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtIamax = new GridBagConstraints();
		gbc_txtIamax.insets=new Insets(5, 5, 5, 5);
		gbc_txtIamax.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtIamax.gridx = 1;
		gbc_txtIamax.gridy = 3;
		add(txtIamax, gbc_txtIamax);
		txtIamax.setColumns(10);
		entigrator=console.getEntigrator();
		String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		entity=entigrator.getEntityAtLabel(entityLabel$);
		init();
	}
	public static String classLocator() {
		 Properties locator=new Properties();
		 locator.put(FacetHandler.FACET_NAME,"Drive");
		    locator.put(FacetHandler.FACET_TYPE,"drive");
		    locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
			locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
			locator.put(DEFAULT_PARENT, JEntityFacetList.KEY);
		    locator.put(ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
		    locator.put(FacetHandler.FACET_MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.DriveMaster");
		    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DriveHandler");
		    locator.put(FacetHandler.FACET_KEY,DriveHandler.KEY);
		    locator.put(Locator.LOCATOR_TITLE,"Drive");
		    locator.put(FacetHandler.FACET_MASTER_KEY,KEY);
		    locator.put( IconLoader.ICON_FILE, "drive.png");
		    locator.put( IconLoader.ICON_CONTAINER,"_54rGxWBplMoFP63dPDOkOuRcxH4");
		    locator.put(FacetHandler.FACET_TYPE,"drive");
		    locator.put(FacetMaster.MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.DriveMaster");
		    locator.put(JContext.CONTEXT_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.drive.JDriveEditor");
		    return Locator.toString(locator);
	}
private void init() {
	try {
		DefaultComboBoxModel<String> modelMotor=new DefaultComboBoxModel <String>();
		String[] ma=entigrator.listEntities("entity", "dcm");
		if(ma!=null) {
		ArrayList<String>ml=new ArrayList<String>();
		String ml$;
		 for(String m$:ma) {
			 ml$=entigrator.getLabel(m$);
			 if(ml$!=null)
				 ml.add(ml$);
		 }
		 if(ml.size()>0) {
		 Collections.sort(ml);
		 String [] sa=new String[ml.size()];
		 ml.toArray(sa);
		 modelMotor=new DefaultComboBoxModel<String> (sa);
		 }
		}
		cbxMotor.setModel(modelMotor);
		DefaultComboBoxModel<String> ac3dcModel=new DefaultComboBoxModel <String>();
		String[] ra=entigrator.listEntities("entity", "ac3dc");
		if(ra!=null) {
		ArrayList<String>rl=new ArrayList<String>();
		String rl$;
		 for(String r$:ra) {
			 rl$=entigrator.getLabel(r$);
			 if(rl$!=null)
				 rl.add(rl$);
		 }
		 if(rl.size()>0) {
		 Collections.sort(rl);
		 String [] sa=new String[rl.size()];
		 rl.toArray(sa);
		 ac3dcModel=new DefaultComboBoxModel<String> (sa);
		 }
		}
		cbxRectifier.setModel(ac3dcModel);
		String ucmax$=entity.getElementItemAt("drive", "Ucmax");
		txtUcmax.setText(ucmax$);
		String iamax$=entity.getElementItemAt("drive", "Iamax");
		txtIamax.setText(iamax$);
		String motor$=entity.getElementItemAt("drive", "motor");
		if(motor$!=null)
			selectCombo(cbxMotor,motor$);
		String rectifier$=entity.getElementItemAt("drive", "rectifier");
		if(rectifier$!=null)
			selectCombo(cbxRectifier,rectifier$);
	}catch(Exception e) {
		System.out.println("JDriveEditor:init"+e.toString());
	}
}
@Override
public String getClassLocator() {
	// TODO Auto-generated method stub
	return null;
}
@Override
public String reply(JMainConsole console, String locator$) {
	// TODO Auto-generated method stub
	return null;
}
	
}
