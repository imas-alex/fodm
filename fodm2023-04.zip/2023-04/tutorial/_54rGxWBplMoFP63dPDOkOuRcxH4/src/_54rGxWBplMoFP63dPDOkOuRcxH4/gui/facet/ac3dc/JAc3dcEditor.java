package _54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.ac3dc;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.JPlotPanel;
import _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.Ac3dcHandler;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Properties;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JAc3dcEditor extends JGuiEditor{
	public static final String KEY="_1Roc_SiX_9ZkY04LjCZj_7QftopM";
	JTextField txtVoltage;
	JTextField txtFrequency;
	JTextField txtControl;
	public JAc3dcEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0,0,1};
		gridBagLayout.rowHeights = new int[]{0,0,0,0,1};
		gridBagLayout.columnWeights = new double[]{0.0,0.0,1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0.0,Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblVoltage = new JLabel("Voltage");
		GridBagConstraints gbc_lblVoltage = new GridBagConstraints();
		gbc_lblVoltage.anchor = GridBagConstraints.LINE_START;
		gbc_lblVoltage.insets = new Insets(5, 5, 5, 5);
		gbc_lblVoltage.gridx = 0;
		gbc_lblVoltage.gridy = 0;
		add(lblVoltage, gbc_lblVoltage);
		
		txtVoltage = new JTextField();
		txtVoltage.setColumns(10);
		txtVoltage.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String amplitude$=txtVoltage.getText();
		    	if(!entity.existsElement("ac3dc"))
		    		entity.createElement("ac3dc");
	    		entity.putElementItem("ac3dc", new Core(null,"voltage",amplitude$));	
				 console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtAmplitude = new GridBagConstraints();
		gbc_txtAmplitude.insets = new Insets(5, 5, 5, 5);
		gbc_txtAmplitude.gridx = 1;
		gbc_txtAmplitude.gridy = 0;
		add(txtVoltage, gbc_txtAmplitude);
		
		JLabel lblFrequency = new JLabel("Frequency");
		GridBagConstraints gbc_lblFrequency = new GridBagConstraints();
		gbc_lblFrequency.anchor = GridBagConstraints.LINE_START;
		gbc_lblFrequency.insets = new Insets(0, 5, 5, 5);
		gbc_lblFrequency.gridx = 0;
		gbc_lblFrequency.gridy = 1;
		add(lblFrequency, gbc_lblFrequency);
		
		txtFrequency = new JTextField();
		txtFrequency.setColumns(10);
		txtFrequency.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		    	String frequency$=txtFrequency.getText();
		    	if(!entity.existsElement("ac3dc"))
		    		entity.createElement("ac3dc");
	    		entity.putElementItem("ac3dc", new Core(null,"frequency",frequency$));	
				console.getEntigrator().putEntity(entity);
				 }
	      });
		GridBagConstraints gbc_txtFrequency = new GridBagConstraints();
		gbc_txtFrequency.insets = new Insets(0, 5, 5, 5);
		gbc_txtFrequency.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtFrequency.gridx = 1;
		gbc_txtFrequency.gridy = 1;
		add(txtFrequency, gbc_txtFrequency);
		
		JLabel  lblControl = new JLabel("Control");
		GridBagConstraints gbc_lblControl = new GridBagConstraints();
		gbc_lblControl.insets = new Insets(0, 5, 5, 5);
		gbc_lblControl.anchor=GridBagConstraints.LINE_START;
		gbc_lblControl.gridx = 0;
		gbc_lblControl.gridy = 2;
		add(lblControl, gbc_lblControl);
		
		txtControl = new JTextField();
		txtControl.setColumns(10);
		GridBagConstraints gbc_txtControl = new GridBagConstraints();
		gbc_txtControl.insets = new Insets(0, 5, 5, 5);
		gbc_txtControl.gridx = 1;
		gbc_txtControl.gridy = 2;
		add(txtControl, gbc_txtControl);
		txtControl.addCaretListener(new CaretListener() {
				@Override
				public void caretUpdate(CaretEvent e) {
					String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    	String control$=txtControl.getText();
			    	if(!entity.existsElement("ac3dc"))
			    		entity.createElement("ac3dc");
		    		entity.putElementItem("ac3dc", new Core(null,"control",control$));	
					console.getEntigrator().putEntity(entity);
					 }
		      });
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
    	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
    	entity.printElement("ac3dc");
    	String voltage$=entity.getElementItemAt("ac3dc", "voltage");
    	txtVoltage.setText(voltage$);
    	String frequency$=entity.getElementItemAt("ac3dc", "frequency");
    	txtFrequency.setText(frequency$);
    	String control$=entity.getElementItemAt("ac3dc", "control");
    	txtControl.setText(control$);
    	System.out.println("JAc3cdEditor:voltage="+voltage$+" frequency="+frequency$+" control="+control$);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,"Ac3dc");
		locator.put(FacetHandler.FACET_TYPE,"ac3dc");
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.Ac3dcMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
		locator.put(JContext.CONTEXT_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.ac3dc.JAc3dcEditor");
		return Locator.toString(locator);
	}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu.addSeparator();
		JMenuItem gainItem = new JMenuItem("Gain");
		gainItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					gain();
					showPlot();
				}
			} );
		menu.add(gainItem);	
		return menu;
	}
	private void gain( )  {
		Ac3dcHandler ac3dcHandler=new Ac3dcHandler(console.getEntigrator(),locator$);
	//	System.out.println("JAc3cdEditor::gain:T="+ac3dcHandler.T+"  Um="+ac3dcHandler.Uam+" K="+ac3dcHandler.Ucm);
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String entityKey$=console.getEntigrator().getKey(entity$);
		File entityHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$);
		try {
				if(!entityHome.exists())
			    	entityHome.mkdir();
				 File data=	new File(entityHome.getPath()+"/gain.data");
				 if(data.exists())
					 data.delete();
			data.createNewFile();
			PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(data, true)));
			String line$;//=new StringBuffer();
			String format$="##.####E0";
			NumberFormat valFormat = new DecimalFormat(format$);
			double duc=0.01;
	    	double uc=0;
	    	double ud=0;
	    	double gain=0;
	    	double ud0=0;
	    	double Kd=0;
			writer.close();
			}catch(Exception e) {
				System.out.println("JAc3cdEditor::gain:"+e.toString());
			}
	}
	private Sack getPlot() {
		//System.out.println("JSisoEditor:remakePlot:type="+plotType);
		try {
			String plotType$="gain";
			String suffix$="gain";
			Ac3dcHandler ac3dcHandler=new Ac3dcHandler(console.getEntigrator(),locator$);
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String entityKey$=console.getEntigrator().getKey(entity$);
			Sack entity=console.getEntigrator().getEntity( entityKey$);
			String [] sa=entity.elementListNames("link");
			if(sa!=null) {
				Sack candidate;
				for(String s:sa) {
					candidate=console.getEntigrator().getEntity(s);
					if(candidate!=null) {
						String candidateType$=candidate.getProperty("plot type");
						if(plotType$.equals(candidateType$))
							return candidate;
					}
				}
			}
			String plotLabel$=entity.getProperty("label")+"."+suffix$;
			Properties plotLocator=new Properties();
			plotLocator.put( ModuleHandler.FACET_MODULE, "_TZ34ntGtza4ryheSV3Xo_JOLOIU");
			plotLocator.put( FacetMaster.MASTER_CLASS, "_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster");
			String plotLocator$=Locator.toString(plotLocator);
			PlotMaster plotMaster=(PlotMaster)FacetMaster.build(console, plotLocator$);
			Sack plot= plotMaster.createEntity(console.getEntigrator(), plotLabel$);
			console.getEntigrator().putEntity(plot);
			plot=console.getEntigrator().assignProperty("plot type", plotType$, plot.getKey());
			console.getEntigrator().link(entity, plot);
			plot.createElement("Quadrant");
			plot.putElementItem("Quadrant", new Core("50","Vertical","0.8"));
			plot.putElementItem("Quadrant", new Core("100","Horizontal","0.8"));
			plot.createElement("Surface");
			plot.putElementItem("Surface", new Core(null,"Horizontal",null));
			plot.putElementItem("Surface", new Core("0","Vertical","0.8"));
			plot.putElementItem("Surface", new Core("0","Horizontal","0.8"));
			plot.createElement("canvas");
		    plot.putElementItem("canvas", new Core(null,"area","Quadrant"));
			plot.putElementItem("canvas", new Core(null	,"backcolor","white"));
			plot.putElementItem("canvas", new Core(null	,"font.color","blue"));
			plot.putElementItem("canvas", new Core(null,"font.size","12"));
			plot.putElementItem("canvas", new Core(null,"font.style","bold"));
			plot.putElementItem("canvas", new Core(null,"frontcolor","black"));
			plot.putElementItem("canvas", new Core(null,"pointer.size","6"));
			plot.putElementItem("canvas", new Core(null,"shift","40"));
			plot.putElementItem("canvas", new Core(null,"stroke","2"));
			plot.createElement("scale.layout");
			plot.putElementItem("scale.layout", new Core("Vertical","gain","1"));
			plot.putElementItem("scale.layout", new Core("Vertical","Ud","0"));
        	plot.putElementItem("scale.layout", new Core("Horizontal","Uc","0"));
			plot.createElement("scale.max");
			plot.putElementItem("scale.max", new Core("0.###","gain","120"));
			plot.putElementItem("scale.max", new Core("0.###","Ud","600"));
			plot.putElementItem("scale.max", new Core("0.###","Uc","12"));
			plot.createElement("scale.mark");
			plot.putElementItem("scale.mark", new Core(null,"gain","20"));
			plot.putElementItem("scale.mark", new Core("(V)","Ud","100"));
			plot.putElementItem("scale.mark", new Core("(V)","Uc","2"));
			plot.createElement("scale.raster");
			plot.putElementItem("scale.raster", new Core("linear","Uc","2"));
			plot.putElementItem("scale.raster", new Core("linear","Ud","100"));
			plot.putElementItem("scale.raster", new Core("linear","gain","100"));
			plot.createElement("ray.color");
			plot.createElement("ray.index");
			plot.createElement("ray.name");
			plot.createElement("ray.scale");
			plot.createElement("ray.shift");
			plot.createElement("ray.symbol");
			plot.createElement("ray.visible");
			String rayKey$=Identity.key();
			//gain 
			plot.putElementItem("ray.color", new Core(null,rayKey$,"red"));
			plot.putElementItem("ray.index", new Core(null,rayKey$,"1"));
			plot.putElementItem("ray.name", new Core(null,rayKey$,"gain"));
			plot.putElementItem("ray.scale", new Core(null,rayKey$,"gain"));
			plot.putElementItem("ray.shift", new Core(null,rayKey$,"0"));
			plot.putElementItem("ray.symbol", new Core("K",rayKey$,""));
			plot.putElementItem("ray.visible", new Core("2",rayKey$,"true"));
			rayKey$=Identity.key();
			//Ud
			plot.putElementItem("ray.color", new Core(null,rayKey$,"magenta"));
			plot.putElementItem("ray.index", new Core(null,rayKey$,"0"));
			plot.putElementItem("ray.name", new Core(null,rayKey$,"ud"));
			plot.putElementItem("ray.scale", new Core(null,rayKey$,"Ud"));
			plot.putElementItem("ray.shift", new Core(null,rayKey$,"0"));
			plot.putElementItem("ray.symbol", new Core("Ud",rayKey$,""));
			plot.putElementItem("ray.visible", new Core("2",rayKey$,"true"));
			rayKey$=Identity.key();
			//Kd
			plot.putElementItem("ray.color", new Core(null,rayKey$,"blue"));
			plot.putElementItem("ray.index", new Core(null,rayKey$,"2"));
			plot.putElementItem("ray.name", new Core(null,rayKey$,"Kd"));
			plot.putElementItem("ray.scale", new Core(null,rayKey$,"gain"));
			plot.putElementItem("ray.shift", new Core(null,rayKey$,"0"));
			plot.putElementItem("ray.symbol", new Core("Kd",rayKey$,""));
			plot.putElementItem("ray.visible", new Core("2",rayKey$,"true"));
			console.getEntigrator().putEntity(plot);
			plot=FolderHandler.add(console.getEntigrator(), plot);
			return plot;
		}catch(Exception e) {
			System.out.println("JSisoEditor:createPlot:"+e.toString());
		}
		return null;
	}
	private void transferData() {
		try {
		//System.out.println("JAc3dcEditor:transferData:plot type="+plotType);
		Sack plot=getPlot();
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String entityKey$=console.getEntigrator().getKey(entity$);
		String in$=console.getEntigrator().getEntihome()+"/"+entityKey$+"/gain.data";
		String out$=console.getEntigrator().getEntihome()+"/"+plot.getKey()+"/gain.data";	
//		System.out.println("JSisosEditor:transferData:in="+in$+"  out="+out$);
		File in=new File(in$);
		Scanner ins = new Scanner(in);	
		File out=new File(out$);
		if(out.exists())
			out.delete();
		out=new File(out$);
		PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(out)));
		String line$;
		while(ins.hasNextLine()) {
			line$=ins.nextLine();
			writer.write(line$+"\n");
		}
		ins.close();
		writer.close();
		}catch(Exception e) {
			System.out.println("JAc3dcEditor:transferData:"+e.toString());
		}
	}
	private void  showPlot() {
		Sack plot=getPlot();
		if(plot==null) {
			 System.out.println("JAc3dcEditor:showPlot:cannot find plot ");
			 return;
		}
		transferData();
		String plotLocator$=JPlotPanel.classLocator();
		plotLocator$=Locator.append(plotLocator$, Entigrator.ENTITY_LABEL, plot.getProperty("label"));	
		//String instance$=Locator.getProperty(getLocator(), INSTANCE);
		String instance$=getInstance();
		System.out.println("JAc3dcEditor:showPlot:instance="+instance$);
		plotLocator$=Locator.append(plotLocator$, PARENT, instance$);	
		plotLocator$=Locator.append(plotLocator$, INSTANCE, Identity.key());
		String plotType$="gain";
		//System.out.println("JSisoEditor:showPlot:plot type="+plotType$);
		plotLocator$=Locator.append(plotLocator$, Locator.LOCATOR_TITLE, plotType$);
//		System.out.println("JSisoEditor:setBodeUnclosedPlot:editor locator="+getLocator());
		instance$=SessionHandler.putLocator(console.getEntigrator(),getLocator());
		plotLocator$=Locator.append(plotLocator$, PARENT, instance$);
//		System.out.println("JSisoEditor:setBodeUnclosedPlot:plot locator="+plotLocator$);
	    JPlotPanel plotViewer=new JPlotPanel(console,plotLocator$);
		//replace(console, plotViewer);
	    console.replaceContext(this, plotViewer);
	}

	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	
	
}
