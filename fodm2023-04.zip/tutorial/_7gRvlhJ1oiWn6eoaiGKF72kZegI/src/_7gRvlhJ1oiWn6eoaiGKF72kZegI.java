import gdt.base.store.Entigrator;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.Ac3dcHandler;
import java.util.Hashtable;
import java.util.Properties;
import gdt.base.generic.Locator;
public class _7gRvlhJ1oiWn6eoaiGKF72kZegI implements SegueController{
private final static String ENTITY_KEY="_7gRvlhJ1oiWn6eoaiGKF72kZegI";
private _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.Ac3dcHandler ac3dcHandler;
public _7gRvlhJ1oiWn6eoaiGKF72kZegI(){}
public Hashtable<String,Double>  stride(Hashtable<String,Double>  ins){ 
	Hashtable<String,Double>outs=ac3dcHandler. stride(ins);
	//EduHandler.printHashtableDouble(ENTITY_KEY+":ins:",ins);
	//EduHandler.printHashtableDouble(ENTITY_KEY+":outs:",outs);
	return outs;
} 
public void reset(){ 
System.out.println(ENTITY_KEY+":reset");	
ac3dcHandler.reset();
} 
public Hashtable<String,Double> getSettings(){ 
return ac3dcHandler.getSettings();
} 
public void putSettings(Hashtable<String,Double> settings){ 
ac3dcHandler.putSettings(settings); 
} 
public Hashtable<String,Double> getOuts(){ 
return ac3dcHandler.getOuts();
}
public double getClock(){
return ac3dcHandler.getClock();
}
public void setClock(double clock){ 
ac3dcHandler.setClock(clock); 
} 
public String[] listInputs(){ 
return ac3dcHandler.listInputs(); 
}
public String[] listOutputs(){ 
return ac3dcHandler.listOutputs(); 
}
public void setEntigrator(Entigrator entigrator){ 
 String entity$=entigrator.getLabel(ENTITY_KEY);
 Properties props=new Properties();
 props.put(Entigrator.ENTITY_LABEL, entity$);
 String locator$=Locator.toString(props);
ac3dcHandler=new Ac3dcHandler(entigrator,locator$);
ac3dcHandler.setEntigrator(entigrator);
} 
}
