import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JEditorPane;

import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.procedure.Procedure;  
public class _YKAnRdWtfFpAEgma84sWT546GGo  implements Procedure {
private final static String ENTITY_KEY="_YKAnRdWtfFpAEgma84sWT546GGo";
public _YKAnRdWtfFpAEgma84sWT546GGo (){} 

@Override
public void exec(JMainConsole console, String locator$, JEditorPane reportPanel) {
	try {
		String[]sa=console.getEntigrator().listEntities();
		@SuppressWarnings("unused")
		String label$=null;
		ArrayList<String>sl=new ArrayList<String>();
	//	ArrayList<String>wl=new ArrayList<String>();
		Sack entity;
		for(String s:sa) {
			label$=console.getEntigrator().getLabel(s);
			entity=console.getEntigrator().getEntity(s);
		    //if(label$!=null)
		    //	sl.add(label$);
			if(entity==null)
				sl.add(s);
		}
		sa = new String[ sl.size()];
		sl.toArray(sa);
		StringBuffer sb =new  StringBuffer();
		Arrays.sort(sa);
		for(String s:sa ) {
			sb.append(s+"\n");
		}
		reportPanel.setText(sb.toString()); 
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+" :"+e.toString());
	}

}
}

