/**
 * 
 */
/**
 * @author alexander
 *
 */
module _54rGxWBplMoFP63dPDOkOuRcxH4 {
	exports _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet;
	requires transitive JEntispace ;
	requires _TZ34ntGtza4ryheSV3Xo_JOLOIU;
	requires transitive java.desktop;
	requires java.logging;
}