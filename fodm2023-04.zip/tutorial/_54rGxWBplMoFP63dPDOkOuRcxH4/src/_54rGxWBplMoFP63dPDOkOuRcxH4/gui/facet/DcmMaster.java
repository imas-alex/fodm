package _54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Properties;
import javax.swing.JPopupMenu;

import _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DcmHandler;
import _54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.dcm.JDcmEditor;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.EduMaster;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
public class DcmMaster extends FacetMaster{
	public static final String KEY="_wQXRAfP8RXusquR6nIdoqZLSCBc";
	public DcmMaster() {
		super();
	}
	public DcmMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.DcmMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DcmHandler");
	    locator.put(HANDLER_KEY,"_54rGxWBplMoFP63dPDOkOuRcxH4");
	    locator.put(Locator.LOCATOR_TITLE,"Dcm");
	    locator.put(MASTER_KEY,"_wQXRAfP8RXusquR6nIdoqZLSCBc");
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "dcm.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_54rGxWBplMoFP63dPDOkOuRcxH4");
	    locator.put(FacetMaster.MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.DcmMaster");
	    locator.put(FacetHandler.FACET_TYPE,"dcm");
	    return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String masterLocator$=classLocator();
		String display$=Locator.getProperty(handlerLocator$, JContext.DISPLAY);
		itemLocator$=Locator.merge(itemLocator$, masterLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		if(display$!=null)
		   itemLocator$=Locator.append(itemLocator$,JContext.DISPLAY, display$);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= DcmHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new DcmHandler(console.getEntigrator(),handlerLocator$); 
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return "Dcm";
	}
	@Override
	public String getType() {
		return "dcm";
	}
	
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			//System.out.println("SignalMaster:entityFacetsItemOnClick:alocator="+alocator$);
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String parentInstance$=context.getInstance();
			String parentLocator$=context.getLocator();
			SessionHandler.putLocator(console.getEntigrator(), parentLocator$);
			String dcmEditor$=JDcmEditor.classLocator();
			dcmEditor$=Locator.merge(dcmEditor$,locator$);
			dcmEditor$=Locator.append(dcmEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			dcmEditor$=Locator.append(dcmEditor$,JContext.PARENT, parentInstance$);
			JDcmEditor dcmEditor=new JDcmEditor(console,dcmEditor$);
			console.replaceContext(context,dcmEditor);
		}catch(Exception e) {
			System.out.println("DcmMaster:entityFacetsItemOnClick:"+e.toString());	
		}
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_54rGxWBplMoFP63dPDOkOuRcxH4",KEY,classLocator()); 
	    // System.out.println("Ac3dcMaster:addToSession:master entry: type="+masterEntry.type+" name="+masterEntry.name+" value="+masterEntry.value);
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_54rGxWBplMoFP63dPDOkOuRcxH4",DcmHandler.KEY,DcmHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("Ac3dcMaster:addToSession:"+e.toString());
	    }
}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
	
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
//		System.out.println("DcmMaster:createEntiy:label="+entityLabel$);
		Sack entity=null;
	try {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_54rGxWBplMoFP63dPDOkOuRcxH4",getType(),EduMaster.classLocator()));
		entity.putElementItem("facet", new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU","edu",classLocator()));
		
		entity.putAttribute(new Core("_54rGxWBplMoFP63dPDOkOuRcxH4","icon","dcm.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty( "operator","true", entity.getKey());
		entity=entigrator.assignProperty( "edu","true", entity.getKey());
			String dcmHandler$=DcmHandler.classLocator();
		dcmHandler$=Locator.append(dcmHandler$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
		System.out.println("DcmMaster:createEntiy:entity key="+entityKey$);
		Properties adapterLocator=new Properties();
		entityKey$=entigrator.getKey(entityLabel$);
	    adapterLocator.put(Entigrator.ENTITY_KEY, entityKey$);
	    adapterLocator.put(SegueController.SEGUE_HANDLER, "DcmHandler");
	    adapterLocator.put(SegueController.SEGUE_INSTANCE, "dcmHandler");
	    adapterLocator.put(SegueController.SEGUE_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DcmHandler");
	    String adapterLocator$=Locator.toString(adapterLocator);
	    System.out.println("DcmMaster:createEntiy:adapter locator="+adapterLocator$);
	    SegueController.createAdapter(entigrator,adapterLocator$ );
		return entity;
	}catch(Exception e) {
		System.out.println("DcmMaster:createEntiy:"+e.toString());
	}
	if(entity!=null)
		return entity;
	else
	    return null;
	}
}
