package _54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Properties;
import javax.swing.JPopupMenu;
import _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DriveHandler;
import _54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.drive.JDriveEditor;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.EduMaster;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;

public class DriveMaster extends FacetMaster {
	public static final String KEY="_vQj7Ft4fNozkanhJiGCnwNPRcI8";
	public DriveMaster() {
		super();
	}
	public DriveMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.DriveMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DriveHandler");
	    locator.put(HANDLER_KEY,"_54rGxWBplMoFP63dPDOkOuRcxH4");
	    locator.put(Locator.LOCATOR_TITLE,"Drive");
	    locator.put(MASTER_KEY,"_wQXRAfP8RXusquR6nIdoqZLSCBc");
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "drive.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_54rGxWBplMoFP63dPDOkOuRcxH4");
	    locator.put(FacetMaster.MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.DriveMaster");
	    locator.put(FacetHandler.FACET_TYPE,"drive");
	    return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String masterLocator$=classLocator();
		String display$=Locator.getProperty(handlerLocator$, JContext.DISPLAY);
		itemLocator$=Locator.merge(itemLocator$, masterLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		if(display$!=null)
		   itemLocator$=Locator.append(itemLocator$,JContext.DISPLAY, display$);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= DriveHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new DriveHandler(console.getEntigrator(),handlerLocator$); 
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return "Drive";
	}
	@Override
	public String getType() {
		return "drive";
	}

@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			//System.out.println("DriveMaster:entityFacetsItemOnClick:alocator="+alocator$);
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String parentInstance$=context.getInstance();
			String parentLocator$=context.getLocator();
			SessionHandler.putLocator(console.getEntigrator(), parentLocator$);
			String driveEditor$=JDriveEditor.classLocator();
			driveEditor$=Locator.merge(driveEditor$,locator$);
			driveEditor$=Locator.append(driveEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			driveEditor$=Locator.append(driveEditor$,JContext.PARENT, parentInstance$);
			JDriveEditor driveEditor=new JDriveEditor(console,driveEditor$);
			console.replaceContext(context,driveEditor);
		}catch(Exception e) {
			System.out.println("DriveMaster:entityFacetsItemOnClick:"+e.toString());	
		}
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_54rGxWBplMoFP63dPDOkOuRcxH4",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_54rGxWBplMoFP63dPDOkOuRcxH4",DriveHandler.KEY,DriveHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("DriveMaster:addToSession:"+e.toString());
	    }	
		}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession(console, locator$);
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		Sack entity=null;
	try {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_54rGxWBplMoFP63dPDOkOuRcxH4",getType(),EduMaster.classLocator()));
		entity.putElementItem("facet", new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU","edu",classLocator()));
		
		entity.putAttribute(new Core("_54rGxWBplMoFP63dPDOkOuRcxH4","icon","drive.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty( "operator","true", entity.getKey());
		entity=entigrator.assignProperty( "edu","true", entity.getKey());
		String driveHandler$=DriveHandler.classLocator();
		driveHandler$=Locator.append(driveHandler$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
		//System.out.println("DriveMaster:createEntiy:entity key="+entityKey$);
		Properties adapterLocator=new Properties();
		entityKey$=entigrator.getKey(entityLabel$);
	    adapterLocator.put(Entigrator.ENTITY_KEY, entityKey$);
	    adapterLocator.put(SegueController.SEGUE_HANDLER, "DriveHandler");
	    adapterLocator.put(SegueController.SEGUE_INSTANCE, "driveHandler");
	    adapterLocator.put(SegueController.SEGUE_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DriveHandler");
	    String adapterLocator$=Locator.toString(adapterLocator);
	    //System.out.println("DriveMaster:createEntiy:adapter locator="+adapterLocator$);
	    SegueController.createAdapter(entigrator,adapterLocator$ );
		return entity;
	}catch(Exception e) {
		System.out.println("DriveMaster:createEntiy:"+e.toString());	}
	if(entity!=null)
		return entity;
	else
	    return null;
	}
}
