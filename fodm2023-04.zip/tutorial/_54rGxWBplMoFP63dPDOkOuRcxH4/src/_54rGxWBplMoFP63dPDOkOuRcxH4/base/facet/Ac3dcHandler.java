package _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Hashtable;
import java.util.Properties;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class Ac3dcHandler extends FacetHandler implements SegueController{
	Sack entity;
	public Ac3dcHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		String entity$=Locator.getProperty(alocator$,Entigrator.ENTITY_LABEL);
		entity=entigrator.getEntityAtLabel(entity$);
	}
	public static final String KEY="_g1tRDc6GPVZKAJcUdehclol5nOI";
	//primary parameterss
	double Ua=0;
	double Uam=0;
	double f=0;
	double Ucm=0;
	//secondary parameters 
	double T=Double.MIN_VALUE;
	double T0=0;
	double T1=0;
	double T2=0;
	double T3=0;
	double T4=0;
	double T5=0;
	double Tr=0;
	double Ku=0;
	double Udm=0;
	//global variable
	double time=0;
	//internal variable
	double uA=0;
	double uB=0;
	double uC=0;
	double uaa=0;
	double ubb=0;
	double ucc=0;
	double ud=0;
	double tau=0;
	double preferredClock=0.00001;
	double clock=preferredClock;
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"Ac3dc");
		locator.put(FACET_TYPE,"ac3dc");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.Ac3dcHandler");
		locator.put(FACET_MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.Ac3dcMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
		locator.put( IconLoader.ICON_FILE, "ac3dc.png");
		locator.put( IconLoader.ICON_CONTAINER,"_54rGxWBplMoFP63dPDOkOuRcxH4");
		return Locator.toString(locator);
	}
	public void reset() {
		Sack ac3dc=entity;
		if(!ac3dc.existsElement(OperatorHandler.OPERATOR))
			ac3dc.createElement(OperatorHandler.OPERATOR);
		ac3dc.putElementItem(OperatorHandler.OPERATOR,new Core("out","ud","0"));
		ac3dc.putElementItem(OperatorHandler.OPERATOR,new Core("in","uc","0"));
		ac3dc.putElementItem(OperatorHandler.OPERATOR, new Core("out","ude","0"));
		ac3dc.putElementItem(OperatorHandler.OPERATOR, new Core("out","uA",String.valueOf(uA)));
		ac3dc.putElementItem(OperatorHandler.OPERATOR, new Core("out","uB",String.valueOf(uB)));
		ac3dc.putElementItem(OperatorHandler.OPERATOR, new Core("out","uC",String.valueOf(uC)));
		Ua=0;
		try {Ua=Double.parseDouble(ac3dc.getElementItemAt("ac3dc", "voltage"));}catch(Exception e) {}
		Uam=Ua*Math.sqrt(2);
		f=0;
		try {f=Double.parseDouble(ac3dc.getElementItemAt("ac3dc", "frequency"));}catch(Exception e) {}
		Ucm=0;
		try {Ucm=Double.parseDouble(ac3dc.getElementItemAt("ac3dc", "control"));}catch(Exception e) {}
		T=1/(f+Double.MIN_VALUE);
		T0=(double)T/12;
		T1=(double)T/4;
		T2=(double)T/4+(double)T/6;
		T3=(double)T/12+(double)T/2;
		T4=(double)3*T/4;
		T5=(double)3*T/4+(double)T/6;
		preferredClock=T/1000;
		Tr=1/(6*f);
		Udm=2.34*Ua;
		Ku=Udm/Ucm;
		ac3dc.putElementItem("ac3dc",new Core(null,"Tr",String.valueOf(Tr)));
		ac3dc.putElementItem("ac3dc",new Core(null,"Ku",String.valueOf(Ku)));
		ac3dc.putElementItem("ac3dc",new Core(null,"Udm",String.valueOf(Udm)));
		ac3dc.putElementItem("ac3dc",new Core(null,"clock",String.valueOf(preferredClock)));
		entigrator.putEntity(ac3dc);
		ac3dc.printElement("ac3dc");
	}
	@Override
	public String[] listOutputs() {
		return new String[] {
				"ud",
				"ude",
				"udm",
				"uA",
				"uB",
				"uC",
				"uaa",
				"ubb",
				"ucc",
				};
	}
	@Override
	public String[] listInputs() {
		return new String[] {"uc"};
	}
	@Override
	public String getName() {
		return "Ac3dc";
	}
	@Override
	public String getType() {
		return "ac3dc";
	}
	@Override
	public String getFacetClass() {
		return "_54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.Ac3dcHandler";
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return null;
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	@Override
	public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
		Hashtable<String, Double> outs=new Hashtable<String, Double>();
		try {
			clock=preferredClock;
			try { clock=ins.get("clock");}catch(Exception e) {}
			double uc=0;
			try { uc=ins.get("uc");}catch(Exception e) {}
			double uin=uc/Ucm;
			if(uin>1)
				uin=1;
			if(uin<-1)
				uin=-1;
			double time=0;
			try{ time=ins.get("time");}catch(Exception e) {}
			ud=0;
			int cnt=(int)(time/T);
			double tk=time-cnt*T;
			double dAlpha=(1-uin)*Math.PI/2;
			double  alphaA=(time*2*Math.PI)/(T+Double.MIN_VALUE);
			//System.out.println("alphaA="+Math.toDegrees(alphaA));
			uA=Uam*Math.sin(alphaA-dAlpha);
			uB=Uam*Math.sin(alphaA-2.0943-dAlpha);
			uC=Uam*Math.sin(alphaA-4.1885-dAlpha);
			double aa=alphaA;
			uaa=Uam*Math.sin(aa);
			ubb=Uam*Math.sin(aa-2.0943);
			ucc=Uam*Math.sin(aa-4.1885);
			if(tk>=0&&tk<T0) {
				ud=uC-uB;
			}
			if(tk>=T0&&tk<T1) {
				ud= uA-uB;
			   }
			if(tk>=T1&&tk<T2) {
				ud= uA-uC;
			}
			if(tk>=T2&&tk<T3) {
				 ud=uB-uC;
			}
			if(tk>=T3&&tk<T4) {
				ud=uB-uA;
			}
			if(tk>=T4&&tk<T5) {
				ud=uC-uA;
			}
			if(tk>=T5&&tk<T) {
				ud=uC-uB;
			}
			outs.put("ud",ud);
			outs.put("uaa",uaa);
			outs.put("ubb",ubb);
			outs.put("ucc",ucc);
		}catch(Exception e) {
			System.out.println("Ac3dcHandler:stride:"+e.toString());
		}
		return outs;
	}
	@Override
	public Hashtable<String, Double> getSettings() {
		Hashtable<String, Double> outs=new Hashtable<String, Double>();
		outs.put("Ku", Ku);
		outs.put("Tr", Tr);
		outs.put("Udm", Udm);
		outs.put("preferredClock", preferredClock);
		return outs;
	}
	@Override
	public void putSettings(Hashtable<String, Double> settings) {
	}
	@Override
	public Hashtable<String, Double> getOuts() {
		Hashtable<String, Double> outs=new Hashtable<String, Double>();
		outs.put("ud",ud);
		outs.put("uaa",uaa);
		outs.put("ubb",ubb);
		outs.put("ucc",ucc);
		return outs;
	}
	@Override
	public double getClock() {
		return clock;
	}
	@Override
	public void setClock(double clock) {
	this.clock=clock;
	}
	@Override
	public void setEntigrator(Entigrator entigrator) {
		this.entigrator=entigrator;
	}
}
