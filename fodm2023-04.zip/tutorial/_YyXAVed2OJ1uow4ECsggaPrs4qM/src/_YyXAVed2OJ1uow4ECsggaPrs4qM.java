import gdt.base.store.Entigrator;
public class _YyXAVed2OJ1uow4ECsggaPrs4qM implements StepHandler{
private final static String ENTITY_KEY="_YyXAVed2OJ1uow4ECsggaPrs4qM";
public _YyXAVed2OJ1uow4ECsggaPrs4qM(){} 
public void step(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reset(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reinit(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
}
