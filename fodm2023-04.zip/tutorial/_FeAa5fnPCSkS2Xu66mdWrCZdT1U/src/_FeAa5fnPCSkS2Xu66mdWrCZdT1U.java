import java.util.Hashtable;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PackHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _FeAa5fnPCSkS2Xu66mdWrCZdT1U  implements SegueController {
//sosPack
	private final static String ENTITY_KEY="_FeAa5fnPCSkS2Xu66mdWrCZdT1U";
PackHandler packHandler;
Entigrator entigrator;
 @Override
public void reset() {
if(entigrator==null) {
System.out.println(ENTITY_KEY+":reset:entigrator is null");
	return;
}
	try {
String packHandler$=PackHandler.classLocator();
String pack$=entigrator.getLabel(ENTITY_KEY);
packHandler$=Locator.append(packHandler$, Entigrator.ENTITY_LABEL, pack$);
packHandler=new PackHandler(entigrator,packHandler$);
packHandler.reset();
	}catch(Exception e) {
System.out.println(ENTITY_KEY+":reset:"+e.toString());
}
}
@Override
public Hashtable<String, Double> getSettings()  {
	return packHandler.getSettings();
	}
 @Override
public void putSettings(Hashtable<String, Double> set)  {}
 @Override
 public String[] listInputs(){
if(packHandler==null) {
reset();
   }
return packHandler.listInputs();
 }
@Override
public String[] listOutputs(){
    if(packHandler==null) {
     	reset();
     }
 	return packHandler.listOutputs();
 	}
 @Override
 public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
	Hashtable<String, Double>outs=packHandler.stride(ins);
 	if(outs==null) {
 		System.out.println(ENTITY_KEY+":stride:outs is null");
 	}
 	return outs;
 }
@Override
 public Hashtable<String, Double> getOuts() {
 	return packHandler.getOuts();
 }
 @Override
 public double getClock() {
 	return packHandler.getClock();
 }
 @Override
 public void setClock(double clock) {
 	packHandler.setClock(clock);
 }
 @Override
 public void setEntigrator(Entigrator entigrator) {
 	this.entigrator=entigrator;
 }
 }
