import gdt.base.store.Entigrator;
public class _3rYleCRkYAZ0a7KOJYRTpOmyb5o implements StepHandler{
private final static String ENTITY_KEY="_3rYleCRkYAZ0a7KOJYRTpOmyb5o";
public _3rYleCRkYAZ0a7KOJYRTpOmyb5o(){} 
public void step(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reset(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reinit(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
}
