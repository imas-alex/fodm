import java.util.Hashtable;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import gdt.base.store.Entigrator;

public class _fruUwhq48AMvVwMmuTz74Km4Rs4  implements SegueController {
//hpf
	double K=10;
	double T=1+Double.MIN_VALUE;
	double defaultClock=0.01;
	double clock=defaultClock;
	double z=0;
	double y=0;
	double a=K*T/(1+K*T);
	double b=1/(1+K*T);
	boolean closed=false;
	Entigrator entigrator;
	private final static String ENTITY_KEY="_fruUwhq48AMvVwMmuTz74Km4Rs4";

@Override
public void reset() {
	y=0;
	z=0;
}
@Override
public Hashtable<String, Double> getSettings() {
	Hashtable<String,Double> set=new Hashtable<String,Double> ();
	set.put("K", K);
	set.put("T", T);
	set.put("clock", clock);
	return set;
}

@Override
public String[] listInputs() {
	return new String[] {"x"};
}
@Override
public String[] listOutputs() {
	return new String[] {"y"};
}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
	boolean closed=false;
	 double open=1;
   try {open= ins.get("open");}catch(Exception e) {}
   try {clock= ins.get("clock");}catch(Exception e) {}
   if(open<0)
   	closed=true;
   double x=0;
   try {x= ins.get("x");}catch(Exception e) {}
   if(!closed)	{
	   y=K*x-z/T;
    }else {
	   y=a*x-b*z;
   }
   double dz=y*clock;
	z=z+dz;
    Hashtable<String,Double> outs=new Hashtable<String,Double>();
	outs.put("y", y);
	//System.out.println(ENTITY_KEY+" x="+x+"  y="+y);
    return outs;
}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double>outs=new Hashtable<String, Double>();
	outs.put("y",y);
	outs.put("z",z);
	return outs;
}
@Override
public double getClock() {
		return defaultClock;
}
@Override
public void setClock(double clock) {
	
		this.clock=clock;
	
}
@Override
public void setEntigrator(Entigrator entigrator) {
	// TODO Auto-generated method stub
	
}
@Override
public void putSettings(Hashtable<String, Double> settings) {
	// TODO Auto-generated method stub
	
}
}
