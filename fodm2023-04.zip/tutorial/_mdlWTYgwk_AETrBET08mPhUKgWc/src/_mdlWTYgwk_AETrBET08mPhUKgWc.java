import java.util.Hashtable;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _mdlWTYgwk_AETrBET08mPhUKgWc  implements SegueController {
//sosIntEdu
private final static String ENTITY_KEY="_mdlWTYgwk_AETrBET08mPhUKgWc";
double y=0;
//double T=22;
//double T=44;
double T=88;
double preferredClock=0.01;
double clock=preferredClock;
double nextTau=0;
Entigrator entigrator;
@Override
public void reset() {
	y=0;
	Sack entity=entigrator.getEntity(ENTITY_KEY);
	if(!entity.existsElement("operator"))
		entity.createElement("operator");
	entity.putElementItem("operator", new Core("out","y","0"));
	entigrator.putEntity(entity);
}
@Override
public Hashtable<String, Double> getSettings()  {
	Hashtable<String,Double> set=new Hashtable<String,Double> ();
	set.put("T", T);
	return set;
	}

@Override
public String[] listInputs(){
	return new String[] {"x"};
	}
@Override
public String[] listOutputs(){
	return new String[] {"y"};
	}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins){
//	System.out.println(ENTITY_KEY+" BEGIN");
boolean closed=false;
double open=1;
try {open= ins.get("open");}catch(Exception e) {}
try {clock= ins.get("clock");}catch(Exception e) {}
if(open<0)
	closed=true;
double x=0;
try {x= ins.get("x");}catch(Exception e) {}
//System.out.println(ENTITY_KEY+"stride: x="+x);
double dy;
if(!closed)
	dy=x*clock/T;
else
	dy=(x-y)*clock/T;	
y=y+dy;
Hashtable<String,Double> outs=new Hashtable<String,Double>();
outs.put("y", y);
// System.out.println(ENTITY_KEY+"stride: x="+x+"  y="+y);
return outs;
}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double>outs=new Hashtable<String, Double>();
	outs.put("y",y);
	return outs;
}
@Override
public double getClock() {
	return preferredClock;
}
@Override
public void setClock(double clock) {
		this.clock=clock;
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
	
}
@Override
public void putSettings(Hashtable<String, Double> settings) {
	// TODO Auto-generated method stub
	
}
}
