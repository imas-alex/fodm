import java.util.Hashtable;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
public class _M0jIMSoe3C28FgTmRA74Evejrqg  implements SegueController {
//sosSummator
	double dx=0;	
double Kx=1;
double Kxo=-1;
Entigrator entigrator;
private final static String ENTITY_KEY="_M0jIMSoe3C28FgTmRA74Evejrqg";
@Override
public void reset() {
	System.out.println(ENTITY_KEY+":reset:BEGIN");
	dx=0;
	Sack entity=entigrator.getEntity(ENTITY_KEY);
	if(!entity.existsElement("operator"))
		entity.createElement("operator");
	entity.putElementItem("operator", new Core("out","dx","0"));
	entity.putElementItem("operator", new Core("out","x","0"));
	entity.putElementItem("operator", new Core("out","x0","0"));
	entigrator.putEntity(entity);
}
@Override
public Hashtable<String, Double> getSettings()  {
	Hashtable<String, Double>settings=new Hashtable<String, Double>();
	settings.put("Kx",Kx);
	settings.put("Kxo",Kxo);
	return settings;
	}

@Override
public String[] listInputs(){
	return new String[] {"x","xo"};	
}
@Override
public String[] listOutputs(){
	return new String[] {"dx"};	
	}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins){
	//System.out.println(ENTITY_KEY+":stride:BEGIN");
	double x=0;
	try{x =ins.get("x");}catch(Exception ee) {}
	double xo=0;
	try{xo =ins.get("xo");}catch(Exception ee) {}
	dx=Kx*x+Kxo*xo;
	Hashtable<String, Double> outs=new Hashtable<String, Double> ();
	outs.put("dx", dx);
//	 System.out.println("------------------------");
 //   System.out.println(ENTITY_KEY+":stride:x="+x+"  xo="+xo+" dx="+dx);
	return outs;
	}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double> outs=new Hashtable<String, Double> ();
	outs.put("dx", dx);
	//System.out.println(ENTITY_KEY+":getOuts:dx="+dx);
	return outs;
}
@Override
public double getClock() {
	return 1;
}
@Override
public void setClock(double clock) {
	
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
	
}
@Override
public void putSettings(Hashtable<String, Double> settings) {
	// TODO Auto-generated method stub
	
}
}
