import gdt.base.store.Entigrator;
public class _jQFAAQqPLFOgeRLGU1PIOXtwIwg implements StepHandler{
private final static String ENTITY_KEY="_jQFAAQqPLFOgeRLGU1PIOXtwIwg";
public _jQFAAQqPLFOgeRLGU1PIOXtwIwg(){} 
public void step(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reset(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reinit(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
}
