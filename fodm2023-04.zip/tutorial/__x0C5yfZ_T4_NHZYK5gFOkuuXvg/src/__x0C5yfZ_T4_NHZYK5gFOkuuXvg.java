import java.util.Hashtable;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class __x0C5yfZ_T4_NHZYK5gFOkuuXvg  implements SegueController {
//currentLoopObject
	private final static String ENTITY_KEY="__x0C5yfZ_T4_NHZYK5gFOkuuXvg";
double Ta=0.011;
double Tr=0.00333;
double Ku=513;
double Ra=3.72;

double a=0;
double b=0;
double c=0;	
double g=0;
double preferredClock=0;
double clock=0;
double z=0;
double i=0;
double uc=0;
//double yr=0;
Hashtable<String, Double>settings=new Hashtable<String, Double>();
Sack entity;
Entigrator entigrator;
@Override
public void reset() {
	try {
		a=Ra*Ta*Tr/Ku;
		b=Ra*(Ta+Tr)/Ku;
		c=Ra/Ku;
		preferredClock=Ta/100;
		clock=preferredClock;
        if(!entity.existsElement(OperatorHandler.OPERATOR))
	        	entity.createElement(OperatorHandler.OPERATOR);
    	entity.putElementItem(OperatorHandler.OPERATOR, new Core("in","uc","0"));
	    entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","i","0"));
	    entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","z","0"));
	    entigrator.putEntity(entity);
	      
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+":reset:"+e.toString());
	}
}
@Override
public Hashtable<String, Double> getSettings()  {
	Hashtable<String, Double>settings=new Hashtable<String, Double>();
	settings.put("Ta", Ta);
	settings.put("Tr",Tr);
	settings.put("Ku",Ku);
	settings.put("Ra",Ra);
	return settings;
	
	}
@Override
public void putSettings(Hashtable<String, Double> set)  {}
@Override
public String[] listInputs(){
	String[] sa=new String[] {
			"uc"
	};
	return sa;
}
@Override
public String[] listOutputs(){
	String[] sa=new String[] {
			"i",
			"z"
	};
	return sa;
	}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
	Hashtable<String, Double> outs=new Hashtable<String, Double>();
	//EduHandler.printHashtableDouble(ENTITY_KEY+":stride:ins", ins);
	try {
	//input
	clock=ins.get("clock");
	uc=ins.get("uc");
	//object
	double dy=z*clock;
	double dz=(-b*z-c*i+uc)*clock/a;
	i=i+dy;
	z=z+dz;
	outs.put("i", i);
	outs.put("z", z);
	//EduHandler.printHashtableDouble(ENTITY_KEY+":stride:outs", outs);
	return outs;
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+"stride:"+e.toString());
		return null;
	}
}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double> outs=new Hashtable<String, Double>();
	outs.put("i", i);
	outs.put("z", z);
	return outs;
}
@Override
public double getClock() {
	return preferredClock;
}
@Override
public void setClock(double clock) {
	this.clock=clock;
	
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
	entity=entigrator.getEntity(ENTITY_KEY);
}
}
