import gdt.base.store.Entigrator;
import java.util.Hashtable;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _YKL1_S8sed_SnHQA8mSOwW94Bbveg  implements SegueController {
//bpf
private final static String ENTITY_KEY="_YKL1_S8sed_SnHQA8mSOwW94Bbveg";
double K1=10;
double T1=1;
double K2=1;
double T2=10;
double defaultClock=0.01;
double clock=defaultClock;

double a1=K1/(T1+Double.MIN_VALUE);
double b1=1/(T1+Double.MIN_VALUE);
double a2=K2/(T2+Double.MIN_VALUE);
double b2=1/(T2+Double.MIN_VALUE);

double y1=0;
double y2=0;
double z=0;
@Override
public void reset() {
	y1=0;
	y2=0;
	z=0;
}

@Override
public Hashtable<String, Double> getSettings()  {
	Hashtable<String,Double> set=new Hashtable<String,Double> ();
	set.put("K1", K1);
	set.put("T1", T1);
	set.put("K2", K2);
	set.put("T2", T2);
	return set;
	}
@Override
public String[] listInputs(){
	return new String[] {"x"};
	}
@Override
public String[] listOutputs(){
	return new String[] {"y"};
	}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins){
	boolean closed=false;
	Hashtable<String,Double> outs=new Hashtable<String,Double>();
	double open=1;
     try {open= ins.get("open");}catch(Exception e) {}
     try {clock= ins.get("clock");}catch(Exception e) {}
    try {open= ins.get("open");}catch(Exception e) {}
    if(open<0)
    	closed=true;
     double x=0;
     double dy1=0;
     try {x= ins.get("x");}catch(Exception e) {}
   	 z=z+y2*clock; 
   	if(!closed) 
   		y2=a2*x-b2*z;
   	else 
   		 y2=a2*(x-y1)-b2*z;
   	 dy1=(a1*y2 - b1*y1)*clock;
   	 y1=y1+dy1;
   	 outs.put("y", y1);
    return outs;
	}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double>outs=new Hashtable<String, Double>();
	outs.put("y",y1);
	outs.put("y2",y2);
	outs.put("z",z);
	return outs;
}
@Override
public double getClock() {
	return defaultClock;
}
@Override
public void setClock(double clock) {
		this.clock=clock;
}
@Override
public void setEntigrator(Entigrator entigrator) {
	// TODO Auto-generated method stub
}
@Override
public void putSettings(Hashtable<String, Double> settings) {
	// TODO Auto-generated method stub
}
}
