package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
public class MathUtil {
public static class M2{
		public double a11;
		public double a12;
		public double a21;
		public double a22;
		public M2(double a11,double a12,double a21,double a22){
		this.a11=a11;
			this.a12=a12;
			this.a21=a21;
			this.a22=a22;
	}
private M2 getMinor(){
	return new M2(a22,a21,a12,a11);
}
private M2 getCofactor(){
	return new M2(a11, -a12, -a21,a22);
}
private M2 getTranspose(){
   return new M2(a11,a21,a12,a22   );
}
private M2 divide(double factor){
	return new M2(a11/factor,a12/factor,a21/factor,a22/factor);
}
public M2 inverse(){
	 try{
			double det=  a11*a22-a12*a21;
			if(det==0)
				det =1E-5;
			M2 minor=getMinor();
			M2 cofactor=minor.getCofactor();
			M2 transpose=cofactor.getTranspose();
			return transpose.divide(det);	
		 }catch(Exception ee){
			 return null;
		 }
}
public M2 multiplication(M2  m2){
	    double b11=a11*m2.a11+a12*m2.a21;
	    double b12=a11*m2.a12+a12*m2.a22;
	   double b21=a21*m2.a11+a22*m2.a21;
	   double  b22= a21*m2.a12+ a22*m2.a22;
	   return new M2(b11,b12,b21,b22);
	}
public M2 add(M2  m2){
    double b11=a11+m2.a11;
    double b12=a12+m2.a12;
   double b21=a21+m2.a21;
   double  b22= a22+m2.a22;
   return new M2(b11,b12,b21,b22);
}
public M2 minus(){
    double b11= -a11;
    double b12= -a12;
   double b21= -a21;
   double  b22= -a22;
   return new M2(b11,b12,b21,b22);
}
public V2 product(V2 v){
	double x=a11*v.x+ a12*v.y;
	double y=a21*v.x+ a22*v.y;
	return new V2(x,y);
}
public V4 product(V4 v){
	return new V4(v.v1.product(a11).add(v.v2.product(a12)),v.v1.product(a21).add(v.v2.product(a22)));
}
public void print(String name$){
	System.out.println("M2    "+name$);
	System.out.println("a11= "+a11+"   a12="+a12+ "   a21="+a21+ "   a22="+a22); 
}
public static M2 rot(double angle) {
	double ar= (angle/180)*Math.PI;
	double cos=Math.cos(ar);
	double sin=Math.sin(ar);
	return new M2(cos,-sin,sin,cos);
}
	}
public static class Z{
		public double re;
		public double im;
		public Z( double re,double im){
			this.re=re;
			this.im=im;
		}
		public Z add(Z  z2){
			Z ret=new Z(0,0);
			ret.re=re+z2.re;
			ret.im=im+z2.im;
		   return ret;
	}	
		public Z inverse(){
			double det= re*re+im*im;
			if(det==0)
				return null;
			Z ret=new Z(0,0);
			ret.re=re/det;
			ret.im=-im/det;
			return ret;
		}
		public Z product(Z z){
			double a=re*z.re-im*z.im;
			double b=re*z.im+im*z.re;
			return new Z(a,b);
		}
		public V2 product(V2 v){
			V2 ret=new V2(0,0);
			ret.x=re*v.x-im*v.y;
			ret.y=re*v.y+im*v.x;
			return ret;
		}
		public Z product(double factor){
			Z ret=new Z(0,0);
			ret.re=re*factor;
			ret.im=im*factor;
			return ret;
		}
		public double norm() {
			return Math.sqrt(re*re+im*im);
		}
		public V2 unit() {
			double factor=norm();
			double cos=re/factor;
			double sin =im/factor;
			return new V2(cos,sin);
		}
		public V2 unit(V2 v) {
			double factor=norm();
			double cos=re/factor;
			double sin =im/factor;
			double x=v.x*cos-v.y*sin;
			double y=v.x*sin+v.y*cos;
			double m=Math.sqrt(x*x+y*y);
			return new V2(x/m,y/m);
		}
		public void print(String name$){
			System.out.println("MathUtil:Z="+name$+"  re="+re+ " im="+im);
		}
	}
public static class V2{
	public double x;
	public double y;
	public V2(double x,double y){
		this.x=x;
		this.y=y;
	}
	public  V2 add(V2 v){
		double x2=x+v.x;
		double y2=y+v.y;
		return new V2(x2,y2);	
}
	public double dotProduct(V2 v){
		double ret=x*v.x +  y*v.y;
		return ret;
	}
	public double crossProduct(V2 v){
		return (-x*v.y) + (y*v.x);
	}
	public double rotProduct(V2 z){
		double ret=-y*z.x +  x*z.y;
		return ret;
	}
	public V2 product(double factor){
		double x2=x*factor;
		double y2=y*factor;
		 return new V2(x2,y2);	
	}
	public V2   rotation(){
		return new V2(-y,x);
	}
	public V2   relative(V2 vo) {
		try{
		//	System.out.println("MathUtil:relative:this  x="+x+" y="+y+"   relative   x="+vo.x+"  y="+vo.y);
			double mod=Math.sqrt(vo.x*vo.x+vo.y*vo.y);
			double cos=vo.x/mod;
			double sin=vo.y/mod;
			M2 mo=new M2(cos,-sin,sin,cos);
			M2 moi=mo.inverse();
			V2 vr=moi.product(this);
			return vr;
		}catch(Exception e) {
			System.out.println("MathUtil:relative:"+e.toString());
		}
		return null;
	}
	public V2   rotation(double ag){
		double ar=Math.toRadians(ag);
		double cos=Math.cos(ar);
		double sin=Math.sin(ar);
		double x1=x*cos-y*sin;
		double x2=x*sin+y*cos;
		return new V2(x1,x2);
	}
	public V2 minus(){
		double x2=-x;
		double y2=-y;
		 return new V2(x2,y2);	
	}
	public double norm(){
		return Math.sqrt(x*x+y*y);
	}
	public M2 rotator() {
		double norm=Math.sqrt(x*x+y*y);
		double xn=x/norm;
		double yn=y/norm;
		return new M2 (xn, -yn,yn,xn);
	}
	public static  V2 restore(double norm,M2 rotator) {
		double x=norm*rotator.a11;
		double y=norm*rotator.a21;
		return new V2(x,y); 
	}
	public V2 unit(){
	    double norm=norm();	
	    if(norm==0)
	    	return new V2(0,0);
		return new V2(x/norm,y/norm);
	}
	public double angle(){
		double xa=Math.abs(x);
		double ya=Math.abs(y);
		double yxa=Math.atan(ya/xa);
		double xya=Math.atan(xa/ya);

		int q=0;
		if(x>=0) {
			if(y>=0) {
				if(xa>=ya)
					q=1;
				else
					q=2;
			}else {
				if(xa>=ya)
					q=8;
				else
					q=7;
			}
		}else {
			if(y>=0) {
				if(xa>=ya)
					q=4;
				else
					q=3;
			}else {
				if(xa>=ya)
					q=5;
				else
					q=6;
			}
		}
		double angle=0;
		switch(q) {
		case 1: angle= yxa;break;
		case 2: angle= Math.PI/2-xya;break;
		case 3: angle= Math.PI/2+xya;break;
		case 4: angle= Math.PI-yxa;break;
		case 5: angle= -Math.PI+yxa;break;
		case 6: angle= -Math.PI/2-xya;break;
		case 7: angle= -Math.PI/2+xya;break;
		case 8: angle= -yxa;
		}
	return Math.toDegrees(angle);	
	}
	public double angle(V2 v){
		M2 r=v.rotator().inverse().multiplication(rotator());
		V2 vv=new V2(r.a11,r.a12);
		return vv.angle();
	}
	public V2 resolveProjections(V2 v1,V2 v2) {
		try{
			M2 m=new M2(v1.x,v1.y,v2.x,v2.y);
			M2 mi=m.inverse();
			V2 ret=mi.product(this);
			return ret;
			}catch(Exception e) {
				System.out.println("MathUtil:V2:resolveProections:"+e.toString());
			}	
	return null;	
	}
	
public void print(String name$){
    System.out.println("MathUtil:V2: "+name$+ ":    x="+x+"  y="+y);
}
}
public static  class V4{
	public V2 v1;
	public V2 v2;
	public V4( V2 v1,V2 v2){
		this.v1=v1;
		this.v2=v2;
	}
	public V4 add(V4 v){
		V2 a=v1.add(v.v1);
		V2 b=v2.add(v.v2);
		return new V4(a,b);
	}
	public V4 product(double x){
		V2 a=v1.product(x);
		V2 b=v2.product(x);
		return new V4(a,b);
	}
	public V4 componentRotation(){
		V2 a=v1.rotation();
		V2 b=v2.rotation();
		return new V4(a,b);
	}
	
}
public static class V5{
	public double a0;
	public double a1;
	public double a2;
	public double a3;
	public double a4;
	public V5(double a0,double a1,double a2,double a3,double a4) {
		this.a0=a0;
		this.a1=a1;
		this.a2=a2;
		this.a3=a3;
		this.a4=a4;
	}
  public V5 scale(V5 v) {
	  return new V5(v.a0*a0,v.a1*a1,v.a2*a2,v.a3*a3,v.a4*a4);
  }
  public V5 subtract(V5 v) {
	  return new V5(a0-v.a0,a1-v.a1,a2-v.a2,a3-v.a3,a4-v.a4);
  }
  public double worth() {
	  return Math.abs(a0)+Math.abs(a1)+Math.abs(a2)+Math.abs(a3)+Math.abs(a4);
  }
  public double norm() {
	  return a0*a0+a1*a1+a2*a2+a3*a3+a4*a4;
	  //return worth();
  }
  public double getVal(int i) {
	  switch(i) {
	  case 0:
		  return a0;
	  case 1:
		  return a1;	
	  case 2:
		  return a2;
	  case 3:
		  return a3;
	  case 4:
		  return a4;			  
	  }
	  return 0;
	  
  }
  public V5 clone() {
	  return new V5(a0,a1,a2,a3,a4);  
  }
  public V5 product(double factor) {
	  return new V5(a0*factor,a1*factor,a2*factor,a3*factor,a4*factor);  
  }
  public void print(String name$) {
	  System.out.println("MathUtil:name="+name$+" a0="+a0+" a1="+a1+" a2="+a2+" a3="+a3+" a4="+a4);
  }
  public void print(String name$,String a0$,String a1$,String a2$,String a3$,String a4$) {
	  System.out.println("MathUtil:"+name$+","+a0$+"="+a0);
	  System.out.println("MathUtil:"+name$+","+a1$+"="+a1);
	  System.out.println("MathUtil:"+name$+","+a2$+"="+a2);
	  System.out.println("MathUtil:"+name$+","+a3$+"="+a3);
	  System.out.println("MathUtil:"+name$+","+a4$+"="+a4);
	
  }
}


}
