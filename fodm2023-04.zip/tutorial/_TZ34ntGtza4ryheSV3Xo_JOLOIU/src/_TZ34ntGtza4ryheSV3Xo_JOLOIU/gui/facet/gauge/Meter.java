package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.gauge;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Scanner;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

import javax.swing.JPanel;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Instrument;
public class Meter extends JPanel implements Instrument{
	public static final String SAVE_MODE="save mode";
	public static final String ONLY_VALUES="only values";
	ArrayList <Double> values;
	private String gaugeKey$;
	private static final long serialVersionUID = 1L;
	public static final int CANVAS_WIDTH  = 120;
	public static final int CANVAS_HEIGHT = 100;
	  String title$="Title";
	   String var$="Variable";
	   String unit$=null;
	  double value=0;
	  String factor$="";
	  boolean middle=true;
	  int beginArc=90;
	  int endArc=-45;
	  String format$="##.##"; 
	 // parameters  
	private    double valueMaximum=1;
	Entigrator entigrator;
	public Meter(Entigrator entigrator,String locator$) {
		super();
		this.entigrator=entigrator;
		values=new ArrayList <Double>();
		gaugeKey$=Locator.getProperty(locator$, Entigrator.ENTITY_KEY);
		if(gaugeKey$!=null) {
		Sack gauge=entigrator.getEntity(gaugeKey$);
		init(gauge);
		}
	}
	public Meter() {
		super();
		values=new ArrayList <Double>();
	}
	public void setGauge(Sack gauge) {
		init(gauge);
	}
	private void  init(Sack gauge) {
			var$=gauge.getElementItemAt("gauge", "variable");
			unit$=gauge.getElementItemAt("gauge", "unit");
			title$=gauge.getElementItemAt("gauge", "title");
			format$=gauge.getElementItemAt("gauge", "format");
			String nullpos$=gauge.getElementItemAt("gauge", "nullpos");
			if("middle".equals(nullpos$))
				middle=true;
			else
				middle=false;
			String maximum$=gauge.getElementItemAt("gauge", "maximum");
			valueMaximum=Double.parseDouble(maximum$); 
		}
	
	public String getKey(){
		return gaugeKey$;
	}
	@Override
	  protected void paintComponent(Graphics  g) {
		super.setPreferredSize(new Dimension(120,100));
       super.paintComponent(g);   
       setBackground(Color.BLACK);
      g.setColor(Color.DARK_GRAY);
      g.drawArc(5, 30, 100, 100, 0, 180);
      g.setColor(Color.red);
      int angle=(int)((value/valueMaximum)*180);
      if(middle){
    	   angle=(int)((value/valueMaximum)*90);
//System.out.println("Meter:paintComponent: value="+value+" valueMax="+valueMaximum+"  angle="+angle);
       	   if(angle>90)
        		   angle=90;
       	   if(angle<-90)
        		   angle=-90;
       if(angle>0){ 	   
        	 endArc=angle;
        	 beginArc=90-angle;
         }else{
        	//endArc=90-angle;
        	 endArc=-angle;
            beginArc=90;
        }
      }else{
    	  if(angle>180)
   		   angle=180;
  	   if(angle<0)
   		   angle=0;
    	  beginArc=180;
          endArc=-angle;
      }
          g.drawArc(5, 30, 100, 100, beginArc,endArc);
          if(middle){
          g.setColor(Color.lightGray);
          g.drawLine(54, 32,54, 40);
          g.setFont(new Font("Monospaced", Font.PLAIN, 10));
          g.drawString("0", 50, 50);
          }
      g.setColor(Color.lightGray);
      g.drawLine(5, 80,12,80);  
      g.drawLine(97, 80,104,80);  
       g.setFont(new Font("Monospaced", Font.PLAIN, 10));
     if(title$!=null)
        g.drawString(title$, 5, 15);
       if(unit$==null&&var$!=null)
         g.drawString(var$, 5, 25);
       else
    	 if(var$!=null&&var$.length()>0)  
    	     g.drawString(var$+"("+unit$+")", 5, 25);
       g.setColor(Color.WHITE);
       g.setFont(new Font("Monospaced", Font.PLAIN, 20));
       if(format$==null)
    	   format$="##.##";
       NumberFormat valFormat = new DecimalFormat(format$);
       g.drawString(valFormat.format(value), 15, 80);
	}
	@Override
	public Dimension   getPreferredSize(){
		return new Dimension(CANVAS_WIDTH,CANVAS_HEIGHT);
	}
	public void setMiddle(boolean middle){
		this.middle=middle;
	}
	public void setTitle(String operator$){
		this.title$=operator$;
	}
	public void setUnit(String unit$){
		this.unit$=unit$;
	}
	public void setFormat(String format$){
		this.format$=format$;
	}
	public void setVar(String out$){
		this.var$=out$;
	}
	public void setValueMaximum(double  maxValue){
		try{
			valueMaximum=maxValue;
		}catch(Exception e){
			System.out.println("Meter:setValueMaximum:"+e.toString());
		}
	}
	public void setValue(double value){
		this.value=value;
		values.add(value);
		repaint();
		//System.out.println("Meter:setValue:key="+key$+"  value="+value+"  values="+values.size());
	}
	public void showValue(int index){
		int cnt=values.size();
		if(index<0||index>cnt-1)
			return;
		if(index<0||index>cnt)
			value=0;
		else
			value=values.get(index);
    	repaint();
	}
	@Override
	public void revise(Entigrator entigrator, String locator$) {
	try {
	//	System.out.println("Meter:revise:locator="+locator$);
		String mode$=UPDATE;
		if(locator$!=null)
			mode$=Locator.getProperty(locator$, MODE);
		if(RESET.equals(mode$)) {
			setValue(0);
			values.clear();
			return;
		}
		if(SHOW.equals(mode$)) {
			try {
			String  index$=Locator.getProperty(locator$, INDEX);
			int index=Integer.parseInt(index$);
			int cnt=values.size();
			if(index>cnt-1)
				index=cnt-1;
			showValue(index);
			}catch(Exception e) {
				System.out.println("Meter:revise:show:"+e.toString());
			}
			return;
		}
		double value=0;
         try {
         Sack meter=entigrator.getEntity(gaugeKey$);
 		 String value$= meter.getElementItemAt(OperatorHandler.OPERATOR, "in");
 		 value=Double.parseDouble(value$);
         }catch(Exception e) {}
		setValue(value);
		}catch(Exception e) {
			System.out.println("Meter:revise:"+e.toString());
		}
	}
	@Override
	public void associate(Entigrator entigrator, String locator$) {
		try {
			gaugeKey$=Locator.getProperty(locator$, Entigrator.ENTITY_KEY);
			if(gaugeKey$!=null) {
			Sack gauge=entigrator.getEntity(gaugeKey$);
			init(gauge);
			}
			}catch(Exception e) {
				System.out.println("Meter:associate:"+e.toString());
			}
	}
	public ArrayList<Double> getValues(){
		return values;
	}
	public void save(Entigrator entigrator,String locator$){
		try{
		//	System.out.println("Meter:save:gauge key="+gaugeKey$);
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String saveMode$=Locator.getProperty(locator$,SAVE_MODE);
			String entityKey$=entigrator.getKey(entity$); 
	        PrintWriter writer =null;
			String recordHome$=entigrator.getEntihome()+"/"+entityKey$;
			if(gaugeKey$==null)
				gaugeKey$="timer";
			File record=new File(recordHome$+"/"+gaugeKey$+".val");
			record.createNewFile();
		    writer = new PrintWriter(new BufferedWriter(new FileWriter(record.getPath(), true)));
		   int cnt=0; 
//		   System.out.println("TubePanel:savePoints:rays="+rays.size()+" points="+psize);
		   String value$;
		   String cnt$;
		   String line$;
		   for(Double v:values) {
			  cnt$=String.valueOf(cnt);
			  value$=String.valueOf(v);
			  line$=cnt$+";"+value$;
			  writer.println(line$);	
			  cnt++;
		   }
			writer.close();
		  if(ONLY_VALUES.equals(saveMode$)) {
			  return;
		  }
		  if(!gaugeKey$.equals("timer")) { 
		  String gaugePath$=recordHome$+"/"+gaugeKey$+".gauge";
		  Sack gauge=entigrator.getEntity(gaugeKey$);
		  gauge.saveXML(gaugePath$);
		 }
		}catch(Exception e){
			System.out.println("Meter:save:"+e.toString());
		}
	}
	public void restoreValues(String record$){
	 	try{
			String line$="";
			Scanner sc = null;
			File record=new File(record$);
			FileInputStream inputStream = new FileInputStream(record.getPath());
		    sc = new Scanner(inputStream, "UTF-8");
		    double value=0;
	//	    int cnt=0;
            String[] ia;
		    while (sc.hasNextLine()) {
		    	line$ = sc.nextLine();
		        ia=line$.split(";");
		        value=Double.parseDouble(ia[1]);
		        values.add(value);
		    }
		    inputStream.close();
		    sc.close();
		   	}catch(Exception e){
		   		System.out.println("Meter:restoreValues:"+e.toString());
		   	}
	}
	public static Meter restore(String recordHome$,String gaugeKey$) {
		try {
		Meter meter=new Meter();
		Sack gauge=Sack.readXml(recordHome$+"/"+gaugeKey$+".gauge");
		meter.setGauge(gauge);
		meter.restoreValues(recordHome$);
		return meter;
		}catch(Exception e) {
			System.out.println("Meter:restore:"+e.toString());
			return null;
		}
	}
	public void setLastValue() {
		if(values!=null) {
			double last=values.get(values.size()-1);
			setValue(last);
		}
	}
	@Override
	public void reset(Entigrator entigrator) {
	}
	@Override
	public void revise(Entigrator entigrator) {
		try {
		//	 System.out.println("Meter:revise:gauge key="+gaugeKey$+"   title="+title$);	
		if(gaugeKey$==null)
			return;
		Sack gauge=entigrator.getEntity(gaugeKey$);
		String value$=gauge.getElementItemAt("operator", "in");
		double value=Double.parseDouble(value$);
		// System.out.println("Meter:revise:value="+value$);
		setValue(value);
		}catch(Exception e) {
			 System.out.println("Meter:revise:"+e.toString()); 	
		}
	}
	@Override
	public void revise(Entigrator entigrator,int cnt) {
	}
	@Override
	public void saveRecord(Entigrator entigrator,String recordHome$) {
	   PrintWriter writer =null;
      if(gaugeKey$==null)
			gaugeKey$="timer";
	   File record=new File(recordHome$+"/"+gaugeKey$+".val");
	   try {
	   record.createNewFile();
	   writer = new PrintWriter(new BufferedWriter(new FileWriter(record.getPath(), true)));
	   int cnt=0; 
//	   System.out.println("TubePanel:savePoints:rays="+rays.size()+" points="+psize);
	   String value$;
	   String cnt$;
	   String line$;
	   for(Double v:values) {
		  cnt$=String.valueOf(cnt);
		  value$=String.valueOf(v);
		  line$=cnt$+";"+value$;
		  writer.println(line$);	
		  cnt++;
	   }
		writer.close();
	   String gaugePath$=recordHome$+"/"+gaugeKey$+".gauge";
	   Sack gauge=entigrator.getEntity(gaugeKey$);
	   gauge.saveXML(gaugePath$);
	   }catch(Exception e) {
		   System.out.println("Meter:save:"+e.toString()); 
	   }
	}
}
