package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.pack;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PackHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Connection;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JGuiEditor;
public class JPackEditor extends JGuiEditor{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_fy3vMT8zwM8wtNH0J_SdC8dKMFOc";
	JTabbedPane tabbedPane;
	private JComboBox<String> cbxComponent;
	private JComboBox<String> cbxSource;
	private JComboBox<String> cbxOutput;
	private JComboBox<String>  cbxConsumer; 
	private JComboBox<String> cbxInput;
	private JList<String> listComponents;
	
	private JTable  tblConnect; 
	private JButton  btnAddConnection;
	private JComboBox<String> cbxUnit;
	private JComboBox<String> cbxType;
	private JComboBox<String> cbxPin;
	private JButton  btnAddBond;
	private JTextField txtVar;
	private JTable tblBond;
	JPanel tblBonds;
	protected Entigrator entigrator;
	private Sack entity;
	private PackHandler packHandler;
	JPanel bonds;
	public JPackEditor(JMainConsole console,String alocator$) {
		super(console,alocator$);
		instance$=getInstance();
		parent$=Locator.getProperty(alocator$, PARENT);
		if(parent$!=null)
		 locator$=Locator.append(locator$, PARENT, parent$);
		entigrator=console.getEntigrator();
		packHandler=new PackHandler(entigrator,locator$);
		String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		entity=entigrator.getEntityAtLabel(entityLabel$);
		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);	
		 tabbedPane.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) { 
					try{
						JTabbedPane sourceTabbedPane = (JTabbedPane) e.getSource();
				        int index = sourceTabbedPane.getSelectedIndex();
				       // System.out.println("Tab changed to: " + sourceTabbedPane.getTitleAt(index));
						String title$= sourceTabbedPane.getTitleAt(index);
				        if("Commutator".equals(title$)){
				        	initSources();
				        	initOutput();
				        	initConsumers();
				        	initInput();
				        	initConnectionButtons();
				        	replaceTable();
				        }
				        if("Assembler".equals(title$)){
				        	updateComponents();
				        }
				        if("In/Out".equals(title$)){
				            initUnits();
				        	initPins();
				        	setAddBondButton();
				        	refreshBondTable();
				        }
					}catch(Exception ee){}
				}
		 	});
		add(tabbedPane);
		JPanel collector = new JPanel();
		tabbedPane.addTab("Assembler", null, collector, null);
		GridBagLayout gbl_collector=new GridBagLayout();
		collector.setLayout(gbl_collector);
	    GridBagConstraints gbc_controls = new GridBagConstraints();
		gbc_controls.fill = GridBagConstraints.BOTH;
				gbc_controls.weightx = 0.1;
				gbc_controls.gridwidth = 3;
				gbc_controls.gridx =0;
				gbc_controls.gridy = 0;
		  JPanel controls = new JPanel();	
		  controls.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		  controls.setLayout(new GridBagLayout());
		  collector.add(controls, gbc_controls);
		  
		  JLabel lblComponent = new JLabel("Component");
		  GridBagConstraints gbc_lblComponent = new GridBagConstraints();
		  gbc_lblComponent.insets = new Insets(0, 0, 5, 5);
			gbc_lblComponent.weightx = 0.0;
			gbc_lblComponent.weighty = 0.0;
			gbc_lblComponent.gridwidth = 1;
			gbc_lblComponent.gridx = 0;
			gbc_lblComponent.gridy = 0;
		  controls.add(lblComponent, gbc_lblComponent);

		 cbxComponent = new JComboBox<String>();
		 cbxComponent.setModel(new DefaultComboBoxModel<String>(new String[] {""}));
		 GridBagConstraints gbc_cbxComponent = new GridBagConstraints();
		 gbc_cbxComponent.insets=new Insets(3, 3, 5, 5);
			gbc_cbxComponent.fill = GridBagConstraints.HORIZONTAL;
			gbc_cbxComponent.weightx = 0.5;
			gbc_cbxComponent.weightx = 0.1;
			gbc_cbxComponent.gridwidth = 1;
			gbc_cbxComponent.gridx = 1;
			gbc_cbxComponent.gridy = 0;
		  controls.add(cbxComponent, gbc_cbxComponent);
	
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addComponent();
			}
			});
		 GridBagConstraints gbc_btnAdd = new GridBagConstraints();
		 gbc_btnAdd.insets = new Insets(0, 0, 0, 5);
		 gbc_btnAdd.gridx = 2;
		 gbc_btnAdd.gridy = 0;
		 controls.add(btnAdd, gbc_btnAdd);

		  GridBagConstraints gbc_list = new GridBagConstraints();
			gbc_list.fill = GridBagConstraints.BOTH;
					gbc_list.weightx = 0.5;
					gbc_list.weighty = 0.5;
					gbc_list.ipady = 40;      //make this component tall
					gbc_list.weightx = 0.0;
					gbc_list.gridwidth = 3;
					gbc_list.gridx =0;
					gbc_list.gridy = 1;
		
			listComponents = new JList<String>();
			listComponents.setBorder(new CompoundBorder(null, new BevelBorder(BevelBorder.LOWERED, null, null, null, null)));
			listComponents.setLayout(new GridBagLayout());
			listComponents.addMouseListener( new MouseAdapter() {
			   
				public void mousePressed(MouseEvent e) {
			        if ( SwingUtilities.isRightMouseButton(e) ) {      
			          	listComponents.setSelectedIndex(listComponents.locationToIndex(e.getPoint()));
			            JPopupMenu menu = new JPopupMenu();
			            JMenuItem itemOpen = new JMenuItem("Open");
			            itemOpen.addActionListener(new ActionListener() {
			                public void actionPerformed(ActionEvent e) {
			             try{   	
			              String servicesLocator$=JEntityFacetList.classLocator();
			              String operLabel$=listComponents.getSelectedValue();
			              Sack oper=console.getEntigrator().getEntityAtLabel(operLabel$);
			              if(oper==null) {
			            	  System.out.println("JPackEditor:cannot find entity="+operLabel$);
			            	  return;
			              }
			              servicesLocator$=Locator.append(servicesLocator$, Entigrator.ENTITY_LABEL, listComponents.getSelectedValue());
			              JEntityFacetList entityFacetList=new JEntityFacetList(console,servicesLocator$);
						  JDisplay display=new JDisplay(console);
						  display.putContext(entityFacetList);
						  display.setLocationRelativeTo(JPackEditor.this);
						  display.setVisible(true);
						  display.pack();
						  display.revalidate();
						  display.repaint();
						  entityFacetList.rebuild(console);
			             }catch(Exception ee){
			            	 System.out.println("JCduEditor:"+e.toString());
			             }
		                }
			            });
			            menu.add(itemOpen);
			            JMenuItem itemRemove = new JMenuItem("Remove");
			            itemRemove.addActionListener(new ActionListener() {
			                public void actionPerformed(ActionEvent e) {
			                	int response = JOptionPane.showConfirmDialog(collector, "Delete selected components  ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					  		    if (response == JOptionPane.YES_OPTION) 
					  		    	removeComponent(listComponents.getSelectedValue());
			                }
			            });
			            menu.add(itemRemove);
			            JMenuItem itemCancel = new JMenuItem("Cancel");
			            itemCancel.addActionListener(new ActionListener() {
			                public void actionPerformed(ActionEvent e) {
			                }
			            });
			            menu.add(itemCancel);
						String operLabel$=listComponents.getSelectedValue();
		           		String operKey$=entigrator.getKey(operLabel$);
						Sack oper=entigrator.getEntity(operKey$);
						if(oper==null) {
							System.out.println("JhainEditor:cannot find entity="+ operLabel$);
						}else {
						if("tube".equals(oper.getProperty("entity"))) {
							String hide$=oper.getElementItemAt("tube", "hide");
							if("true".equals(hide$)) {
								JMenuItem itemShow = new JMenuItem("Show");
					            itemShow.addActionListener(new ActionListener() {
					                public void actionPerformed(ActionEvent e) {
					                	oper.putElementItem("tube", new Core(null,"hide","false"));
					                	entigrator.putEntity(oper);
					                }
					            });
					            menu.add(itemShow);
							}else {
								JMenuItem itemHide = new JMenuItem("Hide");
					            itemHide.addActionListener(new ActionListener() {
					                public void actionPerformed(ActionEvent e) {
					                	oper.putElementItem("tube", new Core(null,"hide","true"));
					                	entigrator.putEntity(oper);
					                }
					            });
					            menu.add(itemHide);
							}
						}
						}
			            menu.show(listComponents, e.getPoint().x, e.getPoint().y);            
			        }
			    }
			});
		collector.add(listComponents, gbc_list);
		JPanel connector = new JPanel();
		tabbedPane.addTab("Commutator", null, connector, null);

		GridBagLayout gbl_connector=new GridBagLayout();
		gbl_connector.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0};
		gbl_connector.columnWeights = new double[]{1.0, 0.0, 0.0};
		 connector.setLayout( gbl_connector);
		 
		    GridBagConstraints gbc_outputs = new GridBagConstraints();
		    gbc_outputs.insets = new Insets(0, 0, 5, 5);
			gbc_outputs.fill = GridBagConstraints.HORIZONTAL;
			gbc_outputs.weightx = 0.2;
			gbc_outputs.gridwidth = 3;
			gbc_outputs.gridx =0;
			gbc_outputs.gridy = 0;
			
			  JPanel out = new JPanel();	
			  out.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Out", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
			  GridBagLayout gbl_out = new GridBagLayout();
			  out.setLayout(gbl_out);
			  connector.add(out, gbc_outputs);
			  
			  JLabel lblSource = new JLabel("Source");
			  GridBagConstraints gbc_lblSource = new GridBagConstraints();
			  gbc_lblSource.insets = new Insets(0, 0, 5, 5);
				gbc_lblSource.weightx = 0.5;
				gbc_lblSource.weightx = 0.0;
				gbc_lblSource.gridwidth = 1;
				gbc_lblSource.gridx = 0;
				gbc_lblSource.gridy = 0;
				gbc_lblSource.anchor=GridBagConstraints.LAST_LINE_START;
				out.add(lblSource, gbc_lblSource);
			
			 cbxSource = new JComboBox<String>();
			 cbxSource.addActionListener(new ActionListener() {
			 	public void actionPerformed(ActionEvent e) {
		           initOutput();
		           initConnectionButtons(); 
			 	}
			 });
			
			 GridBagConstraints gbc_cbxSource = new GridBagConstraints();
			   gbc_cbxSource.insets=new Insets(3, 3, 5, 3);
				gbc_cbxSource.fill = GridBagConstraints.HORIZONTAL;
				gbc_cbxSource.weightx = 0.5;
				gbc_cbxSource.weighty = 0.1;
				gbc_cbxSource.gridwidth = 1;
				gbc_cbxSource.gridx = 1;
				gbc_cbxSource.gridy = 0;
				gbc_cbxSource.anchor=GridBagConstraints.LINE_START;
			    out.add(cbxSource, gbc_cbxSource);
			    
			    JLabel lblOutput = new JLabel("Output");
				  GridBagConstraints gbc_lblOutput  = new GridBagConstraints();
				  gbc_lblOutput.insets = new Insets(0, 0, 5, 5);
				  gbc_lblOutput .weightx = 0.0;
					gbc_lblOutput .weighty = 0.0;
					gbc_lblOutput .gridwidth = 1;
					gbc_lblOutput.gridx = 0;
					gbc_lblOutput.gridy = 1;
					gbc_lblOutput.anchor= GridBagConstraints.LINE_START;
				  out.add(lblOutput, gbc_lblOutput);
				
				 cbxOutput = new JComboBox<String>();
				 cbxOutput.addActionListener(new ActionListener() {
				 	public void actionPerformed(ActionEvent e) {
				 		initConnectionButtons();
				 	}
				 });
				 GridBagConstraints gbc_cbxOutput = new GridBagConstraints();
				 gbc_cbxOutput.insets=new Insets(3, 3, 5, 3);
					gbc_cbxOutput.fill = GridBagConstraints.HORIZONTAL;
					gbc_cbxOutput.weightx = 1.0;
					gbc_cbxOutput.gridx = 1;
					gbc_cbxOutput.gridy = 1;
				    out.add(cbxOutput, gbc_cbxOutput);
				
				    JPanel in = new JPanel();	
					  in.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "In", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
					  in.setLayout(new GridBagLayout());
					  GridBagConstraints gbc_inputs = new GridBagConstraints();
					  gbc_inputs.insets = new Insets(0, 0, 5, 5);
						gbc_inputs.fill = GridBagConstraints.BOTH;
						gbc_inputs.weightx = 0.2;
						gbc_inputs.gridwidth = 3;
						gbc_inputs.gridx =0;
						gbc_inputs.gridy = 1;
					  connector.add(in, gbc_inputs);
					  
					  JLabel lblConsumer = new JLabel("Consumer");
					  GridBagConstraints gbc_lblConsumer = new GridBagConstraints();
						gbc_lblConsumer.weightx = 0.5;
						gbc_lblConsumer.weightx = 0.0;
						gbc_lblConsumer.gridwidth = 1;
						gbc_lblConsumer.gridx = 0;
						gbc_lblConsumer.gridy = 0;
					  in.add(lblConsumer, gbc_lblConsumer);
					  
					 cbxConsumer = new JComboBox<String>();
					 cbxConsumer.addActionListener(new ActionListener() {
						 	public void actionPerformed(ActionEvent e) {
				           initInput();
				        	initConnectionButtons(); 
						 	}
						 });
						
					 GridBagConstraints gbc_cbxConsumer = new GridBagConstraints();
					   gbc_cbxConsumer.insets=new Insets(3,3,3,3);
						gbc_cbxConsumer.fill = GridBagConstraints.HORIZONTAL;
						gbc_cbxConsumer.weightx = 0.5;
						gbc_cbxConsumer.weighty = 0.1;
						gbc_cbxConsumer.gridwidth = 1;
						gbc_cbxConsumer.gridx = 1;
						gbc_cbxConsumer.gridy = 0;
					    in.add(cbxConsumer, gbc_cbxConsumer);
					    
					    JLabel lblInput = new JLabel("Input");
						  GridBagConstraints gbc_lblInput  = new GridBagConstraints();
						  gbc_lblInput .weightx = 0.5;
							gbc_lblInput .weightx = 0.0;
							gbc_lblInput .gridwidth = 1;
							gbc_lblInput.gridx = 0;
							gbc_lblInput.gridy = 1;
						  in.add(lblInput, gbc_lblInput);
						
						 cbxInput = new JComboBox<String>();
						 cbxInput.addActionListener(new ActionListener() {
						 	public void actionPerformed(ActionEvent e) {
						 	 	initConnectionButtons();
						 	}
						 });
						 GridBagConstraints gbc_cbxInput = new GridBagConstraints();
						 gbc_cbxInput.insets=new Insets(3,3,3,3);
							gbc_cbxInput.fill = GridBagConstraints.HORIZONTAL;
							gbc_cbxInput.weightx = 0.5;
							gbc_cbxInput.weightx = 0.1;
							gbc_cbxInput.gridwidth = 1;
							gbc_cbxInput.gridx = 1;
							gbc_cbxInput.gridy = 1;
						    in.add(cbxInput, gbc_cbxInput);

						    JPanel edit = new JPanel();	
							 edit.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Connection", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 255)));
							 GridBagConstraints gbc_edit = new GridBagConstraints();
							 gbc_edit.insets = new Insets(0, 0, 5, 5);
								gbc_edit.fill = GridBagConstraints.BOTH;
								gbc_edit.weightx = 0.2;
								gbc_edit.gridwidth = 3;
								gbc_edit.gridx =0;
								gbc_edit.gridy = 2;
							  connector.add(edit, gbc_edit);
							
							  btnAddConnection = new JButton("Add");
							  btnAddConnection.addActionListener(new ActionListener() {
							  	public void actionPerformed(ActionEvent e) {
							  	  String source$=(String)cbxSource.getSelectedItem();
							  	 String output$=(String)cbxOutput.getSelectedItem();
							  	 String consumer$=(String)cbxConsumer.getSelectedItem();
							  	 String input$=(String)cbxInput.getSelectedItem();
							  	 Connection connection=new Connection(entity,source$,output$,consumer$, input$);
							  	 if(!connection.alreadyInserted(entity)){
							  		 entity=connection.insert(entity);entigrator.putEntity(entity);
							  		 entigrator.putEntity(entity);
							  		 initConnectionButtons();
							  		 replaceTable();
							  	 }
							  	}
							  });
							  GridBagConstraints gbc_addConnection= new GridBagConstraints();
							  gbc_addConnection.weightx = 0.5;
							  gbc_addConnection.weightx = 0.0;
							  gbc_addConnection.gridwidth = 1;
							  gbc_addConnection.gridx = 1;
							 gbc_addConnection.gridy = 0;
							 edit.add(btnAddConnection, gbc_addConnection);
							 
							  JButton btnClear = new JButton("Clear");
							  btnClear.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										int response = JOptionPane.showConfirmDialog(collector, "Delete all connections' ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
							  		    if (response == JOptionPane.YES_OPTION) {
							  		    	    entity.clearElement("connection");
						            	    	entigrator.putEntity(entity);
						            	    	replaceTable();
								            	initConnectionButtons();
						            	    }
									}
									});
							 GridBagConstraints gbc_btnClear = new GridBagConstraints();
							 gbc_btnClear.insets = new Insets(0, 0, 0, 5);
					 			gbc_btnClear.gridx = 0;
								gbc_btnClear.gridy = 0;
							edit.add(btnClear, gbc_btnClear);

							JScrollPane scrConnect=new JScrollPane();
							 GridBagConstraints gbc_scrConnect = new GridBagConstraints();
							 gbc_scrConnect.insets = new Insets(0, 0, 0, 5);
							 gbc_scrConnect.fill = GridBagConstraints.BOTH;
							 gbc_scrConnect.gridx = 0;
							 gbc_scrConnect.gridy = 3;
							 gbc_scrConnect.gridwidth=3;
							 connector.add(scrConnect, gbc_scrConnect);
							 
							 tblConnect = new JTable();
							 tblConnect.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
							 tblConnect.setModel(new DefaultTableModel(
							  	new Object[][] {
							  	},
							  	new String[] {
							  		"Source", "Output", "Consumer", "Input","Closed"
							  	}
							  ));
							   JTableHeader header = tblConnect.getTableHeader();
							   header.addMouseListener(new MouseAdapter() {
								    @Override
								    public void mouseClicked(MouseEvent e) {
								        int col =tblConnect.columnAtPoint(e.getPoint());
								        Connection [] cona=Connection.getConnections(entigrator,entity);
								        cona=Connection.sortConnections(cona, col);
								    }
								});
							   final JPopupMenu popupMenu = new JPopupMenu();
						      JMenuItem deleteItem = new JMenuItem("Delete");
						      deleteItem.addActionListener(new ActionListener() {
						            @Override
						            public void actionPerformed(ActionEvent e) {
						            	if(tblConnect.getSelectedRow()<0){
						            		JOptionPane.showMessageDialog(collector, "No selection");
						            		return;
						            	}
						            	int response = JOptionPane.showConfirmDialog(collector, "Delete selected connections' ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
							  		    if (response == JOptionPane.YES_OPTION) {
						            	     String[] sa=new String[5];
						            		     int row=tblConnect.getSelectedRow();
						            	     sa[0]=(String)tblConnect.getModel().getValueAt(row, 0);
						            	     sa[1]=(String)tblConnect.getModel().getValueAt(row, 1);
						            	     sa[2]=(String)tblConnect.getModel().getValueAt(row, 2);
						            	     sa[3]=(String)tblConnect.getModel().getValueAt(row, 3);
						            	     String connKey$=Connection.getKey(sa, entity);
						            	    // System.out.println("JCduEditor:delete connection:connection key="+connKey$);
						            	     if(connKey$!=null){
						            	    	entity.removeElementItem("connection",connKey$);
						            	    	entigrator.putEntity(entity);
						            	    }
						            	replaceTable();
						            	initConnectionButtons();
						            }}
						        });
						        popupMenu.add(deleteItem);
						        JMenuItem closedItem = new JMenuItem("Change closed");
						        closedItem.addActionListener(new ActionListener() {
							            @Override
							            public void actionPerformed(ActionEvent e) {
							            	if(tblConnect.getSelectedRow()<0){
							            		JOptionPane.showMessageDialog(collector, "No selection");
							            		return;
							            	}
					            	   //  String[] sa=new String[5];
						            		     int row=tblConnect.getSelectedRow();
							            	     String source$=(String)tblConnect.getModel().getValueAt(row, 0);
							            	     String output$=(String)tblConnect.getModel().getValueAt(row, 1);
							            	     String consumer$=(String)tblConnect.getModel().getValueAt(row, 2);
							            	     String input$=(String)tblConnect.getModel().getValueAt(row, 3);
							            	     Connection con=Connection.getConnection(entity, source$,output$,consumer$,input$);
							            	     if("true".equals(con.closed$)) 
							            	    	 con.closed$="false";
							            	     else
							            	        con.closed$="true";
							            	    // System.out.println("JCduEditor:changed closed="+con.closed$);
							            	     con.insert(entity);
							            	    
							            	     console.getEntigrator().putEntity(entity);
							            	     replaceTable();
							            	initConnectionButtons();
							            }
							        });
							        popupMenu.add(closedItem);
						        
						        tblConnect.setComponentPopupMenu(popupMenu);
							    scrConnect.setViewportView(tblConnect);
							   
								bonds = new JPanel();
								tabbedPane.addTab("In/Out", null, bonds, null);
								GridBagLayout gbl_settings = new GridBagLayout();
								gbl_settings.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0,1.0};
								gbl_settings.columnWeights = new double[]{0.0,  1.0};
								bonds.setLayout(gbl_settings);
								
								GridBagConstraints gbc_lblType = new GridBagConstraints();
								gbc_lblType.insets = new Insets(0, 0, 5, 5);
								gbc_lblType.anchor=GridBagConstraints.LINE_START;
								gbc_lblType.gridx =0;
								gbc_lblType.gridy = 0;
								JLabel lblType=new JLabel("Type");
								bonds.add(lblType,gbc_lblType);
							   
								GridBagConstraints gbc_cbxType = new GridBagConstraints();
								gbc_cbxType.insets = new Insets(0, 0, 5, 0);
								gbc_cbxType.fill = GridBagConstraints.HORIZONTAL;
								gbc_cbxType.gridx =1;
								gbc_cbxType.gridy = 0;
								cbxType=new JComboBox<String>();
								cbxType.setModel(new DefaultComboBoxModel<String>(new String[] {"In", "Out"}));
								cbxType.addItemListener(new ItemListener() {
								    public void itemStateChanged(ItemEvent arg0) {
								        initUnits();
								        initPins();
								        setAddBondButton();
								    }
								});
								bonds.add(cbxType,gbc_cbxType);
								JLabel lblUnit=new JLabel("Unit");
								GridBagConstraints gbc_lblUnit = new GridBagConstraints();
								gbc_lblUnit.insets = new Insets(0, 0, 5, 5);
								//gbc_lblUnit.fill = GridBagConstraints.HORIZONTAL;
								gbc_lblUnit.anchor=GridBagConstraints.LINE_START;
								gbc_lblUnit.gridx =0;
								gbc_lblUnit.gridy = 1;
								bonds.add(lblUnit,gbc_lblUnit);
								
								GridBagConstraints gbc_cbxUnit = new GridBagConstraints();
								gbc_cbxUnit.insets = new Insets(0, 0, 5, 0);
								gbc_cbxUnit.fill = GridBagConstraints.HORIZONTAL;
								gbc_cbxUnit.gridx =1;
								gbc_cbxUnit.gridy = 1;
								cbxUnit=new JComboBox<String>();
								cbxUnit.addItemListener(new ItemListener() {
								    public void itemStateChanged(ItemEvent arg0) {
								    	initPins();
								        setAddBondButton();
								    }
								});
								bonds.add(cbxUnit,gbc_cbxUnit);
								
								GridBagConstraints gbc_lblName = new GridBagConstraints();
								gbc_lblName.insets = new Insets(0, 0, 5, 5);
								gbc_lblName.anchor=GridBagConstraints.LINE_START;
								gbc_lblName.gridx =0;
								gbc_lblName.gridy = 2;
								JLabel lblName=new JLabel("Pin");
								bonds.add(lblName,gbc_lblName);
							   
								GridBagConstraints gbc_cbxName = new GridBagConstraints();
								gbc_cbxName.insets = new Insets(0, 0, 5, 0);
								gbc_cbxName.fill = GridBagConstraints.HORIZONTAL;
								gbc_cbxName.gridx =1;
								gbc_cbxName.gridy = 2;
								cbxPin=new JComboBox<String>();
								cbxPin.addItemListener(new ItemListener() {
								    public void itemStateChanged(ItemEvent arg0) {
								        refreshSelector();
								    }
								});
								bonds.add(cbxPin,gbc_cbxName);
								
								GridBagConstraints gbc_lblVar = new GridBagConstraints();
								gbc_lblVar.insets = new Insets(0, 0, 5, 5);
								gbc_lblVar.anchor=GridBagConstraints.LINE_START;
								gbc_lblVar.gridx =0;
								gbc_lblVar.gridy = 3;
								JLabel lblVar=new JLabel("Connection");
								bonds.add(lblVar,gbc_lblVar);
							   
								GridBagConstraints gbc_txtVar = new GridBagConstraints();
								gbc_txtVar.insets = new Insets(0, 0, 5, 0);
								gbc_txtVar.fill = GridBagConstraints.HORIZONTAL;
								gbc_txtVar.gridx =1;
								gbc_txtVar.gridy = 3;
								txtVar=new JTextField();
								txtVar.addCaretListener(new CaretListener() {
									@Override
									public void caretUpdate(CaretEvent e) {
                                        setAddBondButton();										
									}
							      });
								bonds.add(txtVar,gbc_txtVar);
								
								GridBagConstraints gbc_btnAddBond = new GridBagConstraints();
								gbc_btnAddBond.insets = new Insets(0, 0, 5, 0);
								gbc_btnAddBond.anchor=GridBagConstraints.LINE_START;
								gbc_btnAddBond.gridx =1;
								gbc_btnAddBond.gridy = 4;
								btnAddBond=new JButton("Add");
								btnAddBond.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
									   addBond();
									}
								});
								bonds.add(btnAddBond,gbc_btnAddBond);
								
							    tblBonds	=new JPanel();
								tblBonds.setLayout(new BorderLayout(0, 0));
								GridBagConstraints gbc_tblBonds = new GridBagConstraints();
								gbc_tblBonds.insets = new Insets(0, 0, 0, 5);
								gbc_tblBonds.fill = GridBagConstraints.HORIZONTAL;
								gbc_tblBonds.anchor=GridBagConstraints.LINE_START;
								gbc_tblBonds.gridwidth=2;
								gbc_tblBonds.gridx = 0;
								gbc_tblBonds.gridy = 5;
								bonds.add(tblBonds, gbc_tblBonds);
								tblBond = new JTable();
								tblBond.setBorder(new CompoundBorder());
								tblBond.setModel(new DefaultTableModel(
									new Object[][] {
										{ null, null, null},
									},
									new String[] {
										"Type", "Unit","Pin","Connection"
									}
								));
								JLabel placebo=new JLabel("");
								GridBagConstraints gbc_lblPlacebo = new GridBagConstraints();
								gbc_lblPlacebo.insets = new Insets(0, 0, 5, 5);
								gbc_lblPlacebo.anchor=GridBagConstraints.LINE_START;
								gbc_lblPlacebo.gridx =0;
								gbc_lblPlacebo.gridy = 7;
								bonds.add(placebo,gbc_lblPlacebo);
							    updateComponents();
							    initPins();
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	public static String classLocator() {
		 Properties locator=new Properties();
		 locator.put(FacetHandler.FACET_NAME,"Pack");
		    locator.put(FacetHandler.FACET_TYPE,"pack");
		    locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
			locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
			locator.put(DEFAULT_PARENT, JEntityFacetList.KEY);
		    locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		    locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PackMaster");
		    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PackHandler");
		    locator.put(FacetHandler.FACET_KEY,PackHandler.KEY);
		    locator.put(Locator.LOCATOR_TITLE,"Pack");
		    locator.put(FacetHandler.FACET_MASTER_KEY,KEY);
		    locator.put( IconLoader.ICON_FILE, "pack.png");
		    locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		    locator.put(FacetHandler.FACET_TYPE,PackHandler.PACK_FACET_TYPE);
		    locator.put(FacetMaster.MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PackMaster");
		    locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.pack.JPackEditor");
		    return Locator.toString(locator);
	}
	private void addComponent(){
		 String label$=(String) cbxComponent.getSelectedItem();
		// System.out.println("JCduEditor: addComponent:label="+ label$);
		 if(label$!=null){
			 String key$=entigrator.getKey(label$);
			// System.out.println("JCduEditor: addComponent:check key="+ key$);
			 if(key$==null) {
				 System.out.println("JCduEditor: addComponent:no key for label="+label$);
				 return;
			 }
			 try{
				 if(entity.getElementItem("component", key$)!=null) {
					 System.out.println("JCduEditor: addComponent:already added component label="+label$); 
					 return;
				 }
				 entity.putElementItem("component", new Core("null",key$,label$));
				 Sack component=entigrator.getEntity(key$);
				 if(component==null) {
					 System.out.println("JCduEditor: addComponent:cannot get component label="+label$); 
					 return;
				 }
				 //sources
				 String[] oa=component.listItemsAtType("operator","out");
				 if(oa!=null&&oa.length>0){
					 if(!entity.existsElement("source"))
						 entity.createElement("source");
					 for(String o:oa)
						 entity.putElementItem("source",new Core(component.getProperty("label"),Identity.key(),o));
				 }
	          //consumers
						 String[] ia=component.listItemsAtType("operator","in");
				 if(ia!=null&&ia.length>0){
					 if(!entity.existsElement("consumer"))
						 entity.createElement("consumer");
					 for(String i:ia)
						 entity.putElementItem("consumer",new Core(component.getProperty("label"),Identity.key(),i));
				   }
				
			  entigrator.putEntity(entity);
			  updateComponents();
		 }catch(Exception e){
			 System.out.println("JCduEditor: addComponent:"+ e.toString());
		 		}
		}

	}
	private void refreshComponents() {
		try {
		Core[]  ca=entity.elementGet("component");
		//System.out.println("JCduEditor:refreshComponents:ca="+ca.length);
		ArrayList<String>ll=new ArrayList<String>();
		if(ca!=null)
			for(Core c:ca)
			  if(c.value!=null)	
				   ll.add(c.value);
		String[] la=new String[ll.size()];
		//System.out.println("JCduEditor:refreshComponents:la="+la.length);
		ll.toArray(la);
		Arrays.sort(la);
		//System.out.println("JCduEditor:refreshComponents:1");
		DefaultListModel<String> listModel=new DefaultListModel<String>();
		for(int i=0;i<la.length;i++)
		  listModel.add(i,la[i]);
		if(listComponents!=null)
		  listComponents.setModel(listModel);
		}catch(Exception e) {
			System.out.println("JCduEditor:refreshComponents:"+e.toString());
		}
	}
	private void initUnits() {
		DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String> ();
		String[] ma=listMembers();
		if(ma==null) {
			System.out.println("JCduEditor:initUnis: no units");
			cbxUnit.setModel(model);
			return;
		}
		System.out.println("JCduEditor:initUnis:cbxType index="+cbxType.getSelectedIndex());	
      if(cbxType.getSelectedIndex()==0) {//in
    	  String[] sa=packHandler.listVacantInputs();
    	  if(sa==null||sa.length<1) {
    		  System.out.println("JCduEditor:initUnis: no vacant inputs");
  			cbxUnit.setModel(model);
  			return;
    	  }
    	 ArrayList<String>sl=new ArrayList<String>();
    	 String[] ina;
    	 for(String s:sa) {
    		 ina=s.split(":");
    		 if(!sl.contains(ina[0]))
    			 sl.add(ina[0]);
    	 }
    	 sa=new String[sl.size()];
    	 sl.toArray(sa);
    	 Arrays.sort(sa);
    	 model=new DefaultComboBoxModel<String> (sa);	 
    	 cbxUnit.setModel(model);
      }
      if(cbxType.getSelectedIndex()==1) {
    	  String[] sa=packHandler.listVacantOutputs();
    	  if(sa==null||sa.length<1) {
    		  System.out.println("JCduEditor:initUnis: no vacant outputs");
  			cbxUnit.setModel(model);
  			return;
    	  }
    	  ArrayList<String>sl=new ArrayList<String>();
     	 String[] outa;
     	 for(String s:sa) {
     		 outa=s.split(":");
     		 if(!sl.contains(outa[0]))
     			 sl.add(outa[0]);
     	 }
     	 sa=new String[sl.size()];
     	 sl.toArray(sa);
     	 Arrays.sort(sa);
    	  model=new DefaultComboBoxModel<String> (sa);	 
     	 cbxUnit.setModel(model);  
      }
		cbxUnit.setModel(model);
	}
	 private void initPins() {
		 DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String> ();
			String unit$=(String)cbxUnit.getSelectedItem();
			if(unit$==null) {
				cbxPin.setModel(model);
				return;
			}
			String[] sa=null;
			if(cbxType.getSelectedIndex()==0)
			 sa=packHandler.listVacantInputs(unit$);
			else
				sa=packHandler.listVacantOutputs(unit$);
			if(sa==null||sa.length<1) {
				cbxPin.setModel(model);
				return;
			}
			model=new DefaultComboBoxModel<String> (sa);
			cbxPin.setModel(model);
	 }
   private String[] listMembers() {
		if(entity==null)
			return null;
		Core[] ca=entity.elementGet("component");
		if(ca==null)
			return null;
		ArrayList<String>sl=new ArrayList<String>();
	    for(Core c:ca) 
	    	if(c.value!=null)
	    		sl.add(c.value);
	    if(sl.size()<1)
	    	return null;
	    if(sl.size()==1)
	    	return new String[] {sl.get(0)};
	    Collections.sort(sl);
	    String[] sa=new String[sl.size()];
	    sl.toArray(sa);
	    return sa;
	}
	@SuppressWarnings("unused")
	private String[] listOutputs(String member$) {
		Sack member=entigrator.getEntityAtLabel(member$);
		if(member==null)
			return null;
		String eduHandler$=EduHandler.classLocator();
		eduHandler$=Locator.append(eduHandler$,Entigrator.ENTITY_LABEL, member.getProperty("label"));
		EduHandler eduHandler=new EduHandler(console.getEntigrator(),eduHandler$);
		return eduHandler.listInputs();
	}
	
	@SuppressWarnings("unused")
	private String[] listInputs(String member$) {
		Sack member=entigrator.getEntityAtLabel(member$);
		if(member==null)
			return null;
		Core[] ca=member.elementGet("operator");
		if(ca==null)
			return null;
		ArrayList<String>sl=new ArrayList<String>();
		for(Core c:ca)
			if("input".equals(c.type)
					||"in".equals(c.type)
					)
				sl.add(c.name);
		if(sl.size()==0)
			return null;
		String[] sa=new String[sl.size()];
		sl.toArray(sa);
		return sa;
	}
	private void updateComponents(){
		System.out.println("JPackEditor:updateComponents:BEGIN");  
	try {
		if(entity==null) {
			System.out.println("JPackEditor:updateComponents:entity is null");
		  return;
		}
		String[] allOperators=entigrator.listEntities(OperatorHandler.OPERATOR,"true");
		if(allOperators==null||allOperators.length<1) {
			System.out.println("JPackEditor:updateComponents:no operators");
			return;
		}
		ArrayList<String>sl=new ArrayList<String>();
		 for(String o:allOperators) {
			 if(EduHandler.isAppliable(entigrator, o))
				 sl.add(o);
		 }
		 
//		System.out.println("JPackEditor:updateComponents:operators="+allOperators.length+"  edus="+sl.size());
		 String[] components=entity.elementListNames("component");
		 ArrayList<String>cl=new    ArrayList<String>();
		 if(sl.size()>0) {
			 boolean found;	 
		 for(String o:sl) {
			 found=false; 
			 if(components!=null)
				 for(String c:components) {
				     if(o.equals(c)){
					   found=true;
					   break;
				     }
				 }
			 if(!found)
				 cl.add(o);
		 }
		 }
		// System.out.println("JCduEditor:updateComponents:cl="+cl.size());
		 refreshComponents();
		 DefaultComboBoxModel<String> cbxComponentModel=new  DefaultComboBoxModel<String>();
		 if(cl!=null) {	
			 String component$;
			 ArrayList<String>cnl=new ArrayList<String>();
			 for(String c:cl) {
           		 component$=entigrator.getLabel(c);
           		 if(component$!=null)
           			 cnl.add(component$);
			 }
		//	 System.out.println("JCduEditor:updateComponents:cnl="+cnl.size());	 
		 String[] cka=new String[cnl.size()];
		 cnl.toArray(cka);
		 Arrays.sort(cka);
		 cbxComponentModel=new  DefaultComboBoxModel<String>(cka);
		 }
		if(cbxComponent!=null) 
		   cbxComponent.setModel(cbxComponentModel); 
		// System.out.println("JCduEditor:updateComponents:FINISH"); 
	}catch(Exception e) {
		System.out.println("JPackEditor:updateComponents:"+e.toString());  
	}
	}
	private void initConnectionButtons(){
//		System.out.println("JCduEditor:initConnectioButtons:BEGIN");
	try {
		String consumer$=(String)cbxConsumer.getSelectedItem();
	  	String input$=(String)cbxInput.getSelectedItem();
	  	String source$=(String)cbxSource.getSelectedItem();
	  	String output$=(String)cbxOutput.getSelectedItem();
	   Connection connection=new Connection(entity,source$,output$,consumer$, input$);
	//   System.out.println("JCduEditor:initConnectioButtons:inserted="+connection.alreadyInserted(entity)+" correct="+connection.isCorrect());
	   if(connection.isCorrect()&&
			  ! connection.alreadyInserted(entity)) {
		   btnAddConnection.setEnabled(true);
		   if(consumer$.equals(source$))
		   	 btnAddConnection.setEnabled(false);
	   }
	   else
		   btnAddConnection.setEnabled(false);
	}catch(Exception e) {
		System.out.println("JPackEditor:initConnectioButtons:"+e.toString());
	}
	}
	private void initOutput() {
		DefaultComboBoxModel<String> model= new DefaultComboBoxModel<String> ();
		cbxOutput.setModel(model);
		String source$=(String)cbxSource.getSelectedItem();
		if(source$==null) 
			return;
		String[] sa=packHandler.listOutputs(source$);
		if(sa==null||sa.length<1) 
			return;
		model= new DefaultComboBoxModel<String> (sa);
		cbxOutput.setModel(model);
	}
	private void initInput() {
		DefaultComboBoxModel<String> model= new DefaultComboBoxModel<String> ();
		cbxInput.setModel(model);
		String consumer$=(String)cbxConsumer.getSelectedItem();
		if(consumer$==null) 
			return;
		String[] sa=packHandler.listConsumerInputs(consumer$);
		if(sa==null||sa.length<1) 
			return;
		model= new DefaultComboBoxModel<String> (sa);
		cbxInput.setModel(model);
	}
	
	private void removeComponent(String compName$){
		//System.out.println("JCduEditor:removeComponent:compName="+compName$);
		try{
			String compKey$=entity.getElementItemAtValue("component", compName$);
		//	System.out.println("JCduEditor:removeComponent:compKey="+compKey$);
			if(compKey$==null) {
				System.out.println("JCduEditor:removeComponent:cannot find key for component="+compName$);
				return;
			}
				entity.removeElementItem("component",compKey$);
				entigrator.putEntity(entity);
			//remove source junctions
				Core[] soa=entity.elementGet("source");
			ArrayList<String >sl=new ArrayList<String>();
			if(soa!=null)
				for(Core c:soa)
					if(compName$.equals(c.type))
						sl.add(c.name);
			if(sl.size()>0)
				for(String s:sl)
					entity.removeElementItem("source",s);
			entigrator.putEntity(entity);
			//remove consumer  junctions
			Core[] coa=entity.elementGet("consumer");
			ArrayList<String >nl=new ArrayList<String>();
			if(coa!=null)
				for(Core c:coa)
					if(compName$.equals(c.type))
						nl.add(c.name);
			if(nl.size()>0)
				for(String s:nl)
					entity.removeElementItem("consumer",s);
			entigrator.putEntity(entity);
			//remove connections
			Core[] ta=entity.elementGet("connection");
			if(ta!=null){
				ArrayList<String >tl=new ArrayList<String>();
				for(Core t:ta){
				    for(String s:sl)
				         if(t.type.equals(s))
				        	 tl.add(t.name);
				    for(String s:nl)
				         if(t.value.equals(s))
				        	 tl.add(t.name);
				}
				for(String t:tl)
					entity.removeElementItem("connection",t);
			}
			updateComponents();
		}catch(Exception e){
			System.out.println("JCduEditor:removeComponent:"+e.toString());
		}
	}
	protected void replaceTable(){
		//	System.out.println("JCduEditor:replaceTable:BEGIN");
			try{
				DefaultTableModel model=(DefaultTableModel) tblConnect.getModel();
				while(model.getRowCount()>0)
					model.removeRow(0);
			Connection[]     cona=Connection.getConnections(entigrator,entity);
			if(cona==null) {
				System.out.println("JCduEditor:replaceTable:no connections");
				return;
			}
			//System.out.println("JCduEditor:replaceTable:cona="+cona.length);		
				for(Connection c:cona){
					model.addRow(new String[]{c.source$,c.output$,c.consumer$,c.input$,c.closed$});
				//	System.out.println("JCduEditor:replaceTable:   "+c.source$+"  "+c.output$+" "+c.consumer$+"  "+c.input$);		
				}
				 tblConnect.setModel(model);
				 tblConnect.repaint();
			}catch(Exception e){
				System.out.println("JPackEditor:replaceTable:"+e.toString());
			}
		}
	private void initSources(){
		String[]sa=packHandler.listSources();
		//
			if(sa==null||sa.length<1) {
				System.out.println("JPackEditor:initSources: no sources in pack handler");
			}
		//
		DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String> ();
		cbxSource.setModel(model);
	  if(sa!=null&&sa.length>0)
	           model=new DefaultComboBoxModel<String> (sa);		
	   cbxSource.setModel(model);
	}
	private void initConsumers(){
		
		String[]sa=packHandler.listConsumers();
	    if(sa!=null) {
	    	DefaultComboBoxModel<String>  model=new DefaultComboBoxModel<String> (sa);		
	        cbxConsumer.setModel(model);
	    }else {
	    	DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String> ();
	    	cbxConsumer.setModel(model);
	    }
	}
	
private void refreshSelector() {
	try {
		//System.out.println("JCduEditor:refreshSelector:BEGIN");
		String unit$=(String)cbxUnit.getSelectedItem();
		String type$=((String)cbxType.getSelectedItem()).toLowerCase();
		String name$=(String)cbxPin.getSelectedItem();
		txtVar.setText(null);
		DefaultTableModel model=(DefaultTableModel)tblBond.getModel();
		int rows=model.getRowCount();
		if(rows>0)
			for(int i=0;i<rows;i++) {
				if(type$.equals((String)model.getValueAt(i, 0))
						&&unit$.equals((String)model.getValueAt(i, 2))
						&&name$.equals((String)model.getValueAt(i, 3))){
					txtVar.setText((String)model.getValueAt(i, 1));	
					tblBond.setRowSelectionInterval(i, i);
				}
			}
	}catch(Exception e) {
		System.out.println("JCduEditor:refreshSelector:"+e.toString());
	}
}
private void refreshBondTable(){
	try{
		//System.out.println("JCduEditor:refreshBondTable:BEGIN");
		DefaultTableModel model=(DefaultTableModel) tblBond.getModel();
	tblBond.setDefaultEditor(Object.class, null);
	tblBond.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	while(model.getRowCount()>0)
			try{model.removeRow(0);}catch(Exception ee) {}
	Core[] cina=entity.elementGet("in");
	Core opEntry;
	if(cina!=null) {
	  for(Core c:cina) {
		opEntry=entity.getElementItem("in", c.name);  
		 {
			String[] row=new String[4];
			row[0]="in";
			row[1]=c.type;
			row[2]=c.value;
			row[3]=c.name;
			model.addRow(row);
		}
		 if(opEntry==null) {
				entity.putElementItem("operator",new Core("in",c.name,"0"));
				console.getEntigrator().putEntity(entity);
			}
	}
	}
	 Core[] couta=entity.elementGet("out");
	if(couta!=null) {
			System.out.println("JCduEditor:refreshBondTable:couta="+couta.length);
	  for(Core c:couta) {
			opEntry=entity.getElementItem("out", c.name);  
			 {
				String[] row=new String[4];
				row[0]="out";
				row[1]=c.type;
				row[2]=c.value;
				row[3]=c.name;
				model.addRow(row);
			}
			if(opEntry==null) {
				entity.putElementItem("operator",new Core("out",c.name,"0"));
				console.getEntigrator().putEntity(entity);
			}
		}
		}
 tblBonds.add(tblBond.getTableHeader(), BorderLayout.NORTH);
 tblBonds.add(tblBond,BorderLayout.CENTER);
 tblBond.getTableHeader().addMouseListener(new MouseAdapter() {
			    @Override
			    public void mouseClicked(MouseEvent e) {
			       try {
			    	 tblBond.columnAtPoint(e.getPoint());
//			    	System.out.println("JCduEditor:refreshBondTable:col clicked="+col);
			       }catch(Exception ee) {
			    	   System.out.println("JCduEditor:refreshBondTable:header clicked:"+ee.toString());   
			       }
			    }
			});
		final JPopupMenu popupMenu = new JPopupMenu();
	     JMenuItem deleteItem = new JMenuItem("Delete");
	      deleteItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	int row=tblBond.getSelectedRow(); 
	            	if(row<0) {
            			 JOptionPane.showMessageDialog(tabbedPane,"Row not selected","Confirm", JOptionPane.INFORMATION_MESSAGE );
            			 return;
            		 }
	            	int response = JOptionPane.showConfirmDialog(bonds, "Delete selected bond' ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		  		    if (response == JOptionPane.YES_OPTION) {
		  		    	String[] sa=new String[4];
//	            		 System.out.println("JCduEditor:refreshBondTable:row cnt="+row);
	            	     sa[0]=(String)tblBond.getModel().getValueAt(row, 0);
	            	     sa[1]=(String)tblBond.getModel().getValueAt(row, 1);
	            	     sa[2]=(String)tblBond.getModel().getValueAt(row, 2);
	            	     sa[3]=(String)tblBond.getModel().getValueAt(row, 3);
//	            	     System.out.println("JCduEditor:refreshBondTable:type="+sa[0]+" unit="+sa[1]+" pin="+sa[2]+" connection="+sa[3]);
	            	     deleteBond(sa);
		  		    }
		  		    }
	            });
	        popupMenu.add(deleteItem);
	        tblBond.setComponentPopupMenu(popupMenu);
		 tblBond.revalidate();
		 tblBond.repaint();
	}catch(Exception e){
		System.out.println("JCduEditor:refreshBondTable:"+e.toString());
	}
}
private void deleteBond(String[] sa) {
	entity.removeElementItem("operator", sa[3]);
	entity.removeElementItem(sa[0], sa[3]);
	console.getEntigrator().putEntity(entity);
	refreshBondTable();
	setAddBondButton();
}
private void setAddBondButton() {
	initUnits();
	initPins();
	refreshBondTable();
	if(txtVar.getText()==null||txtVar.getText().length()<1) {
		btnAddBond.setEnabled(false);
		return ;
	}
	if(bondExists())
		btnAddBond.setEnabled(false);
	else
		btnAddBond.setEnabled(true);
}
private boolean bondExists() {
	String type$=(String)cbxType.getSelectedItem();
	String unit$=(String)cbxUnit.getSelectedItem();
	String pin$=(String)cbxUnit.getSelectedItem();
    
	Core[] ca;
	if("In".equals(type$)) {
		ca=entity.elementGet("in");
		if(ca!=null)
			for(Core c:ca) {
				if(unit$.equals(c.type)&&pin$.equals(c.value))
					return true;
			}
	}
	if("Out".equals(type$)) {
		ca=entity.elementGet("out");
		if(ca!=null)
			for(Core c:ca) {
				if(unit$.equals(c.type)&&pin$.equals(c.value))
					return true;
			}
	}
	return false;	
}
private void addBond() {
	try {
		String unit$=(String)cbxUnit.getSelectedItem();
		String type$=(String)cbxType.getSelectedItem();
		String pin$=(String)cbxPin.getSelectedItem();
		String con$=txtVar.getText();
		if("In".equals(type$)) {
			if(!entity.existsElement("in"))
				entity.createElement("in");
			    entity.putElementItem("in", new Core(unit$,con$,pin$));
			    if(!entity.existsElement("operator"))
			    	entity.createElement("operator");
			    entity.putElementItem("operator", new Core("in",con$,"0"));
		}
		if("Out".equals(type$)) {
			if(!entity.existsElement("out"))
				entity.createElement("out");
			    entity.putElementItem("out", new Core(unit$,con$,pin$));
			    if(!entity.existsElement("operator"))
			    	entity.createElement("operator");
			    entity.putElementItem("operator", new Core("out",con$,"0"));
		}
		console.getEntigrator().putEntity(entity);
		refreshBondTable();
		setAddBondButton();
	}catch(Exception e) {
		System.out.println("JCduEditor:addBond:"+e.toString());
	}	
}

@Override
public String reply(JMainConsole console, String locator$) {
	return null;
}	
}

