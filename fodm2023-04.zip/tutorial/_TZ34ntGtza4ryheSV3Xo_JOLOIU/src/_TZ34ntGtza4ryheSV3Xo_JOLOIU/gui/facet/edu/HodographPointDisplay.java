package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.edu;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.NamedPoint;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.PointDisplay;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;


public class HodographPointDisplay extends PointDisplay{

	@Override
	public String pointsString(ArrayList<NamedPoint> pl) {
		//System.out.println("HodographPointDisplay:pointsString:data path="+dataPath$);
		double re=0;
		double im=0;
		if(pl!=null)
			for(NamedPoint p:pl) {
				if("Re".equals(p.getName()))
					re=p.getValue();
				if("Im".equals(p.getName()))
					im=p.getValue();
			}
		return getBestPoint( re,im);		
		
	}
    public String getBestPoint(double re,double im) {
    	if(dataPath$!=null) {
    		try {
    		BufferedReader br = new BufferedReader(new FileReader(dataPath$));
    		String line$;
    		String[] sa;
    		double x=0;
    		double y=0;
    		double f=0;
    		double err=0;
    		double endErr=Double.MAX_VALUE;
    		double endf=0;
    		while ((line$ = br.readLine()) != null) {
				//System.out.println("JPlotPanel:Ray:load:line="+line$);
				sa=line$.split(";");
                 x=0;
                 y=0;
                 try{x=Double.parseDouble(sa[0]);}catch(Exception e) {}
                 try{y=Double.parseDouble(sa[1]);}catch(Exception e) {}
                 try{f=Double.parseDouble(sa[2]);}catch(Exception e) {}
                 err=Math.pow((x-re),2)+Math.pow((y-im),2);
                 if(err<endErr) {
                	 endErr=err;
                	 endf=f;
                 }
               //  System.out.println("HodographPointDisplay:getBestPoint:re="+re+"  im="+im+"  x="+x+" y="+y+" f="+f+"   err="+err); 
			}
			br.close();
			// System.out.println("HodographPointDisplay:getBestPoint:re="+endRe+"  im="+endIm+"  f="+endf);
			 double gain=Math.sqrt(re*re+im*im);
			 V2 v=new V2(re,im);
			 double angle=v.angle();
			 String format$="0.##E0";
			 NumberFormat Format = new DecimalFormat(format$);
			 NumberFormat angleFormat = new DecimalFormat("###.#");
			 return " gain="+Format.format(gain)+"; angle="+angleFormat.format(angle)+"; f="+Format.format(endf);
    		}catch(Exception ee) {
    			System.out.println("HodographPointDisplay:getBestPoint:"+ee.toString());
        	}
   	}
    
		
    	return "hodograph";
    }
}
