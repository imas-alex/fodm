package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.edu;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Scanner;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.EventHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.FileTool;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JGuiEditor;

import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.io.BufferedWriter;
import java.io.File;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.JPlotPanel;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil.V2;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import javax.swing.BoxLayout;
import javax.swing.border.TitledBorder;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

public class JEduEditor extends JGuiEditor {
	
	private static final long serialVersionUID = 1L;
	public static final String KEY="_qWomcjwaEih_YdA4lCubrR0gwoA";
	public static final String PLOT_TYPE_BANDWIDTH_OPEN="bandwidth open";
	public static final String PLOT_TYPE_BANDWIDTH_CLOSED="bandwidth closed";
	public static final String PLOT_TYPE_HODOGRAPH="Hodograph";
	public static final String PLOT_TYPE_STEP_CLOSED_RESPONSE="step closed";
	public static final String PLOT_TYPE_STEP_OPEN_RESPONSE="step open";

	public static final int PLOT_TYPE=-1;
	public static final int PLOT_TYPE_BODE_OPEN=0;
	public static final int PLOT_TYPE_BODE_CLOSED=1;
	public static final int PLOT_TYPE_HODOGRAPH_OPEN=2;
	public static final int PLOT_TYPE_STEP_CLOSED=3;
	public static final int PLOT_TYPE_STEP_OPEN=4;
	protected JTextField txtTmax;
	protected JTextField txtTmin;
	protected JTextField txtIncrement;
	protected JTextField txtDelay;
	protected JTextField txtFreq;
	protected JTextField txtDuration;
	protected JTextField txtTakt;
	
	protected JTextField txtProgress;
	protected JComboBox <String>cbxTest;
	protected JComboBox <String>cbxIn;
	protected JComboBox <String>cbxOut;
	protected JButton btnStop;
	protected JButton btnRun;
	protected JButton btnView;
	
    Sack entity;
    EduHandler eduHandler;
    boolean breakRun=false;
    JPanel systemPanel;
    JPanel settingsPanel;
    JPanel desk;
    JLabel lblProgress;
    boolean stop=false;
     HashMap<String,Double > pars;
    HashMap<String,Double > state;
    int cycles=0;
    JScrollPane scrollPane;
    JPanel container;
 	public JEduEditor(JMainConsole console,String alocator$) {
		super(console,alocator$);
		String classLocator$=classLocator();
		locator$=Locator.merge(locator$, classLocator$);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	//	System.out.println("JEduEditor:alocator="+alocator$);
	//	System.out.println("JEduEditor:entity="+entity$);
		instance$=getInstance();
		parent$=Locator.getProperty(alocator$, PARENT);
		if(parent$!=null)
		locator$=Locator.append(locator$, PARENT, parent$);
		if(entity$!=null) {
			locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity$);
			entity=console.getEntigrator().getEntityAtLabel(entity$);
			if(entity!=null) {
				try{
					eduHandler=new EduHandler(console.getEntigrator(),locator$);
					eduHandler.operatorKey$=entity.getKey();
					eduHandler.reset();
				}catch(Exception e) {
				//System.out.println("JEduEditor:cannot get eduHandler:"+e.toString());
				//System.out.println("JEduEditor:locator="+locator$);
		   }
		}
		}
		pars=new HashMap<String,Double >();
		state=new HashMap<String,Double >();
		scrollPane = new JScrollPane();
		add(scrollPane);
		container=new JPanel();
		scrollPane.setViewportView(container);
		container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
		systemPanel=new JPanel();
		systemPanel.setBorder(new TitledBorder(null, "System", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
		GridBagLayout systemLayout = new GridBagLayout();
	    systemLayout.columnWeights = new double[]{0.0,  1.0};
		systemLayout.rowWeights = new double[]{0.0,0.0};
		systemPanel.setLayout(systemLayout);
		container.add(systemPanel);
		JPanel snapshotPanel=new JPanel();
			snapshotPanel.setBorder(new TitledBorder(null, "Response", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
			GridBagLayout snapshotLayout = new GridBagLayout();
			snapshotLayout.columnWeights = new double[]{0.0,1.0};
			snapshotLayout.rowWeights = new double[]{1.0,0.0, 0.0};
			snapshotPanel.setLayout(snapshotLayout);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		container.add(snapshotPanel);
		
		 JLabel lblTmax = new JLabel("Tmax");
	        GridBagConstraints gbc_lblTmax = new GridBagConstraints();
	        gbc_lblTmax.insets = new Insets(0, 5, 5, 5);
	    	gbc_lblTmax.gridx = 0;
			gbc_lblTmax.gridy = 0;
			gbc_lblTmax.anchor=GridBagConstraints.LINE_START;
			systemPanel.add(lblTmax, gbc_lblTmax);
			txtTmax = new JTextField();
		    txtTmax.addCaretListener(new CaretListener() {
				@Override
				public void caretUpdate(CaretEvent e) {
					 if(entity!=null) {
						 if(!entity.existsElement("edu"))
							 entity.createElement("edu");
						 entity.putElementItem("edu", new Core(null,"tmax",txtTmax.getText()));
						 console.getEntigrator().putEntity(entity);
					 }
				}
		      });
		    txtTmax.setColumns(10);
		    GridBagConstraints gbc_txtTmax = new GridBagConstraints();
		    gbc_txtTmax.insets=new Insets(3, 3, 5, 3);
			gbc_txtTmax.gridx = 1;
			gbc_txtTmax.gridy = 0;
			gbc_txtTmax.anchor=GridBagConstraints.LINE_START;
			systemPanel.add( txtTmax, gbc_txtTmax);
	    JLabel lblTmin = new JLabel("Tmin");
	    GridBagConstraints gbc_lblTmin = new GridBagConstraints();
        gbc_lblTmin.insets = new Insets(0, 5, 5, 5);
    	gbc_lblTmin.gridx = 0;
		gbc_lblTmin.gridy = 1;
		gbc_lblTmin.anchor=GridBagConstraints.LINE_START;
		systemPanel.add(lblTmin, gbc_lblTmin);
	   
	    txtTmin = new JTextField();
	    txtTmin.setColumns(10);
	    txtTmin.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
				 if(entity!=null) {
					 if(!entity.existsElement("edu"))
						 entity.createElement("edu");
					 entity.putElementItem("edu", new Core(null,"tmin",txtTmin.getText()));
					 double clock=Double.MIN_VALUE;
					 try {double tmin=clock=Double.parseDouble(txtTmin.getText());
					      clock=tmin/100;
					 }catch(Exception ee) {}
					 entity.putElementItem("edu", new Core(null,"preferred.clock",String.valueOf(clock)));
					 }
					 console.getEntigrator().putEntity(entity);
				 }
	      });
	    GridBagConstraints gbc_txtTmin = new GridBagConstraints();
	    gbc_txtTmin.insets=new Insets(3, 3, 5, 3);
		gbc_txtTmin.gridx = 1;
		gbc_txtTmin.gridy = 1;
		gbc_txtTmin.anchor=GridBagConstraints.LINE_START;
		systemPanel.add( txtTmin, gbc_txtTmin);
		 	
			JLabel lblIn = new JLabel("In");
			 GridBagConstraints gbc_lblIn = new GridBagConstraints();
		     gbc_lblIn.insets = new Insets(0, 5, 5, 5);
		     gbc_lblIn.gridx = 0;
			 gbc_lblIn.gridy = 0;
			 gbc_lblIn.anchor=GridBagConstraints.LINE_START;
			 snapshotPanel.add(lblIn, gbc_lblIn);
			 cbxIn=new JComboBox<String>();
			 cbxIn.addItemListener(new ItemListener() {
				    public void itemStateChanged(ItemEvent arg0) {
				       String in$=(String)cbxIn.getSelectedItem();
				       entity.putElementItem("edu", new Core(null,"in",in$));
				       console.getEntigrator().putEntity(entity);
				    }
				});
			 GridBagConstraints gbc_cbxIn = new GridBagConstraints();
			    gbc_cbxIn.insets=new Insets(3, 3, 5, 5);
				gbc_cbxIn.gridx = 1;
				gbc_cbxIn.gridy = 0;
				gbc_cbxIn.anchor=GridBagConstraints.LINE_START;
				snapshotPanel.add( cbxIn, gbc_cbxIn);
				JLabel lblOut = new JLabel("Out");
				 GridBagConstraints gbc_lblOut = new GridBagConstraints();
			     gbc_lblOut.insets = new Insets(0, 5, 5, 5);
			     gbc_lblOut.gridx = 0;
				 gbc_lblOut.gridy = 1;
				 gbc_lblOut.anchor=GridBagConstraints.LINE_START;
				 snapshotPanel.add(lblOut, gbc_lblOut);
				 cbxOut=new JComboBox<String>();
				 cbxOut.addItemListener(new ItemListener() {
					    public void itemStateChanged(ItemEvent arg0) {
					       String out$=(String)cbxOut.getSelectedItem();
					       entity.putElementItem("edu", new Core(null,"out",out$));
					       console.getEntigrator().putEntity(entity);
					    }
					});
				 GridBagConstraints gbc_cbxOut = new GridBagConstraints();
				    gbc_cbxOut.insets=new Insets(3, 3, 5, 5);
					gbc_cbxOut.gridx = 1;
					gbc_cbxOut.gridy = 1;
					gbc_cbxOut.anchor=GridBagConstraints.LINE_START;
					snapshotPanel.add( cbxOut, gbc_cbxOut);	
			JLabel lblTest = new JLabel("Test");
			 GridBagConstraints gbc_lblTest = new GridBagConstraints();
		     gbc_lblTest.insets = new Insets(0, 5, 5, 5);
		     gbc_lblTest.gridx = 0;
			 gbc_lblTest.gridy = 2;
			 gbc_lblTest.anchor=GridBagConstraints.LINE_START;
			 snapshotPanel.add(lblTest, gbc_lblTest);
			 
			 cbxTest=new JComboBox<String>();
			 cbxTest.setModel(new DefaultComboBoxModel<String>(new String[] {"Bandwidth(open)", "Bandwidth(closed)", "Hodograph", "Step(closed)", "Step(open)"}));
			 cbxTest.addItemListener(new ItemListener() {
				    public void itemStateChanged(ItemEvent arg0) {
				       setSettings();
				    }
				});
			 GridBagConstraints gbc_cbxTest = new GridBagConstraints();
			    gbc_cbxTest.insets=new Insets(3, 3, 5, 5);
				gbc_cbxTest.gridx = 1;
				gbc_cbxTest.gridy = 2;
				gbc_cbxTest.anchor=GridBagConstraints.LINE_START;
				snapshotPanel.add( cbxTest, gbc_cbxTest);
		 lblProgress = new JLabel("Progress");
		 GridBagConstraints gbc_lblPrgr = new GridBagConstraints();
	     gbc_lblPrgr.insets = new Insets(0, 5, 5, 5);
	     gbc_lblPrgr.gridx = 0;
		 gbc_lblPrgr.gridy = 3;
		 gbc_lblPrgr.anchor=GridBagConstraints.LINE_START;
		 snapshotPanel.add(lblProgress, gbc_lblPrgr);
		  txtProgress=new JTextField();
		  txtProgress.setColumns(10);
		  txtProgress.setEditable(false);
		  GridBagConstraints gbc_txtTime = new GridBagConstraints();
		     gbc_txtTime.insets = new Insets(0, 5, 5, 5);
		     gbc_txtTime.gridx = 1;
			 gbc_txtTime.gridy = 3;
			 gbc_txtTime.anchor=GridBagConstraints.LINE_START;
			 snapshotPanel.add(txtProgress, gbc_txtTime);
		 		 desk = new JPanel();
			GridBagConstraints gbc_desk = new GridBagConstraints();
			gbc_desk.insets = new Insets(0, 0, 5, 0);
			gbc_desk.fill = GridBagConstraints.BOTH;
			gbc_desk.gridx = 1;
			gbc_desk.gridy = 4;
			snapshotPanel.add(desk, gbc_desk);
		 btnStop = new JButton("Stop");
		 btnStop.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		breakRun=true;
		 		prepareCycleIndicator();
		 	}
		 });
		 desk.setLayout(new BoxLayout(desk, BoxLayout.X_AXIS));
		 btnStop.setEnabled(false);
		 desk.add(btnStop);
		 btnRun = new JButton("Run");
		 btnRun.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		breakRun=false;
		 		btnStop.setEnabled(true);
				Thread t=new Thread(Snapshot);
				t.start();
		 	}
		 });
		 desk.add(btnRun);
		 btnView = new JButton("View");
		 btnView.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent e) {
		 		showPlot();
		 	}
		 });
		 desk.add(btnView);
		  settingsPanel=new JPanel();	
		  settingsPanel.setBorder(new TitledBorder(null, "Settings", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
			container.add(settingsPanel);
			if(entity!=null) {
						if(entity.existsElement("edu")) {
				String tmax$=entity.getElementItemAt("edu", "tmax");
				txtTmax.setText(tmax$);
				String tmin$=entity.getElementItemAt("edu", "tmin");
				txtTmin.setText(tmin$);
				}
			}
		
			if(entity!=null) {
			String test$=entity.getElementItemAt("edu", "test");
			if(test$!=null)
				selectCombo(cbxTest, test$);
		
			setSettings();
			}else {
				System.out.println("JEduEditor:cannot get entity="+entity$);
			}
 			
 	}
		     
		  
 	private void setSettings() {
 		settingsPanel.removeAll();
 		revalidate();
 		repaint();
 		int testIndex=cbxTest.getSelectedIndex();
 		String final$=entity.getElementItemAt("edu", "final");
 		if(testIndex==1||testIndex==3) {
 		if("true".equals(final$)) {
 			btnRun.setEnabled(false);
 			btnStop.setEnabled(false);
 			btnView.setEnabled(false);
 		}
 		}
 		else {
 			 btnRun.setEnabled(true);
 			 btnView.setEnabled(true);
 		}
 		if(testIndex==0||testIndex==1||testIndex==2)
 		   {
 			prepareCycleIndicator();
 			GridBagLayout settingLayout = new GridBagLayout();
 			settingLayout.columnWeights = new double[]{0.0,1.0};
 			settingLayout.rowWeights = new double[]{0.0,0.0};
 			settingsPanel.setLayout(settingLayout);
 			JLabel lblIncr = new JLabel("Increment");
 			 GridBagConstraints gbc_lblIncr = new GridBagConstraints();
 		    gbc_lblIncr.insets = new Insets(0, 5, 5, 5);
 		    gbc_lblIncr.gridx = 0;
 			 gbc_lblIncr.gridy = 0;
 			 gbc_lblIncr.anchor=GridBagConstraints.LINE_START;
 			 settingsPanel.add(lblIncr, gbc_lblIncr);	
 			 txtIncrement = new JTextField();
 			 txtIncrement.setColumns(10);
 			 txtIncrement.addCaretListener(new CaretListener() {
 					@Override
 					public void caretUpdate(CaretEvent e) {
 						// System.out.println(txtAmpl.getText());
 						 if(entity!=null) {
 							 if(!entity.existsElement("edu"))
 								 entity.createElement("edu");
 							 entity.putElementItem("edu", new Core(null,"increment",txtIncrement.getText()));
 							 console.getEntigrator().putEntity(entity);
 							 prepareCycleIndicator();
 						 }
 					}
 			      });
 			 String increment$=entity.getElementItemAt("edu", "increment");
 				txtIncrement.setText(increment$);
 			    GridBagConstraints gbc_txtIncr = new GridBagConstraints();
 			    gbc_txtIncr.insets=new Insets(3, 3, 5, 3);
 				gbc_txtIncr.gridx = 1;
 				gbc_txtIncr.gridy = 0;
 				gbc_txtIncr.anchor=GridBagConstraints.LINE_START;
 				settingsPanel.add( txtIncrement, gbc_txtIncr);
 				if(testIndex==2) {
 					 entity.putElementItem("edu", new Core(null,"closed","false")); 
 					 console.getEntigrator().putEntity(entity);
 				}
 		   }
 		if(testIndex==3||testIndex==4)
 		   {
 			lblProgress.setText("Time");
 			txtProgress.setText("0");
 			GridBagLayout settingLayout = new GridBagLayout();
 			settingLayout.columnWeights = new double[]{0.0,1.0};
 			settingLayout.rowWeights = new double[]{0.0,0.0,0.0};
 			settingsPanel.setLayout(settingLayout);
 			JLabel lblTakt = new JLabel("Takt");
 			 GridBagConstraints gbc_lblTakt = new GridBagConstraints();
 		      gbc_lblTakt.insets = new Insets(0, 5, 5, 5);
 		    gbc_lblTakt.gridx = 0;
 			 gbc_lblTakt.gridy = 0;
 			 gbc_lblTakt.anchor=GridBagConstraints.LINE_START;
 			 settingsPanel.add(lblTakt, gbc_lblTakt);	
 			 txtTakt = new JTextField();
 			 txtTakt.setColumns(10);
 			 
 			 txtTakt.addCaretListener(new CaretListener() {
 					@Override
 					public void caretUpdate(CaretEvent e) {
 						// System.out.println(txtAmpl.getText());
 						 if(entity!=null) {
 							 if(!entity.existsElement("edu"))
 								 entity.createElement("edu");
 							 entity.putElementItem("edu", new Core(null,"takt",txtTakt.getText()));
 							 console.getEntigrator().putEntity(entity);
 						 }
 					}
 			      });
 			     
 			    GridBagConstraints gbc_txtTakt = new GridBagConstraints();
 			    gbc_txtTakt.insets=new Insets(3, 3, 5, 3);
 			    gbc_txtTakt.gridx = 1;
 				gbc_txtTakt.gridy = 0;
 				gbc_txtTakt.anchor=GridBagConstraints.LINE_START;
 				settingsPanel.add( txtTakt, gbc_txtTakt);
 			JLabel lblDur = new JLabel("Duration");
 				 GridBagConstraints gbc_lblDur = new GridBagConstraints();
 			     gbc_lblDur.insets = new Insets(0, 5, 5, 5);
 			     gbc_lblDur.gridx = 0;
 				 gbc_lblDur.gridy = 1;
 				 gbc_lblDur.anchor=GridBagConstraints.LINE_START;
 				 settingsPanel.add(lblDur, gbc_lblDur);	
 				 txtDuration = new JTextField();
 				 txtDuration.setColumns(10);
 				 
 				 txtDuration.addCaretListener(new CaretListener() {
 						@Override
 						public void caretUpdate(CaretEvent e) {
 							// System.out.println(txtAmpl.getText());
 							 if(entity!=null) {
 								 if(!entity.existsElement("edu"))
 									 entity.createElement("edu");
 								 entity.putElementItem("edu", new Core(null,"duration",txtDuration.getText()));
 								 console.getEntigrator().putEntity(entity);
 							 }
 						}
 				      });
 				 
 				    GridBagConstraints gbc_txtDuration = new GridBagConstraints();
 				    gbc_txtDuration.insets=new Insets(3, 3, 5, 3);
 					gbc_txtDuration.gridx = 1;
 					gbc_txtDuration.gridy = 1;
 					gbc_txtDuration.anchor=GridBagConstraints.LINE_START;
 					settingsPanel.add( txtDuration, gbc_txtDuration);
 					JLabel lblDelay = new JLabel("Delay");
 					 GridBagConstraints gbc_lblDelay = new GridBagConstraints();
 				    gbc_lblDelay.insets = new Insets(0, 5, 5, 5);
 				    gbc_lblDelay.gridx = 0;
 					gbc_lblDelay.gridy = 2;
 					gbc_lblDelay.anchor=GridBagConstraints.LINE_START;
 	                settingsPanel.add(lblDelay, gbc_lblDelay);	
 					 txtDelay = new JTextField();
 					 txtDelay.setColumns(10);
 					 
 					 txtDelay.addCaretListener(new CaretListener() {
 							@Override
 							public void caretUpdate(CaretEvent e) {
 								// System.out.println(txtAmpl.getText());
 								 if(entity!=null) {
 									 if(!entity.existsElement("edu"))
 										 entity.createElement("edu");
 									 entity.putElementItem("edu", new Core(null,"delay",txtDelay.getText()));
 									 console.getEntigrator().putEntity(entity);
 								 }
 							}
 					      });
 					 
 					    GridBagConstraints gbc_txtDelay = new GridBagConstraints();
 					    gbc_txtDelay.insets=new Insets(3, 3, 5, 3);
 						gbc_txtDelay.gridx = 1;
 						gbc_txtDelay.gridy = 2;
 						gbc_txtDelay.anchor=GridBagConstraints.LINE_START;
 						settingsPanel.add( txtDelay, gbc_txtDelay);
 					String duration$=entity.getElementItemAt("edu", "duration");
 					txtDuration.setText(duration$);
 					String takt$=entity.getElementItemAt("edu", "takt");
 					txtTakt.setText(takt$);
 					String delay$=entity.getElementItemAt("edu", "delay");
 					txtDelay.setText(delay$);
 		   }
 	    int plotType=getPlotType();
 	    String closed$="false";
 	    switch(plotType) {
 	     case PLOT_TYPE_BODE_CLOSED: closed$="true";break;
 	     case PLOT_TYPE_STEP_CLOSED: closed$="true";;break;
 	    }
 	    entity.putElementItem("edu", new Core(null,"closed",closed$));
 	    entity.putElementItem("edu", new Core(null,"test",(String)cbxTest.getSelectedItem()));
 	    console.getEntigrator().putEntity(entity);
 	    if(eduHandler!=null) {
 			try {
 				eduHandler.reset(console.getEntigrator());
 				String[] sa=eduHandler.listInputs();
 				if(sa!=null) {
 				Arrays.sort(sa);	
 				DefaultComboBoxModel<String> model=	new DefaultComboBoxModel<String>(sa);
 				cbxIn.setModel(model);
 				}
 				}catch(Exception e) {
 					System.out.println("JEduEditor:"+e.toString());
 				}
 			try {
 				String[] sa=eduHandler.listOutputs(console.getEntigrator());
 				if(sa!=null) {
 				Arrays.sort(sa);	
 				DefaultComboBoxModel <String>model=	new DefaultComboBoxModel<String>(sa);
 				cbxOut.setModel(model);
 				}
 				}catch(Exception e) {
 					System.out.println("JEduEditor:"+e.toString());
 				}
 				}
 		String in$=entity.getElementItemAt("edu", "in");
 		if(in$==null) {
 			in$=(String)cbxIn.getSelectedItem();
 			if(in$!=null) {
 				entity.putElementItem("edu",new Core(null,"in",in$));
 				console.getEntigrator().putEntity(entity);
 			}
 		}else
 			selectCombo(cbxIn,in$);
 		String out$=entity.getElementItemAt("edu", "out");
 		if(out$==null) {
 			out$=(String)cbxIn.getSelectedItem();
 			if(out$!=null) {
 				entity.putElementItem("edu",new Core(null,"out",out$));
 				console.getEntigrator().putEntity(entity);
 			}
 		}else
 			selectCombo(cbxOut,out$);
 		
 		setPreferredSize(new Dimension(300,400));
 		revalidate();
 		repaint();
 	}

private void setInOuts() {
	 if(eduHandler!=null) {
			try {
				eduHandler.reset(console.getEntigrator());
				String[] sa=eduHandler.listInputs();
				if(sa!=null) {
				Arrays.sort(sa);	
				DefaultComboBoxModel<String> model=	new DefaultComboBoxModel<String>(sa);
				cbxIn.setModel(model);
				}
				}catch(Exception e) {
					System.out.println("JEduEditor:"+e.toString());
				}
			try {
				String[] sa=eduHandler.listOutputs(console.getEntigrator());
				if(sa!=null) {
				Arrays.sort(sa);	
				DefaultComboBoxModel <String>model=	new DefaultComboBoxModel<String>(sa);
				cbxOut.setModel(model);
				}
				}catch(Exception e) {
					System.out.println("JEduEditor:"+e.toString());
				}
				}
		String in$=entity.getElementItemAt("edu", "in");
		if(in$==null) {
			in$=(String)cbxIn.getSelectedItem();
			if(in$!=null) {
				entity.putElementItem("edu",new Core(null,"in",in$));
				console.getEntigrator().putEntity(entity);
			}
		}else
			selectCombo(cbxIn,in$);
		String out$=entity.getElementItemAt("edu", "out");
		if(out$==null) {
			out$=(String)cbxIn.getSelectedItem();
			if(out$!=null) {
				entity.putElementItem("edu",new Core(null,"out",out$));
				console.getEntigrator().putEntity(entity);
			}
		}else
			selectCombo(cbxOut,out$);
}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.edu.JEduEditor");
	    locator.put(Locator.LOCATOR_TITLE,"Edu editor");
	    locator.put(FacetHandler.FACET_KEY,KEY);
	    locator.put(FacetHandler.FACET_NAME,"Edu");
	    locator.put(FacetHandler.FACET_TYPE,"edu");
	    locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.EduMaster");
	    locator.put(IconLoader.ICON_FILE,"edu.png");
	 	locator.put(IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(DEFAULT_PARENT, JEntityFacetList.KEY);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.EduMaster");
		 return Locator.toString(locator);
	}
	@Override
	public JMenu getContextMenu() {
	JMenu	menu=super.getContextMenu();
		
		JMenuItem resetItem = new JMenuItem("Reset");
		 resetItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if(eduHandler==null) {
						System.out.println("JEduEditor:reset:eduHandler is null");
						return;
					}
					eduHandler.assignController( EduHandler.loadController(console.getEntigrator(), entity$));
					eduHandler.reset();
					setInOuts();
				}
			} );
			menu.add(resetItem);
			menu.addSeparator();
			JMenuItem folderItem = new JMenuItem("Folder");
			folderItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						File folder=new File(console.getEntigrator().getEntihome()+"/"+entity.getKey());
						try{Desktop.getDesktop().open(folder);}catch(Exception ee) {}
					}
				} );
				menu.add(folderItem);
				JMenuItem entityItem = new JMenuItem("Entity");
				entityItem.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							String facetsLocator$=JEntityFacetList.classLocator();
							facetsLocator$=Locator.append(facetsLocator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
							JEntityFacetList facetList=new JEntityFacetList(console,facetsLocator$);
							//JEduEditor.this.replace(console, facetList);
							console.replaceContext(JEduEditor.this, facetList);
						}
					} );
					menu.add(entityItem);	
			return menu;
	}
	private Response frequencyResponse(double f) {
		try {
		eduHandler.reset(console.getEntigrator());
		double open=1;
		String closed$=entity.getElementItemAt("edu","closed" );
		if("true".equals(closed$))
			open=-1;
		//System.out.println("JSisoEditor:frequencyResponse:f="+f);
		double xsin=0;
		double xcos=0;
		double y=0;
		double pi2=2*Math.PI;
		//System.out.println("JEduEditor:frequencyResponse:f="+f);
		Hashtable<String,Double> ins=new  Hashtable<String,Double>();
		Hashtable<String,Double> outs=new  Hashtable<String,Double>();
		String in$=(String)cbxIn.getSelectedItem();
		ins.put("open", open);
		ins.put("time", 0.0);
		String out$=(String)cbxOut.getSelectedItem();
		//System.out.println("JEduEditor:frequencyResponse:edu handler clock="+eduHandler.getClock());
		double dWt=pi2/100;
		double handlerClock=eduHandler.getClock();
		double handlerF=dWt/handlerClock;
		double factor=(handlerF/f);
		double clock=dWt/f;
		System.out.println("JEduEditor:frequencyResponse:f="+f+"   factor="+factor+" dWt="+dWt+" clock="+clock);
		if(factor>0.1) {
			dWt=dWt/(factor*10);
			clock=dWt/f;
		}
		//System.out.println("JEduEditor:frequencyResponse:dWt="+dWt+"  clock="+clock);
		double wt=0;
		double time=0;
		ins.put("time", 0.0);
		while (wt<2*pi2) {
			        xsin=Math.sin(wt);
					xcos=Math.cos(wt);
					ins.put(in$, xcos);
					ins.put("clock",clock);
					outs=eduHandler.stride(ins);
					
				//	System.out.println("JEduEditor:frequencyResponse:1");
					time=time+clock;
					ins.put("time", time);
					wt=wt+dWt;
					//System.out.println("JEduEditor:frequencyResponse:wt="+wt);
					 if(breakRun)
							break;
		}
		double yCosSum=0;
		double ySinSum=0;
			while(wt<4*pi2) {
			xsin=Math.sin(wt);
			xcos=Math.cos(wt);
			ins.put(in$, xcos);
			ins.put("clock",clock);
		    outs=eduHandler.stride(ins);
			time=time+clock;
			ins.put("time", time);
			y=0;
			try { y=outs.get(out$);}catch(Exception ee) {}
			 yCosSum=yCosSum+y*xcos*dWt;
			 ySinSum=ySinSum+y*xsin*dWt;
		     if(breakRun)
						break;
		     wt=wt+dWt;
			}
		double ycos=yCosSum/Math.PI;
		double ysin=ySinSum/Math.PI;
		MathUtil.V2 yv=new MathUtil.V2(ycos,ysin);
		double angle=yv.angle();
		double gain=yv.norm()/2;
		//System.out.println("JEduEditor:frequencyResponse: ycos="+ycos+" ysin="+ysin+"  yCosSum="+yCosSum+"  ySinSum="+ySinSum+"  gaun="+gain);
		return new Response(gain,angle);
		}catch(Exception e) {
			System.out.println("JEduEditor:frequencyResponse:"+e.toString());
			return null;
		}
	}	
	Runnable Snapshot=new Runnable() {	
    public  void run() {
	try {
		btnRun.setEnabled(false);
    	btnStop.setEnabled(true);
     	breakRun=false;
     	String event$=null;
     	if("Bandwidth(open)".equals((String)cbxTest.getSelectedItem())) {
     		frequencyCycle();
     	    event$="Bandwidth(open)";
     	}
     	if("Bandwidth(closed)".equals((String)cbxTest.getSelectedItem())) {
     	    frequencyCycle();
     	   event$="Bandwidth(closed)";
     	}
     	if("Step(closed)".equals((String)cbxTest.getSelectedItem())) {
     	    stepResponse();
     	   event$="Step(closed)";
     	}
     	if("Step(open)".equals((String)cbxTest.getSelectedItem())) {
     	    stepResponse();
     	   event$="Step(open)";
     	}
     	if("Hodograph".equals((String)cbxTest.getSelectedItem())) {
     		hodographCycle();
     		  event$="Hodograph";
     	}
   	  	btnStop.setEnabled(false);
   	   	breakRun=false;
   	    btnRun.setEnabled(true);
   	 transferData();
   	  Properties request=new Properties();
   	request.put(EventHandler.REQUESTOR,entity.getKey());
   	request.put(EventHandler.MESSAGE,event$);
    String request$=Locator.toString(request);
    System.out.println("JEduEditor:snapshot:request="+request$);
    console.getEntigrator().putRequest(request$);
	}catch(Exception e) {
		System.out.println("JEduEditor:snapshot:"+e.toString());
	}
}
};
private void prepareCycleIndicator() {
	try {
	double tmax=Double.parseDouble(entity.getElementItemAt("edu","tmax" ));
	double tmin=Double.parseDouble(entity.getElementItemAt("edu","tmin" ));
	double increment=1.1;
	try {increment=Double.parseDouble(entity.getElementItemAt("edu","increment" ));}catch(Exception e) {}
	if(increment<=1.0)
		increment=1.1;
	double fmin=0.1/tmax;
	double fmax=10/tmin;
	double nd=(Math.log10(fmax/fmin))/Math.log10(increment);
	//System.out.println("JSisoEditor:prepareCycleIndicator:nd="+nd);
	cycles=(int)nd;
	lblProgress.setText("Cycles");
	txtProgress.setText(String.valueOf(cycles));
	}catch(Exception e) {
		System.out.println("JSisoEditro:prepareCycleIndicator:"+e.toString());
	}
}
private boolean frequencyCycle( )  {
	double tmax=Double.parseDouble(entity.getElementItemAt("edu","tmax" ));
	double tmin=Double.parseDouble(entity.getElementItemAt("edu","tmin" ));
	String closed$=entity.getElementItemAt("edu","closed");
	double increment=1.1;
	try {increment=Double.parseDouble(entity.getElementItemAt("edu","increment" ));}catch(Exception e) {}
	if(increment<=1)
		increment=1.1;
	double fmin=1/tmax;
	double fmax=1/tmin;
	//System.out.println("JEduEditor:frequencyCycle:fmin="+fmin+"  fmax="+fmax);
	double f=fmin;
	boolean breaked=false;
	Response response=null;
	String path$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/frequ.data";
	if("true".equals(closed$))
		 path$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/freqc.data";
	File folder=new File(console.getEntigrator().getEntihome()+"/"+entity.getKey());
	if(!folder.exists()) {
	System.out.println("JEduEditor:frequencyCycle:entity="+entity.getProperty("label")+" has no folder");
	return false;
	}
	File freq=new File(path$);
    if(freq.exists())
    	freq.delete();
	try {
	freq.createNewFile();
	//System.out.println("JEduEditor:frequencyCycle:freq="+freq.getPath());
	PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(path$, true)));
	String line$;
	String format$="0.####E0";
	NumberFormat valFormat = new DecimalFormat(format$);
	String cycles$=txtProgress.getText();
	cycles=0;
	try {cycles=Integer.parseInt(cycles$);}catch(Exception ee) {}
	while(f<fmax) {
		//System.out.println("JEduEditor:frequencyCycle:cycle="+cycles+" f="+f);
		response=frequencyResponse(f);
		line$=valFormat.format(f)+";"+valFormat.format(response.gain)+";"+valFormat.format(response.angle);
		//System.out.println("JEduEditor:frequencyCycle:response="+line$);
		writer.println(line$);
		f=increment*f;
		if(breakRun) {
			breaked=true;
			break;
		}
		try{
			cycles=cycles-1;
   			txtProgress.setText(String.valueOf(cycles));
		}catch(Exception e) {}
		//System.out.println("JEduEditor:frequencyCycle:f="+f);
	}
	prepareCycleIndicator();
	writer.close();
	
	}catch(Exception e) {
		System.out.println("JEduEditor:frequencyCycle:"+e.toString());
	}
	
	return breaked;
}
private boolean hodographCycle()  {
	double tmax=Double.parseDouble(entity.getElementItemAt("edu","tmax" ));
	double tmin=Double.parseDouble(entity.getElementItemAt("edu","tmin" ));
	double increment=1.1;
	try {increment=Double.parseDouble(entity.getElementItemAt("edu","increment" ));}catch(Exception e) {}
	if(increment<1.1)
		increment=1.1;
	double fmin=1/(10*tmax);
	double fmax=10/tmin;
	double f=fmin;
	boolean breaked=false;
	String path$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/freqn.data";
	File freq=new File(path$);
    if(freq.exists())
    	freq.delete();
	try {
	freq.createNewFile();	
	PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(path$, true)));
	String line$;//=new StringBuffer();
	String format$="0.####E0";
	NumberFormat valFormat = new DecimalFormat(format$);
	Response response;
	V2 v=null;
	while(f<fmax) {
		response=frequencyResponse(f);
		v=response.toVector();
		if(v!=null) {
		line$=valFormat.format(v.x)+";"+valFormat.format(v.y)+";"+valFormat.format(f);
		writer.println(line$);
		}
		//System.out.println("JSisoEditor:nyquistCycle:gain="+response.gain+" angle="+response.angle+" f="+f);
		f=increment*f;
		if(breakRun) {
			breaked=true;
			break;
		}
		try{
			String cycles$=txtProgress.getText();
			int cycles=Integer.parseInt(cycles$);
			cycles=cycles-1;
			if(cycles>=0)
    			txtProgress.setText(String.valueOf(cycles));
			else
				prepareCycleIndicator();
		}catch(Exception e) {}
	}
	writer.close();
	}catch(Exception e) {
		System.out.println("JEduEditor:hodographCycle:"+e.toString());
	}
	return breaked;
}
private void stepResponse() {
	//System.out.println("JEduEditor:stepResponse:BEGIN");
	double tmax=0;
	String tmax$=txtDuration.getText();
	try {tmax=Double.parseDouble(tmax$);}catch(Exception ee) {}
	if(tmax==0) {
		System.out.println("JEduEditor:stepResponse:duration not defined");
		return;
	}
	String takt$=txtTakt.getText();
	double takt=0;
	try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
	if(takt==0) {
		System.out.println("JEduEditor:stepResponse:takt not defined");
		return;
	}
	String delay$=txtDelay.getText();
	double delay=0;
	try {delay=Double.parseDouble(delay$);}catch(Exception ee) {}
	double y=0;
	String step$="stepo.data";
	int plotType=getPlotType();
	double open=1;
	if(PLOT_TYPE_STEP_CLOSED==plotType) {
		 step$="stepc.data";
		 entity.putElementItem("edu",new Core(null,"closed","true"));
		 open=-1;
	}
	if(PLOT_TYPE_STEP_OPEN==plotType) {
		 entity.putElementItem("edu",new Core(null,"closed","false"));
	}
	console.getEntigrator().putEntity(entity);
	 String path$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/"+step$;
     File step=new File(path$);
     if(step.exists())
     	step.delete();
 	try {
 		eduHandler.reset();
		step.createNewFile();
		PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(path$, true)));
		String line$;
		String format$="0.####E0";
		NumberFormat valFormat = new DecimalFormat(format$);
		Hashtable<String,Double> ins=new  Hashtable<String,Double>();
		Hashtable<String,Double> outs=new  Hashtable<String,Double>();
		String in$=(String)cbxIn.getSelectedItem();
		//ins.put("clock", takt);
		ins.put("open", open);
		ins.put("time", 0.0);
		ins.put(in$, 0.0);
		ins.put("clock",takt); 
		eduHandler.setClock(takt);
		String out$=(String)cbxOut.getSelectedItem();
	//	System.out.println("JSisoEditor:stepResponse:out="+out$+" in="+in$);
		double tau=0;
		while(tau<tmax) {
			tau=tau+takt;
			if(tau>delay) 
				ins.put(in$, 1.0);
  			ins.put("time", tau);
  			ins.put("clock",takt); 
			outs=eduHandler.stride(ins);
			if(outs==null) {
				System.out.println("JEduEditor:stepResponse:eduHandler="+eduHandler.getInstance()+": transition outs  is null");
				break;
			}
			y=outs.get(out$);
			line$=valFormat.format(tau)+";"+valFormat.format(y);
			writer.println(line$);
			btnStop.setEnabled(true);
			if(breakRun)
				break;
			txtProgress.setText(valFormat.format(tau));
		}
		writer.close();
		}catch(Exception e) {
			System.out.println("JEduEditor:stepResponse:"+e.toString());
		}
}
@Override
public String getSubtitle() {
	  return Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
}
@Override
public String getTitle() {
	  return "Edu editor";
}
private void  showPlot() {
	Sack plot=getPlot();
	if(plot==null) {
		 System.out.println("JEduEditor:showPlot:cannot find plot ");
		 return;
	}
	transferData();
	String plotLocator$=JPlotPanel.classLocator();
	plotLocator$=Locator.append(plotLocator$, Entigrator.ENTITY_LABEL, plot.getProperty("label"));	
	String instance$=Locator.getProperty(getLocator(), INSTANCE);
	plotLocator$=Locator.append(plotLocator$, PARENT, instance$);	
	plotLocator$=Locator.append(plotLocator$, INSTANCE, Identity.key());
	String plotType$=(String)cbxTest.getSelectedItem();
	//System.out.println("JSisoEditor:showPlot:plot type="+plotType$);
	if( PLOT_TYPE_HODOGRAPH.equals(plotType$)) {
		//System.out.println("JSisoEditor:showPlot:Hodograph");
		plotLocator$=Locator.append(plotLocator$, JPlotPanel.POINT_DISPLAY,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.siso.HodographPointDisplay");
		
		if(!plot.existsElement("plot"))
		     plot.createElement("plot");
		plot.putElementItem("plot", new Core(null,"point.display","_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.edu.HodographPointDisplay"));
		console.getEntigrator().putEntity(plot);
	}
	plotLocator$=Locator.append(plotLocator$, Locator.LOCATOR_TITLE, plotType$);
	 JPlotPanel plotViewer=new JPlotPanel(console,plotLocator$);
	 plotViewer.setPreferredSize(getSize());
	console.replaceContext(this,plotViewer);
}

private int getPlotType() {
	String plotType$=(String)cbxTest.getSelectedItem();
	//System.out.println("JSisosEditor:getPlotType:plot type="+plotType$);
	if("Bandwidth(closed)".equals(plotType$)) {
	//	System.out.println("JSisosEditor:getPlotType:closed="+PLOT_TYPE_BODE_CLOSED);
		return PLOT_TYPE_BODE_CLOSED;
	}
	if("Bandwidth(open)".equals(plotType$)) {
		//System.out.println("JSisosEditor:getPlotType:unclosed="+PLOT_TYPE_BODE_OPEN);
		return 	
PLOT_TYPE_BODE_OPEN;
	}
	if("Step(closed)".equals(plotType$)) {
		//System.out.println("JSisosEditor:getPlotType:step="+PLOT_TYPE_STEP_CLOSED);
		return PLOT_TYPE_STEP_CLOSED;
	}
	if("Step(open)".equals(plotType$)) {
		//System.out.println("JSisosEditor:getPlotType:step="+PLOT_TYPE_STEP_OPEN);
		return PLOT_TYPE_STEP_OPEN;
	}
	if("Hodograph".equals(plotType$)) {
		//System.out.println("JSisosEditor:getPlotType:step="+PLOT_TYPE_HODOGRAPH_OPEN);
		return PLOT_TYPE_HODOGRAPH_OPEN;
	}
	return -1;
}
private void transferData() {
	try {
	int plotType=getPlotType();	
	//System.out.println("JEduEditor:transferData:plot type="+plotType);
	String in$=null;
	String out$=null;
	Sack plot=getPlot();
	   String plotHome$=console.getEntigrator().getEntihome()+"/"+plot.getKey();
	  FileTool.clear(plotHome$);
	if(PLOT_TYPE_BODE_OPEN==plotType) {
			in$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/frequ.data";
			out$=console.getEntigrator().getEntihome()+"/"+plot.getKey()+"/frequ.data";	
	}
	if(PLOT_TYPE_BODE_CLOSED==plotType) {
		in$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/freqc.data";
		out$=console.getEntigrator().getEntihome()+"/"+plot.getKey()+"/freqc.data";	
   }
	if(PLOT_TYPE_STEP_CLOSED==plotType) {
		in$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/stepc.data";
		out$=console.getEntigrator().getEntihome()+"/"+plot.getKey()+"/stepc.data";	
   }
	if(PLOT_TYPE_STEP_OPEN==plotType) {
		in$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/stepo.data";
		out$=console.getEntigrator().getEntihome()+"/"+plot.getKey()+"/stepo.data";	
   }
	if(PLOT_TYPE_HODOGRAPH_OPEN==plotType) {
		in$=console.getEntigrator().getEntihome()+"/"+entity.getKey()+"/freqn.data";
		out$=console.getEntigrator().getEntihome()+"/"+plot.getKey()+"/freqn.data";	
   }
	//System.out.println("JEduEditor:transferData:in="+in$+"  out="+out$);
	File in=new File(in$);
	Scanner ins = new Scanner(in);	
	File out=new File(out$);
	if(out.exists())
		out.delete();
	out=new File(out$);
	PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(out)));
	String line$;
	while(ins.hasNextLine()) {
		line$=ins.nextLine();
		writer.write(line$+"\n");
	}
	ins.close();
	writer.close();
	}catch(Exception e) {
		System.out.println("JEduEditor:transferData:"+e.toString());
	}
}
private Sack getPlot() {
	int i=cbxTest.getSelectedIndex();
	return getPlot(i);
}
private Sack getPlot(int typeIndex) {
	try {
       String plotType$=null;
       switch(typeIndex) {
       case 0:plotType$=PLOT_TYPE_BANDWIDTH_OPEN;break;
       case 1:plotType$=PLOT_TYPE_BANDWIDTH_CLOSED;break;
       case 2:plotType$=PLOT_TYPE_HODOGRAPH;break;
       case 3:plotType$=PLOT_TYPE_STEP_CLOSED_RESPONSE;break;
       case 4:plotType$=PLOT_TYPE_STEP_OPEN_RESPONSE;break;
       }
	   String [] sa=entity.elementListNames("link");
		if(sa!=null) {
			Sack candidate;
			for(String s:sa) {
				candidate=console.getEntigrator().getEntity(s);
				if(candidate!=null) {
					String candidateType$=candidate.getProperty("plot type");
					if(plotType$.equals(candidateType$)) {
					//	System.out.println("JSisoEditor:getPlot:found ="+candidate.getProperty("label"));
					    
						return candidate;
					}
				}
			}
		}
		//System.out.println("JSisoEditor:getPlot:not found at type="+plotType$+". Remake");
	  Sack plot= remakePlot(typeIndex);
	  plot=console.getEntigrator().assignProperty("plot type", plotType$, plot.getKey());
	  return plot;
	}catch(Exception e) {
		System.out.println("JSisoEditor:getPlot:"+e.toString());
	}
	return null;
}
private Sack remakePlot(int plotType) {
	//System.out.println("JSisoEditor:remakePlot:type="+plotType);
	try {
		String plotType$="";
		String suffix$="";
		double tmark=1;
		try {tmark=	Double.parseDouble(txtTmax.getText());}catch(Exception ee) {}
		double tmax=5*tmark;
		double tmin=0.1;
		if(plotType==PLOT_TYPE_BODE_OPEN) {
			suffix$="bode(open)";
		}
		if(plotType==PLOT_TYPE_BODE_CLOSED) {
			suffix$="bode(closed)";
		}
		if(plotType==PLOT_TYPE_STEP_CLOSED) {
			suffix$="step(closed)";
		}
		if(plotType==PLOT_TYPE_STEP_OPEN) {
			suffix$="step(open)";
		}
		if(plotType==PLOT_TYPE_HODOGRAPH_OPEN) {
			suffix$="hodograph";
		}
		String [] sa=entity.elementListNames("link");
		if(sa!=null) {
			Sack candidate;
			for(String s:sa) {
				candidate=console.getEntigrator().getEntity(s);
				if(candidate!=null) {
					String candidateType$=candidate.getProperty("plot type");
					if(plotType$.equals(candidateType$))
						console.getEntigrator().deleteEntity(s);
				}
			}
		}
		String plotLabel$=entity.getProperty("label")+"."+suffix$;
		//System.out.println("JSisoEditor:createPlot:plot label="+plotLabel$+" entity key="+entity.getKey());
		Properties plotLocator=new Properties();
		plotLocator.put( ModuleHandler.FACET_MODULE, "_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		plotLocator.put( FacetMaster.MASTER_CLASS, "_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster");
		String plotLocator$=Locator.toString(plotLocator);
		PlotMaster plotMaster=(PlotMaster)FacetMaster.build(console, plotLocator$);
		Sack plot= plotMaster.createEntity(console.getEntigrator(), plotLabel$);
		console.getEntigrator().putEntity(plot);
		plot=console.getEntigrator().assignProperty("plot type", plotType$, plot.getKey());
		console.getEntigrator().link(entity, plot);
		plot.createElement("Quadrant");
		plot.putElementItem("Quadrant", new Core("50","Vertical","0.8"));
		plot.putElementItem("Quadrant", new Core("50","Horizontal","0.8"));
		plot.createElement("Surface");
		plot.putElementItem("Surface", new Core(null,"Horizontal",null));
		plot.putElementItem("Surface", new Core("0","Vertical","0.8"));
		plot.putElementItem("Surface", new Core("0","Horizontal","0.8"));
		plot.createElement("canvas");
		if(plotType==2)
			plot.putElementItem("canvas", new Core(null,"area","Surface"));
		else
		    plot.putElementItem("canvas", new Core(null,"area","Quadrant"));
		plot.putElementItem("canvas", new Core(null	,"backcolor","white"));
		plot.putElementItem("canvas", new Core(null	,"font.color","blue"));
		plot.putElementItem("canvas", new Core(null,"font.size","12"));
		plot.putElementItem("canvas", new Core(null,"font.style","bold"));
		plot.putElementItem("canvas", new Core(null,"frontcolor","black"));
		plot.putElementItem("canvas", new Core(null,"pointer.size","6"));
		plot.putElementItem("canvas", new Core(null,"shift","20"));
		plot.putElementItem("canvas", new Core(null,"stroke","2"));
		plot.createElement("scale.layout");
		if(plotType==0||plotType==1) {
			plot.putElementItem("scale.layout", new Core("Vertical","gain","0"));
        	plot.putElementItem("scale.layout", new Core("Horizontal","frequency","0"));
		}
		if(plotType==2) {
			plot.putElementItem("scale.layout", new Core("Vertical","Im","0"));
        	plot.putElementItem("scale.layout", new Core("Horizontal","Re","0"));
		}
		if(plotType==3||plotType==4) {
			plot.putElementItem("scale.layout", new Core("Vertical","response","0"));
        	plot.putElementItem("scale.layout", new Core("Horizontal","time","0"));
		}
		plot.createElement("scale.mark");
		if(plotType==0||plotType==1) {
			plot.putElementItem("scale.mark", new Core("(1/s)","frequency","2"));
			plot.putElementItem("scale.mark", new Core("","gain","2"));
		}
		if(plotType==2) {
			plot.putElementItem("scale.mark", new Core("","Im","1"));
			plot.putElementItem("scale.mark", new Core("","Re","1"));
			}
		if(plotType==3||plotType==4) {
			plot.putElementItem("scale.mark", new Core("(s)","time",String.valueOf(tmark)));
			plot.putElementItem("scale.mark", new Core("","response","0.5"));
			}
		plot.createElement("scale.max");
		if(plotType==0||plotType==1) {
			int fmax=(int)(100*Math.log10(tmax/tmin));
			plot.putElementItem("scale.max", new Core("##.##","frequency",String.valueOf(fmax)));
		}
		if(plotType==2) {
			plot.putElementItem("scale.max", new Core("##.##","Im","2"));
			plot.putElementItem("scale.max", new Core("##.##","Re","2"));
		}
		if(plotType==3||plotType==4) {
			plot.putElementItem("scale.max", new Core("##.##","time",String.valueOf(tmax)));
			plot.putElementItem("scale.max", new Core("##.##","response","2"));
		}
		plot.createElement("scale.raster");
		if(plotType==0||plotType==1) {
		plot.putElementItem("scale.raster", new Core("logarithmic","frequency","10"));
		plot.putElementItem("scale.raster", new Core("logarithmic","gain","10"));
		}
		if(plotType==2) {
			plot.putElementItem("scale.raster", new Core("linear","Re","1"));
			plot.putElementItem("scale.raster", new Core("linear","Im","1"));
			}
		if(plotType==3||plotType==4) {
			plot.putElementItem("scale.raster", new Core("linear","time",String.valueOf(tmark)));
			plot.putElementItem("scale.raster", new Core("linear","response","0.5"));
			}
		String rayKey$=Identity.key();
		plot.createElement("ray.color");
		plot.putElementItem("ray.color", new Core(null,rayKey$,"red"));
		plot.createElement("ray.index");
		plot.putElementItem("ray.index", new Core(null,rayKey$,"0"));
		plot.createElement("ray.name");
		plot.putElementItem("ray.name", new Core(null,rayKey$,"y"));
		plot.createElement("ray.scale");
		if(plotType==0||plotType==1)
			plot.putElementItem("ray.scale", new Core(null,rayKey$,"gain"));
		if(plotType==2)
			plot.putElementItem("ray.scale", new Core(null,rayKey$,"Im"));
		if(plotType==3)
			plot.putElementItem("ray.scale", new Core(null,rayKey$,"response"));
		plot.createElement("ray.shift");
		plot.putElementItem("ray.shift", new Core(null,rayKey$,"0"));
		plot.createElement("ray.symbol");
		plot.putElementItem("ray.symbol", new Core(null,rayKey$,""));
		plot.createElement("ray.visible");
		plot.putElementItem("ray.visible", new Core("2",rayKey$,"true"));
		console.getEntigrator().putEntity(plot);
		//plot.print();
		return plot;
	}catch(Exception e) {
		System.out.println("JSisoEditor:createPlot:"+e.toString());
	}
	return null;
}
class Response{
	public double gain;
	public double angle;
	public Response(double gain,double angle) {
		this.gain=gain;
		this.angle=angle;
	}
	public void print(){
		System.out.println("JEduEditor:response: gain="+gain+" angle="+angle);	
	}
	public V2 toVector() {
		try {
			double radAngle=Math.toRadians(-angle);
			double x=gain*Math.cos(radAngle);
			double y=gain*Math.sin(radAngle);
			return new V2(x,y);
		}catch(Exception e) {
			System.out.println("JEduEditor:response:toVector:"+e.toString()); 
		}
		return null;
	}
}
@Override
public String reply(JMainConsole console, String locator$) {
	return null;
}
@Override
public void propertyChange(PropertyChangeEvent evt) {
	//System.out.println("JEduEditor:propertyChange:evt="+EventHandler.getLocator(console.getEntigrator()));
}

}
 