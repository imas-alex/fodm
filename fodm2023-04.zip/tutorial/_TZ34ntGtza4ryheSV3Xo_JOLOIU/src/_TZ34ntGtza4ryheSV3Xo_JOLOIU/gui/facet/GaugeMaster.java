package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.GaugeHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.gauge.JGaugeEditor;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;

public class GaugeMaster extends FacetMaster{
	public static final String KEY="_sKamxIx_MFicnfIfpb_S8Jn_S6MTM";
	public static final String NAME="Gauge";
	public GaugeMaster() {
		super();
	}
	public GaugeMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return NAME;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.GaugeMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.GaugeHandler");
	    locator.put(HANDLER_KEY,"_LB2om6c408RCVAHg5lk9Pthk_SM0");
	    locator.put(Locator.LOCATOR_TITLE,"Gauge");
	    locator.put(MASTER_KEY,"_sKamxIx_MFicnfIfpb_S8Jn_S6MTM");
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "gauge.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
	    locator.put(FacetHandler.FACET_TYPE,GaugeHandler.GAUGE_FACET_TYPE);
	    return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		//System.out.println("GaugeMaster:getJEntityFacetsItem:locator="+handlerLocator$);
		String itemLocator$=JItemPanel.classLocator();
		String masterLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, masterLocator$);
		String display$=Locator.getProperty(handlerLocator$, JContext.DISPLAY);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		if(display$!=null)
			itemLocator$=Locator.append(itemLocator$,JContext.DISPLAY,display$);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= GaugeHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new GaugeHandler(console.getEntigrator(),handlerLocator$); 
	}
	
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		//	System.out.println("DiagrammaMaster:entityFacetsItemOnClick:entity label="+entityLabel$);
			String gaugeEditor$=JGaugeEditor.classLocator();
			gaugeEditor$=Locator.merge(gaugeEditor$,alocator$);
			gaugeEditor$=Locator.append(gaugeEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			String parentInstance$=context.getInstance();
			String parentLocator$=context.getLocator();
			SessionHandler.putLocator(console.getEntigrator(), parentLocator$);
			gaugeEditor$=Locator.append(gaugeEditor$,JContext.PARENT, parentInstance$);
	       	JGaugeEditor gaugeEditor=new JGaugeEditor(console,gaugeEditor$);	
			console.replaceContext(context,gaugeEditor);
		}catch(Exception e) {
			System.out.println("GaugeMaster:entityFacetsItemOnClick:"+e.toString());	
		}
		}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
	//	final String itemLocator$=alocator$;
		JPopupMenu popup=new JPopupMenu();
		JMenuItem newItem=new JMenuItem("New gauge");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("GaugeMaster:allFacetsItemPopup:new entity:locator="+itemLocator$);
				popup.setVisible(false);
				String textEditor$=JTextEditor.classLocator();
				textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New gauge");
				String facetList$=JEntityFacetList.classLocator();
				facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
				facetList$=Locator.append(facetList$,MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.GaugeMaster");
				facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
				SessionHandler.putLocator(console.getEntigrator(),facetList$);
				textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
				JTextEditor textEditor=new JTextEditor(console,textEditor$);
				//console.replaceContext(textEditor);
				console.replaceContext(GaugeMaster.this.context, textEditor);
			}
		} );
		popup.add(newItem);
		return popup;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public String getType() {
		return "gauge";
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",getType(),classLocator()));
		entity.putAttribute(new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU","icon","gauge.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty( "operator","true", entity.getKey());
		return entity;
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",GaugeHandler.KEY,GaugeHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("GaugeMaster:addToSession:"+e.toString());
	    }
}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
}
