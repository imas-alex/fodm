package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class EduHandler extends OperatorHandler implements SegueController{
	public static final String KEY="_sQY6aqECy8rZbR3p_SL4z6LagLsQ";	
	public static final String CONTROLLER="controller";	
	public static final String LOADABLE="loadable";	
	public static final String EMBEDDED="embedded";	

	private Sack entity;
	protected SegueController controller;
	Hashtable<String,Double> bond;
	boolean isCdu=false;
	public EduHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		if(operatorKey$==null) {
			System.out.println("EduHandler:operator key is null. Locator="+locator$);
			return;
		}
		entity=entigrator.getEntity(operatorKey$);
		if(entity==null) {
			System.out.println("EduHandler:cannot get entity at key="+operatorKey$);
			return;
		}
		setController();
	}
	public String getInstance() {
		if(entity==null)
			return null;
		else
			return entity.getProperty("label");
	}
	public SegueController getController() {
		return controller;
	}
	public void assignController(SegueController controller) {
		this.controller=controller;
	}
	private void setController() {
		//System.out.println("EduHandler:setController:BEGIN");
		if(controller!=null) {
			//System.out.println("EduHandler:setController:controller="+controller.getClass().getName());
			return;
		}
		if(entity==null) {
			System.out.println("EduHandler:setController:entity is null");
			return;
		}
		   controller=loadController(entigrator,entity.getKey());
		if(controller==null)
			System.out.println("EduHandler:cannot set controller for entity="+entity$);
	}
	public void step(Entigrator entigrator, String locator$) {
		try {
			Sack entity=entigrator.getEntity(operatorKey$);
			//System.out.println("EduHandler:step:entity="+entity.getProperty("label"));
			String takt$=entity.getElementItemAt(OPERATOR, "takt");
			double takt=0;
			try {takt=Double.parseDouble(takt$);}catch(Exception ee) {}
			double time=0;
			String time$=entity.getElementItemAt(OPERATOR, "time");
			try {time=Double.parseDouble(time$);}catch(Exception ee) {}
			Hashtable<String,Double> ins=new  Hashtable<String,Double>(	);
			int cnt=(int)(takt/getClock());
		//	System.out.println("EduHandler:step:takt="+takt+" clock="+getClock()+" cnt="+cnt);
			Core[] ca=entity.elementGet(OPERATOR);
			double in=0;
			for(Core c:ca) {
				if("in".equals(c.type)) {
					in=0;
			       try{in=Double.parseDouble(c.value);}catch(Exception ee) {}
			       ins.put(c.name, in);
					}
				}
			Hashtable<String,Double> outs=new Hashtable<String,Double>();
			//stride cycle
			if(cnt<2) {
			ins.put("clock", takt);
			ins.put("time", time);
		//	System.out.println("EduHandler:step:cnt="+cnt+ "clock="+ins.get("clock"));
			outs=stride(ins);
			}else {
				double tau=time;
				double endTime=time+takt;
				double clock=getClock();
				while(tau<endTime)
				{
					ins.put("clock", clock);
					ins.put("time", tau);
					outs=stride(ins);
					tau=tau+clock;
				}
				double dt=tau-time;
				if(dt>0) {
					ins.put("clock", dt);
					ins.put("time", tau-clock);
					outs=stride(ins);
				}
			}
			//end stride cycle
			if(outs!=null) {
				Enumeration<String>  oe= outs.keys();
				String key$=null;
				double value;
				while (oe.hasMoreElements()) {
					key$ = oe.nextElement();
		            value=outs.get(key$);
		            entity.putElementItem(OPERATOR, new Core("out",key$,String.valueOf(value)));
				}
				entigrator.putEntity(entity);
			}
		}catch(Exception e) {
			System.out.println("EduHandler:step:"+e.toString());
		}
	}
	@Override
	public void reset(Entigrator entigrator, String locator$) {
		//System.out.println("EduHandler:reset:");
		this.entigrator=entigrator;
		reset();
	}
	public void reset(Entigrator entigrator) {
		this.entigrator=entigrator;
		reset();
	}
	@Override
	public void reinit(Entigrator entigrator, String locator$) {
		reset(entigrator);
	}
	@Override
	public String[] listOutputs(Entigrator entigrator) {
		//System.out.println("EduHandler:listOutputs.BEGIN:is cdu="+isCdu);
		refresh(entigrator);
		if(controller!=null)
			return controller.listOutputs();
		System.out.println("EduHandler:listOutputs:controller is null");
		return null;
	}
private void refresh(Entigrator entigrator) {
	if(operatorKey$==null) {
		return;
	}
	entity=entigrator.getEntity(operatorKey$);
	if(entity==null) {
		System.out.println("EduHandler:refresh:cannot get entity at key="+operatorKey$);
		return;
	}
	setController();
}
	@Override
	public String[] listInputs(Entigrator entigrator) {
		refresh(entigrator);
	
		if(controller!=null)
			return controller.listInputs();
		System.out.println("EduHandler:listOutputs:controller is null");
		return null;
	}
	@Override
	public String getLocator() {
		String classLocator$=classLocator();
		classLocator$=Locator.merge(classLocator$, locator$);
		return classLocator$;
	}
	@Override
	public String getName() {
		return "Edu";
	}
	public String getEntityName() {
		if(operatorKey$==null||entigrator==null)
			return null;
		return entigrator.getLabel(operatorKey$);
	}
	@Override
	public String getType() {
		return "edu";
	}
@Override
	public String getFacetClass() {
		return "_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler";
	}

	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return entity;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
			return entity;
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"Edu");
		locator.put(FACET_TYPE,"edu");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler");
		locator.put(FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.EduMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put( IconLoader.ICON_FILE, "edu.png");
		locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		return Locator.toString(locator);
	}
	public static  SegueController  loadController(Entigrator entigrator, String entityKey$) {
		if(entityKey$==null) {
			System.out.println("EduHandler:loadController:entity key is null");
			return null;
		}
//		System.out.println("EduHandler:loadController:entity key ="+entityKey$);
		try {
			File bin=new File(entigrator.getEntihome()+"/"+entityKey$+"/bin");
			if(!bin.exists()) {
				System.out.println("EduHandler:loadController:not exists file="+bin.getPath());
				return null;
			}
			URL url=bin.toURI().toURL();
			ClassLoader parentClassLoader=SegueController.class.getClassLoader();
			URLClassLoader cl=new URLClassLoader(new URL[]{url},parentClassLoader);
			Class<?> cls =cl.loadClass(entityKey$);
				Object obj=cls.getDeclaredConstructor().newInstance();
				if(obj instanceof SegueController) {
					((SegueController)obj).setEntigrator(entigrator);
					cl.close();
				    return (SegueController)obj;
				}
				cl.close();
		}catch(Exception e) {
			System.out.println("EduHandler:loadController:"+e.toString());
		}
		return null;
	}
	@Override
	public Hashtable <String,Double>getSettings() {
		if(controller!=null)
			controller.getSettings();
		return null;
	}
	@Override
	public void reset() {
		//System.out.println("EduHandler:reset:entity="+entity.getProperty("label"));
		try {
		refresh(entigrator);
		  controller=loadController(entigrator,entity.getKey());
		//setController();
		if(controller==null) {
			System.out.println("EduHandler:reset:controller is null for  edu="+getEntityName());
		}
		//System.out.println("EduHandler:reset:controller="+controller.getClass().getName());
		controller.setEntigrator(entigrator);
		controller.reset();
		if(!"true".equals(entity.getProperty("cdu"))) {
			 return;
		}
		String[] sa=listInputs();
		if(sa!=null) {
			entity=entigrator.getEntity(operatorKey$);
			if(entity!=null) {
				if(!entity.existsElement(OPERATOR))
					entity.createElement(OPERATOR);
			for(String s:sa) {
				entity.putElementItem(OPERATOR, new Core("in",s,"0"));
			}
			if(entigrator!=null)
			entigrator.putEntity(entity);
			}
		}
		sa=listOutputs();
		//System.out.println("EduHandler:reset;outputs");
		if(sa!=null) {
			//System.out.println("EduHandler:reset;outputs="+sa.length);
			entity=entigrator.getEntity(operatorKey$);
			if(entity!=null) {
				if(!entity.existsElement(OPERATOR))
				entity.createElement(OPERATOR);
			for(String s:sa) {
				entity.putElementItem(OPERATOR, new Core("out",s,"0"));
			}
			if(entigrator!=null)
			entigrator.putEntity(entity);
			}
		}
		}catch(Exception e) {
			System.out.println("EduHandler:reset;"+e.toString());
			e.printStackTrace();
		}
	}
	@Override
	public String[] listInputs() {
		return listInputs(entigrator);
	}
	@Override
	public String[] listOutputs() {
		return listOutputs(entigrator);
	}
	public void bondInit() {
		try {
		if(entity==null) {
			 System.out.println("EduHandler:bondInit:entity is null");
			return;
		}
		String entity$=entity.getProperty(Entigrator.ENTITY_LABEL);
		bond=new Hashtable<String,Double>();
		String [] sa=listInputs();
		if(sa!=null)
			for(String s:sa)
				bond.put("in:"+entity$+":"+s, 0.0);
		sa=listOutputs();
		if(sa!=null)
			for(String s:sa)
				bond.put("out:"+entity$+":"+s, 0.0);
		}catch(Exception e) {
		 System.out.println("EduHandler:bondInit:"+e.toString());
		}
	}
	private String[] bondListConnections(String type$) {
		if(bond==null)
			bondInit();
		Enumeration<String>  pe= bond.keys();
		ArrayList<String>sl=new ArrayList<String>();
		String key$;
		String[] sa;
		while (pe.hasMoreElements()) {
            key$ = pe.nextElement();
            sa=key$.split(":");
            if(type$.equals(sa[0]))
            	sl.add(key$);
		}
		sa=new String[sl.size()];
		sl.toArray(sa);
		return sa;
	}
	public String[] bondListIns() {
		return bondListConnections("in");
	}
	public String[] bondListOuts() {
		return bondListConnections("out");
	}
	public void bondTransition() {
		if(bond==null)
	       return;
		Hashtable<String,Double>ins=new Hashtable<String,Double>();
		Enumeration<String>  pe= bond.keys();
		String[] sa;
		String key$;
		String entity$=entity.getProperty(Entigrator.ENTITY_LABEL);
		double value;
		String name$;
		while (pe.hasMoreElements()) {
			key$ = pe.nextElement();
			sa=key$.split(":");
			if(!"in".equals(sa[0]))
				continue;
			if(!entity$.equals(sa[1]))
				continue;
			name$=sa[2];
			value=bond.get(key$);
			ins.put(name$, value);
		}
		Hashtable<String,Double>outs=stride(ins);
		if(outs!=null) {
			pe= outs.keys();
			while (pe.hasMoreElements()) {
				name$=pe.nextElement();
				value=outs.get(name$);
				key$="out:"+entity$+":"+name$;
				bond.put(key$, value);
			}
		}
}
	public double getClock() {
		if(controller!=null)
			return controller.getClock();
		return 0;
	}
	@SuppressWarnings("unchecked")
	public static <T> boolean isAppliable(Entigrator entigrator,String operatorKey$) {
		try {
		 Sack entity=entigrator.getEntity(operatorKey$);
		 Core[] ca=entity.elementGet(FACET);
			if(ca==null) {
				System.out.println("EduHandler:isAppliable:no facets in entity="+entity.getProperty("label"));
				return false;
			}
			String class$;
			Class<T> cls;
				for(Core c:ca) {
			      	class$=Locator.getProperty(c.value, FACET_HANDLER_CLASS);
			      	cls= (Class<T>) entigrator.getClass(class$);
			    	if(cls==null) {
			    		System.out.println(" EduHandler:isAppliable:wrong facet handler class in entity="+entity.getProperty("label"));
			    		continue;
			    	}
			      	if(cls.isAssignableFrom(EduHandler.class))
			      		return true;
				}
		}catch(Exception e) {
			System.out.println("EduHandler:isAppliable:"+e.toString());
		}
		return false;
	}
	@Override
	public Hashtable<String, Double> getOuts() {
		if(controller!=null)
			return controller.getOuts();
		return null;
	}
	@Override
	public void setClock(double clock) {
		if(controller!=null)
			 controller.setClock( clock);
	}
	public static void printHashtableDouble(String name$,Hashtable<String,Double> ht) {
		if(ht==null)
			return;
		if(ht.isEmpty()) {
			System.out.println("----------Hashtable="+name$ +"  is empty");
			return;
		}
		System.out.println("----------Hashtable="+name$);
		Enumeration<String> en=ht.keys();
		String key$;
		Double val;
		while(en.hasMoreElements()) {
			key$=en.nextElement();
			val=ht.get(key$);
			System.out.println(key$+"="+val);
		}
		System.out.println("----------End "+name$);
	}
	public static void printHashtableString(String name$,Hashtable<String,String> ht) {
		if(ht==null)
			return;
		if(ht.isEmpty()) {
			System.out.println("----------Hashtable="+name$ +"  is empty");
			return;
		}
		System.out.println("----------Hashtable="+name$);
		Enumeration<String> en=ht.keys();
		String key$;
		String val;
		while(en.hasMoreElements()) {
			key$=en.nextElement();
			val=ht.get(key$);
			System.out.println(key$+"="+val);
		}
		System.out.println("----------End "+name$);
	}
	@Override
	public void setEntigrator(Entigrator entigrator) {
		this.entigrator=entigrator;
		
	}
	
	@Override
	public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
		if(controller ==null) {
			System.out.println("EduHandler:step:controller is null");
			return null;
		}
		return controller.stride(ins);
	}
	@Override
	public void putSettings(Hashtable<String, Double> settings) {
		controller.putSettings(settings);
	}
public static void createAdapter(Entigrator entigrator,String locator$) {
	try{
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String entityKey$=entigrator.getKey(entity$);
		String controller$=Locator.getProperty(locator$, CONTROLLER);
		File sourceHome=new File(entigrator.getEntihome()+"/"+entityKey$+"/src");
		if(!sourceHome.exists())
			sourceHome.mkdirs();
		File binHome=new File(entigrator.getEntihome()+"/"+entityKey$+"/bin");
		if(!binHome.exists())
			binHome.mkdirs();
		File adapterJava=new File(entigrator.getEntihome()+"/"+entityKey$+"/src/"+entityKey$+".java");
		if(!adapterJava.exists())
			adapterJava.createNewFile();
		 FileOutputStream fos = new FileOutputStream(adapterJava, false);
		 Writer writer = new OutputStreamWriter(fos, "UTF-8");
		 writer.write("import java.util.Hashtable;\n");
		 writer.write("import gdt.base.store.Entigrator;\n");
		 writer.write("import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;\n");
		 writer.write("import "+controller$+";\n");
		 writer.write(controller$+" controller;\n");
		 writer.write("public Hashtable<String,Double>  stride(Hashtable<String,Double>  ins) {\n");
			writer.write("return controller.stride( ins);\n");
			writer.write("}\n");
			writer.write("public void  reset() {\n");
			writer.write("controller.reset();\n");
			writer.write("}\n");
			writer.write("public Hashtable<String,Double>  getSettings() {\n");
			writer.write("return controller.getSettings()();\n");
			writer.write("}\n");  
			writer.write("public void  putSettings(Hashtable<String,Double> settings) {\n");
			writer.write("controller.putSettings(( settings);\n");
			writer.write("}\n"); 
			writer.write("public Hashtable<String,Double>  getOuts() {\n");
			writer.write("return controller.getOuts()();\n");
			writer.write("}\n");  
			writer.write("public doubel  getClock() {\n");
			writer.write("return controller.getClock();\n");
			writer.write("}\n");   
			writer.write("public void  setClock(double clock) {\n");
			writer.write("controller.setClock(clock) ;\n");
			writer.write("}\n");
			writer.write("public String[] listInputs() {\n");
			writer.write("return controller.listInputs() ;\n");
			writer.write("}\n");
			writer.write("public String[] listOutputs() {\n");
			writer.write("return controller.listOutputs() ;\n");
			writer.write("}\n");
			writer.write("public void  setEntigrator(Entigrator  entigrator) {\n");
			Properties locator=new Properties();
			locator.put(Entigrator.ENTITY_KEY, entityKey$);
			String alocator$=Locator.toString(locator);
			writer.write("controller=new "+controller$+"(entigrator,"+alocator$+");\n");
			writer.write("controller.setEntigrator(entigrator);\n");
			writer.write("}\n");
			writer.write("}\n");
		 writer.close();   
	}catch(Exception e){
		System.out.println("EduHandler:createAdapter"+e.toString());
	}
}
	
}