package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Properties;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
public class RecordHandler extends FacetHandler{
	public RecordHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}
	public static final String KEY="_pFs9ZvkoamvEj7E11nu1wgKaPEU";
	public static final String RECORD_FACET_TYPE="record";
	public static final String RECORD_FACET_NAME="Record";
	public static final String RECORD_FACET_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.RecordHandler";
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,RECORD_FACET_NAME);
		locator.put(FACET_TYPE,RECORD_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.RecordHandler");
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.RecordMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put( IconLoader.ICON_FILE, "record.png");
		locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	@Override
	public String getName() {
		return RECORD_FACET_NAME;
	}
	@Override
	public String getType() {
		return RECORD_FACET_TYPE;
	}
	@Override
	public  String getFacetClass() {
		return RECORD_FACET_CLASS;
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return null;
	}
	}


