package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import gdt.base.generic.Locator;
import gdt.base.store.Sack;
import gdt.base.store.Entigrator;
import gdt.base.generic.*;

public  abstract class OperatorHandler extends  FacetHandler implements StepHandler{
	public static final String OPERATOR="operator";
	public static final String OPERATOR_KEY="operator key";
	public static final String METHOD="method";
	public static final String STEP="step";
	public static final String RESET="reset";
	public static final String REINIT="reinit";
	public static final String MODULE="_TZ34ntGtza4ryheSV3Xo_JOLOIU";
	 protected double time;
	 protected  double takt;
	 public String operatorKey$;
	 protected String appliance$;
	 protected OperatorHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		entity$=Locator.getProperty(alocator$,Entigrator.ENTITY_LABEL);
		if(entity$!=null) {
		//System.out.println("OperatorHandler:entity="+entity$);
		operatorKey$=entigrator.getKey(entity$);
		}
		}
    public    abstract String[] listOutputs  ( Entigrator entigrator );
    public    abstract String[] listInputs  ( Entigrator entigrator );
    public    abstract String getLocator();
	public static OperatorHandler getOperatorHandler(Entigrator entigrator ,Sack operator) {
	FacetHandler[] fha=FacetHandler.getHandlers(entigrator, operator);
	if(operator==null) {
		System.out.println("OperatorHandler:getOperatorHandler: operator is null");
		return null;
	}
	if(fha==null) {
		System.out.println("OperatorHandler:getOperatorHandler:no handlers in operator="+operator.getProperty("label"));
		return null;
	}
	OperatorHandler oh=null; 
	for(FacetHandler fh:fha) {
	//	System.out.println("OperatorHandler:getOperatorHandler:handler="+fh.getName());
	  if(fh instanceof OperatorHandler) {
		((OperatorHandler)fh).operatorKey$=operator.getKey();
		oh=(OperatorHandler)fh;
	  }
	}
	//System.out.println("OperatorHandler:getOperatorHandler:return handler="+oh.getName());
	return oh;
}
	protected StepHandler getStepHandler(Entigrator entigrator) {
		try {
			String operatorHome$=entigrator.getEntihome()+"/"+operatorKey$+"/bin";
			entigrator.addURL(operatorHome$);
		    Class <?>cls = entigrator.getClass(operatorKey$);
		    if(cls==null)
		    	return null;
		    Object stephandler =cls.getDeclaredConstructor().newInstance();
		    return (StepHandler)stephandler;
		  	}catch(Exception e) {
				System.out.println("OperatorHandler: getStepHandler:"+e.toString());
			}
		 return null;
	}
	 public  void rewrite(Entigrator entigrator) {
		 try{
		//		System.out.println("OperatorHandler: rewrite:entity key="+operatorKey$);
				File sourceHome=new File(entigrator.getEntihome()+"/"+operatorKey$+"/src");
				if(!sourceHome.exists())
					sourceHome.mkdirs();
				File binHome=new File(entigrator.getEntihome()+"/"+operatorKey$+"/bin");
				if(!binHome.exists())
					binHome.mkdirs();
				File operatorJava=new File(entigrator.getEntihome()+"/"+operatorKey$+"/src/"+operatorKey$+".java");
				if(operatorJava.exists())
					operatorJava.delete();
				operatorJava.createNewFile();
				 FileOutputStream fos = new FileOutputStream(operatorJava, false);
				 Writer writer = new OutputStreamWriter(fos, "UTF-8");
				 writer.write("import gdt.base.store.Entigrator;\n");
				 writer.write("public class "+operatorKey$+" implements StepHandler{\n");
				 writer.write("private final static String ENTITY_KEY=\""+operatorKey$+"\";\n");
				 writer.write("public "+operatorKey$+"(){} \n");
				 writer.write("public void step(Entigrator entigrator, String locator$) {\n");
				 writer.write("System.out.println(ENTITY_KEY+\":\"+locator$);\n");
				 writer.write("	}\n");
				 writer.write("public void reset(Entigrator entigrator, String locator$) {\n");
				 writer.write("System.out.println(ENTITY_KEY+\":\"+locator$);\n");
				 writer.write("	}\n");
				 writer.write("public void reinit(Entigrator entigrator, String locator$) {\n");
				 writer.write("System.out.println(ENTITY_KEY+\":\"+locator$);\n");
				 writer.write("	}\n");
				 writer.write("}\n");
				 writer.close();   
			}catch(Exception e){
				System.out.println("OperatorHandler:rewrite:"+e.toString());
			}
	 }
}
