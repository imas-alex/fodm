package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.math.BigDecimal;
import java.util.Properties;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;

public class PlotHandler extends FacetHandler{
	public PlotHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}
	public static final String KEY="_njrQQTLhFlAwtRgRo3qksmryXQM";
	public static final String PLOT_FACET_TYPE="plot";
	public static final String PLOT_FACET_NAME="Plot";
	public static final String PLOT_FACET_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PlotHandler";
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,PLOT_FACET_NAME);
		locator.put(FACET_TYPE,PLOT_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PlotHandler");
		locator.put(FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster");
		locator.put(FacetHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	@Override
	public String getType() {
		return PLOT_FACET_TYPE;
	}
	@Override
	public String getName() {
		return PLOT_FACET_NAME;
	}
	@Override
	public String getFacetClass() {
		return PLOT_FACET_CLASS;	
	}

	public static class ScaleSetting {
		public double max;
		public double scale;
		public ScaleSetting(double max,double scale) {
			this.max=max;
			this.scale=scale;
		}
	}
	private static double getMantissa(double vmax) {
		double log=Math.log10(vmax);
		BigDecimal bigDecimal = new BigDecimal(log);
		int chr = bigDecimal.intValue();
		BigDecimal fractionValue=bigDecimal.subtract(new BigDecimal(chr));
		double mantissa=fractionValue.doubleValue();
		return mantissa;
	}
	private static int getCharacteristic(double vmax) {
		double log=Math.log10(vmax);
		BigDecimal bigDecimal = new BigDecimal(log);
		int chr = bigDecimal.intValue();
		return chr;
	}
	public static ScaleSetting getPreferredMaximum(double vmax) {
		int chr=getCharacteristic(vmax);
		double mantissa=getMantissa(vmax);
		double pm2=getMantissa(2);
		double pm5=getMantissa(5);
		double scale=0;
		double pm=0;
		int state=0;
		  if(mantissa>0) { 	
				pm=pm2;
				state=0;
		  if(mantissa>=pm2) { 	
				pm=pm5;
				state=1;
		  }
		  if(mantissa>=pm5) { 	
				pm=0;
				chr=chr+1;
				state=2;
			 }
		  }
		  if(mantissa<0) {
				pm=-pm2;
				state=3;
		  if(mantissa>=-pm2) {   
			  pm=0;
			  state=4;
		  }
		  if(mantissa<=-pm5) {
				pm=pm2;
				chr=chr-1;
				state=5;
			 }
		  }
			double pot=chr+pm;	
			double pmax=Math.pow(10, pot);
			switch (state){
			case 0: scale=pmax/4.0; break;
			case 1: scale=pmax/5.0; break;
			case 2: scale=pmax/5.0; break;
			case 3: scale=pmax/5.0; break;
			case 4: scale=pmax/5.0; break;
			case 5: scale=pmax/4.0; break;
			}
//			System.out.println("PlotHandler:getPreferred:vmax = "+vmax+"  pmax="+pmax+" state=" +state+" scale="+scale);
			return new ScaleSetting(pmax,scale);
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
			return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
			return null;
	}
	}


