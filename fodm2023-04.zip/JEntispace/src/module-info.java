
/**
 * @author alexander imas
 *
 */
module JEntispace {
	requires java.logging;
	requires java.xml;
	requires transitive java.desktop;
	requires java.compiler;
	
	exports  gdt.gui.facet;
	exports  gdt.base.store;
	exports  gdt.base.generic;
	exports  gdt.base.facet;
	exports gdt.gui.console;
	exports gdt.gui.generic;
	exports  gdt.gui.facet.procedure;
	exports  gdt.gui.entity;
}