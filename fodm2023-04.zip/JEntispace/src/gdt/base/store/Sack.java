package gdt.base.store;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.lang.reflect.Array;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Stack;
import java.util.logging.Logger;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import gdt.base.btree.BTree;
import gdt.base.generic.Locator;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
public class Sack extends Identity {
	final Logger LOGGER= Logger.getLogger(Sack.class.getName()); 
    private final BTree attributes;
    private final BTree elements;
    static boolean debug=false;   
    public static final String PERMANENT="permanent";
    public static final String ATTRIBUTES="attributes";
    public static final String PROPERTY="property";
    public static final String RESIDENT="resident";
    public String rpath;
    public Sack() {
    super();
        attributes = new BTree();
        elements = new BTree();
    }
    public Sack(String fname$) { 
        super();
            attributes = new BTree();
            elements = new BTree();
            Path p = Paths.get(fname$);
            key=p.getFileName().toString();
            path=fname$;
        }
    public Sack(String fname$,String entihome$) { 
        super();
            attributes = new BTree();
            elements = new BTree();
            Path entihome= Paths.get(entihome$);
            Path p = Paths.get(fname$);
            Path relp=p.relativize(entihome);
            key=p.getFileName().toString();
            path=fname$;
            rpath=relp.toString();
        }
    public static void traceCalls(){
    	StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
    	for (int i = 1; i < stackTraceElements.length && i<=4; i++) {
    	StackTraceElement stackTraceElement = stackTraceElements[i];
    	System.out.println("->"+stackTraceElement.getClassName() + ":"
    	+ stackTraceElement.getMethodName());
    	}
    	}  
    private static Document loadXMLdocument(String fname$) {
	   FileChannel channel=null;
	   InputStream is =null;
	   try {
		   File file=new File(fname$);
		   if(!file.exists()) {
			  // System.out.println("Sack:loadXMLdocument: not exists file="+fname$);
			  // traceCalls();
			   return null;
		   }
		   
		   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
           DocumentBuilder db = dbf.newDocumentBuilder();
          RandomAccessFile raf = new RandomAccessFile(file, "r");
           channel = raf.getChannel();
       	  /*
           try {
       	   channel.lock() ;
       	   }catch(java.nio.channels.OverlappingFileLockException ee) {
       		System.out.println("Sack:loadXMLdocument:try lock:"+ee.toString());
       	    raf.close();
       		   return null;
       	   }
       	   */
       	   is =  Channels.newInputStream(channel);
       if(is.available()<10) {
      	// System.out.println("Sack:loadXMLdocument: not available file="+fname$+"  length="+is.available());
      	 channel.close();
      	 is.close();
      	// traceCalls();
      	 raf.close();
      	//System.out.println("Sack:loadXMLdocument: not available file="+fname$);
      	 return null;
       }
       Document doc=null;
       SackLoadErrorHandler errorHandler=new SackLoadErrorHandler(fname$);
       db.setErrorHandler(errorHandler);
          doc =  db.parse(is);
          if(!errorHandler.success) {
        	  System.out.println("Sack:loadXMLdocument: cannot parse file="+fname$);
        	  doc=null;
          }
         channel.close();
          is.close();
          raf.close();
           return doc;
         }catch(Exception ioe) {
		//   LOGGER.severe("loadXMLdocument:file="+fname$+" error="+ioe.toString());
	    //   ioe.printStackTrace();
		   if(is!=null)
	    	  try {	is.close();}catch(Exception ee) {}
	    	if(channel!=null)
		    	  try {	channel.close();}catch(Exception ee) {}
	    	//System.out.println("Sack:loadXMLdocument: cannot load file="+fname$);
		   return null; 
	   }
   }
   public static Sack reload(Sack origin) {
	   try {
	   return readXml(origin.getPath());
	   }catch(Exception e) {
		   System.out.println("Sack:reload:"+e.toString()) ;
		   return null;
	   }
   }
   
   public static Sack readXml(String entihome$,String container$,String key$) {
		try {  
	   Path p=Paths.get(entihome$, container$,key$);
		   Sack sack=readXml(p.toString());
			   return sack;
		}catch(Exception e) {
			 System.out.println("Sack:readXML:cannot read entihome="+entihome$+" container="+container$+" key="+key$);
			   return null;
		   }	      
   }
   
   public static Sack readXml(String fname$) throws SAXParseException{
   	  
     	  try {
     		 Document doc=null;
             int cnt=0;
     		while(cnt<20) {
     			try {	
     				doc=loadXMLdocument(fname$);	
     			    if(doc!=null) {
     			    	break;
     			    }
     			   Thread.sleep(10);
     			   cnt++;
     			//  System.out.println("Sack:readXml:cnt="+cnt);
     			  if(cnt>9) {
     				 System.out.println("Sack:readXml:cannot read file="+fname$);
     				// traceCalls();
     				  return null;
     			  }
     			}catch(Exception e ) {
     				//System.out.println("Sack:readXml:cnt="+cnt+" cannot read file="+fname$);
     			}
     			}
     		 doc.setXmlVersion("1.1");
             Sack ret = new Sack(fname$);
             NodeList attributes =  doc.getElementsByTagName("attribute");
             NodeList elements = doc.getElementsByTagName("element");
             NodeList items;
             String type$;
             String name$;
             String value$;
             String title$;
             Core core;
             for (int i = 0; i < attributes.getLength(); i++) {
                 Element attribute = (Element) attributes.item(i);
                 type$ = attribute.getAttribute("type");
                 name$ = attribute.getAttribute("name");
                 value$ = attribute.getAttribute("value");
                 if (name$ != null) {
                     core = new Core(type$, name$, value$);
                     ret.putAttribute(core);
                 }
             }
             for (int i = 0; i < elements.getLength(); i++) {
                 Element element = (Element) elements.item(i);
                 title$ = element.getAttribute("title");
                   items = element.getElementsByTagName("item");
                  if (items != null)
                     for (int j = 0; j < items.getLength(); j++) {
                         Element item = (Element) items.item(j);
                         type$ = item.getAttribute("type");
                         name$ = item.getAttribute("name");
                         value$ = item.getAttribute("value");
                         if (name$ != null) {
                             core = new Core(type$, name$, value$);
                             ret.putElementItem(title$, core);
                         }
                     }
             }
            // System.out.println("Sack:readXML:success sack="+ret.getKey());
             return ret;
         } catch (Exception e) {
        	    	System.out.println("Sack:readXML:"+e.toString());
        	    	return null;
         }
     }
    public void putAttribute(Core core) {
        if (core == null||core.name==null)
            return;
        attributes.put(core.name.trim(), core);
    }
   public void removeAttribute(String attr) {
        attributes.remove(attr);
    }
    public void removeAttributes() {
    	Stack<String> s=attributes.keys();
    	while(!s.isEmpty()){
    		   attributes.remove(s.pop());
    		  }
    }
    public Core getAttribute(String key) {
        if (key == null)
            return null;
        return (Core) attributes.get(key);
    }
    public String getAttributeAt(String key) {
        if (key == null)
            return null;
        if (attributes.get(key) == null)
            return null;
        if(((Core) attributes.get(key)).value==null)
        	return null;
        return ((Core) attributes.get(key)).value.trim();
    }

    private Stack<String> listAttributes() {
        return attributes.keys();
    }
    public Core[] attributesGet() {
        Stack<String> s = attributes.keys();
        if (s == null)
            return null;
        Stack<Core> ss = new Stack<Core>();
        String name;
        while (!s.isEmpty()) {
            name = s.pop().toString();
            if (name == null)
                continue;
            ss.push(getAttribute(name));
        }
        int cnt = ss.size();
        if (cnt < 1)
            return null;
        Core[] ret = new Core[cnt];
        for (int i = 0; i < cnt; i++)
            ret[i] = (Core) ss.pop();
        return ret;
    }
   public String[] elementListNames(String element$) {
        if (element$ == null)
            return null;
        Core[] cores = elementGet(element$);
        if (cores == null)
            return null;
        int cnt = Array.getLength(cores);
        String[] ret = new String[cnt];
        for (int i = 0; i < cnt; i++)
            ret[i] = cores[i].name;
        return ret;
    }
    public String[] elementListValues(String element$) {
        if (element$ == null)
            return null;
        Core[] cores = elementGet(element$);
        if (cores == null)
            return null;
        int cnt = Array.getLength(cores);
        String[] ret = new String[cnt];
        for (int i = 0; i < cnt; i++)
            ret[i] = cores[i].value;
        return ret;
    }
     public Core[] elementGet(String element$) {
        return enumerateElement(element$);
    }
    public void elementReplace(String element$, Core[] ca) {
        removeElement(element$);
        if (element$ == null)
            return;
        createElement(element$);
        if (ca == null)
            return;
        for (Core aCa : ca) putElementItem(element$, aCa);
    }
    public void attributesReplace(Core[] ca) {
        removeAttributes();
        for (Core aCa : ca) putAttribute(aCa);
    }
    public void elementRename(String oldElement$,String newElement$) {
    	try {
    	if(newElement$==null) {
    		System.out.println("Sack:elementRename:new element is null");
    		return;
    	}
    	if(oldElement$==null||newElement$.equals(oldElement$))
    		return;
        Core[] ca=elementGet(oldElement$);
        
        createElement(newElement$);
        for (Core aCa : ca)
        	putElementItem(newElement$, aCa);
        removeElement(oldElement$);
    	}catch(Exception e) {
    		System.out.println("Sack:elementRename:"+e.toString());
    	}
    }
    
   private Core[] enumerateElement(String element) {
        if (element == null)
            return null;
       Stack<String> s = listElement(element);
        if (s == null)
            return null;
        Stack<Core> ss = new Stack<Core>();
        String name;
        while (!s.isEmpty()) {
            name = s.pop().toString();
            if (name == null)
                continue;
            ss.push(getElementItem(element, name));
        }
        int cnt = ss.size();
        if (cnt < 1)
            return null;
        Core[] ret = new Core[cnt];
        for (int i = 0; i < cnt; i++)
            ret[i] = (Core) ss.pop();
        return ret;
    }
    public String[] listItemsAtType(String element$, String type$) {
    	if (type$ == null)
            return null;
        if (element$ == null)
            return null;
        Stack<String> s = listElement(element$);
        
        if (s == null)
            return null;
        int cnt = s.size();
        if (cnt < 1)
            return null;
        Stack<String> out = new Stack<String>();
        Core core;
        while (!s.isEmpty()) {
            core = getElementItem(element$, s.pop().toString());
            if(core==null)
            	continue;
            if (type$.equals(core.type))
                out.push(core.name);
        }
        cnt = out.size();
        if (cnt < 1)
            return null;
        String[] ret = new String[cnt];
        for (int i = 0; i < cnt; i++)
            ret[i] = out.pop().toString();
        return ret;
    }
   
    public String[] elementsListNoSorted() {
        Stack<String> s = listElements();
        String[] ret = new String[s.size()];
        int cnt = s.size();
        for (int i = 0; i < cnt; i++) {
            ret[i] = s.pop().toString();
        }
        return ret;
    }
    Stack <String>listElements() {
        return elements.keys();
    }
    public boolean existsElement(String element$) {
        if(element$==null)
        	return false;
    	return elements.containsKey(element$.trim());
    }
    public String getElementItemAtValue(String element$, String value$) {
        if (!existsElement(element$))
            return null;
        if (value$ == null)
            value$ = "";
        BTree bTree = (BTree) elements.get(element$);
        Stack<String> keys = bTree.keys();
        Object key ;
        Object value ;
        while (!keys.isEmpty()) {
            key = keys.pop();
            if (key == null)
                continue;
            value = bTree.get(key.toString());
            if (value == null)
                continue;
            if (value$.equals(((Core) value).value))
                return key.toString();
        }
        return null;
    }
    public String getElementItemAtType(String element$, String type$) {
        if (!existsElement(element$))
            return null;
        if (type$ == null)
            type$ = "";
        BTree bTree = (BTree) elements.get(element$);
        Stack<String> keys = bTree.keys();
        Object key ;
        Object value ;
        while (!keys.isEmpty()) {
            key = keys.pop();
            if (key == null)
                continue;
            value = bTree.get(key.toString());
            if (value == null)
                continue;
            if (type$.equals(((Core) value).type))
                return key.toString();
        }
        return null;
    }
    private Stack<String> listElement(String element) {
       try {
    	if(ATTRIBUTES.equals(element)) {
        	return listAttributes();
        }
    	BTree bTree = (BTree) elements.get(element);
        if (bTree == null)
            return null;
        Stack<String> s = bTree.keys();
        if (s == null)
            return null;
        Stack <String>ret = new Stack<String>();
        while (!s.isEmpty())
            ret.push(s.pop());
        return ret;
       }catch(Exception e) {
    	   System.out.println("Sack:listElement:cannot list element="+element);
    	   return null;
       }
    }
    public void clearElement(String element$) {
        if (element$ == null)
            return;
        Stack <String>s = listElement(element$);
        if (s == null)
            return;
        while (!s.isEmpty())
            removeElementItem(element$, s.pop().toString());
    }
    public void createElement(String element$) {
        if(element$==null)
        	return;
        if(existsElement(element$))
        	return;
    	elements.put(element$.trim(), new BTree());
    }
    public void removeElement(String element$) {
        elements.remove(element$);
    }
    public void putElementItem(String element$, Core core) {
        if (element$ == null || core == null||core.name==null)
            return;
        if(ATTRIBUTES.equals(element$)) {
        	putAttribute(core);
        	return;
        }
        BTree bTree = (BTree) elements.get(element$.trim());
        if (bTree == null) {
            elements.put(element$.trim(), new BTree());
            bTree = (BTree) elements.get(element$.trim());
            if (bTree == null)
                return;
        }
        bTree.put(core.name.trim(), core);
    }
    public Core getElementItem(String element$, String item$) {
    	if (element$ == null || item$ == null)
            return null;
        BTree bTree = (BTree) elements.get(element$);
        if (bTree == null)
            return null;
        return (Core) bTree.get(item$);
    }
    public String getElementItemAt(String element$, String item$) {
        if (element$ == null)
            return null;
        if (item$ == null)
            item$ = "";
        BTree bTree = (BTree) elements.get(element$);
        if (bTree == null)
            return null;
        Core core = (Core) bTree.get(item$);
        if (core == null)
            return null;
        if (core.value == null)
            return null;
        return core.value.trim();
    }
    public void removeElementItem(String element$, String item$) {
        try {
    	if (element$ == null || item$ == null) {
            return;
        }
    	if(ATTRIBUTES.equals(element$)) {
    		removeAttribute(item$);
    		return;
    	}
        BTree bTree = (BTree) elements.get(element$);
        if (bTree == null) {
            return;
        }
        bTree.remove(item$);
        }catch(Exception e) {
        	LOGGER.severe(":"+e.toString());
        	System.out.println("Sack:element="+element$+" item="+item$);
        }
    }
    public void printElement(String element$) {
    	if(!existsElement(element$)) {
    		System.out.println("Sack key="+key+"  doesn't contain element="+element$);
    		return;
  	}
//    	System.out.println("  ENTITY	key="+getKey()+" label="+getProperty("label")+"  element="+element$);
    	 ArrayList<String>en=new ArrayList<String>(listElement(element$));
		if(en!=null&&!en.isEmpty()) {
	    	System.out.println("  	<"+element$+">");
			 Collections.sort(en);
			 Iterator<String> itn=en.iterator();
			 Core c;
			 while (itn.hasNext()) {
			  c=getElementItem(element$,itn.next());
			  if(c.type==null||"null".equals(c.type))
				  System.out.println("name="+c.name+" value="+c.value); 
			  else
				  System.out.println("name="+c.name+" value="+c.value+" type="+c.type); 
		  }
		}else {
			System.out.println("Sack:printElement:doesn't contain element="+element$);
		}
	//		 System.out.println("  END ENTITY");		 
    }
    @SuppressWarnings("unused")
	private void printAttributes() {
    	System.out.println("  ENTITY	key="+getKey()+" label="+getProperty(Entigrator.LABEL));
    	System.out.println("  	Attributes");
    	ArrayList<String>al=new ArrayList<String>(listAttributes());
    	Collections.sort(al);
    	if(al!=null) {
    		 Iterator<String> it=al.iterator();
    		 Core c;
    		  while (it.hasNext()) {
    			  c=getAttribute(it.next());
    			  if(c.type==null||"null".equals(c.type))
    				  System.out.println("name="+c.name+" value="+c.value); 
    			  else
    				  System.out.println("name="+c.name+" value="+c.value+" type="+c.type); 
    		  }
    	}
    	System.out.println("  END ENTITY");
    }
    public void print() {
    	System.out.println("  ENTITY	key="+getKey()+" label="+getProperty(Entigrator.LABEL));
    	System.out.println("  	Attributes");
    	ArrayList<String>al=new ArrayList<String>(listAttributes());
    	Collections.sort(al);
    	if(al!=null) {
    		 Iterator<String> it=al.iterator();
    		 Core c;
    		  while (it.hasNext()) {
    			  c=getAttribute(it.next());
    			  if(c.type==null||"null".equals(c.type))
    				  System.out.println("name="+c.name+" value="+c.value); 
    			  else
    				  System.out.println("name="+c.name+" value="+c.value+" type="+c.type); 
    		  }
    	}
    	ArrayList<String>el=new ArrayList<String>(listElements());
    	Collections.sort(el);
    	if(el!=null) {
   		 Iterator<String> it=el.iterator();
   		 String element$;
   		  while (it.hasNext()) {
   			  element$=it.next();
   			  System.out.println("	<"+element$+">");
   			  ArrayList<String>en=new ArrayList<String>(listElement(element$));
   			 if(en!=null) {
   			 Collections.sort(en);
   			 Iterator<String> itn=en.iterator();
   			 Core c;
   			 while (itn.hasNext()) {
   			  c=getElementItem(element$,itn.next());
   			  if(c.type==null||"null".equals(c.type))
   				  System.out.println("name="+c.name+" value="+c.value); 
   			  else
   				  System.out.println("name="+c.name+" value="+c.value+" type="+c.type); 
   		  }
   			}
   		  }
   	}
    	System.out.println("  END ENTITY");
    }
    public String toString() {
        return getKey();
    }
 
 public boolean save() {
	try {
		String path$=getPath();
		if(path$==null) {
			System.out.println("Sack:save "+key+ "  empty path");
			return false;
		}
		String timestamp$=String.valueOf(System.currentTimeMillis());
		putAttribute(new   Core("runtime",SackCachedRepository.TIMESTAMP,timestamp$));
		//if(Locator.LOCATOR_TRUE.equals(getProperty("sysbase")))
		if("session".equals(getProperty("label")))
			return false;
		return saveXML(path$);
	}catch(Exception e) {
		LOGGER.severe(e.toString());
		return false;
	}
}
 public boolean save(String sackdir$) {
		try {
			if(rpath==null) {
				System.out.println("Sack:save:empty relative path in sack="+getKey());
				return false;
			}
			Path p=Paths.get(sackdir$, rpath);
			String timestamp$=String.valueOf(System.currentTimeMillis());
			putAttribute(new   Core("runtime",SackCachedRepository.TIMESTAMP,timestamp$));
//			System.out.println("Sack:save:sackdir="+sackdir$+" rpath="+rpath.toString());
			return saveXML(p.toString());
		}catch(Exception e) {
			LOGGER.severe(e.toString());
			return false;
		}
	}
 public boolean save(String entihome$,String rpath$) {
		try {
			String resident$=getAttributeAt(RESIDENT);
	    	if(Locator.LOCATOR_TRUE.equals(resident$))
	    		return true;
			String timestamp$=String.valueOf(System.currentTimeMillis());
			putAttribute(new   Core("runtime",SackCachedRepository.TIMESTAMP,timestamp$));
			//System.out.println("Sack:save:rpath="+rpath$);
			rpath=rpath$+"/"+key;
			store();
			return true;
		}catch(Exception e) {
			LOGGER.severe(e.toString());
			return false;
		}
	}
public synchronized boolean saveXML(String fname$){
	if (fname$ == null){
		LOGGER.severe(":saveXML: fname is null");
		return false;
	}
	 FileOutputStream fos = null;
	 FileChannel channel=null;
     
	 try{
        String out;
        File file = new File(fname$);
        if(!file.exists()) {
          if (!file.createNewFile()) {
        	  System.out.println("Sack:saveXML:cannot create file="+fname$);
        	return false;
          }
        }
        Path path = Paths.get(fname$);
        String entityKey$=path.getFileName().toString();
        fos = new FileOutputStream(fname$, false);
        channel=fos.getChannel();	
        Writer writer = new OutputStreamWriter(fos, "UTF-8");
        writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>");
        writer.write(10);
        out = "<sack path=\"" + rpath + "\" key=\"" + entityKey$ + "\">";
        writer.write(10);
        writer.write(out);
        writer.write(10);
        Stack<String> s = new Stack<String>();
        Stack<String> buf = attributes.keys();
        while (!buf.isEmpty())
            s.push(buf.pop());
        writer.write("<attributes>");
        writer.write(10);
        String key$;
        Core core;
        while (!s.isEmpty()) {
            key$ = s.pop().toString();
            core = getAttribute(key$);
            if(core!=null) {
            out = "<attribute type=\"" + translate(core.type) + "\" name=\"" + translate(core.name) + "\" value=\"" + translate(core.value) + "\" />";
            writer.write(out);
            writer.write(10);
            }
        }
        writer.write("</attributes>");
        writer.write(10);
        writer.write("<elements>");
        writer.write(10);
        buf = elements.keys();
        while (!buf.isEmpty())
            s.push(buf.pop());
        BTree element ;
        Stack<String> items = new Stack<String>();
        while (!s.isEmpty()) {
            key$ = s.pop().toString();
            element = (BTree) elements.get(key$);
            buf = element.keys();
            while (!buf.isEmpty())
                items.push(buf.pop());
            out = "<element title=\"" + translate(key$) + "\" >";
            writer.write(out);
            writer.write(10);
            while (!items.isEmpty()) {
                key$ = items.pop().toString();
                core = (Core) element.get(key$);
                if (core == null)
                    continue;
                out = "<item type=\"" + translate(core.type) + "\" name=\"" + translate(core.name) + "\" value=\"" + translate(core.value) + "\" />";
                writer.write(out);
                writer.write(10);
            }
            writer.write("</element>");
            writer.write(10);
        }
        writer.write("</elements>");
        writer.write(10);
        writer.write("</sack>");
        writer.write(10);
        writer.close();
       channel.close();
      fos.close();
    
        return true;
    }catch(Exception e){
    	LOGGER.severe(":saveXML:file="+fname$+"   "+e.toString());
    	//e.printStackTrace();
    	 try{if(fos!=null)  fos.close();}catch(Exception eee) {}
    	 try{  if(channel!=null) channel.close();}catch(Exception eee) {}
    	 return false;
    }
    }

    public boolean writeXML(OutputStream os) throws IOException {
    	if (os == null) {
    		LOGGER.severe(":saveXML::writeXML: parameter 'OutputStream' is null");	
            return false;
        }
        os.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>".getBytes());
        String out = "<sack path=\"" + rpath + "\" key=\"" + key + "\">";
        os.write(10);
        os.write(out.getBytes());
        os.write(10);
        Stack<String> s = new Stack<String>();
        Stack<String> buf = attributes.keys();
        while (!buf.isEmpty())
            s.push(buf.pop());
        os.write("<attributes>".getBytes());
        os.write(10);
        String key$;
        Core core;
        while (!s.isEmpty()) {
            key$ = s.pop().toString();
            core = getAttribute(key$);
            out = "<attribute type=\"" + translate(core.type) + "\" name=\"" + translate(core.name) + "\" value=\"" +translate(core.value) + "\" />";
            os.write(out.getBytes());
            os.write(10);
        }
        os.write("</attributes>".getBytes());
        os.write(10);
        os.write("<elements>".getBytes());
        os.write(10);
        buf = elements.keys();
        while (!buf.isEmpty())
            s.push(buf.pop());
        BTree element ;
        Stack<String> items = new Stack<String>();
        while (!s.isEmpty()) {
            key$ = s.pop().toString();
            element = (BTree) elements.get(key$);
            buf = element.keys();
            while (!buf.isEmpty())
                items.push(buf.pop());
            out = "<element title=\"" + key$ + "\" >";
            os.write(out.getBytes());
            os.write(10);
            while (!items.isEmpty()) {
                key$ = items.pop().toString();
                core = (Core) element.get(key$);
                if (core == null)
                    continue;
                out = "<item type=\"" +translate(core.type) + "\" name=\"" + translate(core.name) + "\" value=\"" + translate(core.value) + "\" />";
                os.write(out.getBytes());
                os.write(10);
            }
            os.write("</element>".getBytes());
            os.write(10);
        }
        os.write("</elements>".getBytes());
        os.write(10);
        os.write("</sack>".getBytes());
        os.write(10);
        return true;
    }
    public String getProperty(String property$) {
        if (property$ == null)
            return null;
        Core[] ca = elementGet(PROPERTY);
        if (ca == null)
            return null;
        for (Core aCa : ca)
            if (property$.equals(aCa.type))
                return aCa.value;
        return null;
    }
    public Core getPropertyEntry(String property$) {
        if (property$ == null)
            return null;
        if("label".equals(property$))
        	return getElementItem(PROPERTY, getKey());
        Core[] ca = elementGet(PROPERTY);
        if (ca == null)
            return null;
        for (Core aCa : ca)
            if (property$.equals(aCa.type))
                return aCa;
        return null;
    }
    public void removePropertyEntry(String property$) {
        if (property$ == null)
            return ;
        if("label".equals(property$))
        	return; 
        Core[] ca = elementGet(PROPERTY);
        if (ca == null)
            return ;
        for (Core aCa : ca)
            if (property$.equals(aCa.type))
               removeElementItem(PROPERTY,aCa.name);        
    }
    public String [] listProperties() {
        Core[] ca = elementGet(PROPERTY);
        if (ca == null)
            return null;
        ArrayList<String>sl=new ArrayList<String>();
        for (Core c : ca)
        	sl.add(c.type);
        String[]sa=new String[sl.size()];
        return sl.toArray(sa);
    }
    public static String translate(String string$) {
        if (string$ == null)
            return null;
        String ret$ = string$.replaceAll("&", "&amp;");
        ret$ = ret$.replaceAll(">", "&gt;");
        ret$ = ret$.replaceAll("<", "&lt;");
        ret$ = ret$.replaceAll("\"", "&quot;");
        ret$ = ret$.replaceAll("\n", "&#xA;");
        ret$ = ret$.replaceAll("'", "&apos;");
        return ret$;
    }
    public boolean equal(Sack sack) {
    	if(sack==null)
    		return false;
    	//System.out.println("Sack:equal:begin:sack="+sack.getKey());
    	Core[] ca=attributesGet();
    	if(ca!=null)
    		for(Core c:ca) {
    			if("runtime".equals(c.type))
    				continue;
    			if("timestamp".equals(c.name))
    				continue;
    			if("session".equals(c.name))
    				continue;
    			if("id".equals(c.name))
    				continue;
    			if(!c.equal(sack.getAttribute(c.name))) {
    				System.out.println("Sack:equal:not equal attribute="+c.name+"  sack="+sack.getKey());
    				return false;
    			}
    		}
    	String[] ea=elementsListNoSorted();
    	if(ea!=null&&ea.length>0)
    		for(String e:ea) {
    			if(!sack.existsElement(e)) {
    				System.out.println("Sack:equal:not exists element="+e+"  sack="+sack.getKey());
    				return false;
    			}
    			 ca=elementGet(e);
    			 if(ca!=null)
    		    		for(Core c:ca) {
    		    			if(!c.equal(sack.getElementItem(e,c.name))) {
    		    				System.out.println("Sack:equal:not equals item="+c.name+"  element="+e+"  sack="+sack.getKey());			
    		    				return false;
    		    			}
    		    		}
    		}
    	//System.out.println("Sack:equal:sack="+sack.getKey());
    	return true;
    }
    public void store() {
    	//traceCalls();
    	try {
    		String fname$=getPath();
    		File file=new File(fname$);
    		if(!file.exists()) {
    			File parent=file.getParentFile();
    			if(parent.exists()) {
    				if(!parent.canWrite()) {
    			       System.out.println("Sack:store:not exists sack path="+getPath());
    			       return;
    				}
    			}else {
    				System.out.println("Sack:store:not exists parent ="+parent.getPath());
 			       return;
    			}
    		}else {
    			if(!file.canWrite()) {
    				return;
    			}
    		}
    			
    	}catch(Exception e) {
    		System.out.println("Sack:store:sack path="+getPath());
    	}
    	new StoreThread().start();
    }
    
    class StoreThread extends Thread{
    	public void run(){
    		if("session".equals(getProperty("label")))
    			return ;
    	
    	//System.out.println("Sack:StoreThread:BEGIN");
    	//	traceCalls();
    		int cnt=0;
    		 Sack check=null;	
    	 while (cnt<40) {
    	 // try {
    		 if(save()) {
    			
           	  try { 
           		  check=readXml(getPath());
           		if(check!=null) {
          		  if(check.equal(Sack.this)) {
          			//  System.out.println("Sack:StoreThread:success store sack="+key);
          			  return;
          		  }else {
          			  System.out.println("Sack:StoreThread:failed check sack="+key+" cnt="+cnt);
          		  }
           		}else {
           			
           		}
           	  }catch(Exception ee) {
           		  System.out.println("Sack:StoreThread:failed read check="+getPath());
           	  }
    		 }
    	try {Thread.sleep(100);}catch(Exception ee) { System.out.println("Sack:StoreThread:"+ee.toString());}	 
    	   cnt++;
    	 }
    	 
    	 System.out.println("Sack:StoreThread:cnt="+cnt+" cannot store sack="+ getPath());
    	 if(check==null)
    		 System.out.println("Sack:StoreThread:check is null");
    	 
    	}
    	
    }
 static class SackLoadErrorHandler implements  ErrorHandler{
 public boolean success=true;
 String fname$;
 public SackLoadErrorHandler(String fname$) {
	 this.fname$=fname$;
 }
	@Override
	public void warning(SAXParseException exception) throws SAXException {
		System.out.println("Sack:errorHandler:exception:"+exception.toString()+"  file="+fname$);
		success=false;
		
	}

	@Override
	public void error(SAXParseException exception) throws SAXException {
		System.out.println("Sack:errorHandler:exception:"+exception.toString()+"  file="+fname$);
		success=false;
	}

	@Override
	public void fatalError(SAXParseException exception) throws SAXException {
		System.out.println("Sack:errorHandler:fatal:exception="+exception.toString()+"  file="+fname$);
		success=false;
	}
	 
 }
}
