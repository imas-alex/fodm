package gdt.base.store;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.util.ArrayList;
public class Core {
    public String type = "string";
    public String name;
    public String value;
    public Core() {
    }
    public Core(String type, String name, String value) {
       	this.type = type;
        this.name = name;
        this.value = value;
    }
        public static Core[] sortAtIntType(Core[] ca) {
        if (ca == null)
            return null;
        Core c;
        boolean greater;
        for (int i = ca.length; --i >= 0; ) {
            boolean flipped = false;
            for (int j = 0; j < i; j++) {
                greater = false;
                if (ca[j].type == null)
                    ca[j].type = "0";
                if (ca[j + 1].type == null)
                    ca[j + 1].type = "0";
                if (ca[j].type.equals("0")) {
                    //greater = false;
                    continue;
                }
                if (ca[j + 1].type.equals("null")) {
                    //greater = false;
                    continue;
                }
                int a=0;
                int b=0;
                try{ a=Integer.parseInt(ca[j].type);}catch( NumberFormatException e){}
                try{ b=Integer.parseInt(ca[j+1].type);}catch( NumberFormatException e){}
                if(a> b)
                    greater = true;
                if (greater) {
                    c = ca[j];
                    ca[j] = ca[j + 1];
                    ca[j + 1] = c;
                    flipped = true;
                }
            }
            if (!flipped)
                return ca;
        }
        return null;
    }
    public static Core[] sortAtLongType(Core[] ca) {
        if (ca == null)
            return null;
        Core c;
        boolean greater;
        for (int i = ca.length; --i >= 0; ) {
            boolean flipped = false;
            for (int j = 0; j < i; j++) {
                greater = false;
                if (ca[j].type == null)
                    ca[j].type = "0";
                if (ca[j + 1].type == null)
                    ca[j + 1].type = "0";
                if (ca[j].type.equals("0")) {
                    //greater = false;
                    continue;
                }
                if (ca[j + 1].type.equals("null")) {
                    //greater = false;
                    continue;
                }
                long a=0;
                long b=0;
                try{ a=Long.parseLong(ca[j].type);}catch( NumberFormatException e){}
                try{ b=Long.parseLong(ca[j+1].type);}catch( NumberFormatException e){}
                if(a> b)
                    greater = true;
                if (greater) {
                    c = ca[j];
                    ca[j] = ca[j + 1];
                    ca[j + 1] = c;
                    flipped = true;
                }
            }
            if (!flipped)
                return ca;
        }
        return null;
    }
    public static Core[] sortAtLongValue(Core[] ca) {
        if (ca == null)
            return null;
        Core c;
        boolean greater;
        for (int i = ca.length; --i >= 0; ) {
            boolean flipped = false;
            for (int j = 0; j < i; j++) {
                greater = false;
                if (ca[j].value == null)
                    ca[j].value = "0";
                if (ca[j + 1].value == null)
                    ca[j + 1].value = "0";
                if (ca[j].value.equals("0")) {
                    //greater = false;
                    continue;
                }
                if (ca[j + 1].value.equals("null")) {
                    //greater = false;
                    continue;
                }
                long a=0;
                long b=0;
                try{ a=Long.parseLong(ca[j].value);}catch( NumberFormatException e){}
                try{ b=Long.parseLong(ca[j+1].value);}catch( NumberFormatException e){}
                if(a> b)
                    greater = true;
                if (greater) {
                    c = ca[j];
                    ca[j] = ca[j + 1];
                    ca[j + 1] = c;
                    flipped = true;
                }
            }
            if (!flipped)
                return ca;
        }
        return null;
    }
    public static Core[] sortAtIntName(Core[] ca) {
        if (ca == null)
            return null;
        Core c;
        boolean greater;
        for (int i = ca.length; --i >= 0; ) {
            boolean flipped = false;
            for (int j = 0; j < i; j++) {
                greater = false;
                if (ca[j].name == null)
                    ca[j].name = "0";
                if (ca[j + 1].name == null)
                    ca[j + 1].name = "0";
                if (ca[j].name.equals("0")) {
                    //greater = false;
                    continue;
                }
                if (ca[j + 1].name.equals("null")) {
                    //greater = true;
                    continue;
                }
               
                int a=0;
                int b=0;
                try{ a=Integer.parseInt(ca[j].name);}catch( NumberFormatException e){}
                try{ b=Integer.parseInt(ca[j+1].name);}catch( NumberFormatException e){}
                if(a> b)
                    greater = true;
                if (greater) {
                    c = ca[j];
                    ca[j] = ca[j + 1];
                    ca[j + 1] = c;
                    flipped = true;
                }
            }
            if (!flipped)
                return ca;
        }
        return null;
    }
    public static Core[] sortAtName(Core[] ca) {
        if (ca == null)
            return null;
        Core c;
        boolean greater;
        for (int i = ca.length; --i >= 0; ) {
            boolean flipped = false;
            for (int j = 0; j < i; j++) {
                greater = false;
                if (ca[j].name.compareToIgnoreCase(ca[j + 1].name) > 0)
                    greater = true;
                if (greater) {
                    c = ca[j];
                    ca[j] = ca[j + 1];
                    ca[j + 1] = c;
                    flipped = true;
                }
            }
            if (!flipped)
                return ca;
        }
        return null;
    }
    public static Core[] sortAtType(Core[] ca) {
        if (ca == null)
            return null;
        Core c;
        boolean greater;
        for (int i = ca.length; --i >= 0; ) {
            boolean flipped = false;
            for (int j = 0; j < i; j++) {
                greater = false;
                if (ca[j].type.compareToIgnoreCase(ca[j + 1].type) > 0)
                    greater = true;
                if (greater) {
                    c = ca[j];
                    ca[j] = ca[j + 1];
                    ca[j + 1] = c;
                    flipped = true;
                }
            }
            if (!flipped)
                return ca;
        }
        return null;
    }
    public static Core[] sortAtValue(Core[] ca) {
        if (ca == null)
            return null;
        Core c;
        boolean greater;
        for (int i = ca.length; --i >= 0; ) {
            boolean flipped = false;
            for (int j = 0; j < i; j++) {
                greater = false;
                if (ca[j].value.compareToIgnoreCase(ca[j + 1].value) > 0)
                    greater = true;
                if (greater) {
                    c = ca[j];
                    ca[j] = ca[j + 1];
                    ca[j + 1] = c;
                    flipped = true;
                }
            }
            if (!flipped)
                return ca;
        }
        return null;
    }
   public String toString() {
	   return "type="+type+";  name="+name+"; value="+value;
   }
    public static Core[] subtract(Core[] ca1,Core[] ca2){
    	if(ca1==null)
    		return null;
    	if(ca2==null)
    		return ca1;
    	ArrayList<Core>cl=new ArrayList<Core>();
    	boolean found;
    	for(Core aCa1:ca1){
    		found=false;
    		for(Core aCa2:ca2)
    			 if(aCa1.name.equals(aCa2.name)){
    			    	found=true;
    			    	break;
    			   }
    		if(!found)
    			cl.add(aCa1);
    	}
    	 return cl.toArray(new Core[0]);
    }
  public boolean equal(Core core) {
	  if(core==null) {
		  System.out.println("Core not equal: check is null");
		  return false;
	  }
	 
	  if(type==null)
		  type="null";
	  if(core.type==null)
		  core.type="null";
	 if(!type.equals(core.type)) {
		  System.out.println("Core not equal: type="+type+" check="+core.type);
		  return false;
	    }
	  
	  
	  if(!name.equals(core.name)) {
		  System.out.println("Core not equal: name="+type+" check="+core.name);
		  return false;
	  }
	
	  if(value==null)
		  value="null";
	  if(core.value==null)
		  core.value="null";
	  if(!value.equals(core.value)) {
		  System.out.println("Core not equal: value this="+value+" candidate="+core.value+" type this="+type+" candidate="+core.type);
		  return false;
	  }
	  return true;
  }
  
}