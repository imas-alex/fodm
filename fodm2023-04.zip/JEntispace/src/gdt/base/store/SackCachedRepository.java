package gdt.base.store;
/*
 * Copyright 2016-2023 Alexander Imas

 */
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import gdt.base.generic.Locator;
import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_MODIFY;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.nio.file.ClosedWatchServiceException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import  java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;

public class SackCachedRepository {

public static final String TIMESTAMP="timestamp";

public static final String RUNTIME="runtime";
public static final String EVENT_SOURCE="event source";
public static final String EVENT_TYPE="event type";
public static final String EVENT_SOURCE_CACHE="cache";
public static final String EVENT_TYPE_SACK_CHANGED="sack changed";
public static final String EVENT_CONTAINER="container";
public static final String EVENT_TYPE_CLOSED="closed";
public static final String EVENT_TYPE_SLEEPING="sleeping";
public static final String EVENT_TYPE_LOADED="loaded";
public static final String EVENT_TYPE_STARTED="started";
public static final String SACK_KEY="sack key";
public static final String START_WATCHING="start watching";
public static final String START_REFRESH="start refresh";
public static final String TERMINATED_REFRESH="terminated refresh";
public static final String TERMINATED_WATCHING="terminated watching";
public static final String RUNNING_REFRESH="running refresh";
public static final String RUNNING_WATCHING="running watching";
public static final String TERMINATED_CACHE="terminated cache";
public static final String STARTED_CACHE="started cache";
public static final String WAITING_REFRESH="waiting refresh";
public static final String ROOT="/";
public static final String SAVED="saved";

ConcurrentHashMap <String,Sack>cache=new ConcurrentHashMap<String,Sack>();
Thread watchingThread;
Thread refreshThread; 
final Logger LOGGER= Logger.getLogger(SackCachedRepository.class.getName());
final static boolean debug=false;
boolean permanent;
int delay=1000;
boolean pauseWatching=false;
String entihome$;
Path sackdir;
Path root;
String container$;
String fname$=null;
WatchService watcher;
//Services
private static int NOP=0;
private static int START=1;
private static int TERMINATE=2;
private static int NOT_STARTED=0;
private static int RUNNING=2;
private static int TERMINATED=3;
//Refresh
int refreshState=NOT_STARTED;
int refreshControl=NOP;
//Watching
int watchingState=NOT_STARTED;
int watchingControl=NOP;
PropertyChangeSupport pcs;
public SackCachedRepository(String entihome$,String container$,boolean permanent) {
	if(entihome$==null||container$==null)
		 throw new RuntimeException(getClass().getName()+":invalid parameters ");
	this.entihome$=entihome$;
	this.permanent=permanent;
	this.container$=container$;
	if(ROOT.contentEquals(container$))
		sackdir = Paths.get(entihome$);
	else
	    sackdir = Paths.get(entihome$+"/"+container$+"/data");
	File container=sackdir.toFile();
	if(!container.exists())
			container.mkdirs();
	pcs=new PropertyChangeSupport(this);
	start();
}

public void execRefresh(int control) {
	//System.out.println("SackCachedRepository:execRefresh:control="+control);
	switch (control){
	case 0: 
		return;
	case 1:
		startRefresh();
		System.out.println("SackCachedRepository:start refresh:container="+container$);
		return;
	case 2:
		System.out.println("SackCachedRepository:terminate refresh:container="+container$);
		if(refreshThread==null||refreshThread.isInterrupted())
			return;
		try {	refreshThread.interrupt();}catch(Exception e) {System.out.println("SackCachedRepository:terminate refresh:"+e.toString());}
		return;
	}
}
public void execWatching(int control) {
	//System.out.println("SackCachedRepository:execWatching:control="+control);
	switch (control){
	case 0: 
		return;
	case 1:
		startWatching();
		//System.out.println("SackCachedRepository:execWatching:start container="+container$);
		return;
	case 2:
		
		if(watchingThread==null||watchingThread.isInterrupted())
			return;
		try {watchingThread.interrupt();}catch(Exception e) {System.out.println("SackCachedRepository:terminate watching:"+e.toString());}
		
		
        System.out.println("SackCachedRepository:execWatching:terminate container="+container$);
       
		return;
	}	
}

private void startWatching() {
	try{
	if(watchingThread==null||watchingThread.getState()==Thread.State.TERMINATED) {	
		//System.out.println("SackCachedRepository:start watching");
		watchingThread=new Thread(processEvents);
	 watchingThread.start();
	}
    }catch(Exception e){
			LOGGER.severe("startWatching:"+e.toString());
	}
}
private void startRefresh() {
	
	try{
	if(refreshThread==null||refreshThread.getState()==Thread.State.TERMINATED) {
		//System.out.println("SackCachedRepository:startRefresh:1");	
    refreshThread=new Thread(refresh);
    refreshThread.start();
	}else {
		//System.out.println("SackCachedRepository:startRefresh:2");	
	}
	//System.out.println("SackCachedRepository:startRefresh:container="+container$+" sackdir="+sackdir.toString());
    }catch(Exception e){
		LOGGER.severe("startRefresh:"+e.toString());
	}
	
}
Runnable processEvents =new Runnable(){ 
public void run(){
	try {
		System.out.println("SackCachedRepository:processEvents:start:container="+container$+" thread="+Thread.currentThread().hashCode());
		watcher = FileSystems.getDefault().newWatchService();
		watchingState=RUNNING;
	
        for(;;){
        	//System.out.println("SackCachedRepository:processEvents:0");
        	WatchKey key=null;
        try{
        	 key = sackdir.register(watcher, ENTRY_CREATE, ENTRY_MODIFY);
             key = watcher.take();
        } catch (ClosedWatchServiceException expected) {
        	System.out.println("SackCachedRepository:processEvents:break:ClosedWatchServiceException:"+expected.toString());
        	break;    	
        
        }catch (InterruptedException x) {
        	  // System.out.println("SackCachedRepository:processEvents:break:interrupted:"+x.toString());
        	   break;
         }
        String key$=null;
        for (WatchEvent<?> event: key.pollEvents()){
        	//System.out.println("SackCachedRepository:processEvents::container="+container$+"  event="+event.toString());
                  Object context = event.context();
                  if (context != null && context instanceof Path) {
                     Path p = (Path) context;
                     String p$=p.toString();
                    // System.out.println("SackCachedRepository:processEvents:1");
                     if(p$.startsWith(".goutputstream")) 
                    	 continue;
                     key$=p$;
                     
                     if(IndexHandler.CONTAINER_ENTITIES.equals(container$)) {
                    	 Sack entityInMemory=cache.get(key$);
                    	 if(entityInMemory!=null) {
                    		 String resident$=entityInMemory.getAttributeAt(Sack.RESIDENT);
                    		 if(Locator.LOCATOR_TRUE.equals(resident$))
                    			 continue;
                    		 else {
                    			 //System.out.println("SackCachedRepository:processEvents:not resident entity="+entityInMemory.getProperty("label")); 
                    		 }
                    	 }
                     }
                     WatchEvent.Kind<?> kind = event.kind();
                 if( StandardWatchEventKinds.ENTRY_MODIFY.equals(kind)) {
                   	try {
                   		Sack diskSack=null;
                   		if("/".equals(container$))
                   			diskSack=Sack.readXml(entihome$,"/",p$);
                   		else
                   		  diskSack=Sack.readXml(entihome$,container$+"/data",p$);
                   		if(diskSack==null) {
                   			System.out.println("SackCachedRepository:processEvents:cannot read sack="+p$);
                			continue;	
                   		}
                   		String label$=diskSack.getProperty("label");
                   		if("session".equals(label$))
                       		  continue;	
                    	Sack memorySack=cache.get(key$);
                    	if(memorySack==null){
                    		cache.put(diskSack.getKey(),diskSack);
                    	}else {
                   		String idMemory$=memorySack.getAttributeAt("id");
                   		if(idMemory$==null) {
                   			idMemory$=Identity.key();
                   			memorySack.putAttribute(new Core("runtime","id",idMemory$));
                   		}
                   		String idDisk$=diskSack.getAttributeAt("id");
                   		
                   		if(!idMemory$.equals(idDisk$))
                   			cache.put(key$, diskSack);
                    	}
                    	if("_ohFgnS1GWzafxslParpkvqk3XwA".equals(key$)) { 
                    		System.out.println("SackCachedRepository:processEvents:fire event");		
                    	Properties prop=new Properties();
                         prop.put(EVENT_SOURCE, EVENT_SOURCE_CACHE);
                         prop.put(EVENT_CONTAINER, container$);
                         prop.put(EVENT_TYPE, EVENT_TYPE_SACK_CHANGED);
                         prop.put(Entigrator.ENTITY_KEY, key$);
                         String locator$=Locator.toString(prop);
                         PropertyChangeEvent pce=new  PropertyChangeEvent(this,locator$,null,null);
                         pcs.firePropertyChange(pce);
                         }
                    	}catch(Exception eee) {
                    		System.out.println("SackCachedRepository:processEvents:"+eee.toString());	
                     	}
                      }
                    }
                  }
      boolean valid = key.reset();
      if (!valid) {
    	  System.out.println("SackCachedRepository:processEvents:break watching cache="+container$+" invalid key");
          break;
      }
     }
      watcher.close();
      watchingState=TERMINATED;
  //    System.out.println("SackCachedRepository:processEvents:terminated:container="+container$+" thread="+Thread.currentThread().hashCode());
     }catch (Exception x) {
	       	//System.out.println("Process events:"+x.toString());
	    	   LOGGER.severe("SackCachedRepository:processEvents:"+x.toString());
	       }
	}
};
public synchronized Sack put(Sack sack){
	if(sack==null) {
		System.out.println("SackCachedRepository:put:sack is null");
		return null;
	}
	if(IndexHandler.CONTAINER_ENTITIES.equals(container$)) {
		if(watchingState==2)
			    execWatching(1);
		// System.out.println("SackCachedRepository:watching state="+watchingState);
		 
	}
	sack.removeAttribute(SAVED);
	if(IndexHandler.CONTAINER_ENTITIES.equals(container$)) {
     sack.putAttribute(new Core("runtime",TIMESTAMP,String.valueOf(System.currentTimeMillis())));
	 sack.putAttribute(new Core("runtime",SAVED,"true"));
	 sack.putAttribute(new Core("runtime","id",Identity.key()));
	 sack.setPath(sackdir+"/"+sack.getKey());
	  //sack.store();
	}
	cache.put(sack.getKey(),sack);
	return sack;
	}
public  synchronized int size() {
	return cache.size();
}
public synchronized Sack getFromCache(String sackKey$) {
	return cache.get(sackKey$);
}
public  Sack get(String sackKey$){
	try{
		if(sackKey$==null) {
			return null;
		}
		//System.out.println("SackCachedRepository:try get :key="+sackKey$+"  in container="+container$);
		 Sack sack=cache.get(sackKey$);
		 if(sack==null) {
			 //System.out.println("SackCachedRepository:reload:key="+sackKey$+"  in container="+container$);
			 sack=Sack.readXml(sackdir.toString()+"/"+sackKey$);
			 if(sack==null) {
				 System.out.println("SackCachedRepository:get:container="+container$+"  cannot read sack at path="+sackdir.toString()+"/"+sackKey$);
				 return null;
			 }
			 put(sack);
		 }
		return sack;
	}catch(Exception e){
		LOGGER.severe(e.toString());
		return null;
	}
}

public synchronized boolean delete(String sackKey$){
	//System.out.println("SackCachedRepository:refreshCache:delete:cache="+container$+"delete="+sackKey$);
	cache.remove(sackKey$);
	try {
	File file=new File(sackdir.toString()+"/"+sackKey$);
   return file.delete();
	}catch(Exception e) {
		LOGGER.severe("delete:"+e.toString());
		return false;
	}
}
Runnable refresh=new Runnable(){
	public void run(){
		for(;;) {
				 refreshState=RUNNING;
	  		try {	
				 Thread.sleep(delay);
	  		}catch(InterruptedException e) {
	  			//System.out.println("SackCachedRepository:refresh:container="+container$+"  error="+e.toString());
	  			break;
	  		}
	  		//System.out.println("SackCachedRepository:refresh:container="+container$);
			 if(cache.isEmpty()) 
						continue;	
  			Iterator<String> itr=cache.keySet().iterator();
  			String sackKey$;
  			Sack memorySack;
  			Sack diskSack;
  			 while (itr.hasNext()) {
  				 try {
  					 sackKey$=itr.next();
  					 memorySack=cache.get(sackKey$);
  					 //global index
  					if("/".equals(container$)) {
	 					memorySack.save(entihome$,container$);
	 					continue;
					}
  					//regular cache
  					//System.out.println("SackCachedRepository:refreshCache:BEGIN:key="+sackKey$);
  					if(Locator.LOCATOR_TRUE.equals(memorySack.getProperty("sysbase")))
  						continue;
  					if("/".equals(container$)) {
  						diskSack=Sack.readXml(entihome$,container$,sackKey$);
  					}else
	 					diskSack=Sack.readXml(entihome$,container$+"/data",sackKey$);
  					if(diskSack==null) {
  					//	System.out.println("SackCachedRepository:refresh:sack="+entihome$+container$+"/data/"+sackKey$);
  					//	memorySack.print();
  						memorySack.save(entihome$,container$);
  						continue;
  					}
  					String memoryId$=memorySack.getAttributeAt("id");
  					if(memoryId$==null) {
  						memoryId$=Identity.key();
  						memorySack.putAttribute(new Core("runtime","id",memoryId$));
  						
  						//System.out.println("SackCachedRepository:refreshCache:0:key="+sackKey$);
  						continue;
  					}
  					String diskId$=diskSack.getAttributeAt("id");
  					if(memoryId$.equals(diskId$))
  						continue;
  					//System.out.println("SackCachedRepository:refreshCache:1:key="+sackKey$);
						
  					memorySack.save(entihome$,container$);
  					boolean outdated=false;
  					long timestamp=Long.parseLong(memorySack.getAttributeAt(TIMESTAMP));
  					long currentTime=System.currentTimeMillis();
  					long delta=currentTime-timestamp;
  					if(delta>delay+100)
  						 outdated=true;
  					
		    	 //System.out.println("SackCachedRepository:refreshCache:delta="+delta+" outdated="+outdated); 	 
  					 if(outdated){
	    			// System.out.println("SackCachedRepository:refreshCache:outdated="+sackKey$);
  						cache.remove(sackKey$);   
  					 	}
  				 }catch(Exception ee) {
				 System.out.println("SackCachedRepository:refreshCache:"+ee.toString());	
  				 }
  			 }
  		}
		refreshState=TERMINATED;
	}
};

boolean isStopped() {
	boolean refreshStopped=false;
	if(refreshState==TERMINATED)
		refreshStopped=true;
	boolean watchingStopped=false;
	if(watchingState==TERMINATED)
		watchingStopped=true;
	if(refreshStopped&&watchingStopped)
		return true;
	else
		return false;
}
boolean isStarted() {
	if(refreshState==RUNNING)
		return true;
	else
		return false;
}
public void clear(boolean onDisk){
	terminate();
	cache.clear();
	if(onDisk) {
		File container=sackdir.toFile();
		File[] fa=container.listFiles();
		if(fa!=null)
			for(File f:fa)
				try{f.delete();}catch(Exception e) {}
	}
}
public String[] listFiles() {
	File container=sackdir.toFile();
	return container.list();
}
public String[] getKeys() {
	Enumeration <String> en= cache.keys();
	ArrayList<String>sl=new ArrayList<String>();
	while(en.hasMoreElements()){
		sl.add(en.nextElement());
		}
	String[] sa=new String[sl.size()];
	return sl.toArray(sa);
}

public void terminate() {
//	System.out.println("SackCachedRepository:terminate:container="+container$);	
	execRefresh(TERMINATE);
	execWatching(TERMINATE);
}
public void start() {
	//System.out.println("SackCachedRepository:start:container="+container$);
	if(IndexHandler.CONTAINER_ENTITIES.equals(container$))
	   execRefresh(START);
	execWatching(START);
}
public void dump(){
	Iterator<String> eki=cache.keySet().iterator();
	Sack sack;
	String key$;
	terminate();
	while(eki.hasNext()){
		key$=eki.next();
		//System.out.println("SackCachedRepository:dump:key="+key$);
		sack=cache.get(key$);
		if(sack!=null) {
			sack.store();
		}
  }
}
public void load() {
	try {
		String parent$;
		if(ROOT.equals(container$))
			parent$=sackdir.toString();
		else
			parent$=sackdir.toString();
		//System.out.println("SackCachedRepository:loadContainer:parent="+parent$);
		File parent=new File(parent$);
		String[] sa=parent.list();
		Sack sack;
        terminate();
		for(String s:sa) {
			sack=Sack.readXml(parent$+"/"+s);
			if(sack!=null)
				put(sack);
			else {
				//Sack.traceCalls();
			}
		}
	 start();	
	}catch(Exception e) {
		System.out.println("SackCachedRepository:load container:"+e.toString());
	}
}
public void setDelay(int delay) {
	this.delay=delay;
}
public void addPropertyChangeListener(PropertyChangeListener pcl) {
	pcs.addPropertyChangeListener(pcl);
}
}
