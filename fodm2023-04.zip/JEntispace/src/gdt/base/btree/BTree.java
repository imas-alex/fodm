package gdt.base.btree;
/*
 * Copyright 2016-2023 Alexander Imas

 */
import java.util.Stack;

public class BTree {
    protected BNode root;
    
    public BTree() {
        root = new BNode();
        root.parent = null;
        root.bTree = this;
    }
    public int put(String key, Object value) {
         return root.put(key, value);
    }
    public Object get(String key) {
        return root.getObject(key);
    }
    public Object remove(String key) {
    	Object ret=root.getObject(key);
        root.remove(key);
        return ret;
    }
    public Stack<String> keys() {
        Stack <String>ret = new Stack<String>();
        pushKeys(ret, root);
        return ret;
    }
    public boolean containsKey(String key) {
        return root.containsKey(key);
    }

    private void pushKeys(Stack<String> s, BNode bNode) {
        if (s == null || bNode == null)
            return ;
        if (bNode.last_ == 0)
            return ;
        for (int i = 0; i < bNode.last_; i++) {
            if (bNode.values[i] == null)
                continue;
            if (bNode.values[i].containsNode())
                pushKeys(s, ((BNode) bNode.values[i].value));
            else
                s.push(bNode.values[i].key);
        }
    }

}
