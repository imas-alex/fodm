package gdt.base.generic;
/*
 * Copyright 2016-2023 Alexander Imas
  */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.logging.Logger;

import gdt.base.facet.ModuleHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.JContext;

public class SessionHandler {

public static final	String HISTORY="history";
public static final	String INSTANCE="instance";
public static final	String PARAMETER="parameter";	
public static final	String CORE="core";	
public static final	String COPY="copy";	
public static final	String ITEM_TITLE="item title";
public static final	String DEFAULT="default";
public static final	String ENTITY="entity";
public static final	String CONTAINER="container";
public static final	String CONTEXT="context";
	public static Sack getSession(Entigrator entigrator) {
		if(entigrator==null) {
			System.out.println("SessionHandler:getSession:entigrator is null");
			return null;
		}
		//System.out.println("SessionHandler:getSession:entigrator instance="+entigrator.getInstance());
		
		Sack session=entigrator.getEntityAtLabel("session");
		
		if(session==null) {
			String session$=Identity.key();
		    session= entigrator.createEntity("session","sysbase",session$);
			session.createElement(PARAMETER);
			Core entihome=new Core(null,"entihome",entigrator.getEntihome());
			session.putElementItem(PARAMETER, entihome);
			session.putAttribute(new Core(null,Sack.RESIDENT,Locator.LOCATOR_TRUE));
			entigrator.putEntity(session);
			session=entigrator.assignProperty("session", Locator.LOCATOR_TRUE,session$);
			session=entigrator.assignProperty("sysbase", Locator.LOCATOR_TRUE,session$);
			session=entigrator.assignProperty("runtime", Locator.LOCATOR_TRUE,session$);
			session.createElement(INSTANCE);
			session.createElement(HISTORY);
			session.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","session.png"));
			session.putAttribute(new Core("runtime","resident",Locator.LOCATOR_TRUE));
			entigrator.putEntity(session);
		}
		return session;
		
	/*
		System.out.println("SessionHandler:getSession:cannot get session. Try create the session");
		try {
		String entigratorInstane$=entigrator.getInstance();
		session= entigrator.createEntity(entigratorInstane$,"sysbase",entigratorInstane$);}catch(Exception e) {
		}
		if(session==null) {
			System.out.println("SessionHandler:getSession:cannot create new session ");
			return null;
		}
		//System.out.println("SessionHandler:getSession:session="+session.getKey());
		entigrator.putEntity(session);
		session=entigrator.assignProperty("session", Locator.LOCATOR_TRUE,session.getKey());
		session=entigrator.assignProperty("runtime", Locator.LOCATOR_TRUE,session.getKey());
		 if(!session.existsElement("INSTANCE"))
			 session.createElement(INSTANCE);
		 if(!session.existsElement("HISTORY"))
			 session.createElement(HISTORY);
		 session.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","session.png"));
		 session.putAttribute(new Core("runtime","resident",Locator.LOCATOR_TRUE));
		 if(!session.existsElement(PARAMETER))
				session.createElement(PARAMETER);
			Core entihome=new Core(null,"entihome",entigrator.getEntihome());
			session.putElementItem(PARAMETER, entihome);
			entigrator.putEntity(session);
		 entigrator.putEntity(session);
		return session;
		*/
	}
	
	public static void clearInstances(Entigrator entigrator) {
   		Sack session=getSession(entigrator);
        if(session==null) {
           	return ;
        }
           if(!session.existsElement(INSTANCE))
    		session.createElement(INSTANCE);
        else
        	session.clearElement(INSTANCE);
		entigrator.putEntity(session);
	}
	public static void removeHistoryInstance(Entigrator entigrator,String instance$) {
        Sack session=getSession(entigrator);
       try {
       	     session.removeElementItem(HISTORY, instance$);
       	     entigrator.putEntity(session);
        }catch(Exception e) {
        	System.out.println("SessionHandler:rHistoryInstance::"+e.toString());
        }
  }
	public static String getInstanceLocator(Entigrator entigrator,String instance$) {
		if(entigrator==null)
			return restoreLocator();
		if(instance$==null)
			return null;
		Sack session=getSession(entigrator);
		 if(session==null)
			 return null;
		return session.getElementItemAt(INSTANCE, instance$);
	}
	public static String restoreLocator() {
		try {  
	        	File home=new File(System.getProperty("user.home")+"/.entigrator");
	 			File locator=new File(home.getPath()+"/locator");
			 FileInputStream fis = new FileInputStream(locator);
	         InputStreamReader ins = new InputStreamReader(fis, "UTF-8");
	         BufferedReader rds = new BufferedReader(ins);
	         String locator$= rds.readLine();
		     rds.close();
		     fis.close();
		    return locator$;	
	         }catch(Exception e) {
	        	 System.out.println("SessionHandler:restoreLocator:"+e.toString());
	        	 return null;
	         }
	}
	public static String getHistoryInstanceLocator(Entigrator entigrator,String instance$) {
		if(instance$==null) {
			System.out.println("SessionHandler:getHistoryInstanceLocator:instance is null");
			return null;
		}
		Sack session=getSession(entigrator);
		 if(session==null) {
			 System.out.println("SessionHandler:getHistoryInstanceLocator:session is null");
			 return null;
		 }
		return session.getElementItemAt(HISTORY, instance$);
	}
	public static String getFacetLocator(Entigrator entigrator,String facetClass$) {
		if(facetClass$==null) {
			System.out.println("SessionHandler:getFacetLocator:facet class is null is null");
			return null;
		}
		Sack session=getSession(entigrator);
		 if(session==null) {
			 System.out.println("SessionHandler:getFacetLocator:session is null");
			 return null;
		 }
		Core[] ca=session.elementGet("facet.master");
//		System.out.println("SessionHandler:getFacetLocator:ca="+ca.length);
		if(ca==null)
			return null;
		for(Core c:ca) {
//			System.out.println("SessionHandler:getFacetLocator:facet="+facetClass$+" candidate="+Locator.getProperty(c.value, FacetMaster.MASTER_CLASS));
			if(facetClass$.equals(Locator.getProperty(c.value, FacetMaster.MASTER_CLASS))) {
	//			System.out.println("SessionHandler:getFacetLocator:RETURN="+c.value);
				return c.value;
			}
		}
		return null;
	}
	
	public static void saveLocator(String locator$) {
		try{
	    	File home=new File(System.getProperty("user.home")+"/.entigrator");
			if(!home.exists())
				home.mkdir();
			File locator=new File(home.getPath()+"/locator");
			locator.createNewFile();
			 FileOutputStream fos = new FileOutputStream(locator, false);
			 Writer writer = new OutputStreamWriter(fos, "UTF-8");
			 writer.write(locator$);
			 writer.close();
			 fos.close();
		}catch(Exception e){
			System.out.println("SessionHandler:saveLocator:"+e.toString());
		}
	}

	public static String putLocator(Entigrator entigrator,String locator$) {
		if(locator$==null) {
			System.out.println("SessionHandler:putLocator:: locator is null");
			return null;
		}
		if(entigrator==null) {
			saveLocator(locator$);
			System.out.println("SessionHandler:putLocator:: entigrator is null");
			return null;
		}
		String instance$=Locator.getProperty(locator$, JContext.INSTANCE);
		if(instance$==null) {
			instance$=Identity.key();
			locator$=Locator.append(locator$, JContext.INSTANCE, instance$);
			System.out.println("SessionHandler:putLocator:: new instance ");

		}
		String parent$=Locator.getProperty(locator$, JContext.PARENT);
		if(parent$==null) {
			System.out.println("SessionHandler:putLocator:: parent is null in locator="+locator$);
		}
		   putInstanceLocator(entigrator,parent$,instance$,locator$);
		return instance$;   
	}
	public static void forgetOld(Entigrator entigrator,int keep) {
		//System.out.println("SessionHandler:putLocator:: locator ="+locator$);
		if(entigrator==null) {
			System.out.println("SessionHandler:forgetOld: entigrator is null");
			return ;
		}
		Sack session=getSession(entigrator);
		 if(session==null) {
			 System.out.println("SessionHandler:forgetOld: cannot get session");
			 return ;
		 }
	     if(keep==0) {
	    	 session.removeElement("instance");
	    	 session.removeElement("history");
	     }
	     entigrator.putEntity(session);

	}
	public static void putCores(Entigrator entigrator,Core[] ca) {
		if(ca==null||ca.length<1) {
			System.out.println("SessionHandler:putCores: empty argument");
			return;
		}
		Sack session=getSession(entigrator);
		if(!session.existsElement(CORE))
			session.createElement(CORE);
		else
			session.clearElement(CORE);
		for(Core c:ca)
			session.putElementItem(CORE, c);
		entigrator.putEntity(session);
	}
	public static void putCopiedEntity(Entigrator entigrator,String entityKey$) {
		if(entityKey$==null)
			return;
		Sack session=getSession(entigrator);
		if(!session.existsElement(COPY))
			session.createElement(COPY);
		session.putElementItem(COPY, new Core(ENTITY,entityKey$,null));
		entigrator.putEntity(session);
	}
	public static String[] listCopiedEntities(Entigrator entigrator) {
		Sack session=getSession(entigrator);
		if(!session.existsElement(COPY))
		    return null;
		ArrayList<String>sl=new ArrayList<String>();
		Core[] ca=session.elementGet(COPY);
		for(Core c:ca) {
			if(ENTITY.equals(c.type))
				sl.add(c.name);
		}
		String[] sa=new String[sl.size()];
		sl.toArray(sa);
		return sa;
	}
	public static boolean hasCopyEntity(Entigrator entigrator) {
		if(entigrator==null) {
			System.out.println("SessionHandler:hasCopy: entigrator is null");
			return false;
		}
		Sack session=getSession(entigrator);
		if(session==null) {
			System.out.println("SessionHandler:hasCopy: no session in entigrator="+entigrator.getEntihome());
			return false;
		}
		if(!session.existsElement(COPY))
		    return false;
		Core[] ca=session.elementGet(COPY);
		for(Core c:ca) {
			if(ENTITY.equals(c.type))
				return true;
		}
		return false;
		
	}
	public static boolean hasCopyContainer(Entigrator entigrator) {
		if(entigrator==null) {
			System.out.println("SessionHandler:hasCopy: entigrator is null");
			return false;
		}
		Sack session=getSession(entigrator);
		if(session==null) {
			System.out.println("SessionHandler:hasCopy: no session in entigrator="+entigrator.getEntihome());
			return false;
		}
		if(!session.existsElement(COPY))
		    return false;
		Core[] ca=session.elementGet(COPY);
		for(Core c:ca) {
			if(CONTAINER.equals(c.type))
				return true;
		}
		return false;
		
	}
	public static boolean hasCopy(Entigrator entigrator) {
		if(entigrator==null) {
			System.out.println("SessionHandler:hasCopy: entigrator is null");
			return false;
		}
		Sack session=getSession(entigrator);
		if(session==null) {
			System.out.println("SessionHandler:hasCopy: no session in entigrator="+entigrator.getEntihome());
			return false;
		}
		if(session.existsElement(COPY))
		    return true;
		else {
			return false;
		}
		
	}
	public static void clearCopy(Entigrator entigrator) {
		Sack session=getSession(entigrator);
		session.removeElement(COPY);
		entigrator.putEntity(session);
		}
	public static void clearFacets(Entigrator entigrator) {
		Sack session=getSession(entigrator);
		session.removeElement("facet.handler");
		session.removeElement("facet.master");
		entigrator.putEntity(session);
		
		}
	public static Core[] getCores(Entigrator entigrator) {
		Sack session=getSession(entigrator);
		if(!session.existsElement(CORE))
		    return null;
		return session.elementGet(CORE);
	}
	public static boolean hasCores(Entigrator entigrator) {
		Sack session=getSession(entigrator);
		if(session==null) {
			System.out.println("SessionHandler:hasCores:session is null is null");
			return false;
		}
		if(!session.existsElement(CORE))
		    return false;
		Core[] ca=session.elementGet(CORE);
		if(ca!=null&&ca.length>0)
			return true;
		return false;
	}
	public static void removeParameter(Entigrator entigrator,String parameter$) {
		if(parameter$==null) {
			return ;
		}
		Sack session=getSession(entigrator);
		if(!session.existsElement(PARAMETER))
			return ;
		session.removeElementItem(PARAMETER, parameter$);
		entigrator.putEntity(session);
	}
	public static String getCurrentLocator(Entigrator entigrator) {
	if(entigrator==null) {
		System.out.println("SessionHandler:getCurrentLocator:entigrator is null");
		return null;
	}
	Sack session=getSession(entigrator);
		 if(session==null) {
			 System.out.println("SessionHandler:getCurrentLocator:session is null");
			 return null ;
		 }
		 Core currentLocator=session.getAttribute("actual");
		 if(currentLocator==null)
			 return null;
		return currentLocator.value;
	}
	
private static void putInstanceLocator(Entigrator entigrator,String parent$,String instance$,String locator$) {
		if(instance$==null||locator$==null) {
			System.out.println("SessionHandler:putInstanceLocator: instance is null");
			return ;
		}
		Sack session=getSession(entigrator);
		 if(session==null) {
			 System.out.println("SessionHandler:putInstanceLocator: cannot get session");
			 return ;
		 }
	
		Core instanceEntry=new Core(parent$,instance$,locator$);
		session.putElementItem(INSTANCE, instanceEntry);
		putHistoryLocator(entigrator ,locator$);
		session.putElementItem(INSTANCE, instanceEntry);
		entigrator.putEntity(session);
		
	}
	public static void putHistoryLocator(Entigrator entigrator ,String locator$) {
		if(locator$==null) {
			System.out.println("SessionHandler:putHistoryLocator:locator is null");
			return;
		}
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			if(entity$==null)
				return;
			Sack session=getSession(entigrator);
			if(!session.existsElement(HISTORY))
				session.createElement(HISTORY);
			String title$=Locator.getProperty(locator$,Locator.LOCATOR_TITLE);
			
			String itemTitle$=title$;
			
			if(entity$!=null)
				if(!itemTitle$.contains("("+entity$+")")) 
					itemTitle$=title$+"("+entity$+")";
				else
					itemTitle$=title$;
			String instance$=Locator.getProperty(locator$,JContext.INSTANCE);
			String itemLocator$=Locator.append(locator$, ITEM_TITLE, itemTitle$);
			Core item=new Core(null,instance$,itemLocator$);
			Core[] ca=session.elementGet(HISTORY);
            if(ca!=null) {
            	String ctitle$;
            	for (Core c:ca) {
            		ctitle$=Locator.getProperty(c.value,ITEM_TITLE);
//            		System.out.println("SessionHandler:putHistoryLocator:item title="+itemTitle$+"; ctitle="+ctitle$);
            		if(itemTitle$.equals(ctitle$)) {
            			session.removeElementItem(HISTORY, c.name);
            		}
            	}
            }
            session.putElementItem(HISTORY, item);
            entigrator.putEntity(session);
		}catch(Exception e) {
			System.out.println("SessionHandler:putHistoryLocator:locator="+locator$+";  error="+e.toString());
		}
	}
	public static String[] listHistoryItems(Entigrator entigrator) {
		try {
			Sack session=getSession(entigrator);
			if(session==null){
				System.out.println("SessionHandler:listHistoryItems:session is null");
				return null;
			}
			session=entigrator.getEntity(session.getKey());
			//session.print();
			Core [] ca=session.elementGet(HISTORY);
			if(ca==null) {
				System.out.println("SessionHandler:listHistoryItems:no history element");
				return null;
			}
			
			if(ca.length==0) {
				System.out.println("SessionHandler:listHistoryItems:no history items");
				return null;
			}
			//System.out.println("SessionHandler:listHistoryItems:ca="+ca.length);
			if(ca.length==1)
				return new String[] {ca[0].name};
			ca=Core.sortAtLongType(ca);
			//System.out.println("SessionHandler:listHistoryItems:sorted ca="+ca.length);
			String[]sa=new String[ca.length];
			int cnt=ca.length;
			for(int i=0;i<cnt;i++)
				sa[i]=ca[cnt-1-i].name;
			return sa;
		}catch(Exception e) {
			System.out.println("SessionHandler:listHistoryItems:"+e.toString());
		}
		return null;
	}
	public static void store(Entigrator entigrator){
		try{
			//System.out.println("SessionHandler:store:BEGIN");
			if(entigrator==null)
				return;
			File home=new File(System.getProperty("user.home")+"/.entigrator");
			if(!home.exists())
				home.mkdir();
			Sack session=getSession(entigrator);
			
			if(session!=null) {
				session.putAttribute(new Core(null,"entihome",entigrator.getEntihome()));
				File sessionFile=new File(System.getProperty("user.home")+"/.entigrator/session");
				if(!sessionFile.exists())
					sessionFile.createNewFile();
				//session.setPath(System.getProperty("user.home")+"/.entigrator/session");
				session.saveXML(sessionFile.getPath());
			}
		}catch(Exception e){
			Logger.getLogger(SessionHandler.class.getName()).severe(e.toString());
		}
	}
	
	public static void collectParents(Sack current,String instance$,ArrayList<String>pl ) {
		Core entry=current.getElementItem("instance", instance$);
		if(entry==null)
			return;
		String parent$=entry.type;
		if(parent$==null)
			return;
		pl.add(parent$);
		collectParents( current,parent$,pl );
	}
	public static void collectChildren(Sack current,String instance$,ArrayList<String>cl ) {
		cl.add(instance$);
		Core [] ia=current.elementGet("instance");
		for(Core i:ia) {
			if(instance$.equals(i.type)) {
				collectChildren(current,i.name,cl);
			}
		}
	}
}
