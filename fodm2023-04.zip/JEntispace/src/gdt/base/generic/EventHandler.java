package gdt.base.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.util.Properties;
import gdt.base.facet.ModuleHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

public class EventHandler {
	public static final	String KEY="_ohFgnS1GWzafxslParpkvqk3XwA";
	public static final	String REQUESTOR="requestor";
	public static final	String CONSUMER="consumer";
	public static final	String MESSAGE="message";
	public static final	String ENTIGRATOR="entigrator";
	public static Sack getEvent(Entigrator entigrator) {
		//System.out.println("EventHandler:getEvent:BEGIN");
		if(entigrator==null) {
			System.out.println("EventHandler:getEvent:entigrator is null");
			return null;
		}
		Sack event=entigrator.getEntity(KEY);
		if(event!=null) {
			//System.out.println("EventHandler:getEvent:found event");
			return event;
		}
		try { 
			event= entigrator.createEntity("event","sysbase",KEY);
			entigrator.putEntity(event);
		    entigrator.assignProperty("event", Locator.LOCATOR_TRUE, KEY);
		    event.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","event.png"));
			entigrator.putEntity(event);
			entigrator.reindexEntity(event);
		//	System.out.println("EventHandler:getEvent:created event="+event.getProperty("label"));
			return event;
		}catch(Exception e){
			
			System.out.println("EventHandler:getEvent:failed create new session");
			return null;
		}
	}
	public static void putRequest(Entigrator entigrator,String locator$) {
		try {
		//	System.out.println("EventHandler:putRequest:locator="+locator$);
			String requestor$=Locator.getProperty(locator$, REQUESTOR);
			String consumer$=Locator.getProperty(locator$, CONSUMER);
			String message$=Locator.getProperty(locator$, MESSAGE);
			Sack event=getEvent(entigrator);
			
			if(!event.existsElement("request"))
				 event.createElement("request");
			if(consumer$==null) {
				System.out.println("EventHandler:putRequest:consumer is null");
				//return;
			}
			if(requestor$==null) {
				System.out.println("EventHandler:putRequest:requestor is null");
				return;
			}
			if(message$==null) {
				System.out.println("EventHandler:putRequest:message is null");
				return;
			}
			 if(!event.existsElement("request"))
				 event.createElement("request");
			 else
				 event.clearElement("request");
			Core requestor=new Core(null,"requestor",requestor$); 
			event.putElementItem("request", requestor);
			if(consumer$!=null) {
			Core consumer=new Core(null,"consumer",consumer$); 
			event.putElementItem("request", consumer);
			}
			//Core enti=new Core(null,"entigrator",entigrator.getInstance());
			//event.putElementItem("request", enti);
			Core message=new Core(null,"message",message$);
			event.putElementItem("request", message);
			entigrator.putEntity(event);
			
		}catch(Exception e) {
			System.out.println("EventHandler:putRequest:"+e.toString());
		}
	}
	public static String getLocator(Entigrator entigrator) {
		try {
			Sack event=getEvent(entigrator);
			Properties props=new Properties();
			String consumer$=event.getElementItemAt("request", CONSUMER);
			if(consumer$!=null)
				props.put(CONSUMER, consumer$);
			String requestor$=event.getElementItemAt("request", REQUESTOR);
			if(requestor$!=null)
				props.put(REQUESTOR, requestor$);
			String entigrator$=event.getElementItemAt("request",ENTIGRATOR);
			if(entigrator$!=null)
				props.put(ENTIGRATOR, entigrator$);
			String message$=event.getElementItemAt("request",MESSAGE);
			if(message$!=null)
				props.put(MESSAGE, message$);
			String locator$=Locator.toString(props);
			//System.out.println("EventHandler:getLocator:locator="+locator$);
			return locator$;
		}catch(Exception e) {
			System.out.println("EventHandler:getLocator:"+e.toString());
		}
		return null;
	}
	
}
