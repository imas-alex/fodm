package gdt.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.EntityToolset;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;
import java.util.Properties;

public class ModuleHandler extends FacetHandler{
	public ModuleHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}
	public static final String MODULE_HANDLER_NAME="Module";
	public static final String MODULE_HANDLER_TYPE="module";
	public static final String MODULE_HANDLER_CLASS="gdt.base.facet.ModuleHandler";
	public static final String KEY="_cwP5HjsG5BZl9YLn7QSln4hTtug";
	public static final String SYSTEM="system";
	public static final String FACET_MODULE="module";
	
	@Override
	public String getKey() {
		return KEY;
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,MODULE_HANDLER_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,MODULE_HANDLER_CLASS);
		locator.put(FACET_TYPE,MODULE_HANDLER_TYPE);
		locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
		locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.ModuleMaster");
		return Locator.toString(locator);
	}
	@Override
	public String getName() {
		return MODULE_HANDLER_NAME;
	}
	@Override
	public String getType() {
			return MODULE_HANDLER_TYPE;
	}
	@Override
	public String getFacetClass() {
		return MODULE_HANDLER_CLASS;
	}
@Override
public Sack apply(Entigrator entigrator, Sack entity) {
	return add( entigrator,  entity); 
}
public static Sack add(Entigrator entigrator, Sack entity) {
	//System.out.println("FolderHandler:add:locator="+locator$);    
	try { 
        entity=FolderHandler.add(entigrator, entity);
        entity=entigrator.assignProperty(MODULE_HANDLER_TYPE,Locator.LOCATOR_TRUE,entity.getKey());
        String facetLocator$=classLocator();
        facetLocator$=Locator.append(facetLocator$, Entigrator.ENTITY_LABEL, entity.getProperty(Entigrator.LABEL));
        entity.putElementItem(FACET, new Core(ModuleHandler.SYSTEM,KEY,facetLocator$));
        entigrator.putEntity(entity);
        }catch(Exception e) {
        	System.out.println("ModuleHandler:add:"+e.toString()); 
        }
	    return entity;
	}
@Override	
public  Sack remove(Entigrator entigrator, Sack entity) {
	return delete( entigrator, entity);
}
public  static Sack delete(Entigrator entigrator, Sack entity) {
	 try { 	 
		    String entityType$=entity.getProperty("entity");
		    if(MODULE_HANDLER_TYPE.equals(entityType$))
		    	return entity;
			entity=FolderHandler.delete(entigrator, entity);
			entity=entigrator.takeOffProperty(MODULE_HANDLER_TYPE, entity.getKey());
			entity.removeElementItem(FACET, KEY);
			entity.removeElement("customer");
			entity.removeElement("handler");
			entigrator.putEntity(entity);
     }catch(Exception e) {
     	System.out.println("ModuleHandler:remove:"+e.toString());
     }
	 return entity;
	}
public String clearFolder(Entigrator entigrator,String locator$) {
	 try { 	
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);	
		if(entity$==null) {
				//System.out.println("ModuleHandler:clearFolder:entity label is null");
				locator$=Locator.append(locator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_FALSE); 
 			return locator$;
		}
	String path$=entigrator.getEntihome()+"/"+entigrator.getKey(entity$);
    File folder=new File(path$);
    if(folder.exists()) 
       EntityToolset.deleteDirectory(folder);
    locator$=Locator.append(locator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_TRUE); 
	return locator$;
	 }catch(Exception e) {
	     	System.out.println("ModuleHandlerHandler:clearFolder:"+e.toString());
	     	 locator$=Locator.append(locator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_FALSE); 
				return locator$;
	     }
}

}
