package gdt.base.facet;

import java.util.Properties;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;

public class PanoramaHandler extends FacetHandler{
	public static final String KEY="_kXlD9sxhSYq_SnurpJSx3Q3caTsw";	
	public static final String PANORAMA_FACET_NAME="Panorama";
	public static final String PANORAMA_FACET_TYPE="panorama";
	public static final String PANORAMA_FACET_CLASS="gdt.base.facet.PanoramaHandler";
	public PanoramaHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,PANORAMA_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,PANORAMA_FACET_CLASS);
		locator.put(FACET_TYPE,PANORAMA_FACET_TYPE);
		locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
		locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.PanoramaMaster");
		return Locator.toString(locator);
	}
	@Override
	public String getName() {
		return PANORAMA_FACET_NAME;
	}

	@Override
	public String getType() {
		return PANORAMA_FACET_TYPE;
	}
	@Override
	public String getFacetClass() {
		return PANORAMA_FACET_CLASS;
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		// TODO Auto-generated method stub
		return null;
	}
}
