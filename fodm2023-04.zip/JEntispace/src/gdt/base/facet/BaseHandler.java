package gdt.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.util.ArrayList;
import java.util.Properties;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.IndexHandler;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;

public class BaseHandler extends FacetHandler{
	public static final String BASE_FACET_TYPE="base";
	public static final String BASE_FACET_NAME="Base";
	public static final String BASE_FACET_CLASS="gdt.base.facet.BaseHandler";
	public final static String KEY="_35teh7wtNSKoQU7vr29xTRHVGys";
	public BaseHandler(Entigrator entigrator, String locator$) {
		super(entigrator, locator$);

	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY, KEY);
		locator.put(FACET_HANDLER_CLASS, BASE_FACET_CLASS);
		locator.put(FACET_NAME, BASE_FACET_NAME);
		locator.put(FACET_TYPE,BASE_FACET_TYPE );
		locator.put(FACET_CONTAINER_TYPE,FACET_CONTAINER_INTERNAL);
		locator.put(FACET_ADDABLE, Locator.LOCATOR_FALSE);
		locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.BaseMaster");
		return Locator.toString(locator);
	}

	@Override
	public String getName() {
		return BASE_FACET_NAME;
	}

	@Override
	public String getType() {
		return BASE_FACET_TYPE;
	}

	@Override
	public String getFacetClass() {
		return BASE_FACET_CLASS;
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return entity;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return entity;
	}
	public static String[] allLinks(Entigrator entigrator,String entityKey$) {
		ArrayList<String> ll=new ArrayList<String>();
		collectLinks( entigrator,entityKey$ ,ll);
		String[] la=new String[ll.size()];
		ll.toArray(la);
		return la;
	}
	private  static void collectLinks(Entigrator entigrator,String entityKey$ ,ArrayList<String> ll) {
		ll.add(entityKey$);
		Sack entity=entigrator.getEntity(entityKey$);
		if(entity==null)
			return;
		String[]la =entity.elementListNames("link");
		if(la==null)
			return;
		for(String l:la)
			collectLinks( entigrator,l ,ll); 
	}
	public static Entigrator createBlankDatabase(String entihome$){
		try{
		//	 System.out.println("BaseHandler:createBlankDatabase.entihome="+entihome$);
			File entihome=new File(entihome$);
			if(!entihome.exists()){
				entihome.mkdir();
			}
			Entigrator newEntigrator=new Entigrator(entihome$,true);
			newEntigrator.makeNewIndex(entihome$);
			return  newEntigrator;
		}catch(Exception e){
			 System.out.println("BaseHandler:createBlankDatabase:"+e.toString());
		}
		return null;
	}
	public static String[] listDatabases(File selection){
		ArrayList<String>bl=new ArrayList<String>();
		File[] fa=selection.listFiles();
	    if(fa!=null) {
		for(File f:fa) {
			File[] files = f.listFiles();
			if(files!=null) {
				for(File ff:files ) 
				   if(IndexHandler.PROPERTY_INDEX.equals(ff.getName())) {	
				      bl.add(f.getPath());
				      break;
					}
				}
			}
		}
	String[] ba=new String[bl.size()];
	bl.toArray(ba);
	return ba;
	}
	public static Entigrator setDefaultBase() {
		Entigrator defaultEntigrator=null;
		File defaultHome=new File(System.getProperty("user.home")+"/.entigrator/default");
		if(!defaultHome.exists()) { 
			defaultEntigrator=BaseHandler.createBlankDatabase(System.getProperty("user.home")+"/.entigrator/default");
		    defaultEntigrator=new Entigrator(defaultHome.getPath());
		    defaultEntigrator.rebuildIndex();
		    //System.exit(0);
		}else
			defaultEntigrator=new Entigrator(defaultHome.getPath());
		return defaultEntigrator;
	}
}
