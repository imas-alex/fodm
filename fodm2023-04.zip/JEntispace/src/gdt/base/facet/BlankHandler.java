package gdt.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Properties;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;

public class BlankHandler extends FacetHandler {
	public static final String BLANK_FACET_TYPE="blank";
	public static final String BLANK_FACET_NAME="Blank";
	public static final String BLANK_FACET_CLASS="gdt.base.facet.BlankHandler";
	public BlankHandler(Entigrator entigrator, String locator$) {
		super(entigrator, locator$);
	}
	public final static String KEY="_umTtTS25W6Xq_SW3GizYuhmnhtiw";	
	
public static String classLocator() {
	Properties locator=new Properties();
	locator.put(FACET_KEY, KEY);
	locator.put(FACET_HANDLER_CLASS, BLANK_FACET_CLASS);
	locator.put(FACET_NAME, BLANK_FACET_NAME);
	locator.put(FACET_TYPE,BLANK_FACET_TYPE );
	locator.put(FACET_CONTAINER_TYPE,FACET_CONTAINER_INTERNAL);
	locator.put(FACET_ADDABLE, Locator.LOCATOR_FALSE);
	locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.BlankMaster");
	return Locator.toString(locator);
}
@Override
public String getKey() {
	return KEY;
}
public static BlankHandler  build(Entigrator entigrator) {
	return new BlankHandler(entigrator,BlankHandler.classLocator());
}

@Override
public boolean isAdded(Entigrator entigrator,String locator$ ) {
	try {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		Sack entity=entigrator.getEntityAtLabel(entity$);
		if(entity==null) {
			System.out.println("BlankHandler:isAdded:cannot get entity="+entity$);
			return false;
			}
		if(entity.getProperty("entity")==null||BLANK_FACET_TYPE.equals(entity.getProperty("entity")))
			return true;
	    return false;
	}catch(Exception e) {
		System.out.println(" BlankHandler:isAdded:"+e.toString());
	}
	return false;
}

@Override
public String getName() {
	return BLANK_FACET_NAME;
}
@Override
public String getType() {
		return BLANK_FACET_TYPE;
}
@Override
public String getFacetClass() {
	return BLANK_FACET_CLASS;
}
@Override
public Sack apply(Entigrator entigrator, Sack entity) {
	return entity;
}
@Override
public Sack remove(Entigrator entigrator, Sack entity) {
	return entity;
}
}
