package gdt.gui.facet.panorama;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JSetEditor;

public class JPanoramaEditor extends JSetEditor{
	public static final String PANORAMA="panorama";
	JMenuItem deleteItem;
	JMenuItem pasteItem;

	
	public JPanoramaEditor(JMainConsole console, String alocator$) {
		super(console, alocator$);
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		JSetItem[] ipa=getItems(console,alocator$);
		if(ipa!=null)
			for(JSetItem ip:ipa) {
				addItem(ip);
			}
	}
	private static final long serialVersionUID = 1L;

	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.facet.panorama.JPanoramaEditor");
	    locator.put(Locator.LOCATOR_TITLE,"Panorama editor");
		locator.put(IconLoader.ICON_FILE,"panorama.png");
	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(DEFAULT_PARENT, JAdminPanel.KEY);
		 return Locator.toString(locator);
	   }

	@Override
	public String reply(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public String getClassLocator() {
				return classLocator();
	}
	
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
JMenuItem saveItem = new JMenuItem("Save");
		saveItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JPanoramaElement[] ca=getElements();
				    if(ca!=null)
					for(JPanoramaElement c:ca)
						c.save();
				}
			} );
		   menu.add(saveItem); 
		JMenuItem restoreItem = new JMenuItem("Restore");
		restoreItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JPanoramaElement[] ca=getElements();
			    if(ca!=null)
				for(JPanoramaElement c:ca)
					c.restore();
							}
		} );
		menu.add(restoreItem);
		JMenuItem disposeItem = new JMenuItem("Dispose");
		disposeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			    JPanoramaElement[] ca=getElements();
			    if(ca!=null)
				for(JPanoramaElement c:ca)
					c.dispose();
			}
		} );
		menu.add(disposeItem);
	
		return menu;
		}
	private JPanoramaElement[] getElements() {
		try {
			Sack panorama=console.getEntigrator().getEntityAtLabel(entity$);
			String[] sa=panorama.elementListNames("set");
			if(sa==null||sa.length<1)
				return null;
			JContextContainer[] containers=console.getContainers();
			if(containers==null||containers.length<1)
				return null;
			String item$;
			ArrayList<JContextContainer>cl=new ArrayList<JContextContainer>();
			for(JContextContainer c:containers) {
				item$=c.getItem();
				if(item$==null)
					continue;
				for(String s:sa)
					if(s.equals(item$))
				       cl.add(c);
				}
			JPanoramaElement[] ca=new JPanoramaElement[cl.size()];
			cl.toArray(ca);
			return ca;
			}catch(Exception ee) {
				System.out.println("JPanoramaEditor:getContainers:"+ee.toString());
				return null;
			}
	}
	@Override
	protected void showSet() {
		try {
			Core[] ca=set.elementGet("set");
			if(ca==null||ca.length<1)
				return;
			JPanoramaElement display;
		    String element$;
		    String context$;
			String displayLocator$=JDisplay.classLocator();
			displayLocator$=Locator.append(displayLocator$, PANORAMA, entity$);
			for(Core c:ca) {
			element$=Locator.getProperty(c.value, Entigrator.ENTITY_LABEL);
			context$=Locator.getProperty(c.value, JContext.CONTEXT_CLASS);
			displayLocator$=Locator.append(displayLocator$, Entigrator.ENTITY_LABEL, element$);
			displayLocator$=Locator.append(displayLocator$, JContext.CONTEXT_CLASS, context$);
			displayLocator$=Locator.append(displayLocator$, JSetEditor.SET_ITEM, c.name);
			display=new JPanoramaElement(console,displayLocator$);
	        console.putContainer(display); 
		//	System.out.println("JContext:display:context container="+newContext.getContainerKey());
			display.revalidate();
			display.repaint();
			}
				}catch(Exception e) {
					System.out.println("JPanoramaEditor:showPanorama:"+e.toString());
				}
	}
	@Override
	protected void paste() {
		pasteToSet();
	}

	@Override
	protected void toFront() {
		JPanoramaElement[] ca=getElements();
	    if(ca!=null)
		for(JPanoramaElement c:ca)
			c.toFront();
	}

	@Override
	protected void dispose() {
		// TODO Auto-generated method stub
	}
	@Override
	protected void deleteItem(String item$) {
		// TODO Auto-generated method stub
	}
}

