package gdt.gui.facet.rack;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.border.BevelBorder;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JDisplayList;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JItemPanel;

public class JRackDisplay extends JDialog implements JContextContainer{
private static final long serialVersionUID = 1L;
public static final String DISPLAY_KEY="display key";    
 public static final String DISPLAY_WIDTH="display width";  
 public static final String DISPLAY_HEIGHT="display height";
 public static final String DISPLAY_WPOS="display wpos"; 
 public static final String DISPLAY_HPOS="display hpos"; 
 public static final String DISPLAY_LOCATOR="display locator"; 
 public static final String CONTEXT_INSTANCE="context instance"; 
 public static final String RACK_DISPLAY_CLASS="rack display class";	
    JMainConsole console;
    JMenu menu;
    String locator$;
    String container$;
    JLabel subtitle;
    JRackFrame rackFrame;
    String entity$;
    BorderLayout borderLayout=new BorderLayout(0, 0);
    JMenuBar menuBar = new JMenuBar();
    public JRackDisplay() {
    	super();
    	
    	setTitle("Title");
    	setJMenuBar(menuBar);
    	menu=new JMenu("Context");
    	menuBar.add(menu);
    	getContentPane().setLayout(borderLayout);
    	subtitle = new JLabel();
    	subtitle.setText("Subtitle");
    	subtitle.setPreferredSize(new Dimension(30,20));
    	subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
    	subtitle.setOpaque(true);
    	subtitle.setBackground(Color.BLACK);
    	subtitle.setForeground(Color.WHITE);
    	getContentPane().add(subtitle);
    	console.putContainer(this);
    	}
    
    
     public JRackDisplay(JMainConsole console,String alocator$) {
     	super();
     	setVisible(false);
       	this.console=console;
       	locator$=alocator$;
    	entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
       //	System.out.println("JRackDisplay:locator="+locator$);
       	setTitle("Rack console");
     	subtitle = new JLabel();
     	subtitle.setPreferredSize(new Dimension(30,20));
     	subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
     	subtitle.setOpaque(true);
     	subtitle.setBackground(Color.BLACK);
     	subtitle.setForeground(Color.WHITE);
     	subtitle.setText(entity$);
     	getContentPane().add(subtitle,BorderLayout.SOUTH);
     	container$=Locator.getProperty(locator$,JContextContainer.CONTAINER);
     	 if(container$==null) { 
         	container$=Identity.key();
         	locator$=Locator.append(locator$,JContextContainer.CONTAINER, container$);
         }
     	 String rackFrame$=JRackFrame.classLocator();
     	 rackFrame$=Locator.append(rackFrame$, Entigrator.ENTITY_LABEL, entity$);
     	rackFrame=new JRackFrame(console,rackFrame$);
     	rackFrame.rackDisplay=this;
     	setJMenuBar(menuBar);
     	menu=rackFrame.getContextMenu();
     	menu.addSeparator();
        JMenuItem deleteItem = new JMenuItem("Dispose");
    		deleteItem.addActionListener(new ActionListener() {
    			@Override
    			public void actionPerformed(ActionEvent arg0) {
    				int response = JOptionPane.showConfirmDialog( JRackDisplay.this, "Finally delete display ?", "Confirm",JOptionPane.YES_NO_CANCEL_OPTION);
    			   if (response == JOptionPane.YES_OPTION) { 
    				  rackFrame.dispose();
    				  console.removeContainer(JRackDisplay.this.container$); 
    				  dispose();
    			   }
    			   
    			}
    				});
    		menu.add(deleteItem);	
     	menuBar.add(menu);
     	
     	getContentPane().add(rackFrame,BorderLayout.CENTER);
     	setSize(console.getMainFrame().getSize());
   		setLocationRelativeTo(console.getMainFrame());
 		setVisible(true);
 		addComponentListener(new ComponentAdapter() {
 		    public void componentMoved(ComponentEvent e) {
 		    	save();
 		    }
 		});
 		locate();
 		setVisible(true);
 		console.putContainer(this);
     }
     public static String classLocator() {
    	 Properties locator=new Properties();
 	    locator.put(RACK_DISPLAY_CLASS,"gdt.gui.facet.rack.JRackDisplay");
 	    locator.put(Locator.LOCATOR_TITLE,"Rack display");
 		locator.put(IconLoader.ICON_FILE,"rack.png");
 	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
 		return Locator.toString(locator); 
     }
     private void locate() {
    	 try {
    		 String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
    	 		if(entity$==null) {
    	 			System.out.println("JRackDisplay:locate:no entity label in locator"+locator$);
    	 			return ;
    	 		}
    	 	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
    	 	if(entity==null) {
    	 		System.out.println("JRackDisplay:locate:cannot get entity="+ entity$);
    	 		return ;
    	 	} 
    	 	Core location=entity.getElementItem("rack.desktop", "location");
    	 	Core size=entity.getElementItem("rack.desktop", "size");
    	 	int x=Integer.parseInt(location.type);
    	 	int y=Integer.parseInt(location.value);
    	 	int w=Integer.parseInt(size.type);
    	 	int h=Integer.parseInt(size.value);
    	 	Point point=new Point(x,y);
    	 	Dimension dim=new Dimension(w,h);
    	 	setLocation(point);
    	 	setSize(dim);
    	 }catch(Exception e) {
  			System.out.println("JRackDisplay:locate:"+e.toString());	
  		}
     }
     private void save() {
 		try {
 			Point location=getLocation();
 			Dimension size=getSize();
 			//System.out.println("JRackDisplay:save x="+location.x+" y="+location.y+" w="+size.width+" h="+size.height);
 		    String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
 		if(entity$==null) {
 			System.out.println("JRackDisplay:save:no entity label in locator"+locator$);
 			return ;
 		}
 	Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
 	if(entity==null) {
 		System.out.println("JRackDisplay:save:cannot get entity="+ entity$);
 		return ;
 	}
 		if(!entity.existsElement("rack.desktop"))
 			entity.createElement("rack.desktop");
 		entity.putElementItem("rack.desktop", new Core(String.valueOf(location.x),"location",String.valueOf(location.y)));
 		entity.putElementItem("rack.desktop", new Core(String.valueOf(size.width),"size",String.valueOf(size.height)));
 		
 		console.getEntigrator().putEntity(entity);
 		}catch(Exception e) {
 			System.out.println("JRackDisplay:save:"+e.toString());	
 		}
 	}
    
   public void setSubtitle(String subtitle$) {
	    subtitle.setText(subtitle$);
  }
  public String getLocator() {
	  String displayLocator$=classLocator();
	  Properties locator=Locator.toProperties(displayLocator$);
	  Dimension dim=getSize();
	  locator.put(DISPLAY_WIDTH,  String.valueOf(dim.width));
	  locator.put(DISPLAY_HEIGHT, String.valueOf(dim.height));
	  Point p=getLocation();
	  locator.put(DISPLAY_WPOS, String.valueOf(p.x));
	  locator.put(DISPLAY_HPOS, String.valueOf(p.y));
	  if(entity$!=null) 
		  locator.put(Entigrator.ENTITY_LABEL, entity$);
	  displayLocator$=Locator.toString(locator);
	  return displayLocator$;
  }
  
  public JMenu getDisplayMenu() {
	  return menu;
  }
@Override
public void putContext(JContext context) {
}
@Override
public JContext getContext() {
	// TODO Auto-generated method stub
	return null;
}
@Override
public JItemPanel getItemPanel() {
		   String itemLocator$=JItemPanel.classLocator();
		   itemLocator$=Locator.append(itemLocator$, Locator.LOCATOR_TITLE, entity$);
		   JRackItem ip=new JRackItem(console,itemLocator$);
		   return ip;
}
@Override
public String getItem() {
	return null;
}
private class JRackItem extends JItemPanel {
	private static final long serialVersionUID = 1L;
	public JRackItem(JMainConsole console,JContext context, String locator$) {
		super(console,context, locator$);
		ImageIcon icon=IconLoader.getGenericIcon("rack.png");
		setIcon(icon);
	}
	public JRackItem(JMainConsole console, String locator$) {
		super(console,getContext(), locator$);
		ImageIcon icon=IconLoader.getGenericIcon("rack.png");
		setIcon(icon);
	}
	
	@Override
	public JPopupMenu getPopup(JMainConsole console, String locator$) {
		JPopupMenu popup=new JPopupMenu();
		JMenuItem disposeItem=new JMenuItem("Dispose");
		popup.setVisible(true);
		disposeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				popup.setVisible(false);
				JRackDisplay.this.dispose();
				console.removeContainer(JRackDisplay.this);
				String displayListLocator$=JDisplayList.classLocator();
				JDisplayList displayList=new JDisplayList(console,displayListLocator$);
			    console.replaceContext(null, displayList);
			}
		} );
		popup.add(disposeItem);
		return popup;
	}
	@Override
	public void onClick(JMainConsole console, String locator$) {
		JRackDisplay.this.toFront();
	}
}
 }
