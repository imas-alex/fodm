package gdt.gui.facet;

import java.util.Properties;
import javax.swing.JPopupMenu;
import gdt.base.facet.CollageHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.facet.RackHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.collage.JCollageEditor;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JItemPanel;

public class CollageMaster extends  FacetMaster{
	public static final String KEY="_YLWUGHHt_6uLuwZDIWSE_S4pb__Y";
	public static final String NAME="Collage";
	public static final String FACET_HANDLER_KEY="_V3la4lHnj_SbNbh5sLOLzxYKeRu4";	
	String entity$;
	String parent$;
	public CollageMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
		entity$=Locator.getProperty(alocator$,Entigrator.ENTITY_LABEL);
		parent$=Locator.getProperty(alocator$,JContext.PARENT);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	     locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
	     locator.put(MASTER_CLASS,"gdt.gui.facet.CollageMaster");
	     locator.put(FacetHandler.FACET_HANDLER_CLASS,CollageHandler.COLLAGE_FACET_CLASS);
	     locator.put(Locator.LOCATOR_TITLE,"Collage");
	     locator.put(MASTER_KEY,KEY);
	     locator.put(JContext.PARENT,ALL_FACETS_KEY);
	     locator.put( IconLoader.ICON_FILE, "collage.png");
	     locator.put( IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	     locator.put(FacetHandler.FACET_TYPE,RackHandler.RACK_FACET_TYPE);
	     return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "collage.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Collages");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		String entityLabel$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		  if(entityLabel$!=null)
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL,entityLabel$);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "collage.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Collage");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL,Locator.getProperty(locator$,Entigrator.ENTITY_LABEL));
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}

	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
	}

	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String rackHandler$=RackHandler.classLocator();
			rackHandler$=Locator.append(rackHandler$, Entigrator.ENTITY_LABEL, entity$);
			RackHandler rackHandler =new RackHandler(console.getEntigrator(),rackHandler$);
			return rackHandler;
		}catch(Exception e) {
			System.out.println("CollageMaster:getFacetHandler:"+e.toString());
		}
		return null;
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public String getName() {
		return "Collage";
	}
	@Override
	public String getType() {
		return "collage";
	}

	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		String collageEditor$=JCollageEditor.classLocator();
		collageEditor$=Locator.merge(collageEditor$,locator$);
		collageEditor$=Locator.append(collageEditor$, Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
		  collageEditor$=Locator.append(collageEditor$,JContext.PARENT,parent$);
		JCollageEditor collageEditor=new JCollageEditor(console,collageEditor$);
		String container$=Locator.getProperty(locator$,JContextContainer.CONTAINER);
		JContextContainer container=null;
		if(container$!=null)
			container=console.getContextContainer(container$);
		if(container==null)
			console.replaceContext(CollageMaster.this.context, collageEditor);
		else
		  container.putContext(collageEditor);	
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getLocator() {
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String thisLocator$=classLocator();
		if(entity$!=null)
		   thisLocator$=Locator.append(thisLocator$,Entigrator.ENTITY_LABEL, entity$);
		return thisLocator$;
		}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		 Sack session=getSession(console,locator$);
	     Core masterEntry=new Core(ModuleHandler.SYSTEM,KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core(ModuleHandler.SYSTEM,RackHandler.KEY,RackHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("RackMaster:addToSession:"+e.toString());
	    }
	}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity.putElementItem("facet", new Core(ModuleHandler.SYSTEM,getType(),classLocator()));
		//entity=FolderHandler.add(entigrator, entity);
		entigrator.assignProperty(entityKey$, "collage", Locator.LOCATOR_TRUE);
		entity.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","collage.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		//createSource(entityLabel$);
		return entity;
	}
}
