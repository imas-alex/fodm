package gdt.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Properties;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import gdt.base.facet.ModuleHandler;
import gdt.base.facet.ProjectHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JAddFacetsList;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;

public class ProjectMaster extends  FacetMaster {
	public static final String KEY="_RLQ1WnxQdSTCxZU_Q71aKueFpSw";
	public static final String NAME="Project";
	public static final String FACET_HANDLER_KEY="_UhYQQb945G1bf0c9DimVfO_SQKZA";	
	String entity$;
	public ProjectMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
		//System.out.println("ProjectMaster:alocator="+alocator$);
		entity$=Locator.getProperty(alocator$,Entigrator.ENTITY_LABEL);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	     locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
	     locator.put(MASTER_CLASS,"gdt.gui.facet.ProjectMaster");
	     locator.put(FacetHandler.FACET_HANDLER_CLASS,ProjectHandler.PROJECT_FACET_CLASS);
	     locator.put(Locator.LOCATOR_TITLE,"Project");
	     locator.put(MASTER_KEY,KEY);
	     locator.put(JContext.PARENT,ALL_FACETS_KEY);
	     locator.put( IconLoader.ICON_FILE, "project.png");
	     locator.put( IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	     locator.put(FacetHandler.FACET_TYPE,ProjectHandler.PROJECT_FACET_TYPE);
	     return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
	//	System.out.println("ProjectMaster:getJAllFacetsItem:locator="+handlerLocator$);
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "project.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Projects");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		String entityLabel$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		  if(entityLabel$!=null)
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL,entityLabel$);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String parent$=Locator.getProperty(locator$, JContext.PARENT);
		String itemLocator$=JItemPanel.classLocator();
		if(entity$!=null)
		  itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
			  itemLocator$=Locator.append(itemLocator$,JContext.PARENT, parent$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "project");
		itemLocator$=Locator.append(itemLocator$,IconLoader.ICON_FILE,"project.png");
		itemLocator$=Locator.append(itemLocator$,MASTER_CLASS,"gdt.gui.facet.ProjectMaster");
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_HANDLER_CLASS,ProjectHandler.PROJECT_FACET_CLASS);
		JEntityAddFacetItem itemPanel=new JEntityAddFacetItem(console,context,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
//		System.out.println("FolderMaster:getJAllFacetsItem:locator="+handlerLocator$);
			String itemLocator$=JItemPanel.classLocator();
			itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "export.png");
			itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Export");
			itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
			itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL,Locator.getProperty(locator$,Entigrator.ENTITY_LABEL));
			JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,context,itemLocator$);
			return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String projectHandler$=ProjectHandler.classLocator();
			projectHandler$=Locator.append(projectHandler$, Entigrator.ENTITY_LABEL, entity$);
			//System.out.println("ProjectMaster:getFacetHandler:locator="+folderHandler$);
			ProjectHandler projectHandler =new ProjectHandler(console.getEntigrator(),projectHandler$);
			return projectHandler;
		}catch(Exception e) {
			System.out.println("ProjectMaster:getFacetHandler:"+e.toString());
		}
		return null;
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return "Project";
	}
	
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String locator$) {
	//	System.out.println("ProjectMaste:export:entity="+ entity$+"    locator="+locator$);
		JFileChooser chooser = new JFileChooser(); 
	    chooser.setCurrentDirectory(new java.io.File(System.getProperty("user.home")));
	    chooser.setDialogTitle("Bases directory");
	    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    if (chooser.showOpenDialog(console.getMainFrame()) == JFileChooser.APPROVE_OPTION) { 
	    	File selection=chooser.getSelectedFile();
	    	String directory$=selection.getPath();
	    	ProjectHandler.export(directory$, console.getEntigrator(), entity$);
//	    	System.out.println("ProjectMaster:export:directory="+selection.getPath());  
	      }
	}

	@Override
	public void addFacetItemOnClick(JMainConsole console, String alocator$) {
		//System.out.println("ProcedurMaster:addFacetItemOnClick:locator="+alocator$);
		String entityLabel$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
		Sack entity=console.getEntigrator().getEntityAtLabel(entityLabel$);
		entity=ProjectHandler.add(console.getEntigrator(), entity);
		String addFacetsList$=JAddFacetsList.classLocator();
		addFacetsList$=Locator.append(addFacetsList$,Entigrator.ENTITY_LABEL , entityLabel$);
		JAddFacetsList addFacetsList=new JAddFacetsList(console,addFacetsList$); 
		console.saveContext();
		console.replaceContext(context,addFacetsList);
	}

	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		//final String itemLocator$=alocator$;
		JPopupMenu popup=new JPopupMenu();
		JMenuItem newItem=new JMenuItem("New project");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("ProjectMaster:entityFacetsItemPopup:new entity:locator="+itemLocator$);
				popup.setVisible(false);
				String textEditor$=JTextEditor.classLocator();
				textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New project");
				String facetList$=JEntityFacetList.classLocator();
				facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
				facetList$=Locator.append(facetList$,MASTER_CLASS,"gdt.gui.facet.ProjectMaster");
				facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
				//SessionHandler.putLocator(console.getEntigrator(),facetList$);
				textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
				JTextEditor textEditor=new JTextEditor(console,textEditor$);
				console.replaceContext(ProjectMaster.this.context, textEditor);
			}
		} );
		popup.add(newItem);
		return popup;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String alocator$) {
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			final String entityKey$=console.getEntigrator().getKey(entity$);
			alocator$=Locator.append(alocator$, Entigrator.ENTITY_LABEL, entity$);
			JPopupMenu popup=new JPopupMenu();
			JMenuItem removeItem=new JMenuItem("Remove from database");
			removeItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				//	System.out.println("ProcedureMaster:entityFacetsItemPopup:remove:locator="+removeLocator$);
					popup.setVisible(false);
					int response = JOptionPane.showConfirmDialog(console.getMainFrame(), "Remove project completely ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		  		    if (response == JOptionPane.YES_OPTION) {
					console.getEntigrator().deleteEntityRecursively(entityKey$);
					JAdminPanel adminPanel=new JAdminPanel(console,null);
					//console.replaceContext(adminPanel);
					console.replaceContext(ProjectMaster.this.context, adminPanel);
		  		    }
				}
			} );
			popup.add(removeItem);
			return popup;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
			return null;
	}
	@Override
	public String getLocator() {
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String thisLocator$=classLocator();
		if(entity$!=null)
		   thisLocator$=Locator.append(thisLocator$,Entigrator.ENTITY_LABEL, entity$);
		return thisLocator$;
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		 Sack session=getSession(console,locator$);
	     Core masterEntry=new Core(ModuleHandler.SYSTEM,KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core(ModuleHandler.SYSTEM,ProjectHandler.KEY,ProjectHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("ProjectMaster:addToSession:"+e.toString());
	    }
	}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
	@Override
	public String getType() {
		return "project";
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity.putElementItem("facet", new Core(ModuleHandler.SYSTEM,getType(),classLocator()));
		entity.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","project.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		return entity;
	}
}
