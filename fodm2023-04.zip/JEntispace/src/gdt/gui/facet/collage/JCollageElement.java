package gdt.gui.facet.collage;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.ImageIcon;
import javax.swing.JMenuBar;

import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JInternalDisplay;
import gdt.gui.generic.JSetElement;

public class JCollageElement extends JInternalDisplay implements JSetElement{
private static final long serialVersionUID = 1L;
JCollageFrame collageFrame;
Sack collage;

public JCollageElement(JMainConsole console,String locator$,JCollageFrame collageFrame) {
	 super(console,locator$);
	 this.collageFrame=collageFrame;
	 collage=collageFrame.collage;
	 String type$=collage.getProperty("entity");
	ImageIcon icon =FacetMaster.getIcon(console, type$);
		if(icon!=null)
			this.setFrameIcon(icon);
}
public JCollageFrame getCollageFrame() {
	if(collageFrame!=null)
		return collageFrame;
	if(getDesktop()!=null)
		return (JCollageFrame)getDesktop();
	return null;
}
public void setCollageFrame(JCollageFrame  collageFrame) {
	this.collageFrame=collageFrame;
}
public void setCollage(Sack  collage) {
	this.collage=collage;
}
@Override
public void putContext(JContext context ) {
    //	System.out.println("JInternalDisplay:putContext:container="+container$);
 	if(context==null)
    		return;
 	this.context=context;
 	context$=context.getInstance();
     getContentPane().removeAll();
    	    getContentPane().add(context,BorderLayout.CENTER);	
    		subtitle.setText(context.getSubtitle());
     	getContentPane().add(subtitle,BorderLayout.SOUTH);	
     	menu=getElementMenu(context);
 		JMenuBar menuBar = new JMenuBar();
     	setJMenuBar(menuBar);
 		menuBar.add(menu);
 		//arrangeItem.setEnabled(false);
 		
 		setTitle(context.getTitle());
 		setSubtitle(context.getSubtitle());
 		//String locator$=context.getLocator();
     	pack();		
 		invalidate();
 		validate();
 		repaint();
   }
@Override
public void save() {
	try {
	JContext context=getContext();
	//System.out.println("JCollageElement:onContextChange:context="+context.getClass().getName());
	Sack collage=collageFrame.getEntity();
	Core c=collage.getElementItem("set", getItem());
	String contextClass$=Locator.getProperty(context.getLocator(),JContext.CONTEXT_CLASS);
	c.value=Locator.append(c.value, JContext.CONTEXT_CLASS, contextClass$);
	collage.putElementItem("set", c);
	Dimension size=getSize();
	Point location=this.getLocation();
	if(!collage.existsElement("collage.size"))
		collage.createElement("collage.size");
	if(!collage.existsElement("collage.location"))
		collage.createElement("collage.location");
	collage.putElementItem("collage.size", new Core(String.valueOf(size.width),getItem(),String.valueOf(size.height)));
	collage.putElementItem("collage.location", new Core(String.valueOf(location.x),getItem(),String.valueOf(location.y)));
	console.getEntigrator().putEntity(collage);
	}catch(Exception e) {
		System.out.println("JCollageElement:save:"+e.toString());
	}	
}	

public void setLocation(Sack collage) {
	Point point=new Point(0,0);
	Dimension size=new Dimension(300,200);
	try {
		Core sc=collage.getElementItem("collage.size", getItem());
		int w=Integer.parseInt(sc.type);
		int h=Integer.parseInt(sc.value);
		size=new Dimension(w,h);
		Core lc=collage.getElementItem("collage.location", getItem());
		int x=Integer.parseInt(lc.type);
		int y=Integer.parseInt(lc.value);
		point=new Point(x,y);
	}catch(Exception e) {
		System.out.println("JCollageElement:setLocation:"+e.toString());
	}
	setSize(size);
	setLocation(point);
}
@Override
public void restore() {
	try {
	JContext context= getItemContext(console,collage,getItem());
	putContext(context);
	setLocation(collage);
	}catch(Exception e) {
		System.out.println("JCollageElement:restore:"+e.toString());
	}
}
}
