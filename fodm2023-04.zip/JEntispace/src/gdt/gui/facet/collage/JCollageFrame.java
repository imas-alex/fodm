package gdt.gui.facet.collage;
import java.awt.Dimension;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JInternalDisplay;

public class JCollageFrame extends JDesktopPane {
	private static final long serialVersionUID = 1L;
	public static final String COLLAGE_FRAME_CLASS="collage frame class";	
String entity$;
JMainConsole console;
String locator$;

Sack collage;
public JCollageDisplay collageDisplay;
Hashtable<String, JCollageElement> items=new Hashtable<String, JCollageElement>(); 
public   JCollageFrame(JMainConsole console,String alocator$) {
		super();
		this.console=console;
	    locator$=alocator$;
		entity$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
//		System.out.println("JRackFrame:entity="+entity$);
		collage=console.getEntigrator().getEntityAtLabel(entity$);
	    if(collage!=null) {
	    	try {
	    		Core size=collage.getElementItem("collage.desktop", "size");
	    		if(size!=null) {
	    			int w=Integer.parseInt(size.type);
	    			int h=Integer.parseInt(size.value);
	    			this.setSize(new Dimension(w,h));
	    		}
	    		Core location=collage.getElementItem("collage.desktop", "location");
	    		if(location!=null) {
	    			int x=Integer.parseInt(location.type);
	    			int y=Integer.parseInt(location.value);
	    			this.setLocation(new Point(x,y));
	    		}
	    	}catch(Exception e) {
	    	}
	    }
	    JCollageElement []ida= getItems();
		if(ida!=null) {
		//	System.out.println("JRackFrame:ida="+ida.length);
			Core location;
			Core size;
			String item$;
			int x=0;
			int y=0;
			for(JCollageElement id:ida) {
				add(id );  
			    id.setVisible(true);
			    item$=id.getItem();
			//    System.out.println("JRackFrame:item="+item$);
			    try {
			    location=collage.getElementItem("collage.location", item$);
			    try {x=Integer.parseInt(location.type);}catch(Exception ee) {
			    	x=x+10;	
			    }
			    try {y=Integer.parseInt(location.value);}catch(Exception ee) {
			    	y=y+10;	
			    }
			    size=collage.getElementItem("collage.size", item$);
			    int w=200;
			    try{w=Integer.parseInt(size.type);}catch(Exception ee) {}
			    int h=200;
			    try{h=Integer.parseInt(size.value);}catch(Exception ee) {}
			    id.setLocation(x, y);
			    id.setSize(w, h);
			    }catch(Exception ee) {
			    	System.out.println("JCollageFrame:item="+item$+":"+ee.toString());
			    }
			}
		}
	
	}
	
	public void dispose() {
		JInternalFrame[] rea=getAllFrames();
		if(rea==null)
			return;
		for(JInternalFrame re:rea) {
			console.removeContainer((JCollageElement)re);
			((JCollageElement)re).dispose();
		}
		console.removeContainer(collageDisplay);
		collageDisplay.dispose();
	}
	
	public JCollageElement [] getItems() {
		try {
			Sack collage=console.getEntigrator().getEntityAtLabel(entity$);
			Core [] pca=collage.elementGet("set");
			if(pca==null||pca.length<1)
				return null;
//			System.out.println("JCollageFrame:getItems:pca="+pca.length);
		    JContext context;
		    JCollageElement item;
		    String item$=JCollageElement.classLocator();
		    ArrayList<JCollageElement>idl=new ArrayList<JCollageElement>();
		    for(Core c:pca) {
		    	//System.out.println("JRackFrame:getInternalDisplays:c.name="+c.name);
		    	context=JContext.build(console, c.value);
		    	if(context!=null) {
		    		//System.out.println("JRackFrame:getInternalDisplays:0");
		    		item$=Locator.append(item$,JInternalDisplay.INTERNAL_DISPLAY_DESKTOP , entity$);
		    		item$=Locator.append(item$,JInternalDisplay.INTERNAL_DISPLAY_ITEM , c.name);
		    		item=new JCollageElement(console,item$,this);
		    		item.putContext(context);
		    		item.setLocation(collage);
		    		item.setCollageFrame(this);
		    		try {
			    		String entity$=context.getEntity();
			    		Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			    		String type$=entity.getProperty("entity");
			       	    ImageIcon icon =FacetMaster.getIcon(console, type$);
			       		if(icon!=null)
			       			item.setFrameIcon(icon);
			    		}catch(Exception ee) {}
		    		idl.add(item);
		    	}
		    	//System.out.println("JRackFrame:getInternalDisplays:NEXT");
		    }
		    if(idl.size()>0) {
		    	JCollageElement []ida=new JCollageElement[ idl.size()];
		    	 idl.toArray(ida);
		    	 return ida;
		    }
		}catch(Exception e) {
			System.out.println("JCollageFrame:getItems:"+e.toString());
		}
		return null;
	}
	
	public static String classLocator() {
		Properties locator=new Properties();
	    locator.put(COLLAGE_FRAME_CLASS,"gdt.gui.facet.collage.JCollageFrame");
	    locator.put(Locator.LOCATOR_TITLE,"Collage");
		locator.put(IconLoader.ICON_FILE,"collage.png");
	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		return Locator.toString(locator);
	}
	public String getLocator() {
		String  locator$ =classLocator();
		locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity$);
		return locator$;
	}
public Sack getEntity() {
	return collage;
}
}
