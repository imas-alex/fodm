package gdt.gui.facet.procedure;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import javax.swing.JEditorPane;

import gdt.gui.console.JMainConsole;
public interface Procedure {
public void  exec(JMainConsole console,String locator$, JEditorPane reportPanel);
}