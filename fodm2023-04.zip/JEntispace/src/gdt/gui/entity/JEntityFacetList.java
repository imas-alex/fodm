package gdt.gui.entity;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JAddFacetsList;
import gdt.gui.console.JAllFacetsList;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
import gdt.gui.generic.JTextEditor;

public class JEntityFacetList extends JItemsListPanel{
	public static final String KEY="_7fwHv_SFQ3PgntP_CPCScrFfNSm0";
	public final String DEFAULT_TITLE="Default";
	public final String DELETE_ACTION="delete";
	public final String LIST_ACTION="list";
	String[] ea=null;
	private static final long serialVersionUID = 1L;
	public JEntityFacetList(JMainConsole console, String alocator$) {
		super(console, alocator$);
		
		//System.out.println("JEntityFacetList:locator="+locator$);
		instance$=getInstance();
		parent$=Locator.getProperty(alocator$, PARENT);
//		System.out.println("JEntityFacetList:entity="+entity$+" parent="+parent$+"  container="+container$);
		if(parent$!=null)
		 locator$=Locator.append(locator$, PARENT, parent$);
		else
		System.out.println("JEntityFacetList:parent null in locator"+locator$);
		if(entity$!=null)
			 locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity$);
	    JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);
	}
	@Override
	public void rebuild(JMainConsole console) {
		//System.out.println("JEntityFacetList:rebuild");
		clear();
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	    il=new ArrayList<JItemPanel>();
	    //System.out.println("JEntityFacetList:rebuild:locator="+locator$);
	    JItemPanel[] ipa=getItems(console,  locator$);
			//System.out.println("JDesignActions:items="+ipa.length);
			if(ipa!=null)
				for(JItemPanel ip:ipa)
				  if(ip!=null)	
					addItem(ip);
			revalidate();
			repaint();
			//System.out.println("JEntityFacetList:rebuild:FINISH display="+display$);	
	}
	public JEntityFacetList(JMainConsole console) {
		super(console);
	}
	@Override
	public String getTitle() {
		return "Entity facet list";
	}
	@Override
	 public String getSubtitle() {
		  return entity$;
	  }
	
	public  JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Select all");
		menu=removeItem(menu,"Unselect all");
		menu=removeItem(menu,"Delete");
		JMenuItem addItem = new JMenuItem("Add facet");
		addItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String addFacets$=JAddFacetsList.classLocator();
				addFacets$=Locator.append(addFacets$, Entigrator.ENTITY_LABEL, entity$);
				JAddFacetsList addFacetsList=new  JAddFacetsList(console,addFacets$);
				console.replaceContext(JEntityFacetList.this,addFacetsList);
			}
			});
		menu.addSeparator();
		menu.add(addItem);
		return menu;
	}
	 public static String classLocator() {
			Properties locator=new Properties();
			 locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
		    locator.put(CONTEXT_CLASS,"gdt.gui.entity.JEntityFacetList");
		    locator.put(Locator.LOCATOR_TITLE,"Entity facets");
			locator.put(IconLoader.ICON_FILE,"facet.png");
			locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
			locator.put(DEFAULT_PARENT,JAllFacetsList.KEY);
			locator.put(DEFAULT_PARENT_CLASS, "gdt.gui.console.JAllFacetsList");
			return Locator.toString(locator);
		} 
	private class JDefaultFacetItem extends JItemPanel{
		private static final long serialVersionUID = -8596195035443603689L;
		@SuppressWarnings("unused")
		String action$=null;
		public JDefaultFacetItem( JMainConsole console,JContext context,String locator$) {
			super(console, context,locator$);
			action$=Locator.getProperty(locator$, JItemPanel.ITEM_ACTION);
			entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		}
		@Override
		public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
		}
		@Override
		public void onClick(JMainConsole console, String alocator$) {
//			System.out.println("JEntityFacetList:onclick:alocator="+alocator$);
			String entityLabel$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
			String listLocator$=JEntityFacetList.this.getLocator();
			String listInstance$=JEntityFacetList.this.getInstance();
			SessionHandler.putLocator(console.getEntigrator(), listLocator$);
			String defaultLocator$=JDefaultServicesList.classLocator();
			defaultLocator$=Locator.append(defaultLocator$, Entigrator.ENTITY_LABEL,entityLabel$);
			defaultLocator$=Locator.append(defaultLocator$,JContext.PARENT,listInstance$ );
			JDefaultServicesList defaultServicesList=new JDefaultServicesList (console,defaultLocator$);
			console.replaceContext(JEntityFacetList.this,defaultServicesList);
		}
	}
	JDefaultFacetItem  getDefaultItem(JMainConsole console) {
		String defaultItemLocator$=JDefaultServicesList.classLocator();
		defaultItemLocator$=Locator.append(defaultItemLocator$, Entigrator.ENTITY_LABEL, entity$);
		defaultItemLocator$=Locator.append(defaultItemLocator$, PARENT, instance$);
		JDefaultFacetItem  defaultItem= new JDefaultFacetItem (console,this, defaultItemLocator$);
	return defaultItem;	  
	}
	
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		//System.out.println("JEntityFacetList:getItems:locator="+locator$);
		try {
		String parentInstance$=getInstance();
	//	System.out.println("JEntityFacetList:getItems:parent instance="+parentInstance$);
		String thisLocator$=getLocator();
		SessionHandler.putLocator(console.getEntigrator(), thisLocator$);
	//	System.out.println("JEntityFacetList:getItems:this locator="+thisLocator$);
		Properties locator=Locator.toProperties(locator$);
		entity$=locator.getProperty(Entigrator.ENTITY_LABEL);
		if(entity$==null)
			return null;
		Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		FacetMaster fm=null;
		JItemPanel item;
		String itemLocator$;
		JDefaultFacetItem defaultItem=getDefaultItem( console);
		ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
		ipl.add(defaultItem);
		String[] sa=entity.elementListNames("facet");
		if(sa!=null) {
			//System.out.println("JEntityFacetList:getItems:sa="+sa.length);
		for(String s:sa) {
			try {
			itemLocator$= entity.getElementItemAt("facet", s);
			//System.out.println("JEntityFacetList:getItems:s="+s);
			itemLocator$=Locator.append(itemLocator$, Entigrator.ENTITY_LABEL, entity$);
			if(parentInstance$!=null)
			  itemLocator$=Locator.append(itemLocator$,JContext.PARENT, parentInstance$);
			fm=FacetMaster.build(console,this,itemLocator$);
			if(fm==null) {
				System.out.println("JEntityFacetList:getItems:cannot get facet master:locator="+itemLocator$);
			    continue;
			}else
			//System.out.println("JEntityFacetList:getItems:fm="+fm.getName());
			item=fm.getJEntityFacetsItem(console, itemLocator$);
			//System.out.println("JEntityFacetList:getItems:1");
			
			if(item!=null)
			   ipl.add(item);
			}catch(Exception ee) {
				System.out.println("JEntityFacetList:getItems:s="+s+"   "+ee.toString());	
			}
		}
		}
		JItemPanel[]ipa=new JItemPanel[ipl.size()];
		ipl.toArray(ipa);
		if(ipa==null||ipa.length<1)
			return null;
		//System.out.println("JEntityFacetList:getItems:ipa="+ipa.length);
		return sortItems(ipa);
		}catch(Exception e) {
			System.out.println("JEntityFacetList:getItems:"+e.toString());	
		}
		return null;
	}
	@Override
	public String reply(JMainConsole console,String locator$) {
//		System.out.println("JEntityFacetList:reply:locator="+locator$);
		try {
			String entityLabel$=Locator.getProperty(locator$,JTextEditor.OUT_TEXT);
			String masterClass$=Locator.getProperty(locator$, FacetMaster.MASTER_CLASS);
			FacetMaster fm=FacetMaster.build(console,this, locator$);
		    Sack entity=fm.createEntity(console.getEntigrator(), entityLabel$);
		    String entityFacetList$ =JEntityFacetList.classLocator();
		    entityFacetList$=Locator.append(entityFacetList$,Entigrator.ENTITY_LABEL, entity.getProperty(Entigrator.LABEL));
		    entityFacetList$=Locator.append(entityFacetList$,FacetMaster.MASTER_CLASS,masterClass$);
		    entityFacetList$=Locator.remove(entityFacetList$, REPLY);
		    return entityFacetList$;
	}catch(Exception e) {
		System.out.println("JEntityFacetList:reply:"+e.toString()+" locator="+locator$);
		return getLocator();
	}
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	}
