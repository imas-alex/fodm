package gdt.gui.entity;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;

import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import gdt.base.facet.ModuleHandler;
import gdt.base.facet.ProjectHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JDesignPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
import gdt.gui.generic.JTextEditor;

public class JListEntities extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	private static final String NEW_ENTITY="new entity";
	private static final String ENTITY_TYPE="entity type";
	JMenuItem copyItem;
	JMenuItem newItem;
	JMenuItem exportItem;
	String entityType$=null;
	String facetMaster$;
	public JListEntities(JMainConsole console, String alocator$) {
		super(console, alocator$);
		String parent$=Locator.getProperty(alocator$, PARENT);
		if(parent$!=null)
			locator$=Locator.append(locator$, PARENT, parent$);
		facetMaster$=Locator.getProperty(locator$, FacetMaster.MASTER_CLASS);
		FacetMaster fm=FacetMaster.build(console, this,locator$);
		if(fm!=null)
			entityType$=fm.getType();
		else
			System.out.println("JListEntities:cannot build facet master for locator="+locator$);
		//System.out.println("JListEntities:facet master="+facetMaster$);
		JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null) {
			//System.out.println("JListEntities:ipa="+ipa.length);
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);
		}else
			System.out.println("JListEntities:ipa is null");
		
	}
	@Override
	protected void deleteItem(JItemPanel item) {
    	super.deleteItem(item);
    	Entigrator entigrator=console.getEntigrator();
    	String entityLabel$=item.getTitle();
    	String entityKey$=entigrator.getKey(entityLabel$);
    	if(entityKey$!=null)
    	  entigrator.deleteEntity(entityKey$);
    }
	@Override
	public  JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu.addMenuListener(new MenuListener(){
		     @Override
		     public void menuCanceled(MenuEvent e) {
			     }
		     @Override
		     public void menuDeselected(MenuEvent e) {
			     }
			@Override
			public void menuSelected(MenuEvent arg0) {
//				System.out.println("JListEntities:menu listener"+arg0.toString());
				JMenuItem deleteItem=getMenuItem(menu,"Delete");
				if(hasChecked()) {
                	copyItem.setEnabled(true);
                	exportItem.setEnabled(true);
                	if(deleteItem!=null)
                		deleteItem.setEnabled(true);
				}else {	
                	copyItem.setEnabled(false);
                	exportItem.setEnabled(false);
                	if(deleteItem!=null)
                		deleteItem.setEnabled(false);
				}
				
				if(entityType$!=null)
					newItem.setEnabled(true);
				else
					newItem.setEnabled(false);
			}
		 });
		 copyItem = new JMenuItem("Copy");
		 copyItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				SessionHandler.clearCopy(console.getEntigrator());
				JItemPanel[] ipa=getChecked();
				System.out.println("JListEntities:copy:ipa="+ipa.length);
				for(JItemPanel ip:ipa) {
					entity$=Locator.getProperty(ip.getLocator(),Locator.LOCATOR_TITLE);
					if(entity$==null)
						continue;
					entityKey$=console.getEntigrator().getKey(entity$);
					SessionHandler.putCopiedEntity(console.getEntigrator(), entityKey$);
				}
			}
			});
		menu.addSeparator();
		menu.add(copyItem);
		newItem = new JMenuItem("New");
			newItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					newEntity();
				}
				});
			menu.addSeparator();
			menu.add(newItem);
			 exportItem = new JMenuItem("Export");
			 exportItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JItemPanel[] ipa=getChecked();
					ArrayList<String>sl=new ArrayList<String>();
					for(JItemPanel ip:ipa) {
						entity$=Locator.getProperty(ip.getLocator(),Locator.LOCATOR_TITLE);
						if(entity$==null)
							continue;
						sl.add(entity$);
						//System.out.println("JListEntities:export:entity="+entity$);
					}
					if(sl.size()<1)
						return;
						JFileChooser chooser = new JFileChooser(); 
						chooser.setApproveButtonText("Export");
						String	path$= System.getProperty("user.home");
					//	System.out.println("JListEntities:export:home="+path$);
			  		    chooser.setCurrentDirectory(new java.io.File(path$));
			  		    chooser.setDialogTitle("Export directory");
			  			if (chooser.showSaveDialog( exportItem ) == JFileChooser.APPROVE_OPTION) {	  
			  			File selection=chooser.getSelectedFile();
			  		    path$=selection.getPath();
			  		    export(path$);
			  		    //System.out.println("JListEntities:export:path="+path$);			
					}
			  		
			  			/*
			  			try{
				    	File list=new File(path$);
						if(list.exists())
							list.delete();
						list.createNewFile();
						 FileOutputStream fos = new FileOutputStream(list, false);
						 Writer writer = new OutputStreamWriter(fos, "UTF-8");
						 for(String s:sl)
							 writer.append(s+"\n");
						 writer.close();
						 fos.close();
						
					}catch(Exception ee){
						System.out.println("JListEntities:export:"+ee.toString());
					}
					*/
				}
				});
			 menu.add(exportItem); 
		return menu;
	}
	private void export(String fname$) {
		//SessionHandler.clearCopy(console.getEntigrator());
		JItemPanel[] ipa=getChecked();
		String zipFile$=fname$.replace(".zip","")+".zip";
		System.out.println("JListEntities:export:fname=" +fname$+" ipa="+ipa.length);
		ArrayList<String>sl=new ArrayList<String>();		
		for(JItemPanel ip:ipa) {
			entity$=Locator.getProperty(ip.getLocator(),Locator.LOCATOR_TITLE);
			if(entity$==null)
				continue;
			String entityKey$=console.getEntigrator().getKey(entity$);
			Sack entity=console.getEntigrator().getEntity(entityKey$);
			if(entity==null)
				continue;
			sl.add(entityKey$);
			//SessionHandler.putCopiedEntity(console.getEntigrator(), entityKey$);
		}
		if(sl.size()<1)
			return;
		String[]sa=new String[sl.size()];
		sl.toArray(sa);
		File zipFile=new File(zipFile$);
		//String dir$=zipFile.getParent();
		try {
			if(! zipFile.exists())
				zipFile.createNewFile();
			ProjectHandler.exportCollection(console.getEntigrator(), zipFile$, sa);   
		}catch(Exception e) {
			System.out.println("JListEntities:export:"+e.toString());
		}
	}
	private void newEntity() {
		try {
		String thisLocator$=JListEntities.this.getLocator();
		thisLocator$=Locator.append(thisLocator$, JContext.REPLY, Locator.LOCATOR_TRUE);
		thisLocator$=Locator.append(thisLocator$,JItemPanel.ITEM_ACTION,NEW_ENTITY);
		if(entityType$!=null)
		thisLocator$=Locator.append(thisLocator$,ENTITY_TYPE,entityType$);
		thisLocator$=Locator.append(thisLocator$, ACTION, NEW_ENTITY);
		SessionHandler.putLocator(console.getEntigrator(),thisLocator$);
		String textEditor$=JTextEditor.classLocator();
		textEditor$=Locator.append(textEditor$, JContext.PARENT, instance$);
		textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New "+entityType$);
		textEditor$=Locator.append(textEditor$, ACTION, NEW_ENTITY);
		JTextEditor textEditor=new JTextEditor(console,textEditor$);
		console.replaceContext(this,textEditor);
		rebuild(console);
		}catch(Exception e) {
			System.out.println("JListEntities:newEntity:"+e.toString());
		}
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
	//	System.out.println("JListEntities:reply:locator="+locator$);
		try {
		String reply$=Locator.getProperty(locator$, REPLY);
		if(!Locator.LOCATOR_TRUE.equals(reply$)) {
			System.out.println("JListEntities:reply:no reply");
			return null;
		}
		Properties locator=Locator.toProperties(locator$);
		String action$=locator.getProperty(ACTION);
		//System.out.println("JListEntities:reply:action="+action$);
		if(NEW_ENTITY.equals(action$)) {
			String newLabel$=locator.getProperty(JTextEditor.OUT_TEXT);
			Entigrator entigrator=console.getEntigrator();
			//System.out.println("JListEntities:reply:0");
			FacetMaster fm=FacetMaster.build(console, this,locator$);
			//System.out.println("JListEntities:reply:1");
			if(fm==null) {
				System.out.println("JListEntities:reply:cannot build facet master for locator="+locator$);
				return null;
			}
			Sack entity=fm.createEntity(entigrator, newLabel$);
			console.getEntigrator().putEntity(entity);
			console.getEntigrator().reindexEntity(entity);
			String[] sa=entigrator.listEntities(entity.getProperty("entity"),Locator.LOCATOR_TRUE);
			if(sa!=null&&sa.length>0) {	
				ArrayList<String>sl=new ArrayList<String>();
			String entityLabel$;
			for(int i=0;i<sa.length;i++) {
				entityLabel$=entigrator.getLabel(sa[i]);
				if(entityLabel$==null) {
					System.out.println("FacetMaster:listFacetMembers:cannot find label at key="+sa[i]);
					continue;
				}else
					sl.add(entityLabel$);
			}
			String ea$=null;
			if(sl.size()>0) {
	        Collections.sort(sl);		
	        sa=new String[sl.size()];
	        sl.toArray(sa);
			 ea$=Locator.toString(sa);
			 locator$=Locator.append(locator$,JDesignPanel.ENTITIES, ea$);
			}
			}
			}
			locator$=Locator.remove(locator$, REPLY);
			return locator$;
		
		
	}catch(Exception e) {
		System.out.println("JListEntities:reply:"+e.toString()+" locator="+locator$);
	}
		return  locator$;
	}
	
	public static String classLocator() {
		Properties locator=new Properties();
		 locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.entity.JListEntities");
	    locator.put(Locator.LOCATOR_TITLE,"Entities list");
		locator.put(IconLoader.ICON_FILE,"entities.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(DEFAULT_PARENT, JDesignPanel.KEY);
		 return Locator.toString(locator);
	} 
private class JEntityItem extends JItemPanel {
	private static final long serialVersionUID = 1L;
	public JEntityItem(JMainConsole console,JContext context, String locator$) {
		super(console,context, locator$);
	}
@Override
public JPopupMenu getPopup(JMainConsole console, String locator$) {
		return null;
}
@Override
public void onClick(JMainConsole console, String locator$) {
	//System.out.println("JListEntitis:on item click:item locator="+locator$);
	//System.out.println("JListEntitis:on item click:container="+container$);
	String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	String listLocator$=JListEntities.this.getLocator();
	String itemParent$=JListEntities.this.getInstance();
	String facetsLocator$=JEntityFacetList.classLocator();
	facetsLocator$=Locator.append(facetsLocator$,Entigrator.ENTITY_LABEL, entityLabel$);
	facetsLocator$=Locator.append(facetsLocator$, PARENT,itemParent$);
	//			System.out.println("JEntityEditor:addElement:display="+display$);
	JEntityFacetList facetList=new JEntityFacetList(console,facetsLocator$);
	SessionHandler.putLocator(console.getEntigrator(),listLocator$);
	console.replaceContext(JListEntities.this,facetList);
}
}
@Override
public JItemPanel[] getItems(JMainConsole console, String alocator$) {
	
	String ea$=Locator.getProperty(alocator$,JDesignPanel.ENTITIES);
	String[] ea=Locator.toArray(ea$);
	if(ea==null) {
		System.out.println("JListEntities:getItems:ea is null");
		return null;
	}
	Properties entityLocator;
	ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
	if(ea!=null) {
		Sack entity;
		String entityLocator$;
		JEntityItem entityItem;
	//	System.out.println("JListEntities:add items:this locator="+locator$);
	String parentKey$=getInstance();
	SessionHandler.putLocator(console.getEntigrator(), getLocator());
	//	System.out.println("JListEntities:add items:this instance=="+parentKey$);
	//	System.out.println("JListEntities:add items:this locator="+locator$);
		for(String e:ea) {
	       entity=console.getEntigrator().getEntityAtLabel(e);
	       if(entity!=null) {
	    	   entityLocator=new Properties();
	           entityLocator.put(Locator.LOCATOR_TITLE, e);
	           entityLocator.put(JItemPanel.ITEM_CHECKABLE,Locator.LOCATOR_TRUE);
	           entityLocator.put(JItemPanel.ITEM_CHECKED,Locator.LOCATOR_FALSE);
	           Core icon=entity.getAttribute("icon");
	           if(icon!=null) {
	        	   entityLocator.put(IconLoader.ICON_FILE,icon.value);
	        	   entityLocator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	        	   if(icon.type!=null&& icon.type.length()>0) {
	        	      entityLocator.put(ModuleHandler.FACET_MODULE,icon.type);
	        	      entityLocator.remove(IconLoader.ICON_CONTAINER);
	        	   }
	           }else {	   
	        	   entityLocator.put(IconLoader.ICON_FILE,"box.png");
	               entityLocator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	           }
	           entityLocator.put(Entigrator.ENTITY_LABEL,e);
	           entityLocator.put(SessionHandler.INSTANCE,console.getEntigrator().getKey(e));
	           entityLocator.put(JContext.PARENT,parentKey$);
	           entityLocator.put(JContext.DEFAULT_PARENT,KEY);
	           String entityType$=entity.getProperty("entity");
	           entityLocator$=Locator.toString(entityLocator);
	          
	           if(entityType$!=null) {
	        	   Sack session=SessionHandler.getSession(console.getEntigrator());
	        	   String iconLocator$=session.getElementItemAt(FacetMaster.ICON_ELEMENT, entityType$);
	        	   entityLocator$=Locator.merge(entityLocator$, iconLocator$);
	           }
	          
	           entityItem=new JEntityItem(console,this,entityLocator$);
	       //    System.out.println("JListEntities:getItems:entity locator="+entityLocator$);
	            ipl.add(entityItem);
	       }else {
	    	   System.out.println("JListEntities:getItems:cannot get entity="+e);
	       }
		}
	}
	JItemPanel[] ipa=new JItemPanel[ipl.size()]; 
	ipl.toArray(ipa);
	return sortItems(ipa);
}
@Override
public String getClassLocator() {
	return classLocator();
}

}
