package gdt.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.Constructor;
import java.util.Properties;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.gui.console.JMainConsole;

public  abstract class JContext extends JPanel implements PropertyChangeListener{
private static final long serialVersionUID = 1L;
public static final String PARENT="parent";

public static final String DEFAULT_PARENT="default parent";
public static final String DEFAULT_PARENT_CLASS="default parent class";
public final static String REPLY="reply";
public final static String ACTION="action";
public final static String INSTANCE="instance";
public final static String NON_REMOVABLE="non removable";
public final static String DISPLAY="display";
public final static String MAIN_CONTAINER_KEY="__1ezu_xEQYdAgL1ItdNbR_nBQ3s";
public final static String CONTEXT_CLASS="context class";
public final static String EVENT_ID="event id";
public final static String EVENT_NAME="event name";

protected JMainConsole console;
protected String locator$;
protected String instance$;
protected String parent$;
protected String entity$;
protected String entityKey$;
protected String reply$;
protected String status$;
protected boolean nomenu=false;


public   JContext () {
	super();
	setLayout(new BorderLayout(0, 0));
}
public JContext(JMainConsole console) {
	super();
	this.console=console;
	locator$=getClassLocator();
	instance$=getInstance();
	if(console!=null)
	   console.getEntigrator().addPropertyChangeListener(this);
}
public  JContext (JMainConsole console,String alocator$){
	super();
		//System.out.println("JContext:alocator="+alocator$);
	locator$=Locator.merge( getClassLocator(),alocator$);
	parent$=Locator.getProperty(alocator$, PARENT);
//	container$=Locator.getProperty(alocator$, JContextContainer.CONTAINER);
	entity$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
	entityKey$=Locator.getProperty(alocator$, Entigrator.ENTITY_KEY);
	if(parent$!=null)
	 locator$=Locator.append(locator$, PARENT, parent$);
	if(entity$!=null)
 	 locator$=Locator.append(locator$, Entigrator.ENTITY_LABEL, entity$);
	if(entityKey$!=null)
	 	 locator$=Locator.append(locator$, Entigrator.ENTITY_KEY, entityKey$);
		//System.out.println("JEntityFacetList:entitx is null in locator="+locator$);
	this.console=console;
	instance$=getInstance();
	locator$=Locator.append(locator$, INSTANCE, instance$);
	parent$=Locator.getProperty(alocator$, PARENT);
	if(parent$!=null)
	   locator$=Locator.append(locator$, PARENT, parent$);
	if(console!=null)
	  if(console.getEntigrator()!=null)
	    console.getEntigrator().addPropertyChangeListener(this);
  }
public abstract String getClassLocator();
public abstract String reply(JMainConsole console,String locator$);
public abstract boolean handleDone();
public  void append( String property$,String  value$) {
	if(property$!=null&&value$!=null)
	 locator$=Locator.append(locator$, property$, value$);
}
public  JMenu getContextMenu() {
	// System.out.println("JContext:getContextMenu:this="+getClass().getName());
	  JMenu menu=new JMenu("Context");
    	JMenuItem doneItem = new JMenuItem("Done");
		doneItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handleDone();
					}
				});
		   menu.add(doneItem);
		JMenuItem displayItem = new JMenuItem("Display");
		displayItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
		//		System.out.println("JContext:display: this locator="+locator$);
				JDisplay display=new JDisplay(console);
				String newContainer$=console.putContainer(display);
//				System.out.println("JContext:display:new container="+newContainer$);
				String newLocator$=locator$;
				newLocator$=Locator.remove(newLocator$, INSTANCE);
				newLocator$=Locator.remove(newLocator$, PARENT);
				if(newContainer$!=null)
				  newLocator$=Locator.append(newLocator$,JContextContainer.CONTAINER, newContainer$);
				JContext newContext=JContext.build(console, newLocator$);
				display.putContext(newContext);
				display.revalidate();
				display.repaint();
	
			}
		});
		menu.add(displayItem);
		return menu;
  };
 public static JMenu removeItem(JMenu menu,String item$) {
	 if(menu==null||item$==null)
		 return menu;
	 int cnt=menu.getItemCount();
		if(cnt>0)
			for(int i=0;i<cnt;i++) {
				JMenuItem item=menu.getItem(i);
				if(item==null)
					continue;
				if(item$.equals(item.getText())) {
					menu.remove(i);
					return menu;
				}
			}
	 return menu;	
 }
 public static JMenuItem getMenuItem(JMenu menu,String item$) {
	 if(menu==null||item$==null)
		 return menu;
	 int cnt=menu.getItemCount();
		if(cnt>0)
			for(int i=0;i<cnt;i++) {
				JMenuItem item=menu.getItem(i);
				if(item==null)
					continue;
				if(item$.equals(item.getText())) {
					return item;
				}
			}
	 return null;	
 }
 public void setLocator(String locator$) {
	this.locator$=locator$;
}
public void setParent(String parentInstance$) {
  if(parentInstance$!=null)
	locator$=Locator.append(locator$, PARENT, parentInstance$);
}

public  static  void displayInstance(JMainConsole console, String instance$,JDisplay  display) {
    try {
    	 System.out.println("JContext:displayInstance:instance="+instance$);
    	 if(instance$==null) {
    		 System.out.println("JContext:displayInstance:instance is null");
    		 return ;
    	 }
        String locator$=SessionHandler.getInstanceLocator(console.getEntigrator(), instance$);
        //System.out.println("JContext:displayInstance:locator="+locator$);
        if(locator$==null) {
        	System.out.println("JContext:displayInstance:cannot get locator for instance="+instance$);
        	return ;
        }
        	String contextClass$=Locator.getProperty(locator$, CONTEXT_CLASS);
        //	System.out.println("JContext:displayInstance:context class="+contextClass$);
        	if(contextClass$==null) {
        		System.out.println("JContext:displayInstance:no CONTEXT_CLASS in parent locator ="+locator$);
        		return;
        	}
   			Class <?>contextClass=console.getEntigrator().getClass(contextClass$);
   			Constructor<?> cns=contextClass.getConstructor(JMainConsole.class,String.class);
        	if(cns==null) {
        		System.out.println("JContext:displayInstance::cannot get constructor for context class="+contextClass$);
        			return;
        	}
      		cns.setAccessible(true);
      		Object obj=  cns.newInstance(console,locator$);
      		if(display!=null) {
      			display.putContext((JContext)obj);
      		}else {
      			System.out.println("JContext:displayInstance:replace context="+((JContext)obj).getName());
      			console.replaceContext(null,(JContext)obj);
      		}
        
        }catch(Exception e) {
        	System.out.println("JContext:displayInstance:"+e.toString());
        	return ;
        }
       	}


public  static  void replyInstance(JMainConsole console, String locator$) {
	int breakPoint=0;
	try {
    	// System.out.println("JContext:replyInstance:instance="+instance$);
    	if(locator$==null) {
    		 System.out.println("JContext:replyInstance:locator is null");
    		 return ;
    	 }
    	String instance$=Locator.getProperty(locator$, INSTANCE);
    	if(instance$==null) {
    		 System.out.println("JContext:replyInstance:instance is null in locator="+locator$);
    		 return ;
    	}
       	String contextClass$=Locator.getProperty(locator$, CONTEXT_CLASS);
       	if(contextClass$==null) {
        		System.out.println("JContext:replyInstance:no CONTEXT_CLASS in locator ="+locator$);
        		return;
        	}
		Class <?>contextClass=console.getEntigrator().getClass(contextClass$);
   		 breakPoint=3;
   		Constructor<?> cns=contextClass.getConstructor(JMainConsole.class,String.class);
       	if(cns==null) {
        System.out.println("JContext:replyInstance::cannot get constructor for context class="+contextClass$+" in locator="+locator$);
        			return;
        	}
        breakPoint=4;
      		cns.setAccessible(true);
      	Object obj=  cns.newInstance(console,locator$);
      	 breakPoint=5;
      	if(obj==null) {
      	  System.out.println("JContext:replyInstance::cannot get object for context class="+contextClass$+" in locator="+locator$);
      	return;
      		}
      		 breakPoint=6;
      //	System.out.println("JContext:replyInstance:object="+obj.getClass().getName());
      	locator$=((JContext)obj).reply(console,locator$);
      	 breakPoint=6;
      	SessionHandler.putLocator(console.getEntigrator(), locator$);
      		
        }catch(Exception e) {
        	System.out.println("JContext:replyInstance:"+e.toString()+"  break point="+breakPoint+" locator="+locator$);
        	return ;
        }
    
    	} 

  public String getLocator() {
	  if(locator$==null)
		return null;
	  String instance$=getInstance();
	  locator$=Locator.append(locator$, INSTANCE, instance$);
	  return locator$;
  }
  public String getInstance() {
	  if(locator$==null)
		  return null;
	  String instance$= Locator.getProperty(locator$, INSTANCE);
	  if(instance$!=null)
		  return instance$;
	  instance$=Identity.key();
	  locator$=Locator.append(locator$, INSTANCE, instance$);
	  return instance$;
  }
  public String getParentInstance() {
	  if(locator$==null)
		  return null;
	  return Locator.getProperty(locator$, PARENT);
  }
  
  public static JContext getContainerContext(JMainConsole console,String container$) {
	  JContextContainer container=console.getContextContainer(container$);
	  if(container==null)
		  return null;
	  return container.getContext();
  }
  public String getTitle() {
	  return Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
  }
  public String getSubtitle() {
	  String subtitle$= Locator.getProperty(locator$, Locator.LOCATOR_SUBTITLE);
	  if(subtitle$==null)
		  subtitle$= Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	  return subtitle$;
  }
  public static String getContextTitle(JMainConsole console,String locator$) {
	  try {
	  JContext context=build(console,locator$);
	  String classLocator$=context.getClassLocator();
	  String title$=Locator.getProperty(classLocator$,Locator.LOCATOR_TITLE);
	  return title$;
	  }catch(Exception e) {
		  System.out.println("JContext:getContextTitle:"+e.toString());
		  return null;
	  }
	  
  }
  public static String getContextTitle(JContext context) {
	  try {
	  String classLocator$=context.getClassLocator();
	  String title$=Locator.getProperty(classLocator$,Locator.LOCATOR_TITLE);
	  return title$;
	  }catch(Exception e) {
		  System.out.println("JContext:getContextTitle:"+e.toString());
		  return null;
	  }
  }
  public static JContext build(JMainConsole console,String locator$) {
	String className$="";
	StringBuffer sb=new StringBuffer("JContext:build:log::");
	try {
	//System.out.println("JContext:build:locator="+locator$);
	Properties locator=Locator.toProperties(locator$);
	String containerType$=locator.getProperty(FacetHandler.FACET_CONTAINER_TYPE);
	className$=locator.getProperty(CONTEXT_CLASS);
	if(className$==null)
		className$="gdt.gui.entity.JEntityFacetList";
	sb.append("class name="+className$+"\n");	
//	System.out.println("JContext:build:className="+className$);
	Class<?> cls=null;
	if(FacetHandler.FACET_CONTAINER_INTERNAL.equals(containerType$)) {
		ClassLoader cl=Thread.currentThread().getContextClassLoader();
		try {
		cls=cl.loadClass(className$);
		}catch(ClassNotFoundException ee) {
			System.out.println("JContext:build::cannot load class:"+ee);
			return null;
		}
        sb.append("internal class loaded\n");
		}else{
			cls=console.getEntigrator().getClassLoader().loadClass(className$);
			sb.append("module class loaded\n");
		}
		if(cls==null) {
			System.out.println("JContext:build:2:class is null");
		  return null;
		}
		Constructor <?>ctr= cls.getDeclaredConstructor(JMainConsole.class, String.class);
		if(ctr==null) {
			System.out.println("JContext:build:3:cannot get default constructor:class="+className$);
			return null;
		}
		sb.append("constructor found\n");
		Object  obj= ctr.newInstance(console,locator$);
		if(obj==null) {
			System.out.println("JContext:build:4:cannot instantiate calss="+className$);
			return null;
		}
		sb.append("instance created\n");
		//System.out.println("JContext:build:return context="+obj.getClass().getName()+ "  locator="+((JContext)obj).getLocator());
		return (JContext)obj;
	}catch(Exception e) {
		System.out.println("JContext:build::"+e.toString()+"  class name="+className$+ "  locator="+locator$);
		System.out.print(sb.toString());
	}
	return null;
}
public String getStatus() {
	return status$;
}
public static void selectCombo(@SuppressWarnings("rawtypes") JComboBox combo, String selection$){
	try{
	@SuppressWarnings("unchecked")
	DefaultComboBoxModel<String> model=(DefaultComboBoxModel<String>) combo.getModel();
   int size=model.getSize();
   int sel=0;
 for(int i=0;i<size;i++) {
	 if(selection$.equalsIgnoreCase((String)combo.getItemAt(i))) {
		 sel=i;
	 }
 }
try{combo.setSelectedIndex(sel);}catch(Exception e) {}
}catch(Exception e){
	System.out.println("JContext:selectCombo:"+e.toString());
	}
}
public String getEntityKey() {
	return entityKey$;
}
public String getEntity() {
	return entity$;
}
public void refresh() {
	 }
@Override
public void propertyChange(PropertyChangeEvent evt) {
	//System.out.println("JContext:propertyChange:evt="+EventHandler.getLocator(console.getEntigrator()));
}
}