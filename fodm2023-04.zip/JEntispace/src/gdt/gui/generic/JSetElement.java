package gdt.gui.generic;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;

public interface JSetElement extends JContextContainer{
	
default JMenu getElementMenu(JContext context) {
	if(context==null)
		return null;
	JMenu menu=context.getContextMenu();
	menu=JContext.removeItem(menu,"Display");
	menu.addSeparator();
   JMenuItem disposeItem=new JMenuItem("Dispose");
	disposeItem.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			dispose();
		}
	
	} );
  menu.add(disposeItem);
  JMenuItem saveItem=new JMenuItem("Save");
	saveItem.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			save();
		}
	} );
 menu.add(saveItem);
 JMenuItem restoreItem=new JMenuItem("Restore");
	restoreItem.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			restore();
		}
	
	} );
menu.add(restoreItem);
   return menu;
}
default Sack saveContext(Sack set,String item$,JContext context) {
		try {
		Core itemEntry=set.getElementItem("set", item$);
		String locator$=itemEntry.value;
		locator$=Locator.append(locator$, JContext.CONTEXT_CLASS,context.getClass().getName());
		itemEntry.value=locator$;
		set.putElementItem("set", itemEntry);
		}catch(Exception e) {
			System.out.println("JSetElement:saveContext:"+e.toString());
		}
		return set;
}
default JContext getItemContext(JMainConsole console,Sack set,String item$) {
	try {
		String locator$=set.getElementItemAt("set", item$);
		return JContext.build(console, locator$);
		}catch(Exception e) {
			System.out.println("JSetElement:getContext:"+e.toString());
		}
		return null;
}
public abstract void  dispose();
public abstract void  save();
public abstract void  restore();
}
