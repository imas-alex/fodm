package gdt.gui.generic;

import java.awt.Dimension;

import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.gui.console.JAllFacetsList;
import gdt.gui.console.JMainConsole;

public abstract class JGuiEditor extends JContext{
	private static final long serialVersionUID = 1L;

	//protected String container$;
	public   JGuiEditor () {
		super();
		setPreferredSize(new Dimension(300,300));
	}
	public JGuiEditor(JMainConsole console) {
		super(console);
		setPreferredSize(new Dimension(300,300));
	}
	public  JGuiEditor (JMainConsole console,String alocator$) {
		super(console,alocator$);
		setPreferredSize(new Dimension(300,300));
	}
	
	@Override
	public boolean handleDone() {
		locator$=getLocator();
	//	System.out.println("JGuiEditor:handleDone:locator="+locator$);
		String parent$=Locator.getProperty(locator$, PARENT);
		String defaultParent$=Locator.getProperty(locator$,DEFAULT_PARENT);
		JContext parent=null;
		String parentLocator$=null;
		if(parent$==null)
			parent$=defaultParent$;
		if(parent$!=null) 
			parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
		if(parentLocator$==null&&defaultParent$!=null) 
			parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),defaultParent$);	
		if(parentLocator$!=null) {
			parent=JContext.build(console, parentLocator$);
		//	System.out.println("JGuiEditor:handleDone:parent="+parent.getClass().getName());
			parentLocator$=parent.reply(console, parentLocator$); 
			parent=JContext.build(console, parentLocator$);
		}
		if(parent==null) { 
			parent=new JAllFacetsList(console,null);
			
		}
		console.replaceContext(this,parent);
		return true;
	}
}
