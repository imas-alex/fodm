package gdt.gui.generic;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
public abstract class JSetEditor extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String SET_ITEM="set item"; 
	protected Sack set;
	JMenuItem deleteItem;
	JMenuItem pasteItem;
	JMenuItem copyItem;
	public JSetEditor(JMainConsole console, String alocator$) {
		super(console, alocator$);
	//	System.out.println("JSetEditor:BEGIN");
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		set=console.getEntigrator().getEntityAtLabel(entity$);
		clear();
	}
	protected abstract void showSet(); 
	protected abstract void paste(); 
	protected abstract void toFront();
	protected abstract void dispose(); 
	protected abstract void deleteItem(String item$); 
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Delete");
		menu.addMenuListener(new MenuListener(){
		     @Override
		     public void menuCanceled(MenuEvent e) {
		     		     }
		     @Override
		     public void menuDeselected(MenuEvent e) {
		     }
			@Override
			public void menuSelected(MenuEvent arg0) {
				if(hasChecked()) {
					deleteItem.setEnabled(true);
					copyItem.setEnabled(true);
				}
				else {
					deleteItem.setEnabled(false);
					copyItem.setEnabled(false);
				}
				String[] sa=null;
				try { 
					sa=SessionHandler.listCopiedEntities(console.getEntigrator());}catch(Exception ee) {}
				if(sa==null||sa.length<1) {
					pasteItem.setEnabled(false);
				}
				else {
					pasteItem.setEnabled(true);
				}
				}
			});
	    menu.addSeparator();
		deleteItem = new JMenuItem("Delete");
		deleteItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				int response = JOptionPane.showConfirmDialog(JSetEditor.this, "Delete selected items ?", "Confirm",
					        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				   if (response == JOptionPane.YES_OPTION) { 
			       ArrayList<JSetItem> ipl=new ArrayList<JSetItem>();
					   if(il!=null)
			    	   for(JItemPanel ip:il)
			    		   if(ip.isChecked()) {
			    			   ipl.add((JSetItem)ip);
			    		   }
					   for(JSetItem ip:ipl) {
						   deleteItem(ip.getItem());
					   }
				console.getEntigrator().putEntity(set);	   
				clear();
				JSetItem[] ipa=getItems(console, locator$);
				if(ipa!=null)
					for(JSetItem ip:ipa) {
						addItem((JSetItem)ip);
					}
				}}
			} );
		   menu.add(deleteItem); 
		  copyItem = new JMenuItem("Copy");
		  copyItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						JItemPanel[] ipa=getChecked();
						SessionHandler.clearCopy(console.getEntigrator());
						if(ipa!=null)
							for(JItemPanel ip:ipa) {
								//System.out.println("JSetEditor:copy:item="+ip.getTitle()+" item="+ip.item$);
							   ((JSetItem)ip).copy();
							}  
					}
				} );
		   menu.add(copyItem); 
		   pasteItem = new JMenuItem("Paste");
			  pasteItem.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
						paste();
						}
					} );
			  menu.add(pasteItem); 
		menu.addSeparator();
		JMenuItem showItem = new JMenuItem("Show");
		showItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showSet();
			}
		} );
		menu.add(showItem);
		menu.addSeparator();
		JMenuItem tofrontItem = new JMenuItem("To front");
		tofrontItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				toFront();
			}
		} );
		menu.add(tofrontItem);
		return menu;
		}
	protected String[] pasteToSet() {
		try {
		  Core[] ca=SessionHandler.getSession(console.getEntigrator()).elementGet(SessionHandler.COPY);
		  if(ca==null||ca.length<1) {
			  System.out.println("JSetEditor:paste:no copies");
			  return null;
		  }
		  System.out.println("JSetEditor:paste:paste ca="+ca.length);
		  ArrayList<String>sl=new ArrayList<String>();
		   if(!set.existsElement("set"))
			   set.createElement("set");
		   String candidateKey$;
		   Core [] ca2=set.elementGet("set"); 
		   String memberLabel$;
		   String memberKey$;
		 //System.out.println("JRackEditor:paste:copies="+ca.length+" members="+ca2.length);
		boolean exists;
		 for(Core c:ca) {
			 candidateKey$=c.name;
			 exists=false;
			 if(ca2!=null&&ca2.length>0)
  			 for(Core c2:ca2) { 
			      memberLabel$=Locator.getProperty(c2.value, Entigrator.ENTITY_LABEL);
			      memberKey$=console.getEntigrator().getKey(memberLabel$);
			      if(candidateKey$.equals(memberKey$)) {
			    	  exists=true;
			    	  break;
			      }
  			 	}
  			 if(!exists) {
  			   String entityLocator$= console.getEntigrator().getEntityLocator(c.name);
  			   entityLocator$=Locator.append(entityLocator$, JContext.CONTEXT_CLASS, "gdt.gui.entity.JEntityFacetList");
  			   String item$=Identity.key();
  			   set.putElementItem("set", new Core(null,item$,entityLocator$));
  			   sl.add(item$);
  			 }
		 }
		 console.getEntigrator().putEntity(set);
		 String[] sa=new String[sl.size()];
		 return sl.toArray(sa);
		}catch(Exception e){
			System.out.println("JSetEditor:paste:"+e.toString());
			return null;
		}
	}
	protected void updateItem(JMainConsole console,String item$ ) {
		try {
		   Core item=set.getElementItem("set", item$);
		   String contextClass$=Locator.getProperty(locator$, JContext.CONTEXT_CLASS);
		   item.value=Locator.append(item.value,JContext.CONTEXT_CLASS , contextClass$);
		   set.putElementItem("set", item);
		   console.getEntigrator().putEntity(set);
			}catch(Exception e) {
				System.out.println("JSetItem:updateItem:"+e.toString());	
			}
	}
	@SuppressWarnings("exports")
	@Override
	public JSetItem[] getItems(JMainConsole console,String alocator$) {
		try {
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			if(entity$==null) {
				System.out.println("JSetEditor:getItems:no entity label in locator"+locator$);
				return null;
			}
		Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		if(entity==null) {
			System.out.println("JSetEditor:getItems:cannot get entity="+ entity$);
			return null;
		}
		Core[] ca=entity.elementGet("set");
		if(ca==null) {
			System.out.println("JSetEditor:getItems:empty set");
			return null;
		}
		//System.out.println("JSetEditor:getItems:ca="+ca.length);
		JSetItem ip;
		Properties props=new Properties();
		props.put(JItemPanel.ITEM_CHECKABLE,Locator.LOCATOR_TRUE);
		props.put(JItemPanel.ITEM_CHECKED,Locator.LOCATOR_FALSE);
		props.put(Entigrator.ENTITY_LABEL,entity$);
		String itemLocator$=Locator.toString(props);
		String context$;
		ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
		String title$;
		ArrayList <String> sl=new ArrayList<String>();
		for(Core c:ca) {
			//System.out.println("JSetEditor:getItems:c.name="+c.name);
			try {
			String entityLocator$=c.value;
			entity$=Locator.getProperty(entityLocator$, Entigrator.ENTITY_LABEL);
			context$=JContext.getContextTitle(console, c.value);
			title$=entity$+"("+context$+")";
			for(String s:sl)
				if(s.equals(title$)) {
					title$=title$+Identity.key().substring(0,4);
					break;
				}
			sl.add(title$);
			itemLocator$=Locator.append(itemLocator$, Locator.LOCATOR_TITLE, title$);
			itemLocator$=Locator.append(itemLocator$, JDisplay.DISPLAY_KEY, c.name);
			ip=new JSetItem(console,this,itemLocator$);	
			ip.setItem(c.name);
			 Sack itemEntity=console.getEntigrator().getEntityAtLabel(entity$);
				ImageIcon icon =FacetMaster.getIcon(console, itemEntity.getProperty("entity"));
				if(icon!=null)
					try {
						ip.setIcon(icon);
					}catch(Exception e) {
						System.out.println("JSetEditor:set icon:"+e.toString());
					}
			//System.out.println("JSetEditor:getItems:item="+ip.item$);
			ipl.add(ip);
			}catch(Exception ee) {
				System.out.println("JSetEditor:getItems:"+ee.toString());
			}
		}
		JSetItem[] ipa=new JSetItem[ipl.size()];
		ipl.toArray(ipa);
		return sortItems(ipa);
		}catch(Exception e) {
			System.out.println("JSetEditor:getItems:"+e.toString());
			return null;
		}
	}
protected JSetItem[] sortItems(JSetItem[] ipa) {
		if(ipa==null||ipa.length<2)
			return ipa;
		try {
		Hashtable <String,JSetItem>ipt=new Hashtable <String,JSetItem>();
		ArrayList<String>sl=new ArrayList<String>();
		String title$;
		for(JSetItem ip:ipa) {
			if(ip==null)
				continue;
			title$=ip.getTitle();
			if(title$!=null) {
				sl.add(title$);
				ipt.put(title$, ip);
			}
		}
		String[]sa=new String[sl.size()];
		sl.toArray(sa);
		Arrays.sort(sa);
		JSetItem[]ipsa=new JSetItem[sa.length];
		 for(int i=0;i<sa.length;i++)
			 ipsa[i]=ipt.get(sa[i]);
		 return ipsa;
		}catch(Exception e) {
			System.out.println("JItemsListPanel:sortItems:"+e.toString());
			return ipa;
		}
	}
	protected   class JSetItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JSetItem(JMainConsole console, JContext context,String locator$) {
			super(console,context, locator$);
		}
	@Override
		public void onClick(JMainConsole console, String locator$) {
		try {
			String entityLocator$=set.getElementItemAt("set", getItem());
			String entity$=Locator.getProperty(entityLocator$, Entigrator.ENTITY_LABEL);
			System.out.println("JSetItem:onClick:item="+item$+" entity label="+entity$);
			String facetList$=JEntityFacetList.classLocator();
			facetList$=Locator.append(facetList$, Entigrator.ENTITY_LABEL,entity$);
			JDisplay display=new JDisplay(console);
			String secondKey$=console.putContainer(display);
			display.setLocationRelativeTo(JSetEditor.this);
			facetList$=Locator.append(facetList$, DISPLAY,secondKey$);
			JEntityFacetList entityFacetList=new JEntityFacetList(console,facetList$);  
			  display.putContext(entityFacetList);
			  display.setVisible(true);
			  display.pack();
			  display.revalidate();
			  display.repaint();
			
			}catch(Exception e) {
				System.out.println("JSetItem:"+e.toString());
			}
			}
	@Override
		public JPopupMenu getPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
		}
	public void  copy() {
		try {
			String entityLocator$=set.getElementItemAt("set", item$);
			String entity$=Locator.getProperty(entityLocator$, Entigrator.ENTITY_LABEL);
			String entityKey$=console.getEntigrator().getKey(entity$);
			SessionHandler.putCopiedEntity(console.getEntigrator(), entityKey$);
			}catch(Exception e) {
				System.out.println("JSetItem:copy:"+e.toString());
			}
	}
	}
}
