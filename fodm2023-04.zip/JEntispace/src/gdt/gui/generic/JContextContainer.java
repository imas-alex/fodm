package gdt.gui.generic;


public interface JContextContainer {
	public final static String CONTAINER="container";
	public final static String CONTAINER_TYPE="container type";
	public final static String CONTAINER_HEIGHT ="container height";
	public final static String CONTAINER_HPOS ="container hpos";
	public final static String CONTAINER_WIDTH="container width";
	public final static String CONTAINER_WPOS="container wpos";
	
	
	public void putContext(JContext context);
	public JContext getContext();
    public void dispose();
    public void toFront();
    public void revalidate();
    public void repaint();
    public void setTitle (String title$);
    public void setSubtitle (String subtitle$);
    public String getLocator();
    public void setVisible(boolean vivsible);
    public JItemPanel getItemPanel();
    public String getItem();
     
}
