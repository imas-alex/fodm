package gdt.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.Image;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.gui.console.JMainConsole;

public class IconLoader {
	 public static final String ICON_FILE="icon file";
	 public static final String ICON_CONTAINER="icon container";
	 public static final String ICON_CONTAINER_GENERIC="generic";

 public static ImageIcon getImageIcon(JMainConsole console,String locator$) {
	 //System.out.println("IconLoader:getImageIcon:locator="+locator$);
	 Properties locator=Locator.toProperties(locator$);
	 String containerType$=locator.getProperty(ICON_CONTAINER);
	 //System.out.println("IconLoader:getImageIcon:container type="+containerType$);
	 String iconFile$=locator.getProperty(ICON_FILE);
	 String module$=locator.getProperty(ModuleHandler.FACET_MODULE);
	 if(module$!=null) {
		 if(module$.equals("system"))
			 return  getGenericIcon( iconFile$);
		 else
		     return getModuleIcon(console.getEntigrator(),locator$);
	 }
	 if(containerType$==null)
		 return  getGenericIcon( iconFile$);
	 if(containerType$.equals("system"))
		 return  getGenericIcon( iconFile$);
	 if(containerType$.equals(FacetHandler.FACET_CONTAINER_INTERNAL))
		 return  getGenericIcon( iconFile$);
	 if(containerType$.equals(ICON_CONTAINER_GENERIC))
		 return  getGenericIcon( iconFile$);
	return null;
	 
 }
 public static ImageIcon getGenericIcon(String iconFile$){
		 try{
			 URL imageURL = IconLoader.class.getResource(iconFile$);
			// System.out.println("IconLoader:getGenericIcon:URL="+imageURL.toString());
		 	if(imageURL==null) {
		 		System.out.println("IconLoader:getGenericIcon:imageURL  is null for file="+iconFile$);
		 		return null;
		 	}
		 	//System.out.println("IconLoader:getGenericIcon:imageURL="+imageURL.toString());
		 	ImageIcon icon = new ImageIcon(imageURL);
		 	Image img = icon.getImage();  
		 	Image newimg = img.getScaledInstance(24,24, java.awt.Image.SCALE_SMOOTH);
		 	icon = new ImageIcon(newimg);
		 //	System.out.println("IconLoader:getGenericIcon:iconFile:FINISH");
		 	return icon;
		 }catch(Exception e){
		 	 Logger.getLogger(IconLoader.class.getName()).severe(e.toString());
		 }
		 return null;
		 }
 public static ImageIcon getModuleIcon(Entigrator entigrator,String locator$){
	 URLClassLoader moduleClassLoader=null;
	 try{
//		 System.out.println("IconLoader:getModuleIcon:locator="+locator$);
			String module$=Locator.getProperty(locator$, "module");
			String iconFileName$=Locator.getProperty(locator$, ICON_FILE);
	//		System.out.println("FacetMaster:build:module="+module$+"   locator="+locator$);
			String jar$="jar:file:" +entigrator.getEntihome()+"/"+module$+"/lib/"+module$+".jar!/";
			ArrayList <URL> urll=new ArrayList<URL>();
		   urll.add(new URL(jar$));
		   URL[] urls=urll.toArray(new URL[0]);
		    moduleClassLoader=new URLClassLoader(urls);
		   String iconPath$=module$+"/gui/generic/"+iconFileName$;
		   URL imageURL =moduleClassLoader.getResource(iconPath$);
    	 	if(imageURL==null) {
	 		System.out.println("IconLoader:getModuleIcon:imageURL  is null for resource="+iconPath$);
	 		if( moduleClassLoader!=null)
	 			 moduleClassLoader.close();
	 		return null;
	 	}
	 	//System.out.println("IconLoader:getGenericIcon:imageURL="+imageURL.toString());
	 	ImageIcon icon = new ImageIcon(imageURL);
	 	Image img = icon.getImage();  
	 	Image newimg = img.getScaledInstance(24,24, java.awt.Image.SCALE_SMOOTH);
	 	icon = new ImageIcon(newimg);
	 //	System.out.println("IconLoader:getGenericIcon:iconFile:FINISH");
	 	if( moduleClassLoader!=null)
			 moduleClassLoader.close();
	 	return icon;
	 }catch(Exception e){
	 	 Logger.getLogger(IconLoader.class.getName()).severe(e.toString());
	 }
	 return null;
	 }
}
