package gdt.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Properties;
import java.util.logging.Logger;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.BoxLayout;
import javax.swing.JScrollPane;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
public  abstract class JItemsListPanel extends  JGuiEditor {
	public static final String POSITION="position";
	protected JScrollPane scrollPane;
	protected JPanel listPane;
	protected JScrollBar vertical;
	protected int pos=-1;
	int calls=-1;
	private static final long serialVersionUID = 1L;
	public static  final String KEY = "_huRKhnOlyCmWN9RhsWFXcF9FGso";
    private Logger LOGGER=Logger.getLogger(JItemsListPanel.class.getName());
    protected JMenuItem selectItem;
    protected JMenuItem unselectItem;
    JMenuItem recentItem;
    JMenuItem countItem;
    protected JMenu menu;
    protected ArrayList<JItemPanel>il;
    public JItemsListPanel(JMainConsole console) {
    	super(console);
    	
    	il=new ArrayList<JItemPanel>();
    	setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		scrollPane = new JScrollPane();
		add(scrollPane);
		listPane=new JPanel();
		listPane.addMouseListener(new MouseAdapter() { 
            public void mousePressed(MouseEvent me) { 
            } 
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		int cnt=listPane.getComponentCount();
        		Component component;
        		if(cnt>0)
        			for( int i=0;i<cnt;i++) {
        				component=listPane.getComponent(i);
        				((JItemPanel)component).hidePopup();
        			}
        	}
          }); 
		scrollPane.setViewportView(listPane);
		listPane.setLayout(new BoxLayout(listPane, BoxLayout.Y_AXIS));
		vertical = scrollPane.getVerticalScrollBar();
		vertical.addAdjustmentListener( new AdjustmentListener() 
		{		@Override
			public void adjustmentValueChanged(AdjustmentEvent e) {
			  try{
				 
				  if(calls++>2){
			   			pos=vertical.getValue();
			   		//	System.out.println("JItemsPanel:AdjustmentListener:position="+pos);
						return;
			   		}
		   	String position$=Locator.getProperty(locator$, POSITION);
		//   	System.out.println("JItemsListPanel:AdjustmentListener:position given="+pos+" current="+vertical.getValue());
		   	 if(position$!=null){
		   		 if(vertical.getValue()!=pos)
		   		     vertical.setValue(pos);
		   	 }
			  }catch(Exception ee){
				  LOGGER.severe(ee.toString());
			  }
			}
		      });
    }
 //@Override
 public   void rebuild(JMainConsole console){
    	try {
    	listPane.removeAll();
    	il=new ArrayList<JItemPanel>();
    	JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);
	}catch(Exception e) {
				System.out.println("JItemsListPanel:rebuild:"+e.toString());
	}
		revalidate();
		repaint();
    }
	public JItemsListPanel(JMainConsole console,String locator$) {
		super(console, locator$);
		il=new ArrayList<JItemPanel>();
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		scrollPane = new JScrollPane();
		add(scrollPane);
		listPane=new JPanel();
		listPane.addMouseListener(new MouseAdapter() { 
            public void mousePressed(MouseEvent me) { 
            } 
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		int cnt=listPane.getComponentCount();
        		Component component;
        		if(cnt>0)
        			for( int i=0;i<cnt;i++) {
        				component=listPane.getComponent(i);
        				((JItemPanel)component).hidePopup();
        			}
        	}
          }); 
		scrollPane.setViewportView(listPane);
		listPane.setLayout(new BoxLayout(listPane, BoxLayout.Y_AXIS));
		vertical = scrollPane.getVerticalScrollBar();
		vertical.addAdjustmentListener( new AdjustmentListener() 
		{		@Override
			public void adjustmentValueChanged(AdjustmentEvent e) {
			  try{
				 
				  if(calls++>2){
			   			pos=vertical.getValue();
			   		//	System.out.println("JItemsPanel:AdjustmentListener:position="+pos);
						return;
			   		}
		   	String position$=Locator.getProperty(locator$, POSITION);
		//   	System.out.println("JItemsListPanel:AdjustmentListener:position given="+pos+" current="+vertical.getValue());
		   	 if(position$!=null){
		   		 if(vertical.getValue()!=pos)
		   		     vertical.setValue(pos);
		   	 }
			  }catch(Exception ee){
				  LOGGER.severe(ee.toString());
			  }
			}
		      });
	}
	
	@Override
	public JMenu getContextMenu() {
    	//System.out.println("JItemsListPanel:getContextMenu:BEGIN");	
	   if(nomenu)
		   return null;
    	menu=super.getContextMenu();
	   selectItem = new JMenuItem("Select all");
	   selectItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for(JItemPanel ip:il)
		    		  ip.setChecked(true);
			}
		} );
		menu.add(selectItem);
		unselectItem = new JMenuItem("Unselect all");
		   unselectItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					for(JItemPanel ip:il)
			    		  ip.setChecked(false);
				}
			} );
		   menu.add(unselectItem); 
		   JMenuItem deleteItem = new JMenuItem("Delete");
		   deleteItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				int response = JOptionPane.showConfirmDialog(JItemsListPanel.this, "Delete selected items ?", "Confirm",
					        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				   if (response == JOptionPane.YES_OPTION) { 
			       ArrayList<JItemPanel> ipl=new ArrayList<JItemPanel>();
					   if(il!=null)
			    	   for(JItemPanel ip:il)
			    		   if(ip.isChecked()) {
			    			   ipl.add(ip);
			    		   }
					   for(JItemPanel ip:ipl)
						   deleteItem(ip);
				}}
			} );
		   menu.add(deleteItem); 
		return menu;
	}
	public abstract JItemPanel[] getItems(JMainConsole console, String locator$); 
    public void addItem(JItemPanel item) {
    	//System.out.println("JItemsListPanel: addItem:BEGIN");
     	item.setList(this);
    	il.add(item);
    	JItemPanel[]ia=new JItemPanel[il.size()];
    	//System.out.println("JItemsListPanel: addItem:display="+display$);
    	il.toArray(ia);
		for(JItemPanel i:il) {
			listPane.add(i);
			listPane.revalidate();
			listPane.repaint();
		}
    }
    public void clear() {
    	try {
    	ArrayList<JItemPanel >ipl=new ArrayList<JItemPanel >();
    	
    	for(JItemPanel ip:il) {
    		ipl.add(ip);
    	}
    	for(JItemPanel ip:ipl) {
    		deleteItem(ip);
    	}
    	}catch(Exception e) {
    		System.out.println("JItemsListPanel:clear="+e.toString());	
    	}
    		
    }
    protected void deleteItem(JItemPanel item) {
    	//System.out.println("JItemsListPanel: deleteItem="+item.getTitle());
    	for(JItemPanel ip:il)
    		if(item.getTitle().equals(ip.getTitle())) {
    			try {
    			il.remove(ip);
    			handleDelete(ip);
    			listPane.remove(ip);
    			listPane.revalidate();
    			listPane.repaint();
    			}catch(Exception e) {
    				System.out.println("JItemsListPanel: deleteItem:"+e.toString());
    			}
    			return;
    		}
    	
    }
   protected boolean hasChecked() {
	   for(JItemPanel ip:il)
		   if(ip.isChecked()) {
			  return true;
		   }
	   return false;
   }
   protected JItemPanel[] getChecked() {
	   ArrayList<JItemPanel>ipc=new ArrayList<JItemPanel>();
	   for(JItemPanel ip:il)
		   if(ip.isChecked()) {
			  ipc.add(ip);
		   }
	 JItemPanel [] ipa=new JItemPanel[ipc.size()];
	return ipc.toArray(ipa); 
   }
protected void handleAdd(JItemPanel item) {};
protected void handleDelete(JItemPanel item) {};
public static String classLocator() {
Properties locator=new Properties();
locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
locator.put(Locator.LOCATOR_TITLE,"Items");
locator.put(IconLoader.ICON_FILE,"item.png");
locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
locator.put(JContext.INSTANCE, KEY); 
locator.put(JContext.PARENT, JAdminPanel.KEY);
locator.put(JContext.DEFAULT_PARENT, JAdminPanel.KEY);
 return Locator.toString(locator);
}
public static JItemPanel[] sortItems(JItemPanel[] ipa) {
	if(ipa==null||ipa.length<2)
		return ipa;
	try {
	Hashtable <String,JItemPanel>ipt=new Hashtable <String,JItemPanel>();
	ArrayList<String>sl=new ArrayList<String>();
	String title$;
	for(JItemPanel ip:ipa) {
		if(ip==null)
			continue;
		title$=ip.getTitle();
		if(title$!=null) {
			sl.add(title$);
			ipt.put(title$, ip);
		}
	}
	String[]sa=new String[sl.size()];
	sl.toArray(sa);
	Arrays.sort(sa);
	JItemPanel[]ipsa=new JItemPanel[sa.length];
	 for(int i=0;i<sa.length;i++)
		 ipsa[i]=ipt.get(sa[i]);
	 return ipsa;
	}catch(Exception e) {
		System.out.println("JItemsListPanel:sortItems:"+e.toString());
		return ipa;
	}
}

}
