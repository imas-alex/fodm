package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import gdt.base.generic.EventHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;

public class JDisplayList extends JItemsListPanel {
	private static final long serialVersionUID = 1L;
	public static final String ITEM_DISPOSED="item disposed";
	JMenuItem disposeItem;
	JMenuItem toFrontItem;
	JMenuItem copyItem;
	public JDisplayList(JMainConsole console) {
		super(console);
		JDisplay.JDisplayItem[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JDisplay.JDisplayItem ip:ipa) {
				addItem(ip);
			}
		console.getEntigrator().addPropertyChangeListener(this);
	}
	public JDisplayList(JMainConsole console,String locator$) {
		super(console,locator$);
		JDisplay.JDisplayItem[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JDisplay.JDisplayItem ip:ipa) {
				addItem(ip);
			}
		console.getEntigrator().addPropertyChangeListener(this);
	}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Delete");
		menu.addMenuListener(new MenuListener(){
		     @Override
		     public void menuCanceled(MenuEvent e) {
		     		     }
		     @Override
		     public void menuDeselected(MenuEvent e) {
		     }
			@Override
			public void menuSelected(MenuEvent arg0) {
			//	System.out.println("JDisplayList:menu selected");
				if(hasChecked()) {
					disposeItem.setEnabled(true);
					toFrontItem.setEnabled(true);
					//copyItem.setEnabled(true);
				}
				else {
					disposeItem.setEnabled(false);
					toFrontItem.setEnabled(false);
				}
				if(il.size()<1) {
					selectItem.setEnabled(false);
					unselectItem.setEnabled(false);
				}else {
					selectItem.setEnabled(true);
					unselectItem.setEnabled(true);
				}
					
				}
			});
		
		menu.addSeparator();
		disposeItem = new JMenuItem("Dispose");
		disposeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
                	int response = JOptionPane.showConfirmDialog(JDisplayList.this, "Dispose selected displays  ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		  		    if (response == JOptionPane.NO_OPTION)
		  		    	return;
				    	dispose();
				    	
			}
		});
		menu.add(disposeItem);
		toFrontItem = new JMenuItem("To front");
		toFrontItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					toFront();
			}
		});
		menu.add(toFrontItem);
		return menu;
	}
	@Override
	public JDisplay.JDisplayItem[] getItems(JMainConsole console, String locator$) {
		JContextContainer[] displays=console.getContainers();
	//	System.out.println("JDisplayList:getItems:displays="+displays.length);
		if(displays==null||displays.length<1) {
			System.out.println("JDisplayList:getItems:no containers");
			return null;
		}
	//	System.out.println("JDisplayList:getItems:containers="+displays.length);
		JDisplay.JDisplayItem ip;
		Properties props=new Properties();
		props.put(JItemPanel.ITEM_CHECKABLE,Locator.LOCATOR_TRUE);
		props.put(JItemPanel.ITEM_CHECKED,Locator.LOCATOR_FALSE);
		ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
		for(JContextContainer display:displays) {
		//System.out.println("JDisplayList:getItems:container locator="+containerLocator$);
			try {
			ip=(JDisplay.JDisplayItem)display.getItemPanel();
			if(ip==null) {
				//System.out.println("JDisplayList:getItems:ip null in display="+display.getClass().getName());
				continue;
			}
			String displyClass$=ip.getClass().getName();
			if(ip!=null) {
//				System.out.println("JDisplayList:getItems:ip="+ip.getClass().getName());
				if("gdt.gui.generic.JDisplay$JDisplayItem".equals(displyClass$))
			    ipl.add(ip);
				if("gdt.gui.facet.collage.JCollageDisplay$JCollageItem".equals(displyClass$))
				    ipl.add(ip);
				if("gdt.gui.facet.rack.JRackDisplay$JRackItem".equals(displyClass$))
				    ipl.add(ip);
			}
			}catch(Exception ee) {
				System.out.println("JDisplayList:getItems:"+ee.toString());
			}
		}
		JDisplay.JDisplayItem[] ipa=new JDisplay.JDisplayItem[ipl.size()];
		ipl.toArray(ipa);
		return sortItems(ipa);
		//return ipa;

	}
	private JDisplay.JDisplayItem[] sortItems(JDisplay.JDisplayItem[] ida){
		if(ida==null)
			return null;
		HashMap<JItemPanel ,JDisplay.JDisplayItem>map=new HashMap<JItemPanel,JDisplay.JDisplayItem>();
	    JItemPanel[] ipa=new JItemPanel[ida.length];
	    for(int i=0;i<ida.length;i++) {
	    	ipa[i]=(JItemPanel)ida[i];
	    	map.put(ipa[i],ida[i]);
	    }
	    ipa=sortItems(ipa);
	    for(int i=0;i<ipa.length;i++)
	    	ida[i]=map.get(ipa[i]);
	    return ida;
	}
	private void dispose() {
		ArrayList<String>sl=new ArrayList<String>();
    	for(JItemPanel ip:il) {
    		if(!ip.isChecked())
    		   continue;
    		sl.add(ip.getLocator());
    	}
    	JContextContainer[] ca=console.getContainers();
    	for(String s:sl) {
    		//System.out.println("JDisplayList:dispose:ip="+s);
    		String entityLabel$=Locator.getProperty(s,Locator.LOCATOR_TITLE);
    		//System.out.println("JDisplayList:dispose:entity="+entityLabel$);
    		if(ca!=null)
    			for(JContextContainer c:ca) {
    			    String contextLocator$=c.getContext().getLocator();
    			    String contextEntity$=Locator.getProperty(contextLocator$,Entigrator.ENTITY_LABEL);
    			//    System.out.println("JDisplayList:dispose:entity selector="+entityLabel$+"  context="+contextEntity$);
    			    if(entityLabel$.equals(contextEntity$)) {
    			    		c.dispose();
    			            console.removeContainer(c);
    			          
    			    }
    			           // break;
    			     }
    	}
    	clear();
    	JDisplay.JDisplayItem[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JDisplay.JDisplayItem ip:ipa) {
				addItem(ip);
			}
	}
	private void toFront() {
		ArrayList<String>sl=new ArrayList<String>();
    	for(JItemPanel ip:il) {
    		if(!ip.isChecked())
    		   continue;
    		sl.add(ip.getLocator());
    	}
    	JContextContainer[] ca=console.getContainers();
    	for(String s:sl) {
    		//System.out.println("JDisplayList:dispose:ip="+s);
    		String entityLabel$=Locator.getProperty(s,Locator.LOCATOR_TITLE);
    		//System.out.println("JDisplayList:dispose:entity="+entityLabel$);
    		if(ca!=null)
    			for(JContextContainer c:ca) {
    			    String contextLocator$=c.getContext().getLocator();
    			    String contextEntity$=Locator.getProperty(contextLocator$,Entigrator.ENTITY_LABEL);
    			//    System.out.println("JDisplayList:dispose:entity selector="+entityLabel$+"  context="+contextEntity$);
    			    if(entityLabel$.equals(contextEntity$)) {
    			    		c.toFront();
    			    }
    			     }
    	}
	}
	@Override
	protected void handleDelete(JItemPanel item) {
	//	System.out.println("JDisplayList:handleDone:locator="+locator$);
		String container$=Locator.getProperty(locator$,JContextContainer.CONTAINER);
		console.removeContainer(container$);
	};
public static String classLocator() {
	 Properties locator=new Properties();
     locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
     locator.put(CONTEXT_CLASS,"gdt.gui.console.JDisplayList");
     locator.put(Locator.LOCATOR_TITLE,"Display");
     locator.put(IconLoader.ICON_FILE,"display.png");
 	 locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
      locator.put(NON_REMOVABLE,Locator.LOCATOR_TRUE);
      locator.put(PARENT,JAdminPanel.KEY);
  return Locator.toString(locator);
}
	@Override
	public String getClassLocator() {
	  return classLocator();
	}
@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
@Override
public void propertyChange(PropertyChangeEvent evt) {
	System.out.println("JDisplayList:propertyChange:evt="+EventHandler.getLocator(console.getEntigrator()));
    String locator$=EventHandler.getLocator(console.getEntigrator());
    String message$=Locator.getProperty(locator$, EventHandler.MESSAGE);
    if(ITEM_DISPOSED.equals(message$)) {
    	clear();
    	JDisplay.JDisplayItem[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JDisplay.JDisplayItem ip:ipa) {
				addItem(ip);
			}
    }
}
}
