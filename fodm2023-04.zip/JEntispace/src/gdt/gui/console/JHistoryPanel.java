package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
import gdt.gui.generic.JTextEditor; 

public class JHistoryPanel extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_nM9g_LHcE5sv5skKFPHYKlilUFU";
   private String[] exa=new String[] {
	  JAdminPanel.KEY,
	  JHistoryPanel.KEY,
	  JDesignPanel.KEY,
	  JDesignActions.KEY,
	  JDesignActions.ADD_PROPERTY_INSTANCE,
	  JDesignActions.ADD_VALUE_INSTANCE,
	  JDesignActions.ASSIGN_VALUE_INSTANCE,
	  JDesignActions.CLEAR_VALUE_INSTANCE,
	  JDesignActions.DELETE_PROPERTY_INSTANCE,
	  JDesignActions.DELETE_VALUE_INSTANCE,
	  JDesignActions.EDIT_PROPERTY_INSTANCE,
	  JDesignActions.EDIT_VALUE_INSTANCE,
	  JDesignActions.TAKEOFF_VALUE_INSTANCE,
	  JSearchPanel.KEY,
	  JTextEditor.KEY
	  };
boolean hasSelected=false;
	public JHistoryPanel(JMainConsole console, String locator$) {
		super(console, locator$);
		nomenu=false;
		JItemPanel[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa) {
				addItem(ip);
			}
	}
    private boolean exclude(String key$) {
    	try {
    		if(exa==null)
    			return false;
    	for(String s:exa) {
    		if(key$.equals(s))
    			return true;
    	}
    	}catch(Exception e) {
    		System.out.println("JHistoryPanel:exlude:"+e.toString()+" key="+key$);
    	}
    	return false;
    }
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		try {
		String[] sa=SessionHandler.listHistoryItems(console.getEntigrator());
		if(sa==null) {
			System.out.println("JHistoryPanel:getItems:no history items");
			return null;
		}
		int cnt=sa.length;
		String itemLocator$;
		String thisInstance$=getInstance();
		String thisLocator$=getLocator();
		SessionHandler.putLocator(console.getEntigrator(), thisLocator$);
		for(int i=0;i<cnt;i++) {
			//System.out.println("JHistoryPanel:getItems:sa["+i+"]="+sa[i]);
			if(exclude(sa[i])) {
				System.out.println("JHistoryPanel:getItems:excluded="+sa[i]);
				continue;
			}
			itemLocator$=SessionHandler.getHistoryInstanceLocator(console.getEntigrator(), sa[i]);
			if(itemLocator$==null) {
			//	System.out.println("JHistoryPanel:getItems:cannot get locator sa="+sa[i]);
				continue;
			}
			itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE,Locator.LOCATOR_TRUE);
			itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE,Locator.getProperty(itemLocator$, SessionHandler.ITEM_TITLE));
			itemLocator$=Locator.append(itemLocator$,PARENT,thisInstance$);
			JHistoryItem item=new JHistoryItem(console,this,itemLocator$);
			il.add(item);
		}
		cnt=il.size();
		if(cnt<1)
			return null;
		JHistoryItem []ha=new JHistoryItem[cnt];
		il.toArray(ha);
		return ha;
		}catch(Exception e) {
				System.out.println("JHistoryPanel:getItems:"+e.toString());
			}
		return null;
		}
	@Override
	public String getLocator() {
		  return classLocator();
	  }
	@Override
	public String getTitle() {
		return "History";
	}
	@Override
	public String getSubtitle() {
		return "Database:"+console.getEntigrator().getEntihome();
	}

	public JMenu getContextMenu() {
    	//System.out.println("JItemsListPanel:getContextMenu:BEGIN");	
	   menu=super.getContextMenu();
	   menu.addSeparator();
	  JMenuItem clearItem = new JMenuItem("Clear session");
		clearItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int response = JOptionPane.showConfirmDialog(JHistoryPanel.this, "Clear session history  ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		  		  if (response == JOptionPane.YES_OPTION) { 
		  			SessionHandler.forgetOld(console.getEntigrator(),5);
		  		  }
			
			}
				});
		menu.add(clearItem);
		return menu;
	}

	@Override
	protected void handleDelete(JItemPanel item) {
		//System.out.println("JHistoryPanel:handleDelete:locator="+item.getLocator());
		String instance$=Locator.getProperty(item.getLocator(), INSTANCE);
		SessionHandler.removeHistoryInstance(console.getEntigrator(), instance$);
	};
		private   class JHistoryItem extends JItemPanel{
			private static final long serialVersionUID = 1L;
			public JHistoryItem(JMainConsole console,JContext context, String locator$) {
				super(console,context, locator$);
				//System.out.println("JHistoryItem::locator="+locator$);
			}
			public JPopupMenu getPopup(JMainConsole console,String locator$) {
			return null;	
			}
			@Override
			public void onClick(JMainConsole console, String locator$) {
//				System.out.println("JHistoryPanel:onClick:locator="+locator$);
				JContext context=JContext.build(console, locator$);
				if(context==null) {
					System.out.println("JHistoryPanel:onClick:cannot build context at locator="+locator$);
				}
				console.replaceContext(JHistoryPanel.this,context);
			}
		}
		public static String classLocator() {
			 Properties locator=new Properties();
		     locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
		     locator.put(CONTEXT_CLASS,"gdt.gui.console.JHistoryPanel");
		     locator.put(Locator.LOCATOR_TITLE,"History");
		     locator.put(IconLoader.ICON_FILE,"track.png");
		 	 locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		 	 locator.put(PARENT,JAdminPanel.KEY);
		 	 locator.put(INSTANCE,KEY);
		      locator.put(NON_REMOVABLE,Locator.LOCATOR_TRUE);
		  return Locator.toString(locator);
	}
		@Override
		public String getClassLocator() {
			return classLocator();
		}
		@Override
		public String reply(JMainConsole console, String locator$) {
			return null;
		}
	}

