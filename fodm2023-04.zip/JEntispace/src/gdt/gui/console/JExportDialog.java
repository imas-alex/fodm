package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.FileTool;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.BoxLayout;

public class JExportDialog extends JDialog{
	private static final long serialVersionUID = 1L;
	private JTextField txtName;
	private JComboBox <String> cbxTarget;
	private JTextField txtPath;
	private JPanel desk;
	private JButton btnCancel;
	private JButton btnExport;
	JMainConsole console;
	public JExportDialog(JMainConsole console) {
		this.console=console;
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.NORTH);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.rowHeights = new int[]{19, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, Double.MIN_VALUE, 0.0, 0.0, 1.0};
		panel.setLayout(gbl_panel);
		
		JLabel lblName = new JLabel("Name");
		GridBagConstraints gbc_lblName = new GridBagConstraints();
		gbc_lblName.fill = GridBagConstraints.BOTH;
		gbc_lblName.insets = new Insets(5, 5, 5, 5);
		gbc_lblName.gridx = 0;
		gbc_lblName.gridy = 0;
		panel.add(lblName, gbc_lblName);
		
		txtName = new JTextField();
		GridBagConstraints gbc_txtName = new GridBagConstraints();
		gbc_txtName.fill = GridBagConstraints.BOTH;
		gbc_txtName.insets = new Insets(5, 5, 5, 0);
		gbc_txtName.gridx = 1;
		gbc_txtName.gridy = 0;
		panel.add(txtName, gbc_txtName);
		
		JLabel lblTarget = new JLabel("Name");
		GridBagConstraints gbc_lblTarget = new GridBagConstraints();
		gbc_lblTarget.fill = GridBagConstraints.BOTH;
		gbc_lblTarget.insets = new Insets(5, 5, 5, 5);
		gbc_lblTarget.gridx = 0;
		gbc_lblTarget.gridy = 1;
		panel.add(lblTarget, gbc_lblTarget);
		
		cbxTarget = new JComboBox<String>();
		cbxTarget.setModel(new DefaultComboBoxModel<String>(new String[] {"Folder", "Zip"}));
		
		GridBagConstraints gbc_cbxTarget = new GridBagConstraints();
		gbc_cbxTarget.fill = GridBagConstraints.BOTH;
		gbc_cbxTarget.insets = new Insets(5, 5, 5, 0);
		gbc_cbxTarget.gridx = 1;
		gbc_cbxTarget.gridy = 1;
		panel.add(cbxTarget, gbc_cbxTarget);
		
		JLabel lblPath = new JLabel("Path");
		GridBagConstraints gbc_lblPath = new GridBagConstraints();
		gbc_lblPath.fill = GridBagConstraints.BOTH;
		gbc_lblPath.insets = new Insets(5, 5, 5, 5);
		gbc_lblPath.gridx = 0;
		gbc_lblPath.gridy = 2;
		panel.add(lblPath, gbc_lblPath);
		
		txtPath = new JTextField();
		GridBagConstraints gbc_txtPath = new GridBagConstraints();
		gbc_txtPath.fill = GridBagConstraints.BOTH;
		gbc_txtPath.insets = new Insets(5, 5, 5, 0);
		gbc_txtPath.gridx = 1;
		gbc_txtPath.gridy = 2;
		panel.add(txtPath, gbc_txtPath);
		
		desk = new JPanel();
		GridBagConstraints gbc_desk = new GridBagConstraints();
		gbc_desk.insets = new Insets(5, 5, 5, 5);
		gbc_desk.gridx = 1;
		gbc_desk.gridy = 4;
		panel.add(desk, gbc_desk);
		desk.setLayout(new BoxLayout(desk, BoxLayout.X_AXIS));
		btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			    dispose();
			}
		});
		desk.add(btnCancel);
		btnExport = new JButton("Export");
		btnExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
				Entigrator entigrator=console.getEntigrator();
				Sack session=SessionHandler.getSession(entigrator);
				//String path$=txtPath.getText();
				String path$=session.getElementItemAt(SessionHandler.PARAMETER, "entihome");
				JFileChooser chooser = new JFileChooser(); 
				if(path$==null) {
					path$= System.getProperty("user.home");
				    txtPath.setText(path$);
				}
//				System.out.println("JExportDialog:set path="+path$);
	  		    chooser.setCurrentDirectory(new java.io.File(path$));
	  		    chooser.setDialogTitle("Export directory");
	  		    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	  		  if (chooser.showOpenDialog(lblPath) == JFileChooser.APPROVE_OPTION) { 
	  			File selection=chooser.getSelectedFile();
	  			System.out.println("JExportDialog:path="+selection.getPath());
	  		    path$=selection.getPath();
	  		    if(!session.existsElement("export"))
	  		    	session.createElement("export");
	  		    session.putElementItem("export", new Core(null,"path",path$));
	  		    entigrator.putEntity(session);
	  		    txtPath.setText(path$);
	  		   if("Folder".equals((String)cbxTarget.getSelectedItem())) {
	  		    String target$=path$+"/"+txtName.getText();
	  		    File target=new File(target$);
	  		    target.mkdir();
	  		    String entihome$=entigrator.getEntihome();
	  		    FileTool.copyAll(entihome$, target$);
	  		   }
	  		  }
	  		if("Zip".equals((String)cbxTarget.getSelectedItem())) {
	  			toZip(path$+"/"+txtName.getText()+".zip", entigrator.getEntihome());
	  		}
				}catch(Exception e) {
					System.out.println("JExportDialog:export:"+e.toString());
				}
				dispose();
			}
		});
		desk.add(btnExport);
		try {
			Entigrator entigrator=console.getEntigrator();
			Sack session=SessionHandler.getSession(entigrator);
			String path$=session.getElementItemAt("export", "path");
			if(path$==null)
				path$= System.getProperty("user.home");
			txtPath.setText(path$);
			File entihome=new File(entigrator.getEntihome());
			Path basePath= entihome.toPath();
			String base$=basePath.getFileName().toString();
			Calendar cal = Calendar.getInstance();
		    cal.setTime(Date.from(Instant.now()));
		    String record$ = String.format(
		             "%1$tY-%1$tm-%1$td-%1$tk-%1$tS-%1$tp", cal);
			txtName.setText(base$+"_"+record$);
		}catch(Exception e) {
			System.out.println("JExportDialog:"+e.toString());	
		}
		pack();
		revalidate();
		repaint();
	}
	private static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
        if (fileToZip.isHidden()) {
            return;
        }
        if (fileToZip.isDirectory()) {
            if (fileName.endsWith("/")) {
                zipOut.putNextEntry(new ZipEntry(fileName));
                zipOut.closeEntry();
            } else {
                zipOut.putNextEntry(new ZipEntry(fileName + "/"));
                zipOut.closeEntry();
            }
            File[] children = fileToZip.listFiles();
            for (File childFile : children) {
                zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
            }
            return;
        }
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileName);
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        fis.close();
    }
	public static void  toZip(String archive$, String entihome$) {
		FileOutputStream fos =null;
		ZipOutputStream zipOut =null;
       try {
		fos = new FileOutputStream(archive$);
        zipOut = new ZipOutputStream(fos);
        File fileToZip = new File(entihome$);
        zipFile(fileToZip, fileToZip.getName(), zipOut);
        zipOut.close();
        fos.close();
       }catch(Exception e) {
    	   System.out.println("JExportDialog:toZip:"+e.toString());
       }
	    }
}
