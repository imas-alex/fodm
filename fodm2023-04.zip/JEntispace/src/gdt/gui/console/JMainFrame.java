package gdt.gui.console;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.border.BevelBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import gdt.base.facet.BaseHandler;
import gdt.base.facet.ProjectHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JContextContainer;
import gdt.gui.generic.JItemPanel;
import javax.swing.JPanel;
import javax.swing.BoxLayout;

public class JMainFrame extends JFrame implements JContextContainer {
	private static final long serialVersionUID = 1L;
	JMainConsole console; 
	JMenuBar menuBar;
	Container container;
	public 	 JMainFrame(JMainConsole console) {
	this.console=console;
	menuBar = new JMenuBar();
	setJMenuBar(menuBar);
	JMenu mainMenu = new JMenu("Main");
	menuBar.add(mainMenu);
	JMenuItem basesItem = new JMenuItem("Bases");
	basesItem.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
		//	System.out.println("MainConsole:open");  
			Entigrator entigrator=console.getEntigrator();
			if(entigrator==null) {
				System.out.println("JMainFrame:Bases:entigrator is null");
				//entigrator=JBaseList.setDefaultBase();
				entigrator=BaseHandler.setDefaultBase();
				console.setEntigrator(entigrator.getEntihome());
			}
			String path$=null;
			if(entigrator!=null) {
			Sack session=SessionHandler.getSession(console.getEntigrator());
			if(session!=null)
			   path$=session.getElementItemAt(SessionHandler.PARAMETER, "entihome");
			}
			JFileChooser chooser = new JFileChooser(); 
		   if(path$==null)
			chooser.setCurrentDirectory(new java.io.File(System.getProperty("user.home")+"/.entigrator"));
		   else
			   chooser.setCurrentDirectory((new java.io.File(path$)).getParentFile());  
		    chooser.setDialogTitle("Bases directory");
		    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		    chooser.setAcceptAllFileFilterUsed(false);
		    
		    if (chooser.showOpenDialog(JMainFrame.this) == JFileChooser.APPROVE_OPTION) { 
		    	File selection=chooser.getSelectedFile();
		    	String basesLocator$=JBaseList.classLocator();
		    	//System.out.println("JMainConsole:bases:base locaotr="+JBaseList.classLocator()+" selection="+selection.getPath());
		    	basesLocator$=Locator.append(basesLocator$, JBaseList.DIRECTORY, selection.getPath());
		    	JBaseList baseList=new JBaseList(console,basesLocator$);
		    	putContext(baseList);
		      }
		}
	} );
	mainMenu.add(basesItem);
	JMenuItem consoleItem= new JMenuItem("Console");
	consoleItem.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			if(console.getEntigrator()==null)
				return;
			String adminLocator$= JAdminPanel.classLocator();
			if(console.getEntigrator().getEntihome()==null)
				return;
			adminLocator$=Locator.append(adminLocator$, Locator.LOCATOR_SUBTITLE, console.getEntigrator().getEntihome());
			//System.out.println("JMainConsole:Admin:adminLocator="+adminLocator$);
			JAdminPanel adminPanel=new JAdminPanel(console,adminLocator$);
			SessionHandler.putLocator(console.getEntigrator(),adminLocator$);
			putContext(adminPanel);
		}
	} );
	mainMenu.add(consoleItem);
	JMenuItem rebuild= new JMenuItem("Rebuild");
	rebuild.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			int response = JOptionPane.showConfirmDialog(JMainFrame.this, "Rebuild index ?", "Confirm",
			        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		   if (response == JOptionPane.YES_OPTION) { 
		   if(console.getEntigrator()!=null) {
			  Sack session=SessionHandler.getSession(console.getEntigrator());
			  if(session!=null)
				  console.getEntigrator().deleteEntity(session.getKey());
			  SessionHandler.forgetOld(console.getEntigrator(),0);
			  console.getEntigrator().rebuildIndex();
			 
		   }
		   }
		}
	} );
	mainMenu.add(rebuild);
	mainMenu.addSeparator();  
	   JMenuItem importItem = new JMenuItem("Import");
		   importItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  System.out.println("JMainConsole:import");
			JFileChooser chooser = new JFileChooser(); 
		    chooser.setCurrentDirectory(new java.io.File(System.getProperty("user.home")));
		    chooser.setDialogTitle("Bases directory");
		    chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		    chooser.addChoosableFileFilter(new ProjectHandler.ZipFilter());
		    chooser.setAcceptAllFileFilterUsed(true);
		    if (chooser.showOpenDialog(JMainFrame.this) == JFileChooser.APPROVE_OPTION) { 
		    	File selection=chooser.getSelectedFile();
		    	String zip$=selection.getPath();
		    	String[] sa=ProjectHandler.unzip(zip$, console.getEntigrator());
		    	if(sa!=null&&sa.length>0) {
		    		Sack entity;
		    		for(String s:sa) {
		    		    entity=console.getEntigrator().getRawEntity(s);
		    		    if(entity!=null) {
		    		    	console.getEntigrator().putEntity(entity);
		    		    	console.getEntigrator().reindexEntity(entity);
		    		    }
		    		}
		    	}
		      }	
			}
		} );
		mainMenu.add(importItem);
		JMenuItem exportItem = new JMenuItem("Export");
	   exportItem.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			JExportDialog exportDialog=new JExportDialog(console);
			exportDialog.setLocationRelativeTo(JMainFrame.this);
			exportDialog.setVisible(true);
		}
  		} );
	mainMenu.add(exportItem);
	mainMenu.addSeparator();
	
	JMenuItem settings = new JMenuItem("Settings");
	settings.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			Properties baseLocator=new Properties();
			baseLocator.put(Entigrator.ENTIHOME,console.getEntigrator().getEntihome());
			String baseLocator$=Locator.toString(baseLocator);
			JSettingsDialog settingsDialog=new JSettingsDialog(console,baseLocator$);
			settingsDialog.setLocationRelativeTo(JMainFrame.this);
			settingsDialog.setVisible(true);
		}
	} );
	mainMenu.add(settings);
	JMenuItem exit = new JMenuItem("Exit");
	exit.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
		  System.out.println("JMainConsole:exit");
			if(console.getEntigrator()!=null) {
	    	    JContext context=getContext();
	    	    if(context!=null)
	    	    	 SessionHandler.saveLocator(context.getLocator());
	    	     SessionHandler.store(console.getEntigrator());
	    	     console.getEntigrator().close();
			}
		   JMainFrame.this.dispose();
		}
	} );
	mainMenu.add(exit);
	
	mainMenu.addMenuListener(new MenuListener(){
	     @Override
	     public void menuCanceled(MenuEvent e) {
	     		     }
	     @Override
	     public void menuDeselected(MenuEvent e) {
	     		     }
		@Override
		public void menuSelected(MenuEvent arg0) {
			if(console.getEntigrator()==null) {
				rebuild.setEnabled(false);
				importItem.setEnabled(false);
				consoleItem.setEnabled(false);
				exportItem.setEnabled(false);
				settings.setEnabled(false);
			}else {
				importItem.setEnabled(true);
				rebuild.setEnabled(true);
				consoleItem.setEnabled(true);
				exportItem.setEnabled(true);
				settings.setEnabled(true);
			}
		}
	 });
	container = new Container();
	getContentPane().add(container);
	getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
}
	public void clearContextMenu(){
		int cnt=menuBar.getComponentCount();
		ArrayList<JComponent>cl=new ArrayList<JComponent>();
		for(int i=0;i<cnt;i++){
			String menuTitle$=((JMenu)menuBar.getComponent(i)).getText();
	        if("Context".equals(menuTitle$)||"Runtime".equals(menuTitle$))
	         	cl.add((JComponent)menuBar.getComponent(i));	
		}
		JComponent[] ca=cl.toArray(new JComponent[0]);
		if(ca!=null)
			for(JComponent jc:ca)
				menuBar.remove(jc);
	}
@Override
	public void putContext(JContext context) {
	container.putContext(context);	
	}

	@Override
	public JContext getContext() {
		return container.getContext();
	}
	@Override
	public String getLocator() {
		return null;
	}
	
	@Override
	public void setSubtitle(String subtitle$) {
		container.setSubtitle(subtitle$);
	}
	@Override
	public JItemPanel getItemPanel() {
        String locator$=getLocator();
        System.out.println("JMainFrame:getItemPanel:locator="+locator$);
		return null;
	}
public JContextContainer getContextContainer() {
	return container;
}
 class Container extends JPanel implements JContextContainer{
	 private static final long serialVersionUID = 1L;
	JContext context;
	 JLabel subtitle;
	 
	public  Container() {
		super();
		setLayout(new BorderLayout());
		subtitle=new JLabel();
		subtitle = new JLabel();
		subtitle.setAlignmentX(Component.RIGHT_ALIGNMENT);
		subtitle.setLabelFor(subtitle);
		subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
		subtitle.setOpaque(true);
		subtitle.setBackground(Color.BLACK);
		subtitle.setForeground(Color.WHITE);
		add(subtitle,BorderLayout.CENTER);
		subtitle.setText("Subtitle");
		//System.out.println("JMainFrame:container");
		if(console!=null&&console.getEntigrator()!=null) {
		String subtitle$=console.getEntigrator().getEntihome();
		subtitle.setText(subtitle$);
		}
		if(context!=null) 
			subtitle.setText(context.getSubtitle());
	}
	@Override
	public void putContext(JContext context) {
		this.context=context;
		this.removeAll();
		add(context,BorderLayout.CENTER);
		//add(context);
		clearContextMenu();
		if(context.getContextMenu()!=null)
			if(menuBar!=null)
		   menuBar.add(context.getContextMenu());
		String title$=context.getTitle();
		if(title$!=null)
			setTitle(title$);
		String subtitle$=console.getEntigrator().getEntihome();
		String contextSubtitle$=context.getSubtitle();
		if(contextSubtitle$!=null)
			subtitle$=contextSubtitle$;
			subtitle.setText(subtitle$);
		add(subtitle,BorderLayout.SOUTH);
		JMainFrame.this.revalidate();
		JMainFrame.this.repaint();
		
	}
	@Override
	public JContext getContext() {
		return context;
	}
		@Override
	public void dispose() {
	}

	@Override
	public void toFront() {
	}
	@Override
	public void setTitle(String title$) {
		JMainFrame.this.setTitle(title$);
	}
	@Override
	public void setSubtitle(String subtitle$) {
		subtitle.setText(subtitle$);
	}
	@Override
	public String getLocator() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JItemPanel getItemPanel() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getItem() {
		// TODO Auto-generated method stub
		return null;
	}
 }
@Override
public String getItem() {
	// TODO Auto-generated method stub
	return null;
}
}
