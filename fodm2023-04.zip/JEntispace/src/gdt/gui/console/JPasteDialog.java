package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import javax.swing.JPanel;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JRadioButton;
import java.awt.Insets;
import javax.swing.SwingConstants;
import gdt.base.generic.Locator;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JPasteDialog extends JDialog{
	private static final long serialVersionUID = 1L;
	String locator$;
	JMainConsole console;
	public JPasteDialog(JMainConsole console,String locator$) {
		this.console=console;
		this.locator$=locator$;
		setTitle("Paste entities");
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.rowHeights = new int[] {0, 0, 0, 0, 0, 5};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0};
		setLayout(gridBagLayout);
		
		JRadioButton addButton = new JRadioButton("Add");
		addButton.setSelected(true);
		addButton.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_addButton = new GridBagConstraints();
		gbc_addButton.insets = new Insets(0, 0, 5, 5);
		gbc_addButton.anchor=GridBagConstraints.LINE_START; 
		gbc_addButton.gridx = 0;
		gbc_addButton.gridy = 0;
		add(addButton, gbc_addButton);
		
		
		JRadioButton mergeButton = new JRadioButton("Merge");
		GridBagConstraints gbc_mergeButton = new GridBagConstraints();
		gbc_mergeButton.anchor=GridBagConstraints.LINE_START; 
		gbc_mergeButton.insets = new Insets(0, 0, 5, 5);
		gbc_mergeButton.gridx = 0;
		gbc_mergeButton.gridy = 1;
		add(mergeButton, gbc_mergeButton);
		
		
		
		JRadioButton replaceButton = new JRadioButton("Replace");
		GridBagConstraints gbc_replaceButton = new GridBagConstraints();
		gbc_replaceButton.anchor=GridBagConstraints.LINE_START; 
		gbc_replaceButton.insets = new Insets(0, 0, 5, 5);
		gbc_replaceButton.gridx = 0;
		gbc_replaceButton.gridy = 2;
		add(replaceButton, gbc_replaceButton);
		
		JCheckBox clearClipboard = new JCheckBox("Clear clipboard");
		GridBagConstraints gbc_cbxClearClipboard = new GridBagConstraints();
		gbc_cbxClearClipboard.anchor=GridBagConstraints.LINE_START; 
		gbc_cbxClearClipboard.insets = new Insets(0, 0, 5, 5);
		gbc_cbxClearClipboard.gridx = 0;
		gbc_cbxClearClipboard.gridy = 3;
		add(clearClipboard, gbc_cbxClearClipboard);
		
		JPanel desk=new JPanel();
		GridBagConstraints gbc_desk = new GridBagConstraints();
		gbc_desk.insets = new Insets(0, 0, 5, 0);
		gbc_desk.fill = GridBagConstraints.BOTH;
		gbc_desk.gridx = 0;
		gbc_desk.gridy = 4;
		add(desk, gbc_desk);
		
		
		JButton btnPaste = new JButton("Paste");
		btnPaste.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			   String locator$=JPasteDialog.this.locator$;
			   String mode$=JBaseList.MODE_ADD;
			   if(mergeButton.isSelected())
				   mode$=JBaseList.MODE_MERGE;
			   if(replaceButton.isSelected())
				   mode$=JBaseList.MODE_REPLACE;
			   String clear$=Locator.LOCATOR_FALSE;
			   if(clearClipboard.isSelected())
				   clear$=Locator.LOCATOR_TRUE;
			   locator$=Locator.append(locator$,JBaseList.MODE ,mode$);
			   locator$=Locator.append(locator$,JBaseList.CLEAR_CLOPBOARD ,clear$);
			   JBaseList.pasteEntities(console, locator$);
			   dispose();
			}
		});
		
		desk.add(btnPaste);
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			    dispose();
			}
		});
		desk.add(btnCancel);
		ButtonGroup group=new ButtonGroup();
		group.add(addButton);
		group.add(mergeButton);
		group.add(replaceButton);
		pack();
		revalidate();
		repaint();
	}

}
