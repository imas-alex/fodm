package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.record;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.JContext;
import java.awt.Dimension;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.Border;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.gauge.Meter;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube.DiagrammPanel;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube.JDiagrammDialog;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube.TubePanel;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Instrument;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Logger;
import javax.swing.JSlider;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class JRecordViewer extends JContext {
	private static final long serialVersionUID = 1L;
	public static final String RECORD_FACET_TYPE="record";
	public static final String RECORD_FACET_NAME="Record";
	public static final String RECORD_FACET_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.record.JRecordViwer";
	public static final String KEY="_9_S6UBdJPgqJQSFwr0jRlE_9L_SSU";
	
	private String entityLabel$;
	private Sack entity;
	protected JMenu menu;
	protected Entigrator entigrator;
	TubePanel  tubePanel;
	Meter	timer;
	ArrayList<Meter>gauges=new ArrayList<Meter>();
	JPanel dashboard;
	private JTextField rayValues;
	private JPanel panel;
	private JTextField txtStart;
	private JTextField txtStop;
	private JTextField txtTime;
	JDiagrammDialog dialog;
	public JRecordViewer(JMainConsole console, String locator$) {
 		super(console,locator$);
		//System.out.println("JRecordViwer:locator="+locator$);
		  entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		  entity=console.getEntigrator().getEntityAtLabel(entityLabel$);
	      entigrator=console.getEntigrator();
		  setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		  Properties tubeLocator=new Properties();
		  tubeLocator.put(DiagrammPanel.DIA_TITLE, entityLabel$);
		  String tubeLocator$=Locator.toString(tubeLocator);
		  tubePanel=new TubePanel(console.getEntigrator(),null);
		  add(tubePanel);
		tubePanel.setLayout(new BorderLayout(0, 0));
		
		dashboard = new JPanel();
		FlowLayout flowLayout = (FlowLayout) dashboard.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		dashboard.setBackground(Color.BLACK);
		dashboard.setForeground(Color.BLACK);
		dashboard.setMaximumSize(new Dimension(2000, 200));
		add(dashboard);
		timer = new Meter();    // Construct the drawing canvas
		timer.setPreferredSize(timer.getPreferredSize());				       
		timer.setTitle("Timer");
		timer.setVar(Instrument.TIME);
		timer.setUnit("s");
		double stopTime=100;
	     try{	 stopTime=Double.parseDouble(entity.getElementItemAt("tuner","stop" ));}catch(Exception e){}
		timer.setValueMaximum(stopTime);
		double time=0;
		  try{	 time=Double.parseDouble(entity.getElementItemAt("tuner",Instrument.TIME));}catch(Exception e){}
		  try{ timer.setValue(time);
		  		timer.setMiddle(false);
		  }catch(Exception e){}
		dashboard.add(timer);
		JSlider slider = new JSlider();
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
			        if (slider.getValueIsAdjusting()) {
			        	int pos = (int)slider.getValue();
			        //    System.out.println("JRecordViwer:slider="+pos);
			            handleSlider(pos);
			        }    
			}
		});
		add(slider);
		panel = new JPanel();
		add(panel);
		panel.setMaximumSize(new Dimension(10000,50));
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWeights = new double[]{0.0, 0.0,0.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0};
		panel.setLayout(gbl_panel);
		txtStart = new JTextField();
		txtStart.setText("Start");
		txtStart.setHorizontalAlignment(SwingConstants.LEFT);
		txtStart.setEditable(false);
		GridBagConstraints gbc_txtStart = new GridBagConstraints();
		gbc_txtStart.insets = new Insets(0, 0, 0, 5);
		gbc_txtStart.gridx = 0;
		gbc_txtStart.gridy = 0;
		panel.add(txtStart, gbc_txtStart);
		txtStart.setColumns(12);
		txtStop = new JTextField();
		txtStop.setText("Stop");
		txtStop.setEditable(false);
		txtStop.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_txtStop = new GridBagConstraints();
		gbc_txtStop.insets = new Insets(0, 0, 5, 5);
		gbc_txtStop.gridx = 1;
		gbc_txtStop.gridy = 0;
		panel.add(txtStop, gbc_txtStop);
		txtStop.setColumns(12);
		
		txtTime = new JTextField();
		txtTime.setText("Time");
		txtTime.setEditable(false);
		txtTime.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_txtTime = new GridBagConstraints();
		gbc_txtTime.insets = new Insets(0, 0, 0, 5);
		gbc_txtTime.gridx = 2;
		gbc_txtTime.gridy = 0;
		panel.add(txtTime, gbc_txtTime);
		txtTime.setColumns(12);
		
		rayValues = new JTextField();
		rayValues.setEditable(false);
		GridBagConstraints gbc_rayValues = new GridBagConstraints();
		gbc_rayValues.insets = new Insets(0, 0, 0, 5);
		gbc_rayValues.gridx = 3;
		gbc_rayValues.gridy = 0;
		gbc_rayValues.fill=GridBagConstraints.HORIZONTAL;
		panel.add(rayValues, gbc_rayValues);
		Border loweredBorder = BorderFactory.createLoweredBevelBorder();
		rayValues.setBorder(loweredBorder);
		this.locator$=Locator.append(this.locator$, Locator.LOCATOR_TITLE, "Record viewer");
		init();
		setTitle("Record viewer");
		locator$=Locator.append(locator$, Locator.LOCATOR_TITLE, "Record viewer");
	}
	private void handleSlider(int pos) {
 try {
      //  System.out.println("JRecordViwer:slider="+pos);
        tubePanel.drawScreenMarker(pos);
      double factor=tubePanel.getFactor();
		int x=tubePanel.getWidth()*pos/100;
		int cnt=(int)(x/factor);
	//	System.out.println("JRecordViwer:handle slider :cnt="+cnt);
		if(cnt>tubePanel.getReviseCount()-1)
			return;
		String format$=entity.getElementItemAt("record", "format");
		if(format$==null)
			format$="0.####E0";
		NumberFormat timeFormat = new DecimalFormat(format$);
		int allSteps=Integer.parseInt(entity.getElementItemAt("record", "all steps"));
		int steps=Integer.parseInt(entity.getElementItemAt("record", "steps"));
		double takt=Double.parseDouble(entity.getElementItemAt("record", "takt"));
		double gtime=(allSteps-steps+cnt)*takt;
	    double time=cnt*takt;
	    double maxTime=(steps)*takt;
//	    System.out.println("JRecordViwer:handle slider :cnt="+cnt+"  time="+time+" max time="+maxTime);
	    timer.setFormat(format$);
	    timer.setValue(time);
	    timer.setValueMaximum(maxTime);
		txtTime.setText("Time="+timeFormat.format(gtime));
		int n=dashboard.getComponentCount();
		for(int i=0;i<n;i++) {
		     ((Meter)dashboard.getComponent(i)).showValue(cnt);
		}
		String[] sa=tubePanel.rayNameValues(cnt);
		StringBuffer sb=new StringBuffer();
		for(String s:sa)
			sb.append(s+"  ");
		rayValues.setText(sb.toString());
		if(dialog!=null) {
			dialog.toFront();
			dialog.revise(cnt);
		}
 }catch(Exception e) {
	 System.out.println("JRecordViwer:handleSlider="+e.toString()); 
 }
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,RECORD_FACET_NAME);
		locator.put(FacetHandler.FACET_TYPE,RECORD_FACET_TYPE);
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.record.JRecordViewer");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.record.JRecordViewer");
		return Locator.toString(locator);
	}	
	@Override
	public String getClassLocator() {
		return classLocator();
	}
private void init() {
	try {
		String entityKey$=entigrator.getKey(entityLabel$);
		String entityHome$=entigrator.getEntihome()+"/"+entityKey$;
	//	System.out.println("JRecordViwer:init: entity home="+entityHome$);
		String tube$=null;
		File entityHome=new File(entityHome$);
		String[] sa=entityHome.list();
		Sack tube=null;
		if(sa!=null) {
			for(String s:sa) 
				if(s.endsWith(".tube")) {
					tube$=s;
					tube=Sack.readXml(entityHome$+"/"+tube$);
					break;
				}
	//	System.out.println("JRecordViwer:init: tube="+entityHome$+"/"+tube$);	
			if(tube==null) {
				System.out.println("JRecordViwer:init: cannot load tube="+entityHome$+"/"+tube$);
				return;
			}
	//		System.out.println("JRecordViwer:init:tube loaded="+tube.getProperty("label"));
			tubePanel.setTube(tube);
			for(String s:sa) 
				if(s.endsWith(".rec")) {
					//System.out.println("JRecordViwer:init: rec="+entityHome$+"/"+s);	
					tubePanel.restorePoints(entityHome$+"/"+s);
					break;
				}
		}
		txtStart.setText("Start="+tubePanel.start$);
		txtStop.setText("Stop="+tubePanel.stop$);
		String timerValues$=entityHome$+"/timer.val";
		timer.restoreValues(timerValues$);
		timer.setLastValue();
		if(tube!=null) {
			try {
		     String width$=tube.getElementItemAt("tube", "width");
		     String height$=tube.getElementItemAt("tube", "height");
		     int width=Integer.parseInt(width$);
		     int height=Integer.parseInt(height$);
		     console.setSize(new Dimension(width,height));
			}catch(Exception ee) {}
		}
		Sack gauge;
		Meter meter;
		String values$;
		for(String s:sa) 
			if(s.endsWith(".gauge")) {
				gauge=Sack.readXml(entityHome$+"/"+s);
				meter=new Meter();
				meter.setGauge(gauge);
				values$=s.replace(".gauge",".val");
				meter.restoreValues(entityHome$+"/"+values$);
				dashboard.add(meter);
			}
	}catch(Exception e) {
		System.out.println("JRecordViwer:init:"+e.toString());
	}
}
@Override
public JMenu getContextMenu() {
	menu=super.getContextMenu();
	menu.addSeparator();
	 JMenuItem folderItem = new JMenuItem("Folder");
				folderItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					  try{
						  File folder=new File(entigrator.getEntihome()+"/"+entigrator.getKey(entityLabel$));
							Desktop.getDesktop().open(folder);
					  }catch(Exception ee){
						  Logger.getLogger(getClass().getName()).severe(ee.toString());
					  }
					}
				} );
				menu.add(folderItem);
	menu.addSeparator();
		 JMenuItem exportItem = new JMenuItem("Export");
					exportItem.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
						  try{
							 // System.out.println("JRecordViwer:export.BEGIN");
							  Rectangle componentRect = JRecordViewer.this.getBounds();
							    BufferedImage bufferedImage = new BufferedImage(componentRect.width, componentRect.height, BufferedImage.TYPE_INT_ARGB);
							    JRecordViewer.this.paint(bufferedImage.getGraphics());
							    File imageFile = new File(entigrator.getEntihome()+"/"+entity.getKey()+"/"+entity.getProperty("label")+".png");
							    ImageIO.write(bufferedImage, "png", imageFile );
							   // System.out.println("JRecordViwer:export.file="+imageFile.getPath());
						  }catch(Exception ee){
							  Logger.getLogger(getClass().getName()).severe(ee.toString());
						  }
						}
					} );
					menu.add(exportItem);
		JMenu lookMenu=new JMenu("Look");
		JMenuItem bwItem = new JMenuItem("Black/white");
		bwItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  try{
				Sack tube= tubePanel.getTube(); 
				tube.putElementItem("tube", new Core (null,"look","bw"));
				tubePanel.setTube(tube);
				String entityHome$=entigrator.getEntihome()+"/"+entity.getKey();
				String record$=entityHome$+"/"+entity.getKey()+".rec";
				tubePanel.restorePoints(record$);
				tubePanel.repaint();
			  }catch(Exception ee){
				  Logger.getLogger(getClass().getName()).severe(ee.toString());
			  }
			}
		} );
		lookMenu.add(bwItem);
		JMenuItem colorItem = new JMenuItem("Color");
		colorItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  try{
				Sack tube= tubePanel.getTube(); 
				tube.putElementItem("tube", new Core (null,"look","//bw"));
				tubePanel.setTube(tube);
				String entityHome$=entigrator.getEntihome()+"/"+entity.getKey();
				String record$=entityHome$+"/"+entity.getKey()+".rec";
				tubePanel.restorePoints(record$);
				tubePanel.repaint();
			  }catch(Exception ee){
				  Logger.getLogger(getClass().getName()).severe(ee.toString());
			  }
			}
		} );
		lookMenu.add(colorItem);
		menu.add(lookMenu);
		menu.addSeparator();
		JMenuItem diaItem = new JMenuItem("Diagramm");
		diaItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dialog=new JDiagrammDialog();
					try {
					   DiagrammPanel diaPanel=tubePanel.getDiagramm();
					if(diaPanel!=null) {
					  dialog.addDiagrammPanel(diaPanel);
					  dialog.setSize(new Dimension(200,200));
					  dialog.setLocationRelativeTo(JRecordViewer.this);
					  dialog.setVisible(true);
					}
					}catch(Exception ee) {
						System.out.println("JApplianceEditor:diagramm:"+ee.toString());
					}
			}
		} );
		menu.add(diaItem);
					return menu;
}
@Override
public String reply(JMainConsole console, String locator$) {
	return null;
}
@Override
public boolean handleDone() {
	JContext.displayInstance(console, parent$);
	return true;
}
}
