package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Properties;
import javax.swing.JPopupMenu;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PackHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.pack.JPackEditor;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
public class PackMaster extends FacetMaster{
	public static final String KEY="_vQj7Ft4fNozkanhJiGCnwNPRcI8";
	public PackMaster() {
		super();
	}
	public PackMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	    locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
	    locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PackMaster");
	    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PackHandler");
	    locator.put(FacetHandler.FACET_KEY,PackHandler.KEY);
	    locator.put(Locator.LOCATOR_TITLE,"Pack");
	    locator.put(FacetHandler.FACET_MASTER_KEY,KEY);
	    locator.put(JContext.PARENT,ALL_FACETS_KEY);
	    locator.put( IconLoader.ICON_FILE, "pack.png");
	    locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
	    locator.put(FacetHandler.FACET_TYPE,PackHandler.PACK_FACET_TYPE);
	    locator.put(FacetMaster.MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PackMaster");
	    return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String facetLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, facetLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		//System.out.println("SisoMaster:getJEntityFacetsItem:locator="+handlerLocator$);
		String entity$=Locator.getProperty(handlerLocator$,Entigrator.ENTITY_LABEL);
		String parent$=Locator.getProperty(handlerLocator$, JContext.PARENT);
		String itemLocator$=JItemPanel.classLocator();
		if(entity$!=null)
		  itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
			  itemLocator$=Locator.append(itemLocator$,JContext.PARENT, parent$);
		itemLocator$=Locator.merge(itemLocator$, locator$);
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetMaster.MASTER_CLASS, Locator.LOCATOR_FALSE);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		//System.out.println("SisoMaster:getFacetHandler:locator="+locator$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= PackHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new PackHandler(console.getEntigrator(),handlerLocator$);
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return "Pack";
	}
	@Override
	public String getType() {
		return "pack";
	}
	@Override
	public void allFacetsItemOnClick(JMainConsole console, String locator$) {
		listFacetMembers(console,classLocator());
	}
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		//	System.out.println("PackMaster:entityFacetsItemOnClick:entity label="+entityLabel$);
			String parent$=Locator.getProperty(locator$, JContext.PARENT);
			String packEditor$=JPackEditor.classLocator();
			packEditor$=Locator.merge(packEditor$,alocator$);
			packEditor$=Locator.append(packEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			packEditor$=Locator.append(packEditor$,JContext.PARENT, parent$);
			JPackEditor packEditor=new JPackEditor(console,packEditor$);
			console.replaceContext((JContext)packEditor);
		}catch(Exception e) {
			System.out.println("CduMaster:entityFacetsItemOnClick:"+e.toString());	
		}
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public String getLocator() {
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String parent$=Locator.getProperty(locator$,JContext.PARENT);
		String thisLocator$=classLocator();
		if(entity$!=null)
		   thisLocator$=Locator.append(thisLocator$,Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
			   thisLocator$=Locator.append(thisLocator$,JContext.PARENT, parent$);
		return thisLocator$;
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",PackHandler.KEY,PackHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("PackMaster:addToSession:"+e.toString());
	    }	
		}
	@Override
	public void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",getType(),classLocator()));
		entity.putAttribute(new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU","icon","pack.png"));
		entity.putElementItem("facet", new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU","edu",EduMaster.classLocator()));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		entity=entigrator.assignProperty("operator", "true", entity.getKey());
		createSource( entigrator, entityLabel$);
		return entity;
	}
	private void createSource(Entigrator entigrator, String entityLabel$){
		try{
			String entityKey$=entigrator.getKey(entityLabel$);
			File sourceHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src");
			if(!sourceHome.exists())
				sourceHome.mkdirs();
			File binHome=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/bin");
			if(!binHome.exists())
				binHome.mkdirs();
			File procedureJava=new File(console.getEntigrator().getEntihome()+"/"+entityKey$+"/src/"+entityKey$+".java");
			if(!procedureJava.exists())
				procedureJava.createNewFile();
			 FileOutputStream fos = new FileOutputStream(procedureJava, false);
			 Writer writer = new OutputStreamWriter(fos, "UTF-8");
			 writer.write("import java.util.Hashtable;\n");
			 writer.write("import gdt.base.generic.Locator;\n");
			 writer.write("import gdt.base.store.Entigrator;\n");
			 writer.write("import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PackHandler;\n");
			 writer.write("import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;\n");
			 writer.write("public class " +entityKey$+"  implements SegueController {\n");
			 writer.write(" private final static String ENTITY_KEY="+entityKey$+";\n");
			 writer.write("PackHandler packHandler;\n");
			 writer.write("Entigrator entigrator;\n");
			 writer.write(" @Override\n");
			 writer.write("public void reset() {\n");
			 writer.write("if(entigrator==null) {\n");
			 writer.write("System.out.println(ENTITY_KEY+\":reset:entigrator is null\");\n");
			 writer.write("	return;\n");
			 writer.write("}\n");
			 writer.write("	try {\n");
			 writer.write("String packHandler$=PackHandler.classLocator();\n");
		     writer.write("String pack$=entigrator.getLabel(ENTITY_KEY);\n");
		     writer.write("packHandler$=Locator.append(packHandler$, Entigrator.ENTITY_LABEL, pack$);\n");
		     writer.write("packHandler=new PackHandler(entigrator,packHandler$);\n");
		     writer.write("packHandler.reset();\n");
		    writer.write("	}catch(Exception e) {\n");
		    writer.write("System.out.println(ENTITY_KEY+\":reset:\"+e.toString());\n");
		    writer.write("}\n");
		    writer.write("}\n");
		    writer.write("@Override\n");
		    writer.write("public Hashtable<String, Double> getSettings()  {\n");
		    writer.write("	return packHandler.getSettings();\n");
		    writer.write("	}\n");
		    writer.write(" @Override\n");
		    writer.write("public void putSettings(Hashtable<String, Double> set)  {}\n");
		    writer.write(" @Override\n");
		    writer.write(" public String[] listInputs(){\n");
		    writer.write("if(packHandler==null) {\n");
		    writer.write("reset();\n");
		    writer.write("   }\n");
		    writer.write("return packHandler.listInputs();\n");
		    writer.write(" }\n");
		    writer.write("@Override\n");
		    writer.write("public String[] listOutputs(){\n");
		    writer.write("    if(packHandler==null) {\n");
		    writer.write("     	reset();\n");
		    writer.write("     }\n");
		    writer.write(" 	return packHandler.listOutputs();\n");
		    writer.write(" 	}\n");
		    writer.write(" @Override\n");
		    writer.write(" public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {\n");
		    writer.write("	Hashtable<String, Double>outs=packHandler.stride(ins);\n");
		    writer.write(" 	if(outs==null) {\n");
		    writer.write(" 		System.out.println(ENTITY_KEY+\":stride:outs is null\");\n");
		    writer.write(" 	}\n");
		    writer.write(" 	return outs;\n");
		    writer.write(" }\n");
		    writer.write("@Override\n");
		    writer.write(" public Hashtable<String, Double> getOuts() {\n");
		    writer.write(" 	return packHandler.getOuts();\n");
		    writer.write(" }\n");
		    writer.write(" @Override\n");
		    writer.write(" public double getClock() {\n");
		    writer.write(" 	return packHandler.getClock();\n");
		    writer.write(" }\n");
		    writer.write(" @Override\n");
		    writer.write(" public void setClock(double clock) {\n");
		    writer.write(" 	packHandler.setClock(clock);\n");
		    writer.write(" }\n");
		    writer.write(" @Override\n");
		    writer.write(" public void setEntigrator(Entigrator entigrator) {\n");
		    writer.write(" 	this.entigrator=entigrator;\n");
		    writer.write(" }\n");
		    writer.write(" }\n");
			 writer.close();   
		}catch(Exception e){
			System.out.println("PackMaster:createSource:"+e.toString());
		}
	}
}
