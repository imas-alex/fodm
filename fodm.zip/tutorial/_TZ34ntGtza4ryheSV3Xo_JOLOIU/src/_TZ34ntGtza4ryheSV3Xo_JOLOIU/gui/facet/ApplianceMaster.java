package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.ApplianceHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.appliance.JApplianceEditor;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;
public class ApplianceMaster extends FacetMaster{
public static final String KEY="_59t3DACXCEBD_SWqSrReGhwOlqRA";
public static final String NAME="Appliance";
public ApplianceMaster() {
	super();
}	
public ApplianceMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
public static String classLocator() {
	 Properties locator=new Properties();
    locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
    locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.ApplianceMaster");
    locator.put(FacetHandler.FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.ApplianceHandler");
    locator.put(HANDLER_KEY,"_12qjkwYaeWRyEvkuHZnC_BdhTa0");
    locator.put(Locator.LOCATOR_TITLE,"Appliance");
    locator.put( IconLoader.ICON_FILE, "appliance.png");
    locator.put(MASTER_KEY,KEY);
    locator.put(JContext.PARENT,ALL_FACETS_KEY);
    locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
    locator.put(FacetHandler.FACET_TYPE,ApplianceHandler.APPLIANCE_FACET_TYPE);
    locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.appliance.JApplianceEditor");
    return Locator.toString(locator);
}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		String applianceLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, applianceLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
	//	System.out.println("ApplianceMaster:getJEntityFacetsItem:locator="+handlerLocator$);
		String entity$=Locator.getProperty(handlerLocator$, Entigrator.ENTITY_LABEL);
		String itemLocator$=JItemPanel.classLocator();
		String applianceLocator$=classLocator();
		itemLocator$=Locator.merge(itemLocator$, applianceLocator$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_ADDABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,itemLocator$);
		return itemPanel;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String handlerLocator$= ApplianceHandler.classLocator();
		handlerLocator$=Locator.append(handlerLocator$,  Entigrator.ENTITY_LABEL,entity$ );
		return new ApplianceHandler(console.getEntigrator(),handlerLocator$); 
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return NAME;
	}
	
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try {
			String parentLocator$=console.getContext().getLocator();
			//String parentInstance$=Locator.getProperty(parentLocator$, JContext.INSTANCE);
			String parentInstance$=console.getContext().getInstance();
			SessionHandler.putLocator(console.getEntigrator(), parentLocator$);
			String entityLabel$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
			String applianceEditor$=JApplianceEditor.classLocator();
			applianceEditor$=Locator.merge(applianceEditor$,alocator$);
			applianceEditor$=Locator.append(applianceEditor$,Entigrator.ENTITY_LABEL, entityLabel$);
			applianceEditor$=Locator.append(applianceEditor$,JContext.PARENT, parentInstance$);
			JApplianceEditor applianceEditor=new JApplianceEditor(console,applianceEditor$);
			//console.replaceContext(applianceEditor);
			String display$=Locator.getProperty(locator$,JContext.DISPLAY);
			JDisplay display=null;
			if(display$!=null)
				display=console.getDisplay(display$);
			if(display==null)
			  console.replaceContext(applianceEditor);
			else
			  display.putContext(applianceEditor);	
		}catch(Exception e) {
			System.out.println("ApplianceMaster:entityFacetsItemOnClick:"+e.toString());	
		}
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String alocator$) {
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		//String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
				final String itemLocator$=alocator$;
				JPopupMenu popup=new JPopupMenu();
				JMenuItem newItem=new JMenuItem("New appliance");
				newItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					//	System.out.println("ApplianceMaster:entityFacetsItemPopup:new entity:locator="+itemLocator$);
						popup.setVisible(false);
						String textEditor$=JTextEditor.classLocator();
						textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New appliance");
						String facetList$=JEntityFacetList.classLocator();
						facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
						facetList$=Locator.append(facetList$,MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.ApplianceMaster");
						facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
						SessionHandler.putLocator(console.getEntigrator(),facetList$);
						textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
						JTextEditor textEditor=new JTextEditor(console,textEditor$);
						console.replaceContext(textEditor);
					}
				} );
				popup.add(newItem);
				return popup;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	@Override
	public String getType() {
		return "appliance";
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",ApplianceHandler.KEY,ApplianceHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("ApplianceMaster:addToSession:"+e.toString());
	    }
}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU",getType(),classLocator()));
		entity.putAttribute(new Core("_TZ34ntGtza4ryheSV3Xo_JOLOIU","icon","appliance.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		entity=entigrator.assignProperty( getType(),"true", entity.getKey());
		return entity;
	}
}
