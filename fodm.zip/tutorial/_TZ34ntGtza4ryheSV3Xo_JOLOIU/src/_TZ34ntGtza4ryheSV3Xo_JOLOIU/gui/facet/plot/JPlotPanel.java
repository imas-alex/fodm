package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;

import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.PlotMaster;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.edu.JEduEditor;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.FileTool;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JGuiEditor;

import java.awt.FontMetrics;
public class JPlotPanel  extends JGuiEditor 
{
	private static final long serialVersionUID = 1L;
	private final String  QUADRANT="Quadrant";
	private final String  SURFACE="Surface";
	public  static final String  POINT_DISPLAY="point display";
	ArrayList<Ray>rays=new ArrayList<Ray>();
	ArrayList<Scale>scales=new ArrayList<Scale>();
	int maxY=0;
	int maxX=0;
	int width;
	Sack plot;
	File record;
	String visible$;
	String rayKey$;
	String rayName$;
	String color$;
	String factor$;
	Ray ray;
	Font defaultFont;
	Entigrator entigrator;
	Area area;
	double fx=0;
	double fy=0;
	boolean showPointer=false;
	String pointDisplay$;
	PointDisplay pointDisplay;
	Scale xscale;
	
	public JPlotPanel(JMainConsole console,String alocator$) {
		super(console,alocator$);
	//	System.out.println("JPlotPanel:locator="+locator$);
		instance$=getInstance();
		parent$=Locator.getProperty(alocator$, PARENT);
		if(parent$!=null)
		locator$=Locator.append(locator$, PARENT, parent$);
		display$=Locator.getProperty(alocator$, DISPLAY);
		if(display$!=null)
		locator$=Locator.append(locator$, DISPLAY, display$);
		try {
		String plot$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		//System.out.println("JPlotPanel:point display="+pointDisplay$);
		plot=console.getEntigrator().getEntityAtLabel(plot$);
		pointDisplay$=plot.getElementItemAt("plot","point.display");
				//Locator.getProperty(locator$,POINT_DISPLAY);
		entigrator=console.getEntigrator();
        area=new Area(plot);
		String [] sa=plot.elementListNames("scale.layout");
        if(sa!=null) {
        	Scale scale=null;
        	for(String s:sa) {
        		if("null".equals(s))
        			continue;
        		scale=new Scale(s);
        	    if(scale!=null&&scale.valid)
        	    	scales.add(scale);
        	    else
        	    	System.out.println("JPlotPanel:invalid scale="+s);
        	}
        }
        addMouseListener(new PlotMouseListener());
        init();
       
		}catch(Exception e) {
			System.out.println("JPlotPanel:"+e.toString());
		}
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,PlotMaster.KEY);
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.JPlotMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.JPlotPanel");
		return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	private void showControl() {
		String[] sa=plot.elementListNames("customer");
		if(sa==null)
			return;
		String maker$=plot.getElementItemAt("customer", sa[0]);
		String eduLocator$=JEduEditor.classLocator();
		eduLocator$=Locator.append(eduLocator$,Entigrator.ENTITY_LABEL, maker$);
		String display$=Locator.getProperty(locator$, DISPLAY);
		 if(display$==null)
			 display$=console.getDisplayKey(this);
		 if(display$!=null)
			 eduLocator$=Locator.append(eduLocator$,DISPLAY, display$);
		 System.out.println("JPlotPanel:showEditor:display="+display$);
		 JEduEditor eduEditor=new   JEduEditor (console,eduLocator$);
		   replace(console, eduEditor);
	}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu.addSeparator();
		JMenuItem editorItem = new JMenuItem("Settings");
		editorItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				    String instance$=console.saveContext();
				    String editorLocator$=JPlotEditor.classLocator();
				    editorLocator$=Locator.merge(editorLocator$,locator$);
				    editorLocator$=Locator.append(editorLocator$, PARENT, instance$);
					JPlotEditor plotEditor=new JPlotEditor(console,editorLocator$);
				   replace(console, plotEditor);
				}
			} );
		menu.add(editorItem);	
		JMenuItem controlItem = new JMenuItem("Control");
		controlItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				    showControl();
				}
			} );
		menu.add(controlItem);	
			JMenuItem saveItem = new JMenuItem("Save");
			saveItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					  save();
					}
				} );
			menu.add(saveItem);	
			JMenuItem exportItem = new JMenuItem("Export");
			exportItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
					  try{
						 // System.out.println("JRecordViwer:export.BEGIN");
						  Rectangle componentRect = JPlotPanel.this.getBounds();
						    BufferedImage bufferedImage = new BufferedImage(componentRect.width, componentRect.height, BufferedImage.TYPE_INT_ARGB);
						    JPlotPanel.this.paint(bufferedImage.getGraphics());
						    File imageFile = new File(entigrator.getEntihome()+"/"+plot.getKey()+"/"+plot.getProperty("label")+".png");
						    ImageIO.write(bufferedImage, "png", imageFile );
						   // System.out.println("JRecordViwer:export.file="+imageFile.getPath());
					  }catch(Exception ee){
						  Logger.getLogger(getClass().getName()).severe(ee.toString());
					  }
					}
				} );
		menu.add(exportItem);
		JMenuItem folderItem = new JMenuItem("Folder");
		folderItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					 try{
						  File folder=new File(console.getEntigrator().getEntihome()+"/"+plot.getKey());
							Desktop.getDesktop().open(folder);
					  }catch(Exception ee){
						  Logger.getLogger(getClass().getName()).severe(ee.toString());
					  }
				}
			} );
		menu.add(folderItem);	
		//
		JMenu lookMenu=new JMenu("Look");
		JMenuItem bwItem = new JMenuItem("Black/white");
		bwItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  try{
				if(!plot.existsElement("plot"))
					plot.createElement("plot");
				plot.putElementItem("plot", new Core (null,"look","bw"));
				console.getEntigrator().putEntity(plot);
				String entityHome$=entigrator.getEntihome()+"/"+plot.getKey();
				File home=new File(entityHome$);
				String [] sa=home.list();
				String data$=null;
				for(String s:sa) {
					if(s.endsWith(".data")) {
						data$=entityHome$+"/"+s;
					}
				}
				if(data$!=null)
					pointDisplay.setDataPath(data$);
				init();
				revalidate();
				repaint();
			  }catch(Exception ee){
				  Logger.getLogger(getClass().getName()).severe(ee.toString());
			  }
			}
		} );
		lookMenu.add(bwItem);
		JMenuItem colorItem = new JMenuItem("Color");
		colorItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  try{
				  if(!plot.existsElement("plot"))
						plot.createElement("plot");
					plot.putElementItem("plot", new Core (null,"look","//bw"));
					console.getEntigrator().putEntity(plot);
					String entityHome$=entigrator.getEntihome()+"/"+plot.getKey();
					File home=new File(entityHome$);
					String [] sa=home.list();
					String data$=null;
					for(String s:sa) {
						if(s.endsWith(".data")) {
							data$=entityHome$+"/"+s;
						}
					}
					if(data$!=null)
						pointDisplay.setDataPath(data$);
					init();
					revalidate();
					repaint();
			  }catch(Exception ee){
				  Logger.getLogger(getClass().getName()).severe(ee.toString());
			  }
			}
		} );
		lookMenu.add(colorItem);
		menu.add(lookMenu);
		return menu;
		 }
	private   Color getColor(String color$){
		if("black".equals(color$))
			return Color.black;
		if("white".equals(color$))
			return Color.white;
		if("blue".equals(color$))
			return Color.blue;
		if("red".equals(color$))
			return Color.red;
		if("orange".equals(color$))
			return Color.orange;
		if("magenta".equals(color$))
			return Color.magenta;
		if("cyan".equals(color$))
			return Color.cyan;
		if("yellow".equals(color$))
			return Color.yellow;
		if("gray".equals(color$))
			return Color.gray;
		return Color.black;
	}
@Override
public String getTitle() {
	return Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
}
@Override
public String getSubtitle() {
	return Locator.getProperty(getLocator(),Entigrator.ENTITY_LABEL);
}
private  int getFontStyle(String style$){
		int style=Font.PLAIN;
		if("bold".equals(style$))
			style=Font.BOLD;
		if("italic".equals(style$))
			style=Font.ITALIC;
		return style;
	}
class PointValue{
	double x;
	double y;
	PointValue (double x,double y){
		this.x=x;
		this.y=y;
	}
}
class PointPosition{
	int x;
	int y;
	PointPosition (int x,int y){
		this.x=x;
		this.y=y;
	}
}
	public  void init() {
	try {
	rays.clear();
	Core[] ca=plot.elementGet("ray.name");	
	if(ca==null) {
		System.out.println("JPlotPanel:init:wrong plot="+plot.getProperty("label"));
		return;
	}
	xscale=new Scale("xbase");
	//System.out.println("JPlotPanel:init:xscale="+xscale.name$);
	Ray ray;
	for(Core c:ca){
	   	try{
	   		ray=new Ray(c.value);
	   		rays.add(ray);
	   		ray.load();
	   	}catch(Exception e){
	   		System.out.println("JPlotPanel:init:"+e.toString());
	   	}
	}
	pointDisplay=new DefaultPointDisplay();
	if(pointDisplay$!=null)
	try {	
	Class<?> cls =getClass().getClassLoader().loadClass(pointDisplay$);
	pointDisplay=(PointDisplay)cls.getDeclaredConstructor().newInstance();
	if(pointDisplay!=null) {
		String entihome$=console.getEntigrator().getEntihome();
		String home$=entihome$+"/"+plot.getKey();
		File home=new File(home$);
		String [] sa=home.list();
		String data$=null;
		for(String s:sa) {
			if(s.endsWith(".data")) {
				data$=home$+"/"+s;
			}
		}
		if(data$!=null)
			pointDisplay.setDataPath(data$);
	}
	}catch(Exception ee) {
		System.out.println("JPlotPanel:init:cannot get point display="+pointDisplay$);		
	}
	
}catch(Exception ee) {
	System.out.println("JPlotPanel:init:"+ee.toString());
}
}
public static void makeData(Entigrator entigrator,String entity$) {
	try{
	String key$=entigrator.getKey(entity$);
	String data$=entigrator.getEntihome()+"/"+key$+"/data.plot";
//	System.out.println("JGraphPanel: makeData:data path="+data$);
	File data=new File(data$);
	if(!data.exists())
		data.createNewFile();
	 FileOutputStream fos = new FileOutputStream(data, false);
	 Writer writer = new OutputStreamWriter(fos, "UTF-8");
	 double cos;
	 double sin;
	 double angle;
	 String format$="0.####E0";
	 NumberFormat valFormat = new DecimalFormat(format$);
	 for (int i=-180;i<180;i++) {
		 angle=Math.toRadians(i);
		 cos=Math.cos(angle);
		 sin=Math.sin(angle);
		 writer.write(valFormat.format(angle)+";"+valFormat.format(cos)+";"+valFormat.format(sin)+"\n");
	 }
	 writer.close();
	 fos.close();
	}catch(Exception e){
   		System.out.println("JPlotPanel: makeData:"+e.toString());
   	}
}
public PointValue  getPointValue(String ray$,int cnt ) {
	try {
		if(rays.equals(null)||rays.size()<1)
			return null;
		for(Ray r:rays) {
			if(ray$.equals(r.name$)) {
				if(r.locations==null||r.locations.size()<1)
					return null;
				return r.locations.get(cnt);
			}
		}
	}catch(Exception e) {
		System.out.println("JPlotPanel: getPointValue:"+e.toString());
	}
	return null;
}
private void drawPointer(Graphics g,Dimension whO,Dimension whm) {
	((Graphics2D)g).setStroke(new BasicStroke(2));
	int r=10;
	try { r=Integer.parseInt(plot.getElementItemAt("canvas","pointer.size" ));}catch(Exception e) {}
	int style=Font.PLAIN;
	try { style=getFontStyle(plot.getElementItemAt("canvas","font.style" ));}catch(Exception e) {}
	Color color=Color.black;
	try { color=getColor(plot.getElementItemAt("canvas","font.color" ));}catch(Exception e) {}
	int size=14;
	try { size=Integer.parseInt(plot.getElementItemAt("canvas","font.size" ));}catch(Exception e) {}
	g.setColor(color);
	g.setFont(new Font("default",style,size));
    int dx=(int)(fx*(whm.width));
      int dy=(int)(fy*(whm.height));
      int x=whO.width+dx;
      int y=whO.height-dy;
    x = x-(r/2);
    y = y-(r/2);
    //System.out.println("JPlothPanel:drawPointer:x="+x+" y="+y); 
    //System.out.println("JPlothPanel:drawPointer:dx="+dx+" dy="+dy+"  dxmax="+(whm.width-whO.width)+"  ymax="+(whm.height-whO.height)+"  fx="+fx+" fy="+fy);
    g.drawOval(x, y, r, r);
    StringBuffer sb=new StringBuffer();
    String format$;
	NumberFormat scaleFormat;// = new DecimalFormat(format$);
	NamedPoint p;
	ArrayList <NamedPoint> pl=new ArrayList <NamedPoint>();
	int xx;
	int yy;
    if(scales!=null)
		for(Scale s:scales) {
			format$=s.format$;
			if(format$==null||"null".equals(format$))
				format$="0.###";
			if("Horizontal".equals(s.direction$)) {
				p=new NamedPoint(s.name$,format$,"h",s.getValue(x,whO,whm));
			    pl.add(p);
			}
			if("Vertical".equals(s.direction$)) {
				p=new NamedPoint(s.name$,format$,"v",s.getValue(y,whO,whm));
			    pl.add(p);
			}
			
		}
    String vals$=pointDisplay.pointsString(pl);
    FontMetrics fm = g.getFontMetrics();
    Rectangle2D rec = fm.getStringBounds(vals$, g);  
   // System.out.println("JPlothPanel:drawPointer:rec  w="+rec.getWidth()+" h="+rec.getHeight());
    g.setColor(Color.white);
    g.fillRect(x+20, y+20-(int)rec.getHeight(), (int)rec.getWidth()+10,(int)rec.getHeight()+10);
    g.setColor(color);
    g.drawString(vals$, x+20, y+20);
}
@Override	
protected void paintComponent(Graphics g) {
	//System.out.println("JPlotPanel:paintComponent:scales="+scales.size());
	try {
		
	Dimension whO=area.getOrigin();
	Dimension whm=area.getMaximums();
	g.setColor(area.backcolor);
	//System.out.println("JGraphPanel:paintComponent:backcolor="+area.backcolor);
	Dimension sz=getSize();
	g.fillRect(0, 0,sz.width ,sz.height);
	if(scales!=null)
		for(Scale s:scales) {
			try{s.draw((Graphics2D)g,whO,whm);}catch(Exception ee) {}
		}
	((Graphics2D)g).setStroke(new BasicStroke(area.stroke));
	//System.out.println("JPlotPanel:init:rays="+rays.size());
	for(Ray r:rays) {
		//System.out.println("JGraphPanel:paint:ray="+r.name$);
		if(r.visible)
		  r.draw((Graphics2D)g, whO,whm);
	}
	if(showPointer)
		   drawPointer(g,whO,whm);
	}catch(Exception e) {
		System.out.println("JPlotPanel:paintComponent"+e.toString());
	}
}
class Scale{
	String name$;
	String direction$;
	double mark;
	String unit$;
	int order;
	double max;
	double raster;
	String style$="linear";
	public boolean valid=false;
	int maxExp=0;
	int minExp=0;
	String format$=null;
	public Scale(String aname$) {
		//System.out.println("JPlotPanel:Scale:aname="+aname$);
		try {
			if("xbase".equals(aname$)) {
			Core[] ca=plot.elementGet("scale.layout");
			//System.out.println("JPlotPanel:Scale:ca="+ca.length);
			for (Core c:ca) {
				if("Horizontal".equals(c.type)&&"0".equals(c.value)) {
					this.name$=c.name;
					//System.out.println("JPlotPanel:Scale:this name="+this.name$);
				}
			}
		}else
			this.name$=aname$;
		//System.out.println("JPlotPanel:Scale:aname="+aname$+"  this name="+this.name$);
		Core layout=plot.getElementItem("scale.layout", this.name$);
		if(layout==null) {
			//System.out.println("JPlotPanel:Scale:cannot get core 'layout' in plot="+plot.getProperty("label")+"  element 'scale.layout'  layout="+ this.name$);	
			return;
		}
		direction$=layout.type;
		//System.out.println("JPlotPanel:Scale:aname="+aname$+"  this name="+this.name$+" direction="+direction$);
		order=Integer.parseInt(layout.value);
		Core markCore=plot.getElementItem("scale.mark", this.name$);
		unit$=markCore.type;
		//System.out.println("JPlotViewer:Scale:1");
		mark=Double.parseDouble(markCore.value);
		Core maxCore=plot.getElementItem("scale.max", this.name$);
		max=Double.parseDouble(maxCore.value);
		if(maxCore.type!=null&&!"null".equals(maxCore.type))
			format$=maxCore.type;
	//System.out.println("JPlotPanel:Scale:format="+format$);
		Core rasterCore=plot.getElementItem("scale.raster", this.name$);
		style$=rasterCore.type;
		//System.out.println("JPlotViewer:Scale:2");
		raster=Double.parseDouble(rasterCore.value);
		//System.out.println("JPlotPanel:Scale:3");
		if("logarithmic".equals(style$)) {
			double lgMax=Math.log10(max+Double.MIN_VALUE);
			maxExp=(int)lgMax;
			minExp=maxExp-(int)mark;
		}
		//System.out.println("JPlotPanel:Scale:FINISH");
		valid=true;	
		}catch(Exception e) {
			System.out.println("JPlotPanel:Scale:"+e.toString());
		}
	}
	private void drawLabel(Graphics2D g,Dimension whO,Dimension whm) {
	g.setColor(Color.BLACK);
	g.setFont(new Font("default", Font.BOLD, 12));
	//System.out.println("JGraphPanel:drawAxisLabels:direction="+direction$+" order="+order+" unit="+unit$);
	if("Horizontal".equals(direction$))
		g.drawString(name$+" "+unit$, whO.width+whm.width+10, whO.height+order*area.shift);
	if("Vertical".equals(direction$)) {
		 Graphics2D g2 =  g;
		 AffineTransform old=g2.getTransform(); 
		AffineTransform at = new AffineTransform();
	    at.setToRotation(Math.toRadians(-90));
	    g2.setTransform(at);
	   // System.out.println("JGraphPanel:drawAxisLabels:x=" +(whO.width-order*area.shift)+"  y="+(whO.height-whm.height));
	    g2.drawString(name$+" "+unit$,-((whO.height-whm.height)),whO.width-order*area.shift);
		g2.setTransform(old);
	}
	}
	private void drawGrid(Graphics2D g,Dimension whO,Dimension whm) {
		//System.out.println("JPlotPanel:scale:drawGrid:style="+style$);
		if("linear".equals(style$))
			drawLinearGrid( g,whO,whm);
		if("logarithmic".equals(style$))
			drawLogarithmicGrid( g,whO,whm);
	}
private void drawLinearGrid(Graphics2D g,Dimension whO,Dimension whm) {
	try {
		int n=(int)(max/raster);
		g.setColor(Color.GRAY);
		g.setStroke(new BasicStroke(1));
		int linePos;
		int linePos2;
		if("Horizontal".equals(direction$)){
			double factor=whm.getWidth()/max;
           		for(int i=0;i<n;i++) {
    				linePos=(int)(raster*i*factor)+whO.width;
    				linePos2=-(int)(raster*i*factor)+whO.width;
    				g.drawLine(linePos, whO.height, linePos,whO.height-whm.height);
    				if("Surface".equals(area.area$)) {
    					g.drawLine(linePos, whO.height, linePos,whO.height+whm.height);
    					g.drawLine(linePos2, whO.height, linePos2,whO.height+whm.height);
    					g.drawLine(linePos2, whO.height, linePos2,whO.height-whm.height);
    				}
           	}
		}
		if("Vertical".equals(direction$)){
			double factor=whm.getHeight()/max;
              		for(int i=0;i<n;i++) {
    				linePos=-(int)(raster*i*factor)+whO.height;
    				linePos2=(int)(raster*i*factor)+whO.height;
           			g.drawLine( whO.width,linePos,whm.width+whO.width, linePos);
           			if("Surface".equals(area.area$)) {
           				g.drawLine( whO.width,linePos,-whm.width+whO.width, linePos);
           			    g.drawLine( whO.width,linePos2,-whm.width+whO.width, linePos2);
           			    g.drawLine( whO.width,linePos2,whm.width+whO.width, linePos2);
           			}
           		}
           //	}
		}
	}catch(Exception e) {
		System.out.println("JPlotPanel:scale:drawGrid:"+e.toString());
	}
}
private void drawLogarithmicGrid(Graphics2D g,Dimension whO,Dimension whm) {
	try {
		double pointValue;
		double expValue;
		int grid=(int)raster;
		int pos=0;
		g.setColor(Color.GRAY);
    	g.setStroke(new BasicStroke(1));
		for(int i=0;i<maxExp-minExp;i++) {
		  	expValue=Math.pow(10, minExp+i);
		  	for(int j=0;j<grid;j++) {
		  		pointValue=expValue*(j);
		  		pos=getPos(pointValue, whO, whm);
		  		//System.out.println("JPlotPanel:scale:drawLogarithmicGrid:value="+pointValue+" inversion="+getValue(pos,whO,whm));
		  		if("Horizontal".equals(direction$))
		  		 g.drawLine(pos,whO.height,pos,whO.height-whm.height);
		  		if("Vertical".equals(direction$)) 
		  			g.drawLine(whO.width,pos,whO.width+whm.width,pos);	
		  	}
		}
	}catch(Exception e) {
		System.out.println("JPlotPanel:scale:drawLogarithmicGrid:"+e.toString());
	}
}

private void drawMarks(Graphics2D g,Dimension whO,Dimension whm) {
	//System.out.println("JPlotPanel:scale:drawMarks:style="+style$);
	if("linear".equals(style$))
		drawLinearMarks( g,whO,whm);
	if("logarithmic".equals(style$))
		drawLogarithmicMarks( g,whO,whm);
}
private void drawLogarithmicMarks(Graphics2D g,Dimension whO,Dimension whm) {
	int num=maxExp-minExp;
	int interval=0;
	int axisShift=0;
	int markSize=2;
	String mark$;
	int pos;
	for(int i=0;i<num;i++) {
		mark$=String.valueOf(Math.pow(10,(i+minExp)));	
		//System.out.println("JPlotPanel:scale:LogarithmicMarks:direction="+direction$+" pow="+(i+minExp));
		if("Horizontal".equals(direction$)) {
			//g.drawLine(gPos, axisShift+markSize, gPos,axisShift-markSize);
			interval=whm.width/num;
			 axisShift=whO.height+order*area.shift;
			pos=whO.width+interval*i;
			g.drawLine(pos, axisShift+markSize, pos,axisShift-markSize);
			g.drawString(mark$,pos, axisShift+15);
		//	System.out.println("JPlotPanel:scale:LogarithmicMarks:horizontal:pos="+pos+" i="+i);
		}
		if("Vertical".equals(direction$)) {
			 axisShift=whO.width-order*area.shift;
			 interval=whm.height/num;
			pos=whO.height-interval*i;
			g.drawLine(axisShift-markSize,pos,axisShift+markSize,pos); 
			area.drawHstring(g, mark$, interval*i,area.shift,whO);
			//  System.out.println("JPlotPanel:scale:LogarithmicMarks:vertical:pos="+pos+" i="+i);
		}
	}
}
private void drawLogarithmicMarksOld(Graphics2D g,Dimension whO,Dimension whm) {
	int num=maxExp-minExp;
	int interval=0;
	int axisShift=0;
	int markSize=2;
//	System.out.println("JPlotPanel:scale:LogarithmicMarks:num="+num);
	if("Horizontal".equals(direction$)) {
			interval=whm.width/num;
			 axisShift=whO.height+order*area.shift;
	}
	if("Vertical".equals(direction$)) {
		 axisShift=whO.width-order*area.shift;
		 interval=whm.height/num;
	}
	String mark$;
	int pos;
	for(int i=0;i<num;i++) {
		mark$=String.valueOf(Math.pow(10,(i+minExp-1)));	
		if("Horizontal".equals(direction$)) {
			pos=whO.width+interval*i;
			g.drawLine(pos, axisShift+markSize, pos,axisShift-markSize);
			g.drawString(mark$,pos, axisShift+15);
		//	System.out.println("JPlotPanel:scale:LogarithmicMarks:horizontal:pos="+pos+" i="+i);
		}
		if("Vertical".equals(direction$)) {
			//g.drawLine(gPos, axisShift+markSize, gPos,axisShift-markSize);
			pos=whO.height-interval*i;
			g.drawLine(axisShift-markSize,pos,axisShift+markSize,pos); 
			area.drawHstring(g, mark$, interval*i,area.shift,whO);
			//  System.out.println("JPlotPanel:scale:LogarithmicMarks:vertical:pos="+pos+" i="+i);
		}
	}
}
private void drawLinearMarks(Graphics2D g,Dimension whO,Dimension whm) {
	try {
		int n=(int)(max/mark);
		double factor;
		g.setFont(new Font("default", Font.BOLD, 14));
		int markSize=2;
		String nMark$=null;
		int nPos=0;
		double nMark;
		int axisShift;
		NumberFormat numberFormat=null;
		if(format$!=null)
			numberFormat=new DecimalFormat(format$);
		if("Horizontal".equals(direction$)){
			axisShift=whO.height+order*area.shift;
			factor=whm.getWidth()/max;
			//System.out.println("JPlotPanel:scale:drawMarks:factor="+factor);
			for(int i=0;i<n;i++) {
				nMark=mark*i;
				nPos=(int)(nMark*factor)+whO.width;
				//System.out.println("JPlotPanel:scale:drawMarks:i="+i+" nPos="+nPos);
				if(numberFormat!=null)
					nMark$=numberFormat.format(nMark);
				else
					nMark$=String.valueOf(nMark);	
				g.drawLine(nPos, axisShift+markSize, nPos,axisShift-markSize);
				g.drawString(nMark$, nPos, axisShift+15);
				if("Surface".equals(area.area$)) {
					if(i==0)
						continue;
					nPos=(int)(-nMark*factor)+whO.width;
					g.drawLine(nPos, axisShift+markSize, nPos,axisShift-markSize);
					g.drawString("-"+nMark$, nPos, axisShift+15);
				}
			}
		}
		if("Vertical".equals(direction$)){
			axisShift=area.shift*order;
			factor=whm.getHeight()/max;
		  for(int i=0;i<n;i++) {
				nMark=mark*i;
				nPos=(int)(nMark*factor);
				//System.out.println("JPlotPanel:scale:drawMarks:vertical:i="+i+" nPos="+nPos+"  wAxisPos="+axisShift);
				if(numberFormat!=null)
					nMark$=numberFormat.format(nMark);
				else
					nMark$=String.valueOf(nMark);
				area.drawHline(g,nPos, axisShift+markSize, nPos,axisShift-markSize,whO);
				area.drawHstring(g, nMark$, nPos,axisShift+15,whO);
				if("Surface".equals(area.area$)) {
					if(i==0)
						continue;
					nMark=-mark*i;
					if(numberFormat!=null)
						nMark$=numberFormat.format(nMark);
					else
						nMark$=String.valueOf(nMark);
					nPos=(int)(nMark*factor);
					area.drawHline(g,nPos, axisShift+markSize, nPos,axisShift-markSize,whO);
					area.drawHstring(g,nMark$, nPos, axisShift+15,whO);
				}
			}
		}
	}catch(Exception e) {
		System.out.println("JPlotPanel:scale:drawMarks:"+e.toString());
	}
}
public void draw(Graphics2D g,Dimension whO,Dimension whm) {
		try {
			//System.out.println("JPlotPanel:scale:draw:BEGIN");
			g.setColor(area.frontcolor);
			g.setStroke(new BasicStroke(2));
			if("Horizontal".equals(direction$)){
					g.drawLine( whO.width , whO.height+order*area.shift,  whO.width +whm.width, whO.height+order*area.shift );
					 if("Surface".equals(area.area$)) 
						 g.drawLine( whO.width , whO.height+order*area.shift,  whO.width -whm.width, whO.height+order*area.shift );
					drawHorizontalArrowHead(g ,whO.width +whm.width , whO.height+order*area.shift);
			}
			if("Vertical".equals(direction$)){
				g.drawLine( whO.width-order*area.shift , whO.height,  whO.width-order*area.shift, whO.height-whm.height );
				if("Surface".equals(area.area$)) 
					 g.drawLine( whO.width-order*area.shift , whO.height,  whO.width-order*area.shift, whO.height+whm.height );
				drawVerticalArrowHead(g ,whO.width-order*area.shift , whO.height-whm.height);
			}
			drawMarks(g,whO,whm);
			drawLabel(g,whO,whm);
		    drawGrid(g,whO,whm);
			   // System.out.println("JPlotPanel:scale:draw:FINISH");	
		}catch(Exception e) {
			System.out.println("JPlotPanel:scale:draw:"+e.toString());	
		}
	}
	private void drawHorizontalArrowHead(Graphics2D g2 ,int x ,int y) {
	    Polygon arrowHead = new Polygon();
	   arrowHead.addPoint(x-10, y+5);
	   arrowHead.addPoint(x-10,y -5);
	   arrowHead.addPoint(x, y);
	   g2.fill(arrowHead);
	}
	private void drawVerticalArrowHead(Graphics2D g2 ,int x ,int y) {
	    Polygon arrowHead = new Polygon();
	   arrowHead.addPoint(x, y);
	   arrowHead.addPoint(x-5,y +10);
	   arrowHead.addPoint(x+5, y+10);
	   g2.fill(arrowHead);
	}
	private void drawVerticalMark(Graphics2D g2 ,int x0 ,int y0, int mark,double factor,int n) {
	   int y=(int)(y0-n*mark*factor);
	   g2.drawLine(x0-2,y,x0+2,y);
	}
	public double getValue(int pos,Dimension whO,Dimension whm) {
		double interval=0;
		double mantissa=0;
		int expNum=0;
		double value=0;
		int sval=0;
		if("logarithmic".equals(style$)) {
			int num=maxExp-minExp;
			if("Horizontal".equals(direction$)) {
				interval=whm.width/(num+Double.MIN_VALUE);
				sval=pos-whO.width;
			}
			if("Vertical".equals(direction$)) {
				interval=whm.height/(num+Double.MIN_VALUE);
				sval=whO.height-pos;
			}
			
			expNum=(int)(sval/interval);
			mantissa=(sval-expNum*interval)/(interval);
			value=Math.pow(10,minExp+expNum+mantissa);
            return value;
		}
		if("linear".equals(style$)) {
			if("Horizontal".equals(direction$)) {
				int shift=pos-whO.width;
				value=shift*max/whm.width;
			}
			if("Vertical".equals(direction$)) {
				int shift=whO.height-pos;
				value=shift*max/whm.height;
			}
            return value;
		}
		return 0;
	}
	public int getPos(double value,Dimension whO,Dimension whm) {
		if(Math.abs(value)<Double.MIN_VALUE)
			value=Double.MIN_VALUE;
		int l=0;
		double shift=0;
		//System.out.println("JPlotViewer:Scale:getPos:whO x="+whO.width+"  y="+whO.height);
		if("linear".equals(style$)) {
			double factor=0;
		if("Horizontal".equals(direction$)) {
			 factor=whm.width/max;
			 shift=(value*factor);
			 l=whO.width+(int)shift;
		}
		if("Vertical".equals(direction$)) { 
			 factor=whm.height/max;
		     shift=(value*factor);
		     l=whO.height-(int)shift;
		}
		}
		//System.out.println("JPlotViewer:Scale:getPos:direction="+direction$+"  value="+value+" shift="+shift+"  position="+l);	
		if("logarithmic".equals(style$)) {
			double lgVal=Math.log10(value);
			int num=maxExp-minExp;
	//	System.out.println("JPlotViewer:Scale:getPos:val="+value+" lgVal="+lgVal+"  lgShift="+lgShift+" lgLen="+lgLen);
			if("Horizontal".equals(direction$)) {
				shift=whm.width*(lgVal-minExp)/(maxExp-minExp);
				l= (int)(whO.width+(int)shift);
			}
			if("Vertical".equals(direction$)) { 
				shift=whm.height*(lgVal-minExp)/(maxExp-minExp);
				l= (int)(whO.height-(int)shift);
			}
		}
		//System.out.println("JPlotViewer:Scale:getPos:value="+value+"  direction="+direction$+"  pos="+l);
		return l;
	}
}
class Area{
	public String area$;
	int woffset;
	double wsize;
	int hoffset;
	double hsize;
	public int shift=10;
	boolean valid=false;
	int stroke=1;
	Color backcolor=Color.white;
	Color frontcolor=Color.black;
	public Area(Sack plot) {
	try {
		area$=plot.getElementItemAt("canvas", "area");
		Core vertical=plot.getElementItem(area$, "Vertical");
		hoffset=Integer.parseInt(vertical.type);
		hsize=Double.parseDouble(vertical.value);
		if(hsize>1)
			hsize=1;
		if(hsize<0.2)
			hsize=0.2;
		Core horizontal=plot.getElementItem(area$, "Horizontal");
		woffset=Integer.parseInt(horizontal.type);
		wsize=Double.parseDouble(horizontal.value);
		if(wsize>1)
			wsize=1;
		if(wsize<0.2)
			wsize=0.2;
		shift=Integer.parseInt(plot.getElementItemAt("canvas", "shift"));
		try{stroke=Integer.parseInt(plot.getElementItemAt("canvas", "stroke"));}catch(Exception e){}
		try{backcolor=getColor(plot.getElementItemAt("canvas", "backcolor"));}catch(Exception e){}
		try{frontcolor=getColor(plot.getElementItemAt("canvas", "frontcolor"));}catch(Exception e){}
		valid=true;
	}catch(Exception e) {
		System.out.println("JPlotView:area:"+e.toString());
	}
	}
	public Dimension  getOrigin() {
	
		int w=JPlotPanel.this.getWidth();
		int h=JPlotPanel.this.getHeight();
//System.out.println("JPlotView:getOrigin:area="+area$+"  w="+w+"  h="+h);
		int wO=0;
		int hO=0;
		if(SURFACE.equals(area$)) {
			wO=w/2+woffset;
			hO=h/2-hoffset;
		}
		if(QUADRANT.equals(area$)) {
			wO=woffset;
			hO=h-hoffset;
		}
		//System.out.println("JPlotView:getOrigin:wO="+wO+" hO="+hO);
		return new Dimension(wO,hO);
	}
	public void drawHline(Graphics2D g2,int x0,int y0,int x1,int y1,Dimension whO) {
		AffineTransform old=g2.getTransform();
		setHGraphics(g2,whO);
		g2.drawLine(x0, -y0, x1, -y1);
		g2.setTransform(old);
	}
	public void drawHstring(Graphics2D g2,String text$, int x,int y,Dimension whO) {
		//System.out.println("JPlotPanel:area:drawHstring:x="+x+" y="+y+"  whO.width="+whO.width+" whO.height="+whO.height);
		AffineTransform old=g2.getTransform();
		setHGraphics(g2,whO);	
		g2.drawString(text$, x, -y);
		g2.setTransform(old);
	}
	private void setHGraphics(Graphics2D g2, Dimension whO) {
		AffineTransform at = new AffineTransform();
		at.setToRotation(-Math.PI/2);
		int hh=console.getFootSize();
		at.translate(-whO.height-hh,whO.width);
		//System.out.println("JPlotPanel:area: setHGraphics: dh="+console.getFootSize());
	    g2.setTransform(at);
	}
	private void setWGraphics(Graphics2D g2, Dimension whO) {
		 AffineTransform at = new AffineTransform();
		 int hh=0;
		    int cnt=getParent().getComponentCount();
			    if(cnt>1)
			        hh=getParent().getComponent(cnt-1).getHeight();
	    at.translate(whO.width,whO.height+hh);
		g2.setTransform(at);
	}
	public Dimension  getMaximums() {
		int w=JPlotPanel.this.getWidth();
		int h=JPlotPanel.this.getHeight();
		int wm=0;
		int hm=0;
		if(SURFACE.equals(area$)) {
			wm=(int)(wsize*w/2);
			hm=(int)(hsize*h/2);
		}
		if(QUADRANT.equals(area$)) {
			wm=(int)(wsize*(w-woffset));
			hm=(int)(hsize*(h-hoffset));
		}
		return new Dimension(wm,hm);
	}
	public boolean outOfScope(int x, int y) {
		int w=JPlotPanel.this.getWidth();
		int h=JPlotPanel.this.getHeight();
		Dimension max= getMaximums();
		if(SURFACE.equals(area$)) {
			int w0=w/2;
			int h0=h/2;
			//System.out.println("JPlotPanel:outOfScope:x="+x+" y="+y+ " w0="+w0+" h0="+h0+" wmax="+max.width+" hmax="+max.height);
			//System.out.println("JPlotPanel:outOfScope:left="+(w0-max.width)+" right="+(w0+max.width)+" top="+(h0-max.height)+" bottom="+(h0+max.height));
			if(x<w0-max.width||x>w0+max.width) {
				//System.out.println("JPlotPanel:outOfScope:TRUE");
				return true;
			}
			if(y<(h0-max.height)||y>h0+max.height) {
				//System.out.println("JPlotPanel:outOfScope:TRUE");
				return true;
			}
		}
		if(QUADRANT.equals(area$)) {
			Dimension whO= getOrigin();
			//System.out.println("JPlotPanel:outOfScope:x="+x+" y="+y+ " whO.w="+whO.width+" whO.h="+whO.height+" wmax="+max.width+" hmax="+max.height);
			//System.out.println("JPlotPanel:outOfScope:left="+whO.width+" right="+(whO.width+max.width)+" top="+(whO.height-max.height)+" bottom="+whO.height);
			if(x<whO.width||x>whO.width+max.width) {
				//System.out.println("JPlotPanel:outOfScope:TRUE");
				return true;
			}
			if(y<(whO.height-max.height)||y>whO.height) {
				//System.out.println("JPlotPanel:outOfScope:TRUE");
				return true;
			}
		}
		//System.out.println("JPlotPanel:outOfScope:FALSE");
		return false;
	}
	}
private void save() {
	try{
	
		Calendar cal = Calendar.getInstance();
	     cal.setTime(Date.from(Instant.now()));
	     String record$ = String.format(
	             "%1$tY-%1$tm-%1$td-%1$tk-%1$tS-%1$tp", cal);
	    PlotMaster plotMaster=new PlotMaster();
	    Sack record=plotMaster.createEntity(console.getEntigrator(), record$);
	    String sourceFolder$=entigrator.folderFile(plot.getKey()).getPath();
	    String targetFolder$=entigrator.folderFile(record.getKey()).getPath();
	    FileTool.copyAll(sourceFolder$,targetFolder$);
	    record.createElement("canvas");
	    Core[] ca=plot.elementGet("canvas");
	    for(Core c:ca)
	       record.putElementItem("canvas", c);
	    record.createElement(QUADRANT);
	    ca=plot.elementGet(QUADRANT);
	    for(Core c:ca)
	       record.putElementItem(QUADRANT, c);
	    ca=plot.elementGet(SURFACE);
	    record.createElement(SURFACE);
	    for(Core c:ca)
	       record.putElementItem(SURFACE, c);
	    
	    ca=plot.elementGet("ray.color");
	    record.createElement("ray.color");
	    for(Core c:ca)
	       record.putElementItem("ray.color", c);
	    
	    ca=plot.elementGet("ray.index");
	    record.createElement("ray.index");
	    for(Core c:ca)
	       record.putElementItem("ray.index", c);
	    ca=plot.elementGet("ray.name");
	    record.createElement("ray.name");
	    for(Core c:ca)
	       record.putElementItem("ray.name", c);
	    ca=plot.elementGet("ray.scale");
	    record.createElement("ray.scale");
	    for(Core c:ca)
	       record.putElementItem("ray.scale", c);
	    ca=plot.elementGet("ray.shift");
	    for(Core c:ca)
	       record.putElementItem("ray.shift", c);
	    ca=plot.elementGet("ray.symbol");
	    record.createElement("ray.symbol");
	    for(Core c:ca)
	       record.putElementItem("ray.symbol", c);
	    ca=plot.elementGet("ray.visible");
	    record.createElement("ray.visible");
	    for(Core c:ca)
	       record.putElementItem("ray.visible", c);
	    ca=plot.elementGet("scale.layout");
	    record.createElement("scale.layout");
	    for(Core c:ca)
	       record.putElementItem("scale.layout", c);
	    ca=plot.elementGet("scale.mark");
	    record.createElement("scale.mark");
	    for(Core c:ca)
	       record.putElementItem("scale.mark", c);
	    ca=plot.elementGet("scale.max");
	    for(Core c:ca)
	       record.putElementItem("scale.max", c);
	    ca=plot.elementGet("scale.raster");
	    record.createElement("scale.raster");
	    for(Core c:ca)
	       record.putElementItem("scale.raster", c);
	    entigrator.putEntity(record);
		}catch (Exception e) {
		 System.out.println("JPlotPanel: save:"+ e.toString());	
	}
	}
    class Ray{
			ArrayList<PointValue> locations;
			public Color color=Color.black;
			public String name$;
			public String symbol$=null;
			public String subsymbol$=null;
			public String scale$;
			int index;
			boolean visible=false;
			public Ray(String name$){
				try{
				this.name$=name$;
				String ray$=plot.getElementItemAtValue("ray.name", name$);
				Core symbol=plot.getElementItem("ray.symbol", ray$);
				if(symbol!=null) {
					symbol$=symbol.type;
					subsymbol$=symbol.value;
				}
				scale$=plot.getElementItemAt("ray.scale", ray$);
				color=Color.black;
				String bw$=plot.getElementItemAt("plot","look");
				if(!"bw".equals(bw$))
				   try{color=getColor(plot.getElementItemAt("ray.color", ray$));}catch(Exception e) {}
				index=0;
				try{index=Integer.parseInt(plot.getElementItemAt("ray.index", ray$));}catch(Exception ee) {}
	              try{visible=Boolean.parseBoolean(plot.getElementItemAt("ray.visible", ray$));}catch(Exception ee) {}
				}catch(Exception e){
					//System.out.println("JPlotViewer:Ray:name="+name$+" factor="+factor$+" color="+color$);
					System.out.println("JPlotPanel:Ray:"+e.toString());
				}
			}
			public  void clear(){
				locations.clear();
			}
		public void draw(Graphics2D g,Dimension whO,Dimension whm) {
				//System.out.println("JPlotPanel:Ray:draw="+name$);
			try {
				int stroke=2;
				String stroke$=plot.getElementItemAt("canvas", "stroke");
				if(stroke$!=null)
					try {stroke=Integer.parseInt(stroke$); }catch(Exception ee) {}
				g.setStroke(new BasicStroke(stroke));
				g.setColor(color);
				//System.out.println("JPlotPanel:Ray:draw:whOx="+whO.width+"  whOy="+whO.height+"  whm.x="+whm.width+" whm.y="+whm.height);
			if(locations==null||locations.size()<1) {
				System.out.println("JPlotPanel:Ray:draw:empty locations");
				return;
			}
				int i=0;
				ArrayList<PointPosition>ppl=new ArrayList<PointPosition>();
				int x;
				int y;
				Scale yscale=new Scale(scale$);
			//	System.out.println("JPlotPanel:Ray:draw:BEGIN:i="+i);
				int[] xa=new int[0];
				int[] ya=new int[0];
				boolean outOfScope=false;
				PointPosition pp;
				for(PointValue l:locations) {
					x=xscale.getPos(l.x,whO, whm);
					y=yscale.getPos(l.y,whO,whm);
					if(!area.outOfScope(x, y)) {
						pp=new PointPosition(x,y);
						if(!ppl.contains(pp))
						ppl.add(pp);
					//	System.out.println("JPlotPanel:Ray:draw:  x="+x+"  y="+y);
					}else {
						xa=new int [ppl.size()];
						ya=new int [ppl.size()];
						int cnt=ppl.size();
						for(int j=0;j<cnt;j++)
						{
							pp=ppl.get(j);
							xa[j]=pp.x;
							ya[j]=pp.y;
							//System.out.println("JPlotPanel:Ray:draw:i="+i+"  x="+pp.x+"  y="+pp.y);
						}	
					  g.drawPolyline(xa,ya,cnt-1);
					  if(symbol$!=null) {
						    int m=xa.length-1;
						    if(m>0)
							 g.drawString(symbol$+subsymbol$, xa[m]+5, ya[m]);
						 }
					  ppl.clear();
					//  System.out.println("JPlotPanel:Ray:draw:i="+i+"  x="+x+"  y="+y+" l.x="+l.x+" l.y="+l.y);
					}
				}
				xa=new int [ppl.size()];
				ya=new int [ppl.size()];
				for(PointPosition pp1:ppl) {
					xa[i]=pp1.x;
					ya[i]=pp1.y;
					i++;
				}
				// System.out.println("JPlotPanel:Ray:symbol="+symbol$+" subsymbol="+subsymbol$+"  xs="+xs+" ys="+ys);
				g.drawPolyline(xa,ya,xa.length);
				  if(symbol$!=null) {
					    int m=xa.length-1;
					    if(m>0)
						 g.drawString(symbol$+subsymbol$, xa[m]+5, ya[m]);
					 }
			}catch(Exception e) {
				System.out.println("JPlotPanel:Ray:draw:"+e.toString());
			}
			}
		
		public void load() {
			//System.out.println("JPlotPanel:Ray:load");
				try {
					String entihome$=console.getEntigrator().getEntihome();
					String home$=entihome$+"/"+plot.getKey();
					File home=new File(home$);
					String [] sa=home.list();
					String data$=null;
					for(String s:sa) {
						if(s.endsWith(".data")) {
							data$=home$+"/"+s;
						}
					}
	//				System.out.println("JPlotPanel:Ray:load:data="+data$);
					if(data$==null) {
						System.out.println("JPlotPanel:Ray:load:cnnot find data file");
						return;
					}
					if(locations==null)
						locations=new ArrayList<PointValue>();
					else
						locations.clear();
					BufferedReader br = new BufferedReader(new FileReader(data$));
					double yval;
					double xval;
					double yloc;
					double xloc;
					String line$;
					PointValue rl;
					//System.out.println("JPlotPanel:Ray:load:name=" +name$+" index="+index);
				while ((line$ = br.readLine()) != null) {
						//System.out.println("JPlotPanel:Ray:load:line="+line$);
						sa=line$.split(";");
	                     xval=0;
	                     yval=0;
	                     try{xval=Double.parseDouble(sa[0]);}catch(Exception e) {}
	                     if(sa.length>index) 
	                    	 try{yval=Double.parseDouble(sa[index+1]);}catch(Exception e) {}
	                   //  System.out.println("JPlotPanel:Ray:load:i="+i+" xval="+xval+" yval="+yval+" xmax="+xscale.max);
	                    // System.out.println("JPlotPanel:Ray:load:xval="+xval+" yval=="+yval);
	                     rl=new PointValue(xval,yval);	 
	                     locations.add(rl);
					}
					br.close();
				}catch(Exception e) {
					System.out.println("JPlotPanel:Ray:load:"+e.toString());
				}
			}
	}
	
    class PlotMouseListener extends MouseAdapter {
	public void mouseClicked(MouseEvent evt) {
    	Point point=evt.getPoint();
        //System.out.println("JPlotPanel:mouse x="+point.x+"  y="+point.y);
        Component root=SwingUtilities.getRoot(JPlotPanel.this);
    	 if (evt.getButton() == MouseEvent.BUTTON1){
            showPointer=true;
         } else if (evt.getButton() == MouseEvent.BUTTON3) {
        	  showPointer=false;
        	  root.revalidate();
              root.repaint();
        	  return;
         } 
        int x=point.x;
        int y=point.y;
        int r=3;
        x = x-(r/2);
        y = y-(r/2);
        Dimension whO=area.getOrigin();
        Dimension whm=area.getMaximums();
        fx=(point.x-whO.width)/(whm.width+Double.MIN_VALUE);
        fy=-(whO.height-point.y)/(-whm.height+Double.MIN_VALUE);
        root.revalidate();
        root.repaint();
    }
    }
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	/*
	@Override
	public boolean handleDone() {
		String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
		JDisplay display=getDisplay();
		if(parentLocator$==null) {
			System.out.println("JPlotPanel:handleDone:parent is null:locator="+locator$);
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String facetList$=JEntityFacetList.classLocator();
			facetList$=Locator.append(facetList$, Entigrator.ENTITY_LABEL, entity$);
			JEntityFacetList facetList=new JEntityFacetList(console,facetList$);
		    replace(console, facetList);
		    return true;
		}
		JContext.displayInstance(console, parent$,getDisplay());
		return true;
	}
	*/
    }	  
