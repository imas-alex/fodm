package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.JTextComponent;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.MathUtil;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.JContext;
import javax.swing.border.LineBorder;
import java.beans.PropertyChangeSupport;
import java.awt.FlowLayout;
import javax.swing.JScrollPane;

public class JPlotEditor extends  JContext{
	private static final long serialVersionUID = 1L;
	public static final String PLOT_FACET_TYPE="plot";
	public static final String PLOT_FACET_NAME="Plot";
	public static final String PLOT_MASTER_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.JPlotMaster";
	public static final String KEY="_yR27ck1Kd9_SVNWtgkaOPcboavPc";
	private Sack entity;
	protected JMenu menu;
	protected boolean ignoreOutdate=false;
	protected Entigrator entigrator;

	JComboBox <String>cbxRaySelector;
	JComboBox <String>cbxRayColor;
	JComboBox <String>cbxRayVisible;
	//JComboBox cbxAxisSelector ;
	JComboBox <String>cbxAxisDirection;
	JComboBox <String>cbxScaleSelector;
	JComboBox <String>cbxScaleDirection;
	JComboBox <String>cbxCanvasDirection;
	JComboBox <String>cbxAxis;
	JComboBox  <String>cbxCanvasArea;
	JComboBox  <String>cbxScaleStyle;
	JComboBox  <String>cbxRayScale;
	JTextField txtRayFactor; 
	JTextField txtOffset;
	JTextField txtGrid;
	JTextField txtSize;
	JTextField txtMark ;
	JTextField txtUnit ;
	JTextField txtOrder;
	JTextField txtDirection;
	JTextField txtMax;
	JTextField txtRaster;
	JTextField txtAxisShift;
	JButton btnRaySave;
	private JTextField txtSymbol;
	private JTextField txtSubsymbol;
	JTextField txtRayIndex;
	JTextField txtRayShift;
	
	boolean initScales=true;
	Font defaultFont;
	public JPlotEditor(JMainConsole console,String locator$) {
			super(console,locator$);
			entigrator=console.getEntigrator();
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		//	System.out.println("JPlotEditor:entity="+entity$);
			entity=entigrator.getEntityAtLabel(entity$);
			setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
			JScrollPane scrollPane = new JScrollPane();
			 add(scrollPane);
			JPanel graph = new JPanel();
			scrollPane.setViewportView(graph);
            graph.setLayout(new BoxLayout(graph, BoxLayout.Y_AXIS));
		 //axis
				JPanel canvasSettings	 = new JPanel();
				canvasSettings.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Canvas", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
				GridBagLayout gbl_canvasSettings = new GridBagLayout();
				canvasSettings.setLayout(gbl_canvasSettings);
				 graph.add(canvasSettings);	
				 
				 JLabel lblCanvasArea= new JLabel("Area");
				 GridBagConstraints gbc_lblCanvasArea = new GridBagConstraints();
				 gbc_lblCanvasArea.insets = new Insets(0, 0, 5, 5);
				 gbc_lblCanvasArea.weightx = 0.0;
				 gbc_lblCanvasArea.weighty = 0.0;
				 gbc_lblCanvasArea.gridwidth = 1;
				 gbc_lblCanvasArea.gridx = 0;
				 gbc_lblCanvasArea.gridy = 0;
				 canvasSettings.add(lblCanvasArea, gbc_lblCanvasArea);

				 cbxCanvasArea = new JComboBox<String>();
				 cbxCanvasArea.addActionListener(new ActionListener() {
				 	public void actionPerformed(ActionEvent arg0) {
				 	    String area$=(String)cbxCanvasArea.getSelectedItem();
				 	    entity.putElementItem("canvas", new Core(null,"area",area$));
				 	    console.getEntigrator().putEntity(entity);
				 		initCanvas();
				 	}
				 });
				 cbxCanvasArea.setModel(new DefaultComboBoxModel<String>(new String[] {"Quadrant", "Surface"}));
				 GridBagConstraints gbc_cbxCanvasArea = new GridBagConstraints();
				 gbc_cbxCanvasArea.insets=new Insets(3, 3, 5, 3);
				 gbc_cbxCanvasArea.fill = GridBagConstraints.HORIZONTAL;
				 gbc_cbxCanvasArea.weightx = 0.5;
				 gbc_cbxCanvasArea.gridwidth = 1;
				 gbc_cbxCanvasArea.gridx = 1;
				 gbc_cbxCanvasArea.gridy =0;
				 canvasSettings.add( cbxCanvasArea, gbc_cbxCanvasArea);
								
				 JLabel lblCanvasDirection= new JLabel("Direction");
				 GridBagConstraints gbc_lblCanvasDirection = new GridBagConstraints();
				 gbc_lblCanvasDirection.insets = new Insets(0, 0, 5, 5);
				 gbc_lblCanvasDirection.weightx = 0.0;
				 gbc_lblCanvasDirection.weighty = 0.0;
				 gbc_lblCanvasDirection.gridwidth = 1;
				 gbc_lblCanvasDirection.gridx = 0;
				 gbc_lblCanvasDirection.gridy = 1;
				 canvasSettings.add(lblCanvasDirection, gbc_lblCanvasDirection);

				 cbxCanvasDirection = new JComboBox<String>();
				 cbxCanvasDirection.addActionListener(new ActionListener() {
				 	public void actionPerformed(ActionEvent e) {
				 		initCanvas();
				 	}
				 });
				 cbxCanvasDirection.setModel(new DefaultComboBoxModel<String>(new String[] {"Horizontal", "Vertical"}));
				 GridBagConstraints gbc_cbxCanvasDirection = new GridBagConstraints();
				 gbc_cbxCanvasDirection.insets=new Insets(3, 3, 5, 3);
				 gbc_cbxCanvasDirection.fill = GridBagConstraints.HORIZONTAL;
				 gbc_cbxCanvasDirection.weightx = 0.5;
				 gbc_cbxCanvasDirection.gridwidth = 1;
				 gbc_cbxCanvasDirection.gridx = 1;
				 gbc_cbxCanvasDirection.gridy =1;
				 canvasSettings.add( cbxCanvasDirection, gbc_cbxCanvasDirection);
				 
				 JLabel lblOffset = new JLabel("Offset");
					  GridBagConstraints gbc_lblOffset = new GridBagConstraints();
					  gbc_lblOffset.insets = new Insets(0, 0, 5, 5);
						gbc_lblOffset.weightx = 0.0;
						gbc_lblOffset.weighty = 0.0;
						gbc_lblOffset.gridwidth = 1;
						gbc_lblOffset.gridx = 0;
						gbc_lblOffset.gridy = 2;
					canvasSettings.add(lblOffset, gbc_lblOffset);

					txtOffset = new JTextField();
					 GridBagConstraints gbc_txtOffset = new GridBagConstraints();
					 gbc_txtOffset.insets=new Insets(3, 3, 5, 3);
						gbc_txtOffset.fill = GridBagConstraints.HORIZONTAL;
						gbc_txtOffset.weightx = 0.5;
						gbc_txtOffset.gridwidth = 1;
						gbc_txtOffset.gridx = 1;
						gbc_txtOffset.gridy =2;
			 canvasSettings.add( txtOffset, gbc_txtOffset);
			 
	  JLabel lblSize = new JLabel("Size");
	  GridBagConstraints gbc_lblSize = new GridBagConstraints();
	  gbc_lblSize.insets = new Insets(0, 0, 5, 5);
		gbc_lblSize.weightx = 0.0;
		gbc_lblSize.weighty = 0.0;
		gbc_lblSize.gridwidth = 1;
		gbc_lblSize.gridx = 0;
		gbc_lblSize.gridy = 3;
	   canvasSettings.add(lblSize, gbc_lblSize);
	
	 txtSize = new JTextField();
	 GridBagConstraints gbc_txtSize = new GridBagConstraints();
	 gbc_txtSize.insets=new Insets(3, 3, 5, 3);
		gbc_txtSize.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtSize.weightx = 0.5;
		gbc_txtSize.gridwidth = 1;
		gbc_txtSize.gridx = 1;
		gbc_txtSize.gridy =3;
        canvasSettings.add( txtSize, gbc_txtSize);
        
        JLabel lblShift = new JLabel("Axis shift");
  	  GridBagConstraints gbc_lblShift = new GridBagConstraints();
  	  gbc_lblShift.insets = new Insets(0, 0, 5, 5);
  		gbc_lblShift.weightx = 0.0;
  		gbc_lblShift.weighty = 0.0;
  		gbc_lblShift.gridwidth = 1;
  		gbc_lblShift.gridx = 0;
  		gbc_lblShift.gridy = 4;
  	   canvasSettings.add(lblShift, gbc_lblShift);
  	
  	 txtAxisShift = new JTextField();
  	 GridBagConstraints gbc_txtShift = new GridBagConstraints();
  	 gbc_txtShift.insets=new Insets(3, 3, 5, 3);
  		gbc_txtShift.fill = GridBagConstraints.HORIZONTAL;
  		gbc_txtShift.weightx = 0.5;
  		gbc_txtShift.gridwidth = 1;
  		gbc_txtShift.gridx = 1;
  		gbc_txtShift.gridy =4;
          canvasSettings.add( txtAxisShift, gbc_txtShift);
        
        JPanel desk1 = new JPanel();
        GridBagConstraints gbc_desk1 = new GridBagConstraints();
        gbc_desk1.fill = GridBagConstraints.HORIZONTAL;
        gbc_desk1.gridx = 1;
        gbc_desk1.gridy = 5;
        canvasSettings.add(desk1, gbc_desk1);
        
        JButton btnCanvasSave = new JButton("Save");
        btnCanvasSave.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        		saveCanvasSettings();
        	}
        });
        desk1.add(btnCanvasSave);
//scale settings
JPanel scaleSettings	 = new JPanel();
 scaleSettings.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Scale", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
 GridBagLayout gbl_scaleSettings = new GridBagLayout();
 scaleSettings.setLayout(gbl_scaleSettings);
 graph.add(scaleSettings);		

 JLabel lblScaleDirection= new JLabel("Direction");
 GridBagConstraints gbc_lblScaleDirection = new GridBagConstraints();
 gbc_lblScaleDirection.insets = new Insets(0, 0, 5, 5);
 gbc_lblScaleDirection.gridx = 0;
 gbc_lblScaleDirection.gridy = 0;
 scaleSettings.add(lblScaleDirection, gbc_lblScaleDirection);


 cbxScaleDirection = new JComboBox<String>();
 cbxScaleDirection.setModel(new DefaultComboBoxModel<String>(new String[] {"Horizontal", "Vertical"}));
 cbxScaleDirection.addActionListener(new ActionListener() {
 	public void actionPerformed(ActionEvent e) {
  		setScaleNames();
 		initScale();
	
 	}
 	
 });

 GridBagConstraints gbc_cbxScaleDirection = new GridBagConstraints();
 gbc_cbxScaleDirection.insets=new Insets(3, 3, 5, 3);
 gbc_cbxScaleDirection.fill = GridBagConstraints.HORIZONTAL;
 gbc_cbxScaleDirection.gridx = 1;
 gbc_cbxScaleDirection.gridy =0;
 scaleSettings.add( cbxScaleDirection, gbc_cbxScaleDirection);

 JLabel lblScale = new JLabel("Name");
  GridBagConstraints gbc_lblScale = new GridBagConstraints();
  gbc_lblScale.insets = new Insets(0, 0, 5, 5);
gbc_lblScale.weightx = 0.0;
gbc_lblScale.weighty = 0.0;
			gbc_lblScale.gridx = 0;
			gbc_lblScale.gridy = 1;
		  scaleSettings.add(lblScale, gbc_lblScale);
		  cbxScaleSelector = new JComboBox<String>();
		  cbxScaleSelector.setEditable(true);
		  cbxScaleSelector.addActionListener(new ActionListener () {
			   public void actionPerformed( ActionEvent evt  ){
				   initScale();
			   }
		});
		  final JTextComponent tc = (JTextComponent) cbxScaleSelector.getEditor().getEditorComponent();
		 tc.getDocument().addDocumentListener(new DocumentListener() {
				@Override
				public void changedUpdate(DocumentEvent arg0) {
					 //System.out.println("TextEditor:editorPane:changedUpdate="+arg0.toString());
				}
				@Override
				public void insertUpdate(DocumentEvent arg0) {
					int l=tc.getDocument().getLength();
					try {
					//System.out.println("JPlotEditor:scale selector:insertUpdate="+arg0.getDocument().getText(0,l));
					String scale$=arg0.getDocument().getText(0,l);
					initScale(scale$);
					}catch(Exception e) {}
				}
				@Override
				public void removeUpdate(DocumentEvent arg0) {
					int l=tc.getDocument().getLength();
					try {
					//System.out.println("JPlotEditor:scale selector:remiveUpdate="+arg0.getDocument().getText(0,l ));
					String scale$=arg0.getDocument().getText(0,l);
					initScale(scale$);
					}catch(Exception e) {}
					//System.out.println("JPlotEditor:scale selector:changedUpdate="+tc.getText());
				}
		    });
		 GridBagConstraints gbc_cbxScaleSelector = new GridBagConstraints();
		 gbc_cbxScaleSelector.insets=new Insets(3, 3, 5, 3);
			gbc_cbxScaleSelector.fill = GridBagConstraints.HORIZONTAL;
			gbc_cbxScaleSelector.weightx = 0.5;
			gbc_cbxScaleSelector.weighty = 0.0;
			gbc_cbxScaleSelector.gridwidth = 1;
			gbc_cbxScaleSelector.gridx = 1;
			gbc_cbxScaleSelector.gridy = 1;
			scaleSettings.add( cbxScaleSelector , gbc_cbxScaleSelector);
     JLabel lblMark = new JLabel("Mark");
	  GridBagConstraints gbc_lblMark = new GridBagConstraints();
	  gbc_lblMark.insets = new Insets(0, 0, 5, 5);
		gbc_lblMark.weightx = 0.0;
		gbc_lblMark.weighty = 0.0;
		gbc_lblMark.gridwidth = 1;
		gbc_lblMark.gridx = 0;
		gbc_lblMark.gridy = 2;
	    scaleSettings.add(lblMark, gbc_lblMark);

	 txtMark = new JTextField();
	 GridBagConstraints gbc_txtMark = new GridBagConstraints();
	 gbc_txtMark.insets=new Insets(3, 3, 5, 3);
		gbc_txtMark.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtMark.weightx = 0.5;
		gbc_txtMark.gridwidth = 1;
		gbc_txtMark.gridx = 1;
		gbc_txtMark.gridy =2;
		scaleSettings.add( txtMark, gbc_txtMark);
		
		 JLabel lblUnit = new JLabel("Unit");
		  GridBagConstraints gbc_lblUnit = new GridBagConstraints();
		  gbc_lblUnit.insets = new Insets(0, 0, 5, 5);
			gbc_lblUnit.weightx = 0.0;
			gbc_lblUnit.weighty = 0.0;
			gbc_lblUnit.gridwidth = 1;
			gbc_lblUnit.gridx = 0;
			gbc_lblUnit.gridy = 3;
		    scaleSettings.add(lblUnit, gbc_lblUnit);

		 txtUnit = new JTextField();
		 GridBagConstraints gbc_txtUnit = new GridBagConstraints();
		 gbc_txtUnit.insets=new Insets(3, 3, 5, 3);
			gbc_txtUnit.fill = GridBagConstraints.HORIZONTAL;
			gbc_txtUnit.weightx = 0.5;
			gbc_txtUnit.gridwidth = 1;
			gbc_txtUnit.gridx = 1;
			gbc_txtUnit.gridy =3;
			scaleSettings.add( txtUnit, gbc_txtUnit);
		

JLabel lblOrder = new JLabel("Order");
GridBagConstraints gbc_lblOrder = new GridBagConstraints();
gbc_lblOrder.insets = new Insets(0, 0, 5, 5);
gbc_lblOrder.weightx = 0.0;
gbc_lblOrder.weighty = 0.0;
gbc_lblOrder.gridwidth = 1;
gbc_lblOrder.gridx = 0;
gbc_lblOrder.gridy = 4;
scaleSettings.add(lblOrder, gbc_lblOrder);

txtOrder = new JTextField();
GridBagConstraints gbc_txtOrder = new GridBagConstraints();
gbc_txtOrder.insets=new Insets(3, 3, 5, 3);
gbc_txtOrder.fill = GridBagConstraints.HORIZONTAL;
gbc_txtOrder.weightx = 0.5;
gbc_txtOrder.gridwidth = 1;
gbc_txtOrder.gridx = 1;
gbc_txtOrder.gridy =4;
scaleSettings.add( txtOrder, gbc_txtOrder);

JLabel lblMax = new JLabel("Maximum");
GridBagConstraints gbc_lblMax = new GridBagConstraints();
gbc_lblMax.insets = new Insets(0, 0, 5, 5);
gbc_lblMax.weightx = 0.0;
gbc_lblMax.weighty = 0.0;
gbc_lblMax.gridwidth = 1;
gbc_lblMax.gridx = 0;
gbc_lblMax.gridy = 5;
scaleSettings.add(lblMax, gbc_lblMax);

txtMax = new JTextField();
GridBagConstraints gbc_txtMax = new GridBagConstraints();
gbc_txtMax.insets=new Insets(3, 3, 5, 3);
gbc_txtMax.fill = GridBagConstraints.HORIZONTAL;
gbc_txtMax.weightx = 0.5;
gbc_txtMax.gridwidth = 1;
gbc_txtMax.gridx = 1;
gbc_txtMax.gridy =5;
scaleSettings.add( txtMax, gbc_txtMax);

JLabel lblRaster = new JLabel("Raster");
GridBagConstraints gbc_lblRaster = new GridBagConstraints();
gbc_lblRaster.insets = new Insets(0, 0, 5, 5);
gbc_lblRaster.weightx = 0.0;
gbc_lblRaster.weighty = 0.0;
gbc_lblRaster.gridwidth = 1;
gbc_lblRaster.gridx = 0;
gbc_lblRaster.gridy = 6;
scaleSettings.add(lblRaster, gbc_lblRaster);

txtRaster = new JTextField();
GridBagConstraints gbc_txtRaster = new GridBagConstraints();
gbc_txtRaster.insets=new Insets(3, 3, 5, 3);
gbc_txtRaster.fill = GridBagConstraints.HORIZONTAL;
gbc_txtRaster.weightx = 0.5;
gbc_txtRaster.gridwidth = 1;
gbc_txtRaster.gridx = 1;
gbc_txtRaster.gridy =6;
scaleSettings.add( txtRaster, gbc_txtRaster);

JLabel lblStyle = new JLabel("Style");
GridBagConstraints gbc_lblStyle = new GridBagConstraints();
gbc_lblStyle.insets = new Insets(0, 0, 5, 5);
gbc_lblStyle.weightx = 0.0;
gbc_lblStyle.weighty = 0.0;
gbc_lblStyle.gridx = 0;
gbc_lblStyle.gridy = 7;
scaleSettings.add(lblStyle, gbc_lblStyle);

cbxScaleStyle = new JComboBox<String>();
cbxScaleStyle.setModel(new DefaultComboBoxModel(new String[] {"none", "linear", "logarithmic"}));
GridBagConstraints gbc_cbxScaleStyle = new GridBagConstraints();
gbc_cbxScaleStyle.insets=new Insets(3, 3, 5, 3);
gbc_cbxScaleStyle.fill = GridBagConstraints.HORIZONTAL;
gbc_cbxScaleStyle.weightx = 0.5;
gbc_cbxScaleStyle.weighty = 0.0;
gbc_cbxScaleStyle.gridwidth = 1;
gbc_cbxScaleStyle.gridx = 1;
gbc_cbxScaleStyle.gridy = 7;
scaleSettings.add( cbxScaleStyle , gbc_cbxScaleStyle);


JPanel desk0 = new JPanel();
GridBagConstraints gbc_desk0 = new GridBagConstraints();
gbc_desk0.weightx = 0.0;
gbc_desk0.weighty = 0.0;
gbc_desk0.fill = GridBagConstraints.BOTH;
gbc_desk0.gridx = 0;
gbc_desk0.gridy = 8;
gbc_desk0.gridwidth = 2;
scaleSettings.add(desk0, gbc_desk0);
JButton btnScaleSave = new JButton("Save");
btnScaleSave.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent arg0) {
		saveScale();
	}
});
desk0.add(btnScaleSave);
JButton btnScaleDelete = new JButton("Delete");
btnScaleDelete.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent arg0) {
		deleteScale();
	}
});
desk0.add(btnScaleDelete);

 //ray setting	
JPanel raySettings	 = new JPanel();
					 raySettings.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), "Ray", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLUE));
					 raySettings.setLayout(new GridBagLayout());
					 graph.add(raySettings);		
				 JLabel lblRayOperator = new JLabel("Name");
					  GridBagConstraints gbc_lblRayOperator = new GridBagConstraints();
						
								gbc_lblRayOperator.weightx = 0.0;
								gbc_lblRayOperator.weighty = 0.0;
								gbc_lblRayOperator.gridx = 0;
								gbc_lblRayOperator.gridy = 0;
							  raySettings.add(lblRayOperator, gbc_lblRayOperator);

							 cbxRaySelector = new JComboBox<String>();
							 cbxRaySelector.setEditable(true);
							cbxRaySelector.addActionListener(new ActionListener () {
								   public void actionPerformed( ActionEvent evt  ){
								    	  @SuppressWarnings("unchecked")
										JComboBox<String> cb = (JComboBox) evt.getSource();
										   String  ray$ = (String)cb.getSelectedItem();
										   initRaySettings(ray$);
								   }
							});
							 GridBagConstraints gbc_cbxRaySelector = new GridBagConstraints();
							 gbc_cbxRaySelector.insets=new Insets(3,3,3,3);
								gbc_cbxRaySelector.fill = GridBagConstraints.HORIZONTAL;
								gbc_cbxRaySelector.weightx = 0.5;
								gbc_cbxRaySelector.weighty = 0.0;
								gbc_cbxRaySelector.gridwidth = 1;
								gbc_cbxRaySelector.gridx = 1;
								gbc_cbxRaySelector.gridy = 0;
								raySettings.add( cbxRaySelector , gbc_cbxRaySelector);
						
					 JLabel lblRayColor = new JLabel("Color");
						  GridBagConstraints gbc_lblRayColor = new GridBagConstraints();
							gbc_lblRayColor.weightx = 0.0;
							gbc_lblRayColor.weighty = 0.0;
							gbc_lblRayColor.gridwidth = 1;
							gbc_lblRayColor.gridx = 0;
							gbc_lblRayColor.gridy = 1;
						raySettings.add(lblRayColor, gbc_lblRayColor);

						cbxRayColor = new JComboBox<String>();
						cbxRayColor.setModel(new DefaultComboBoxModel<String>(new String[] {"white", "black", "blue", "red", "orange", "magenta", "cyan"}));
						 GridBagConstraints gbc_cbxRayColor = new GridBagConstraints();
						 gbc_cbxRayColor.insets=new Insets(3,3,3,3);
							gbc_cbxRayColor.fill = GridBagConstraints.HORIZONTAL;
							gbc_cbxRayColor.weightx = 0.5;
							gbc_cbxRayColor.gridwidth = 1;
							gbc_cbxRayColor.gridx = 1;
							gbc_cbxRayColor.gridy = 1;
				raySettings.add( cbxRayColor, gbc_cbxRayColor);
			
				 JLabel lblRayVisible = new JLabel("Visible");
				  GridBagConstraints gbc_lblRayVisible = new GridBagConstraints();
					gbc_lblRayVisible.weightx = 0.0;
					gbc_lblRayVisible.weighty = 0.0;
					gbc_lblRayVisible.gridwidth = 1;
					gbc_lblRayVisible.gridx = 0;
					gbc_lblRayVisible.gridy = 2;
				raySettings.add(lblRayVisible, gbc_lblRayVisible);

				cbxRayVisible = new JComboBox<String>();
				cbxRayVisible.setModel(new DefaultComboBoxModel<String>(new String[] {"false", "true"}));
				 GridBagConstraints gbc_cbxRayVisible = new GridBagConstraints();
				 gbc_cbxRayVisible.insets=new Insets(3,3,3,3);
					gbc_cbxRayVisible.fill = GridBagConstraints.HORIZONTAL;
					gbc_cbxRayVisible.weightx = 0.5;
					gbc_cbxRayVisible.gridwidth = 1;
					gbc_cbxRayVisible.gridx = 1;
					gbc_cbxRayVisible.gridy = 2;
		raySettings.add( cbxRayVisible, gbc_cbxRayVisible);
				
				JLabel lblRayScale = new JLabel("Scale");
				  GridBagConstraints gbc_lblRayScale = new GridBagConstraints();
					gbc_lblRayScale.weightx = 0.0;
					gbc_lblRayScale.gridwidth = 1;
					gbc_lblRayScale.gridx = 0;
					gbc_lblRayScale.gridy = 3;
				raySettings.add(lblRayScale, gbc_lblRayScale);
			
				cbxRayScale = new JComboBox<String>();
				 GridBagConstraints gbc_cbxRayScale = new GridBagConstraints();
				 gbc_cbxRayScale.insets=new Insets(3,3,3,3);
					gbc_cbxRayScale.fill = GridBagConstraints.HORIZONTAL;
					gbc_cbxRayScale.weightx = 0.5;
					gbc_cbxRayScale.gridwidth = 1;
					gbc_cbxRayScale.gridx = 1;
					gbc_cbxRayScale.gridy =3;
					raySettings.add(cbxRayScale, gbc_cbxRayScale);
		
		JLabel lblRayDisplay = new JLabel("Display");
		  GridBagConstraints gbc_lblRayDisplay = new GridBagConstraints();
			gbc_lblRayDisplay.weightx = 0.0;
			gbc_lblRayDisplay.gridwidth = 1;
			gbc_lblRayDisplay.gridx = 0;
			gbc_lblRayDisplay.gridy = 4;
		raySettings.add(lblRayDisplay, gbc_lblRayDisplay);

		JPanel plRayDisplay = new JPanel();
		 GridBagConstraints gbc_plRayDisplay = new GridBagConstraints();
		 gbc_plRayDisplay.insets=new Insets(3,3,3,3);
			gbc_plRayDisplay.fill = GridBagConstraints.HORIZONTAL;
			gbc_plRayDisplay.weightx = 0.5;
			gbc_plRayDisplay.gridwidth = 1;
			gbc_plRayDisplay.gridx = 1;
			gbc_plRayDisplay.gridy =4;
raySettings.add( plRayDisplay, gbc_plRayDisplay);
plRayDisplay.setLayout(new BoxLayout(plRayDisplay, BoxLayout.X_AXIS));
txtSymbol = new JTextField();
plRayDisplay.add(txtSymbol);
txtSymbol.setColumns(10);
txtSubsymbol = new JTextField();
plRayDisplay.add(txtSubsymbol);
txtSubsymbol.setColumns(10);

JLabel lblRayIndex= new JLabel("Index");
GridBagConstraints gbc_lblRayIndex = new GridBagConstraints();
	gbc_lblRayIndex.weightx = 0.0;
	gbc_lblRayIndex.gridwidth = 1;
	gbc_lblRayIndex.gridx = 0;
	gbc_lblRayIndex.gridy = 5;
raySettings.add(lblRayIndex, gbc_lblRayIndex);

txtRayIndex = new JTextField();
GridBagConstraints gbc_txtRayIndex = new GridBagConstraints();
gbc_txtRayIndex.insets=new Insets(3,3,3,3);
	gbc_txtRayIndex.fill = GridBagConstraints.HORIZONTAL;
	gbc_txtRayIndex.weightx = 0.5;
	gbc_txtRayIndex.gridwidth = 1;
	gbc_txtRayIndex.gridx = 1;
	gbc_txtRayIndex.gridy =5;
raySettings.add( txtRayIndex, gbc_txtRayIndex);

JLabel lblRayShift= new JLabel("Shift");
GridBagConstraints gbc_lblRayShift = new GridBagConstraints();
	gbc_lblRayShift.weightx = 0.0;
	gbc_lblRayShift.gridwidth = 1;
	gbc_lblRayShift.gridx = 0;
	gbc_lblRayShift.gridy = 6;
raySettings.add(lblRayShift, gbc_lblRayShift);

txtRayShift = new JTextField();
GridBagConstraints gbc_txtRayShift = new GridBagConstraints();
gbc_txtRayShift.insets=new Insets(3,3,3,3);
	gbc_txtRayShift.fill = GridBagConstraints.HORIZONTAL;
	gbc_txtRayShift.weightx = 0.5;
	gbc_txtRayShift.gridwidth = 1;
	gbc_txtRayShift.gridx = 1;
	gbc_txtRayShift.gridy =6;
raySettings.add( txtRayShift, gbc_txtRayShift);
		
		JPanel desk=new JPanel();  
		 GridBagConstraints gbc_btnDesk = new GridBagConstraints();
			gbc_btnDesk.weightx = 0.0;
			gbc_btnDesk.weighty = 0.0;
			gbc_btnDesk.gridwidth = 2;
			gbc_btnDesk.gridx =0;
			gbc_btnDesk.gridy = 7;
			raySettings.add(desk ,gbc_btnDesk);

		btnRaySave = new JButton("Save");
		btnRaySave.setAlignmentX(Component.CENTER_ALIGNMENT);
		btnRaySave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveRay();
				
			}
		});
		desk.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		desk.add(btnRaySave);
		
		JButton btnRayDelete = new JButton("Delete");
		btnRayDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				deleteRay();
			}
		});
		desk.add(btnRayDelete);
				  
				 JPanel placebo	 = new JPanel();
				 GridBagConstraints gbc_placebo = new GridBagConstraints();
				 gbc_placebo.insets=new Insets(3,3,3,3);
					gbc_placebo.fill = GridBagConstraints.BOTH;
					gbc_placebo.weightx = 0.5;
					gbc_placebo.weighty = 0.5;
					gbc_placebo.gridwidth = 3;
					gbc_placebo.gridx = 0;
					gbc_placebo.gridy = 5;
					 graph.add(placebo);
					 initCanvas();
					 initScales();
					 initRays();
		}
		public static String classLocator() {
			Properties locator=new Properties();
			locator.put(FacetHandler.FACET_KEY,KEY);
			locator.put(FacetHandler.FACET_NAME,PLOT_FACET_NAME);
			locator.put(FacetHandler.FACET_TYPE,PLOT_FACET_TYPE);
			locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
			locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
			locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.JPlotMaster");
			locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
			locator.put(JContext.CONTEXT_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.JPlotEditor");
			return Locator.toString(locator);
		}

private void initRaySettings(String ray$){
	try{
		String key$=entity.getElementItemAtValue("ray.name",ray$);
		String color$=entity.getElementItemAt("ray.color",key$);
		int cnt=cbxRayColor.getModel().getSize();
		int ind=0;
		for(int i=0;i<cnt;i++){
			if(((String)cbxRayColor.getItemAt(i)).equalsIgnoreCase(color$))
				ind=i;
	}
		cbxRayColor.setSelectedIndex(ind);
		String visible$=entity.getElementItemAt("ray.visible",key$);
    	 cnt=cbxRayVisible.getModel().getSize();
			 ind=0;
			for(int i=0;i<cnt;i++){
				if(((String)cbxRayVisible.getItemAt(i)).equalsIgnoreCase(visible$))
					ind=i;
		}
			cbxRayVisible.setSelectedIndex(ind);
		String scale$=entity.getElementItemAt("ray.scale",key$);
		if(scale$!=null)
			selectCombo(cbxRayScale,scale$);
		Core symbol=entity.getElementItem("ray.symbol",key$);
		if(symbol==null){
			txtSymbol.setText(null);
			txtSubsymbol.setText(null);
		}else{
			txtSymbol.setText(symbol.type);
			txtSubsymbol.setText(symbol.value);
		}
		String index$=entity.getElementItemAt("ray.index",key$);
		txtRayIndex.setText(index$);
		String shift$=entity.getElementItemAt("ray.shift",key$);
		//System.out.println("JGraphEditor:initRaySettings:key="+key$+"  shift="+shift$);
		txtRayShift.setText(shift$);
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
}

private void saveCanvasSettings(){
	try{
	String area$=(String)cbxCanvasArea.getSelectedItem();
	String direction$=(String)cbxCanvasDirection.getSelectedItem();
	String offset$=txtOffset.getText();
	String size$=txtSize.getText();
	String shift$=txtAxisShift.getText();
	if(!entity.existsElement(area$))
		entity.createElement(area$);
	entity.putElementItem(area$,new  Core(offset$,direction$,size$ ));
	if((!entity.existsElement("canvas")))
		entity.createElement("canvas");
	entity.putElementItem("canvas",new  Core("","area",area$ ));
	entity.putElementItem("canvas",new  Core("","shift",shift$ ));
	entigrator.putEntity(entity);
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
}

private void initRays(){
	try{
	   Core []ca=entity.elementGet("scale.layout");
	   if(ca!=null) {
		   ArrayList<String>sl=new ArrayList<String>();
		   for(Core c:ca) {
			   if("Vertical".equals(c.type))
				   sl.add(c.name);
		   }
		   String[] sa=new String[sl.size()];
		   sl.toArray(sa);
		   Arrays.sort(sa);
		   DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String>(sa);
		   cbxRayScale.setModel(model);
	   }
		   ca=entity.elementGet("ray.name");
	    if(ca!=null&&ca.length>0l){
	    	String[] sa=new String[ca.length];
	    	for(int i=0;i<ca.length;i++)
	    		sa[i]=ca[i].value;
	    	Arrays.sort(sa);
	    	DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String>(sa);
	    	cbxRaySelector.setModel(model);
	    	initRaySettings(sa[0]);
	    }
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
}

private void initScales(){
	setScaleNames();
    initScale();
}
private void initScale() {
	String scale$=(String)cbxScaleSelector.getSelectedItem();
	initScale(scale$);
}
private void initScale(String scale$){
    Core layout=entity.getElementItem("scale.layout",scale$);
    if(layout!=null){
    	txtOrder.setText(layout.value);
    }else {
    	txtOrder.setText(null);
    }
    Core mark=entity.getElementItem("scale.mark",scale$);
    if(mark!=null){
      txtUnit.setText(mark.type);
      txtMark.setText(mark.value);
    }else {
    	txtUnit.setText(null);
        txtMark.setText(null);
    }
    Core max=entity.getElementItem("scale.max",scale$);
    if(max!=null)
    txtMax.setText(max.value);
    else
    	 txtMax.setText("");
    Core raster=entity.getElementItem("scale.raster",scale$);
    if(raster!=null) {
    txtRaster.setText(raster.value);
    selectCombo(cbxScaleStyle,raster.type);
    }else
    	 txtRaster.setText(null);
}
private void setScaleNames(){
   
    String direction$=(String)cbxScaleDirection.getSelectedItem();
    DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String>();
    ArrayList<String>sl=new  ArrayList<String>();
    Core[] ca=entity.elementGet("scale.layout");
    
    if(ca!=null) {
    	for(Core c:ca) {
    
    		if(direction$.equals(c.type))
    			sl.add(c.name);
    	}
    String[] sa=new String[sl.size()];
    sl.toArray(sa);
    Arrays.sort(sa);
    model=new DefaultComboBoxModel<String>(sa);
    }
   cbxScaleSelector.setModel(model);
   
}
@Override
public JMenu getContextMenu() {
	menu=super.getContextMenu();
	menu.addSeparator();
	JMenuItem viewItem = new JMenuItem("View");
	 viewItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String viewerLocator$= JPlotPanel.classLocator();
				viewerLocator$=Locator.append(viewerLocator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
				//System.out.println("JPlotEditor:vew;locator="+locator$);
				instance$=SessionHandler.putLocator(console.getEntigrator(),locator$);
				viewerLocator$=Locator.append(viewerLocator$,PARENT, instance$);
				String pointDisplay$=entity.getElementItemAt("plot", "point.display");
				if(pointDisplay$==null) 
					pointDisplay$="_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot.DefaultPointDisplay";
				viewerLocator$=Locator.append(viewerLocator$, JPlotPanel.POINT_DISPLAY, pointDisplay$);
				JPlotPanel plotViewer=new JPlotPanel(console,viewerLocator$);
			    replace(console, plotViewer);
			}
		} );
		menu.add(viewItem);	
		JMenuItem makerItem = new JMenuItem("Maker");
		makerItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
				 showMaker();
				}
			} );
			menu.add(makerItem);
		if(!hasMaker())
			makerItem.setEnabled(false);
		JMenuItem folderItem = new JMenuItem("Folder");
		folderItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					File folder=new File(entigrator.getEntihome()+"/"+entity.getKey());
					try{Desktop.getDesktop().open(folder);}catch(Exception ee) {}
				}
			} );
			menu.add(folderItem);
			JMenuItem entityItem = new JMenuItem("Entity");
			entityItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						String facetsLocator$=JEntityFacetList.classLocator();
						facetsLocator$=Locator.append(facetsLocator$, Entigrator.ENTITY_LABEL, entity.getProperty("label"));
						JEntityFacetList facetList=new JEntityFacetList(console,facetsLocator$);
						JPlotEditor.this.replace(console, facetList);
					}
				} );
				menu.add(entityItem);
				JMenuItem interpolateItem = new JMenuItem("Interpolate");
				interpolateItem.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							interpolate();
						}
					} );
					menu.add( interpolateItem);	
	return menu;
	 }
private boolean hasMaker() {
	if(entity.elementListNames("customer")!=null)
		return true;
	return false;
}
private void showMaker() {
	String[] sa=entity.elementListNames("customer");
	if(sa==null)
		return;
	String maker$=entity.getElementItemAt("customer", sa[0]);
	  String mlocator$=JEntityFacetList.classLocator();
	 mlocator$=Locator.append(mlocator$,Entigrator.ENTITY_LABEL, maker$);
	 String display$=Locator.getProperty(locator$, DISPLAY);
	 if(display$==null)
		 display$=console.getDisplayKey(this);
	 if(display$!=null)
		 mlocator$=Locator.append(mlocator$,DISPLAY, display$);
	 System.out.println("JPlotEditor:showMaker:display="+display$);
	 JEntityFacetList facetList=new   JEntityFacetList (console,mlocator$);
	   replace(console, facetList);
	
}
private void deleteScale(){
	try{
		int response = JOptionPane.showConfirmDialog(this, "Delete selected scale  ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		    if (response != JOptionPane.YES_OPTION) 
		    	return;
		String scale$=(String)cbxScaleSelector.getSelectedItem();    
			entity.removeElementItem("scale.layout",scale$ );
    		entity.removeElementItem("scale.mark",scale$ );
    		entigrator.putEntity(entity);
    		initScales();
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
}

public static void  showGraph(Entigrator entigrator ,Sack entity, JPanel panel){
	try{
		System.out.println("JGraphEditor :showGraph: entity="+entity.getProperty("label"));
		String entityKey$=entity.getKey();
	String entihome$=entigrator.getEntihome();
	File implementorHome=new File(entihome$+"/"+entityKey$);
	if(! implementorHome.exists())
		 implementorHome.mkdirs();
	File graphJava=new File(entihome$+"/"+entityKey$+"/"+entityKey$+".java");
	File graphClass=new File(entihome$+"/"+entityKey$+"/"+entityKey$+".class");
	if(!graphClass.exists()){
		System.out.println("JGraphEditor :cannot find class:"+graphClass.getPath());
		return;
	}
	URL url = implementorHome.toURI().toURL();
    URL[] urls = new URL[]{url};
    ClassLoader parentLoader = Entigrator.class.getClassLoader();
    URLClassLoader cl = new URLClassLoader(urls,parentLoader);
    Class <?>cls = cl.loadClass(entityKey$);
   Object    implementor =cls.getDeclaredConstructor().newInstance();
   Method  impShow=implementor.getClass().getDeclaredMethod("show",Entigrator.class, Sack.class,JPanel.class);
	impShow.invoke(implementor,entigrator,entity,panel);
	}catch(Exception e){
		  Logger.getLogger(JPlotEditor.class.getName()).severe(e.toString());
	}
}
private void saveScale() {
	try{
		//System.out.println("JTubeEditor:deleteRay:ray="+ray$);
    	String direction$=cbxScaleDirection.getSelectedItem().toString();
		String name$=cbxScaleSelector.getSelectedItem().toString();
		String mark$=txtMark.getText();
		String unit$=txtUnit.getText();
		String order$=txtOrder.getText();
		String max$=txtMax.getText();
		Core core1=new Core(direction$,name$,order$);
		if(!entity.existsElement("scale.layout"))
			entity.createElement("scale.layout");
		entity.putElementItem("scale.layout", core1);
		Core core2=new Core(unit$,name$,mark$);
		if(!entity.existsElement("scale.mark"))
			entity.createElement("scale.mark");
		entity.putElementItem("scale.mark", core2);
		if(!entity.existsElement("scale.max"))
			entity.createElement("scale.max");
		Core max=entity.getElementItem("scale.max", name$);
		if(max==null)
			max= new Core("0.###",name$,max$);
		else
			max.value=max$;
		entity.putElementItem("scale.max", max);
		if(!entity.existsElement("scale.raster"))
			entity.createElement("scale.raster");
		String raster$=txtRaster.getText();
		String style$=(String)cbxScaleStyle.getSelectedItem();
		entity.putElementItem("scale.raster", new Core(style$,name$,raster$));
   		entigrator.putEntity(entity);
   	    initScales();
   	  //  selectCombo(cbxScaleDirection,direction$);
   	 selectCombo(cbxScaleSelector,name$);
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
}
private void saveRay() {
	try{
    	// System.out.println("JGraphEditor:saveScale:1");
		String name$=cbxRaySelector.getSelectedItem().toString();
		String color$=cbxRayColor.getSelectedItem().toString();
		String visible$=cbxRayVisible.getSelectedItem().toString();
		String scale$=(String)cbxRayScale.getSelectedItem();
		String symbol$=txtSymbol.getText();
		String subSymbol$=txtSubsymbol.getText();
		String index$=txtRayIndex.getText();
		String key$=Identity.key();
		if(!entity.existsElement("ray.name"))
			entity.createElement("ray.name");
		Core [] ca= entity.elementGet("ray.name");
		if(ca!=null)
		  for (Core c:ca)
			if(name$.equals(c.value))
				key$=c.name;
		Core core=new Core(null,key$,name$);
		entity.putElementItem("ray.name", core);
		core=new Core(null,key$,color$);
		if(!entity.existsElement("ray.color"))
			entity.createElement("ray.color");
		entity.putElementItem("ray.color", core);
		core=new Core(null,key$,scale$);
		if(!entity.existsElement("ray.scale"))
			entity.createElement("ray.scale");
		entity.putElementItem("ray.scale", core);
		core=new Core(null,key$,index$);
		if(!entity.existsElement("ray.index"))
			entity.createElement("ray.index");
		entity.putElementItem("ray.index", core);
		core=new Core(symbol$,key$,subSymbol$);
		if(!entity.existsElement("ray.symbol"))
			entity.createElement("ray.symbol");
		entity.putElementItem("ray.symbol", core);
		core=new Core(null,key$,visible$);
		if(!entity.existsElement("ray.visible"))
			entity.createElement("ray.visible");
		entity.putElementItem("ray.visible", core);
		if(!entity.existsElement("ray.shift"))
			entity.createElement("ray.shift");
		entity.putElementItem("ray.shift",new  Core(null,key$,txtRayShift.getText() ));
   		entigrator.putEntity(entity);
   		initRays();
   		selectCombo(cbxRaySelector,name$);
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
}
private void deleteRay() {
	int response = JOptionPane.showConfirmDialog(this, "Delete selected ray  ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
    if (response != JOptionPane.YES_OPTION) 
    	return;
	try{
		String name$=cbxRaySelector.getSelectedItem().toString();
		String key$= entity.getElementItemAtValue("ray.name", name$);
		String index$=txtRayIndex.getText();
		entity.removeElementItem("ray.name", key$);
		entity.removeElementItem("ray.color", key$);
		entity.removeElementItem("ray.scale", key$);
		entity.removeElementItem("ray.symbol", key$);
		entity.removeElementItem("ray.visible", key$);
		entity.removeElementItem("ray.shift", key$);
		entity.removeElementItem("ray.index", index$);
		entigrator.putEntity(entity);
		initRays();
	}catch(Exception e){
		Logger.getLogger(getClass().getName()).severe(e.toString());
	}
}
private void initCanvas() {
	
	String area$=entity.getElementItemAt("canvas", "area");
	selectCombo(cbxCanvasArea,area$);
	String direction$=(String)cbxCanvasDirection.getSelectedItem();
	Core v=entity.getElementItem(area$, direction$);
	if(v!=null) {
		txtOffset.setText(v.type);
		txtSize.setText(v.value);
	}else {
		txtOffset.setText("");
		txtSize.setText("");
	}
	String shift$=entity.getElementItemAt("canvas", "shift");	
	txtAxisShift.setText(shift$);
}
@Override
public String getClassLocator() {
	return classLocator();
}
private void interpolate() {
	try {
		String entihome$=console.getEntigrator().getEntihome();
		String home$=entihome$+"/"+entity.getKey();
		File home=new File(home$);
		String [] sa=home.list();
		String data$=null;
		for(String s:sa) {
			if(s.endsWith(".data")) {
				data$=home$+"/"+s;
				break;
			}
		}
//				System.out.println("JPlotPanel:Ray:load:data="+data$);
		if(data$==null) {
			System.out.println("JPlotEditor:interpolate:cannot find data file");
			return;
		}
		BufferedReader br = new BufferedReader(new FileReader(data$));
		String line$;
		ArrayList<MathUtil.V2>vlg=new ArrayList <MathUtil.V2>();
		ArrayList<MathUtil.V2>vla=new ArrayList <MathUtil.V2>();
		double x=0;
		double y=0;
		double a=0;
		MathUtil.V2 v2=new MathUtil.V2(0,0);
		while ((line$ = br.readLine()) != null) {
			//System.out.println("JPlotPanel:Ray:load:line="+line$);
			sa=line$.split(";");
             try{
            	 x=Double.parseDouble(sa[0]);
            	 y=Double.parseDouble(sa[1]);
            	 a=Double.parseDouble(sa[2]);
            	 vlg.add(new MathUtil.V2(x,y));
            	 vla.add(new MathUtil.V2(x,a));
            	 }catch(Exception e) {
            	 continue;
             }
		}
		br.close();
		MathUtil.V2[] vga=new MathUtil.V2[vlg.size()];
		MathUtil.V2[] vaa=new MathUtil.V2[vla.size()];
		vlg.toArray(vga);
		vla.toArray(vaa);
		vlg.clear();
		vla.clear();
		for(int i=1;i<vga.length-1;i++) {
		    x=0.25*vga[i-1].x+0.5*vga[i].x+ 0.25*vga[i+1].x;
		    y=0.25*vga[i-1].y+0.5*vga[i].y+ 0.25*vga[i+1].y;
		    a=0.25*vaa[i-1].y+0.5*vaa[i].y+ 0.25*vaa[i+1].y;
		    vlg.add(new MathUtil.V2(x, y));
		    vla.add(new MathUtil.V2(x, a));
			//System.out.println("JPlotEditor:interpolate:x="+v.x+" y="+v.y);
		}
		vlg.toArray(vga);
		vla.toArray(vaa);
		File out=new File(data$);
	    if(out.exists())
	    	out.delete();
		out.createNewFile();	
		PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(out, true)));
		String format$="0.####E0";
		NumberFormat valFormat = new DecimalFormat(format$);
		MathUtil.V2 vg;
		MathUtil.V2 va;
		for(int i=0;i<vga.length;i++) {
			try {
			vg=vga[i];
			va=vaa[i];
			line$=valFormat.format(vg.x)+";"+valFormat.format(vg.y)+";"+valFormat.format(va.y);
			writer.println(line$);
			//System.out.println("JPlotEditor:interpolate:x="+vg.x+" y="+vg.y+" y="+va.y);
			}catch(Exception ee) {}
		}
		writer.close();
	}catch(Exception e) {
		System.out.println("JPlotEditor:interpolate:"+e.toString());
	}
}
public static void main( String[] args) {
	String entihome$="/home/alexander/testbench";
	Entigrator entigrator=new Entigrator(entihome$);
	JPlotPanel.makeData(entigrator,"plot0");
}
@Override
public String reply(JMainConsole console, String locator$) {
	return null;
}
@Override
public boolean handleDone() {
	JContext.displayInstance(console, parent$);
	return true;
}
}
