package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.plot;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;

public class DefaultPointDisplay extends PointDisplay{
	@Override
	public String pointsString(ArrayList<NamedPoint> pl) {
		if(pl!=null) {
			 StringBuffer sb=new StringBuffer();
			 NumberFormat pointFormat;
			for(NamedPoint p:pl) {
				pointFormat= new DecimalFormat(p.format$);
			  	sb.append(p.name$+"="+pointFormat.format(p.val)+";");
			}
			return sb.toString();
		}else
		  return null;
	}
}
