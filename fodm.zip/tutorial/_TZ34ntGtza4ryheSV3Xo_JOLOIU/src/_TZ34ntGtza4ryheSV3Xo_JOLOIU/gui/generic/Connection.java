package _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.logging.Logger;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;

public class Connection   {
public String source$;
public  String output$;
public  String consumer$;
public  String input$;
public String sourceKey$;
public String consumerKey$;
public String connectionKey$;
public String value$;
public String closed$="true";
public Connection() {
}
 public Connection  (Sack appliance,String source$,String output$,String consumer$, String input$){
	// source junction
	 sourceKey$=null;
	 Core[] ca=appliance.elementGet("source");  
	 if(ca!=null&&ca.length>0)
         for(Core c:ca)
        	 if( source$.equals(c.type) && output$.equals(c.value)){
        		 sourceKey$=c.name;
        		 break;
         }
	 if(sourceKey$==null)
	       sourceKey$=Identity.key();
//consumer junction	
	 consumerKey$=null;
	  ca=appliance.elementGet("consumer");  
	 if(ca!=null&&ca.length>0)
         for(Core c:ca)
        	 if( consumer$.equals(c.type) && input$.equals(c.value)){
        		 consumerKey$=c.name;
        		 break;
         }
	//connection 
	 if(consumerKey$!=null){
		 ca=appliance.elementGet("connection");
		 if(ca!=null&&ca.length>0)
			 for(Core c:ca)
				 if(c.type.equals(sourceKey$)&&c.value.equals(consumerKey$)){
					 connectionKey$=c.name;
					 break;
				 }
	 }
	 this.source$=source$;
	 this.output$=output$;
	 this.consumer$=consumer$;
	 this.input$=input$;
	 if(consumerKey$==null)
	     consumerKey$=Identity.key();
	 if(connectionKey$==null)
	     connectionKey$=Identity.key();
}
 public Connection  (String source$,String output$,String consumer$, String input$,String sourceKey$,String consumerKey$,String connectionKey$){
	 this.source$=source$;
	 this.output$=output$;
	 this.consumer$=consumer$;
	 this.input$=input$;
	 this.sourceKey$= sourceKey$;
	 this.consumerKey$=consumerKey$;
	 this.connectionKey$=connectionKey$;
}
 public boolean inputAlreadyUsed(Sack appliance){
    	try{
	   if(!appliance.existsElement("consumer"))
    		return false;
    	Core []ca=appliance.elementGet("consumer");
		if(ca==null)
			return false;
    	for(Core c:ca)
			if(consumer$.equals(c.type)&&input$.equals(c.value) )
				return true;
    	}catch(Exception e){
    		Logger.getLogger(e.toString());
    	}
			return false;
    }
   public  boolean alreadyInserted(Sack appliance){
			if(!appliance.existsElement("connection"))
				return false;
			if(appliance.getElementItem("connection",connectionKey$)!=null)
				return true;
			return false;
	}
	public Sack insert(Sack appliance){
		try{
			//System.out.println("Connection:insert;closed="+closed$);
			if(!appliance.existsElement("source"))
					appliance.createElement("source");
			if(!appliance.existsElement("consumer"))
				appliance.createElement("consumer");
			if(!appliance.existsElement("connection"))
				appliance.createElement("connection");
			if(!appliance.existsElement("conn.closed"))
				appliance.createElement("conn.closed");
			appliance.putElementItem("source",new Core(source$,sourceKey$,output$));
			appliance.putElementItem("consumer",new Core(consumer$,consumerKey$,input$));
			appliance.putElementItem("connection",new Core(sourceKey$,connectionKey$,consumerKey$));
			appliance.putElementItem("conn.closed",new Core(null,connectionKey$,closed$));
			}catch(Exception e){
			 Logger.getLogger(this.getClass().getName()).severe(e.toString());
		}
		return appliance;
	}
	public Sack delete(Sack appliance){
		try{
	Core []ca=appliance.elementGet("source");
			
			for(Core c:ca)
				if(source$.equals(c.type)&&output$.equals(c.value) ){
					Core []cca=appliance.elementGet("consumer");
				for(Core cc:cca){
					if(consumer$.equals(cc.type)&&input$.equals(cc.value) ){
						Core []ccca=appliance.elementGet("connection");
						for(Core ccc:ccca){
							if(c.name.contentEquals(ccc.type)&&cc.name.equals(ccc.value)){
								appliance.removeElementItem("source",c.name);
								appliance.removeElementItem("consumer",cc.name);
								appliance.removeElementItem("connection",ccc.name);
							}
						}
					}
				}
				}
			}catch(Exception e){
			 Logger.getLogger(this.getClass().getName()).severe(e.toString());
		}
		return appliance;
	}
	public static Hashtable getMap(Entigrator entigrator,Sack appliance) {
		Hashtable  <String,String> map=new Hashtable  <String,String>();
		Connection[] ca=getConnections(entigrator,appliance);
		if(ca!=null)
			for(Connection c:ca) {
				String key$=c.consumer$+":"+c.input$;
				String value$=c.source$+":"+c.output$;
				map.put(key$, value$);
				System.out.println("Connection:getMap:key="+key$+  "  value="+value$);
			}
		return map;
	}
	public static void main(String[] args) throws IOException {
		String entihome$="/home/alexander/tutorial";
		Entigrator entigrator=new Entigrator(entihome$);
		Sack chain=entigrator.getEntity("_PQO1blhY975vt95IwmiZN1cmkIM");
		getMap( entigrator,chain);
	}
	public static Connection getConnection(Sack appliance,String source$,String output$,String consumer$,String input$) {
		try {
		  if(source$==null||output$==null||consumer$==null||input$==null)
			  return null;
		  Core[] ca=appliance.elementGet("source");
		  if(ca==null)
			  return null;
		  String skey$=null;
		  for(Core c:ca)
			  if(source$.equals(c.type)&&output$.equals(c.value)) {
				  skey$=c.name;
				  break;
			  }
		  if(skey$==null)
			  return null;
		  ca=appliance.elementGet("consumer");
		  if(ca==null)
			  return null;
		  String ckey$=null;
		  for(Core c:ca)
			  if(consumer$.equals(c.type)&&input$.equals(c.value)) {
				  ckey$=c.name;
				  break;
			  }
		  if( ckey$==null)
			  return null;
		  ca=appliance.elementGet("connection");
		  if(ca==null)
			  return null;
		  String conkey$=null;
		  for(Core c:ca)
			  if(skey$.equals(c.type)&&ckey$.equals(c.value)) {
				  conkey$=c.name;
				  break;
			  }
		  if( conkey$==null)
			  return null;
		  return getConnection(appliance,conkey$);
		}catch(Exception e) {
			System.out.println("Connection:getConnection:"+e.toString());
		}
		return null;
	}
	public static Connection getConnection(Sack appliance,String key$) {
	try {
		Core cc=appliance.getElementItem("connection", key$);
		if(cc==null)
			return null;
		Core sc=appliance.getElementItem("source", cc.type);
		if(sc==null)
			return null;
		Core nc=appliance.getElementItem("consumer", cc.value);
		if(nc==null)
			return null;
		Connection con=new  Connection(sc.type,sc.value,nc.type, nc.value,sc.name,nc.name,key$);
		Core cl=appliance.getElementItem("conn.closed", key$);
		con.closed$="true";
		if(cl!=null&&cl.value!=null) 
			con.closed$=cl.value;
		return con;
	}	catch(Exception ee){
		System.out.println("Connection:getConnection:"+ee.toString());
	}
	return null;
	}
	public static Connection[] getConnections(Entigrator entigrator,Sack appliance){
		try{
			Core []ca=appliance.elementGet("connection");
			if(ca==null)
				return null;
			String source$=null;
			String output$=null;
			String consumer$=null;
			String input$=null;
			String closed$="true";
			Core sc;
			Core cc;
			Connection con;
			boolean alterEntity=false;
			ArrayList <Connection> conl=new ArrayList <Connection>();
			//System.out.println("Connection:getConnection:ca="+ca.length);
			for(Core c:ca){
				//System.out.println("Connection:getConnection:c="+c.toString());
				sc=appliance.getElementItem("source",c.type);
				if(sc!=null){
					//System.out.println("Connection:getConnection:sc="+sc.toString());	
				 source$=sc.type;
				 output$=sc.value;
				}
				cc=appliance.getElementItem("consumer",c.value);
				if(cc!=null){
					 consumer$=cc.type;
					input$=cc.value;
					}
				if(source$==null||output$==null||consumer$==null||input$==null
						||source$.equals("null")||output$.equals("null")||consumer$.equals("null")||input$.equals("null")){
					appliance.removeElementItem("connection", c.name);
					alterEntity=true;
				}
				con=new Connection(source$,output$,consumer$,input$,c.type,c.value,c.name);
				String cl$=appliance.getElementItemAt("conn.closed", con.connectionKey$);
				if(cl$!=null)
					con.closed$=cl$;
				//con.print();
				conl.add(con);
			}
			if(alterEntity){
			entigrator.putEntity(appliance);
			}
			Connection []cona =new Connection [conl.size()];
			return conl.toArray(cona);
	}	catch(Exception ee){
		System.out.println("Connection:getConnections:"+ee.toString());
	}
	return null;
	}
public static Connection[] sortConnections(Connection[] cona,int col){
		try{
			for(Connection con:cona)
				System.out.println(con.toString());
		ConnectionComparator comparator=new ConnectionComparator(col);
		comparator.col=col;
		ArrayList <Connection>conl=new ArrayList<Connection>(Arrays.asList(cona));
		Collections.sort(conl,comparator);
		cona=conl.toArray(cona);
		for(Connection con:cona)
			System.out.println(con.toString());
		return cona;
		}	catch(Exception ee){
			System.out.println("Connection:sortConnections:"+ee.toString());
		}
		return cona;
	}
	public static  class ConnectionComparator implements Comparator<Connection> {
	     public int col=0;
	     ConnectionComparator (int col){
	    	 super();
	    	 this.col=col;
	     }
		@Override
    public int compare(Connection  a, Connection b) {
	        try{
	   			int  ret=-100;
	        	if(col==0)
	        		ret= a.source$.compareTo(b.source$);
	        	if(col==1)
	        	 ret=a.output$.compareTo(b.output$);
	        	if(col==2)
		        	 ret=a.consumer$.compareTo(b.consumer$);
	        	if(col==3)
		        	 ret= a.input$.compareTo(b.input$);
	        	return ret;
	        }catch(Exception e){
	        	return -100;
	        }
	    }
	}
  public String toString(){
		  StringBuffer sb=new StringBuffer();
		  sb.append(source$+":"+output$+":"+consumer$+":"+input$);
		  return sb.toString();
	  }
	public static  class StringComparator implements Comparator<String> {
	    @Override
	    public int compare(String a, String b) {
	        try{
	        return a.compareToIgnoreCase(b);
	        }catch(Exception e){
	        	return 0;
	        }
	    }
	}
	public boolean isCorrect(){
		
		if(source$==null||"null".equals(source$))
			return false;
		if(output$==null||"null".equals(output$))
			return false;
		if(consumer$==null||"null".equals(consumer$))
			return false;
		if(input$==null||"null".equals(input$))
			return false;
		return true;
	}
	public void connect(Entigrator entigrator) {
		try {
		//	System.out.println("Connection:connect "+toString());
			Sack source=entigrator.getEntityAtLabel(source$);
			Sack consumer=entigrator.getEntityAtLabel(consumer$);
			value$=source.getElementItemAt(OperatorHandler.OPERATOR, output$);
			consumer.putElementItem(OperatorHandler.OPERATOR, new Core("in",input$,value$));
		//	System.out.println("Connection:connect:source="+source.getProperty("label")+ "  consumer="+consumer.getProperty("label")+" output="+output$+" input="+input$+" value="+value$  );
		//	print();
			entigrator.putEntity(consumer);
			//System.out.println("Connectiom:connet:consumer="+consumer.getKey()+"  cos="+consumer.getElementItemAt(OperatorHandler.OPERATOR, "cos")+"  sin="+consumer.getElementItemAt(OperatorHandler.OPERATOR, "sin"));
		}catch(Exception e) {
			System.out.println("Connection:connect:"+e.toString());
		}
	}
	public boolean isClosed() {
		if("true".equals(closed$))
			return true;
		return false;
	}
	public void setClosed(boolean closed) {
		if(closed)
			closed$="true";
		else
			closed$="false";
	}
	public static String getKey(String[] sa, Sack appliance){
		if(sa==null||sa.length<4)
			return null;
		try{
			Core []ca=appliance.elementGet("connection");
			if(ca==null)
				return null;
			String source$=sa[0];
			String output$=sa[1];
			String consumer$=sa[2];
			String input$=sa[3];
			Core sc;
			Core cc;
			ArrayList <Connection> conl=new ArrayList <Connection>();
			for(Core c:ca){
				sc=appliance.getElementItem("source",c.type);
				if(sc!=null){
				  if(source$.equals(sc.type)&&output$.equals(sc.value)){
					   cc=appliance.getElementItem("consumer",c.value);
					   if(consumer$.equals(cc.type)&&input$.equals(cc.value))
						   return c.name;
				  }	  
			
	}}}	catch(Exception ee){
		System.out.println("Connection:getConnection:"+ee.toString());
	}	
	return null;	
	}
}
