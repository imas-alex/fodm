package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Properties;
import java.util.logging.Logger;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.gauge.Meter;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Instrument;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.InstrumentHandler;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class GaugeHandler extends OperatorHandler implements InstrumentHandler{
	public static final String GAUGE_FACET_TYPE="gauge";
	public static final String GAUGE_FACET_NAME="Gauge";
	public static final String KEY="_LB2om6c408RCVAHg5lk9Pthk_SM0";
	public static final String GAUGE_FACET_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.GaugeHandler";
	public GaugeHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,GAUGE_FACET_NAME);
		locator.put(FACET_TYPE,GAUGE_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.GaugeHandler");
		locator.put(FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.GaugeMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put( IconLoader.ICON_FILE, "gauge.png");
		locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(OPERATOR,Locator.LOCATOR_TRUE);
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	public static Meter getMeter(Entigrator entigrator,Sack gauge){
	Meter meter=new Meter();
		Core[] ca=gauge.elementGet("operator");
		if(ca!=null)
			for(Core c:ca){
				  if(c.name.equals("middle")){
					  if("false".equals(c.value))
							  meter.setMiddle(false);
							  else
								  meter.setMiddle(true);
				  }
				  if(c.name.equals("maximal value")){
					  try{
						 double max=Double.parseDouble(c.value.trim());
						  meter.setValueMaximum(max);
					  }catch(NumberFormatException e){
						  Logger.getLogger(GaugeHandler.class.getName()).info(e.toString());
					  }
				  }
				  if(c.name.equals("value")){
					  try{
						 double value=Double.parseDouble(c.value.trim());
						  meter.setValue(value);
					  }catch(NumberFormatException e){
						  Logger.getLogger(GaugeHandler.class.getName()).info(e.toString());
					  }
				  }
				  if(c.name.equals("unit")){
					  try{
						  meter.setUnit(c.value);
					  }catch(NumberFormatException e){
						  Logger.getLogger(GaugeHandler.class.getName()).info(e.toString());
					  }
				  }
				  if(c.name.equals("operator")){
					  try{
						  meter.setTitle(c.value);
					  }catch(NumberFormatException e){
						  Logger.getLogger(GaugeHandler.class.getName()).info(e.toString());
					  }
				  }
			}
		meter.repaint();
		return meter;
	}
	public static void setMeter(Entigrator entigrator,Meter meter,Sack gauge){
		String title$=gauge.getElementItemAt("gauge", "title");
		String nullpos$=gauge.getElementItemAt("gauge", "nullpos");
		String maximum$=gauge.getElementItemAt("gauge", "maximum");
		String var$=gauge.getElementItemAt("gauge", "variable");
		String unit$=gauge.getElementItemAt("gauge", "unit");
		if("middle".equals(nullpos$))
			  meter.setMiddle(true);
		else
			meter.setMiddle(false);
		double max=1;
		try {max=Double.parseDouble(maximum$);}catch(Exception e) {}
		 meter.setValueMaximum(max);
		 meter.setTitle(title$);
		 meter.setVar(var$);
		 meter.setUnit(unit$);
			meter.repaint();
		}
	@Override
	public String getName() {
		return GAUGE_FACET_NAME;
	}
	@Override
	public String getType() {
		return GAUGE_FACET_TYPE;
	}
	@Override
	public String getFacetClass() {
		return GAUGE_FACET_CLASS;
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String[] listOutputs(Entigrator entigrator) {
		return null;
	}
	@Override
	public String[] listInputs(Entigrator entigrator) {
		return new String[] {"in"};
	}
	@Override
	public Instrument getInstrument() {
		return new Meter(entigrator,locator$);
	}
	@Override
	public String getInstrumentType() {
	return GAUGE;
	}
	public  static void saveValues(Entigrator entigrator, String locator$, Meter meter) {
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		Sack gauge=FolderHandler.assign(entigrator, locator$);
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return entity;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return entity;
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
	}
	@Override
	public void reset(Entigrator entigrator, String locator$) {
		try {
			Sack entity=entigrator.getEntity(operatorKey$);
			if(entity!=null) {
				if(!entity.existsElement(OPERATOR))
					entity.createElement(OPERATOR);
			 entity.putElementItem(OPERATOR, new Core("in","in","0"));
		    entigrator.putEntity(entity);
			}
		}catch(Exception e) {
			System.out.println("SignalHandler:reset:"+e.toString());
		}
	}
	@Override
	public void reinit(Entigrator entigrator, String locator$) {
	}

}
