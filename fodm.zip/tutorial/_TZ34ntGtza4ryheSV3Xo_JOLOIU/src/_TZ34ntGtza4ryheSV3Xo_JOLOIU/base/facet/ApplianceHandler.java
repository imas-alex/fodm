package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import java.util.Properties;
import java.util.logging.Logger;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Connection;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.Instrument;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.*;

public  class ApplianceHandler extends FacetHandler {
	public static final String KEY="_12qjkwYaeWRyEvkuHZnC_BdhTa0";
	public static final String APPLIANCE_FACET_TYPE="appliance";
	public static final String APPLIANCE_FACET_NAME="Appliance";
	public static final String APPLIANCE_FACET_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.ApplianceHandler";
	public static final String COMPONENT="component";
	public static final String SELECT="select";
	public static final String SOURCES="sources";
	public static final String CONSUMERS="consumers";
	public static final String ALL_OPERATORS="all operators";
	public static final String INPUT="input";
	public static final String OUTPUT="output";
	public static final String APPLIANCE="appliance";
	public static final String STEP="step";
	HashMap<String,Double > pars;
	HashMap<String,Double > state;
	ArrayList<OperatorHandler>operators=new ArrayList<OperatorHandler>();
	Sack appliance;
	int step=0;
	public ApplianceHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	    setOperators(entigrator,alocator$);	
	    String appliance$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		appliance=entigrator.getEntityAtLabel(appliance$);
	}
	public void setOperators(Entigrator entigrator,String locator$) {
		try {
	//System.out.println("ApplianceHandler:setOperators:locator="+locator$);
		String appliance$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		System.out.println("ApplianceHandler:setOperators:appliance 0"+appliance$);
		appliance=entigrator.getEntityAtLabel(appliance$);
		if(appliance==null) {
			System.out.println("ApplianceHandler:setOperators:cannot get appliance="+appliance$);
			return;
		}
			
		String [] ra=appliance.elementListNames("component");
		Sack operator;
		OperatorHandler oh;
		if(ra!=null) 
		    for(String r:ra){
		    //	System.out.println("ApplianceHandler:setOperators:r="+r);
			operator=entigrator.getEntity(r);
			if(operator!=null)
		      	System.out.println("ApplianceHandler:setOperators:operator="+operator.getProperty("label"));
			else {
				System.out.println("ApplianceHandler:setOperators:cannot get operator r="+r);
				continue;
			}
			oh=OperatorHandler.getOperatorHandler(entigrator,operator);
			if( oh !=null) {
			//	System.out.println("ApplianceHandler:setOperators:operator handler="+oh.getType());
				oh.operatorKey$=r;
			//	System.out.println("ApplianceHandler:setOperators:operator="+oh.getName()+"  key="+oh.operatorKey$);
				String ohLocator$=oh.getLocator();
			//	System.out.println("ApplianceHandler:setOperators:oh locator="+ohLocator$);
				oh.operatorKey$=operator.getKey();
				boolean inserted=false;
				for(OperatorHandler ohe:operators)
					if(oh.operatorKey$.equals(ohe.operatorKey$)) {
						inserted=true;
						break;
					}
				if(inserted)
					continue;
			   operators.add(oh);
			//	System.out.println("ApplianceHandler:setOperators:oh="+oh.getName()+" operator key="+oh.operatorKey$);
			}else {
				System.out.println("ApplianceHandler:setOperators:cannot get handler for operator="+entigrator.getLabel(r));
			}
				
			}
		//System.out.println("ApplianceHandler:setOperators:all operators="+operators.size());
		}catch(Exception e) {
			System.out.println("ApplianceHandler:setOperators:"+e.toString());	
		}
		//System.out.println("ApplianceHandler:setOperators:operators="+operators.size());
	}
	public boolean containsHandler(String handlerClass$) {
		for(OperatorHandler oh:operators) {
			if(oh.getFacetClass().equals(handlerClass$))
				return true;
		}
		return false;
	}
	@Override
	public String getKey() {
		return KEY;
	}
@Override
	public String getName() {
		return APPLIANCE_FACET_NAME;
	}
@Override
	public String getType() {
		return APPLIANCE_FACET_TYPE;
	}
@Override
	public String getFacetClass() {
		return APPLIANCE_FACET_CLASS;
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,APPLIANCE_FACET_NAME);
		locator.put(FACET_TYPE,APPLIANCE_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.ApplianceHandler");
		locator.put(FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.ApplianceMaster");
		locator.put(IconLoader.ICON_FILE,"appliance.png");
		locator.put(IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	public static String[] listApplianceComponents(Entigrator entigrator,String locator$) {
		String appliance$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		Sack appliance=entigrator.getEntityAtLabel(appliance$);
		return appliance.elementListNames(COMPONENT);
	}
	public  String[] listPinout(Entigrator entigrator,String locator$) {
		String operator$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String select$=Locator.getProperty(locator$, SELECT);
		//System.out.println("Appliancehandler:listPinout: entity="+operator$+" select="+select$);
		try{
		    String label$;
			for(OperatorHandler oh:operators) {
				label$=entigrator.getLabel(oh.operatorKey$);
				if(operator$.equals(label$)) {
					if(INPUT.equals(select$))
						return oh.listInputs(entigrator);
					if(OUTPUT.equals(select$))
						return oh.listOutputs(entigrator);
				}
			}	
		}catch(Exception e) {
			Logger.getLogger(ApplianceHandler.class.getName()).severe(e.toString());
		}
//	System.out.println("Appliancehandler:listPinout:no input/output for  entity="+operator$+" select="+select$);
	return null;	
	}
	public  String[] listOperators(Entigrator entigrator,String locator$) {
		try {
			if(operators==null||operators.size()<1)
				return null;
			String select$=Locator.getProperty(locator$, SELECT);
	//		System.out.println("ApplicationHandler:listOperators:SELECT="+select$);
			ArrayList<String>sl=new ArrayList<String>();
			for(OperatorHandler oh:operators) {
		//		System.out.println("ApplicationHandler:listOperators:operator="+oh.getName()+" key="+oh.operatorKey$);
				if(SOURCES.equals(select$)||ALL_OPERATORS.equals(select$)) { 
				 if(oh.listOutputs(entigrator)!=null) {
					 sl.add(oh.operatorKey$);
				 }else
					 System.out.println("ApplicationHandler:listOperators:no outputs for operator="+oh.getName()+" key="+oh.operatorKey$); 
				}
				 if(CONSUMERS.equals(select$)||ALL_OPERATORS.equals(select$)) {
					 if(oh.listInputs(entigrator)!=null) {
						 sl.add(oh.operatorKey$);
					 }else
						 System.out.println("ApplicationHandler:listOperators:no inputs for operator="+oh.getName()+" key="+oh.operatorKey$); 
				 }
			}
			String[] sa=new String[sl.size()];
			int i=0;
			for( String s:sl) {
				sa[i]=entigrator.getLabel(s);
//				System.out.println("ApplicationHandler:listOperators:key=" +s+" label="+sa[i]);	
				i++;
			}
			Arrays.sort(sa);
			return sa;	
		}catch(Exception e) {
			Logger.getLogger(ApplianceHandler.class.getName()).severe(e.toString());
		}
		return null;
	}    

public void reset(Entigrator entigrator,String locator$) {
	//System.out.println("JApplianceHandler:reset");
	if(appliance==null)
	return;
appliance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TIME,"0"));
String takt$=appliance.getElementItemAt("tuner", Instrument.TAKT);
double takt=1;
try { takt=Double.parseDouble(takt$);}catch(Exception ee) {}
appliance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TAKT,String.valueOf(takt))); 
appliance.putElementItem(OperatorHandler.OPERATOR, new Core(null,"vtime","0"));
double startView=0;
try { startView=Double.parseDouble(appliance.getElementItemAt("tuner", "start view"));}catch(Exception e) {}
appliance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.START_VIEW,String.valueOf(startView)));
//System.out.println("JApplianceHandler:reset:1");
entigrator.putEntity(appliance);
Sack operatorInstance;
step=0;
//System.out.println("JApplianceHandler:reset:2");
for(OperatorHandler oh:operators) {
	if(oh.operatorKey$==null) {
		System.out.println("JApplianceHandler:reset:operator key is null in operator  name="+oh.getName());
		continue;
	}
	System.out.println("JApplianceHandler:reset:operator name="+oh.getName()+" entity="+entigrator.getLabel(oh.operatorKey$));
	//System.out.println("JApplianceHandler:reset:operator name="+oh.getName()+" key="+oh.operatorKey$);
	operatorInstance=entigrator.getEntity(oh.operatorKey$);
	//System.out.println("JApplianceHandler:reset:oh name="+oh.getName()+"  key="+oh.operatorKey$);
	if(operatorInstance==null) {
		System.out.println("JApplianceHandler:reset:cannot get operator  name="+oh.getName()+"  key="+oh.operatorKey$);
		continue;
	}
	operatorInstance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TAKT,String.valueOf(takt))); 
	operatorInstance.putElementItem(OperatorHandler.OPERATOR, new Core(null,"vtime","0"));
	operatorInstance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TIME,"0"));
	operatorInstance.putElementItem(OperatorHandler.OPERATOR, new Core(null,STEP,"0"));
	entigrator.putEntity(operatorInstance);
	//System.out.println("JApplianceHandler:reset:3.7  oh="+oh.getName());
	try {
	String ohLocator$=oh.getLocator();
	//System.out.println("JApplianceHandler:reset:oh="+oh.getName()+"  locator="+ohLocator$);	
	oh.reset(entigrator, ohLocator$);
	oh.reinit(entigrator, locator$);
	}catch(Exception ee) {
		System.out.println("ApplianceHandler:reset:oh="+oh.getName()+"  error="+ee.toString());
	}
	}
}
public  void step(Entigrator entigrator,String locator$) {
	try {
		//System.out.println("ApplianceHandler:step:BEGIN----------------");
		for(OperatorHandler oh:operators) {
			if( oh instanceof RhythmHandler) {
				locator$=Locator.append(locator$,APPLIANCE,appliance.getProperty(Entigrator.LABEL));
				((RhythmHandler)oh).modifyRhythm(entigrator, locator$);
				appliance=entigrator.getEntity(appliance.getKey());
				break;
			}
		}
		double time=Double.parseDouble(appliance.getElementItemAt(OperatorHandler.OPERATOR, Instrument.TIME));
		double startView=Double.parseDouble(appliance.getElementItemAt(OperatorHandler.OPERATOR, Instrument.START_VIEW));
		double vtime=time-startView;
		if(vtime<0)
		  	vtime=0;
		appliance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.VIEW_TIME,String.valueOf(vtime)));
		double takt=Double.parseDouble(appliance.getElementItemAt(OperatorHandler.OPERATOR, Instrument.TAKT));
		Sack operatorInstance;
		step++;
		for(OperatorHandler oh:operators) {
	           operatorInstance=entigrator.getEntity(oh.operatorKey$);
	           if(operatorInstance!=null) {
	        	  try {
	        	   if(!operatorInstance.existsElement(OperatorHandler.OPERATOR))
	        		   operatorInstance.createElement(OperatorHandler.OPERATOR);
	        	   operatorInstance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TIME,String.valueOf(time)));
	        	   operatorInstance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TAKT,String.valueOf(takt)));
	           	   operatorInstance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.VIEW_TIME,String.valueOf(vtime)));
	         	   operatorInstance.putElementItem(OperatorHandler.OPERATOR, new Core(null,STEP,String.valueOf(step)));
	         	   entigrator.putEntity(operatorInstance);
	        	  }catch(Exception ee) {
	        		  System.out.println("Appliancehandler:step:operator="+oh.getName()+" key="+oh.operatorKey$); 
	        	  }
	           }
	        }
			state=new HashMap<String,Double > ();
			pars=new HashMap<String,Double > ();
			pars.put("takt",takt);
			state.put(Instrument.TIME, time);
		 //   System.out.println("Appliancehandler:step:run quantum cycle");
		double endQ=time+takt;	
			time=time+takt;
		// System.out.println("ApplianceHandler:step:time="+time);
		    appliance.putElementItem(OperatorHandler.OPERATOR, new Core(null,Instrument.TIME, String.valueOf(time)));
	//begin regular segment
		for(OperatorHandler oh:operators) {
		//	System.out.println("Appliancehandler:step:oh locator="+oh.getLocator());
			try{oh.step(entigrator,oh.getLocator());
			}
       	 catch(Exception ee)
       	 {
       		 System.out.println("Appliancehandler:step "+oh.getName()+" error="+ee.toString()); 
       	 }
		}
	        
	  entigrator.putEntity(appliance);
      //complete step
	  Connection[] ca=Connection.getConnections(entigrator, appliance);
	 // System.out.println("ApplianceHandler:step:connections:ca="+ca.length);
		if(ca!=null)
			for(Connection c:ca) {
				//System.out.println("ApplianceHandler:step:connection="+c.toString());
				c.connect(entigrator);
			}
	//	System.out.println("ApplianceHandler:step:completed:time="+time);
	}catch(Exception e) {
		System.out.println("ApplianceHandler:step:"+e.toString());		
	}
}
public int getSteps() {
	return step;
}
@Override
public Sack apply(Entigrator entigrator, Sack entity) {
	return null;
}
@Override
public Sack remove(Entigrator entigrator, Sack entity) {
	return null;
}
}
