package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Logger;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.tube.TubePanel;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.generic.InstrumentHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;

public class TubeHandler extends OperatorHandler implements InstrumentHandler{
	public TubeHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}
	private Logger LOGGER=Logger.getLogger(getClass().getName());
	public static final String KEY="_EefAAsaOiynndf5cwWmh61QLZAg";
	public static final String TUBE_FACET_TYPE="tube";
	public static final String TUBE_FACET_NAME="Tube";
	public static final String TUBE_FACET_CLASS="_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.TubeHandler";
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,TUBE_FACET_NAME);
		locator.put(FACET_TYPE,TUBE_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.TubeHandler");
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_TZ34ntGtza4ryheSV3Xo_JOLOIU.gui.facet.TubeMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		 locator.put( IconLoader.ICON_FILE, "tube.png");
		    locator.put( IconLoader.ICON_CONTAINER,"_TZ34ntGtza4ryheSV3Xo_JOLOIU");
		    locator.put(OPERATOR,Locator.LOCATOR_TRUE);
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	@Override
	public String getName() {
		return TUBE_FACET_NAME;
	}
	@Override
	public String getType() {
		return TUBE_FACET_TYPE;
	}
	@Override
	public  String getFacetClass() {
		return TUBE_FACET_CLASS;
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String[] listOutputs(Entigrator entigrator) {
		return null;
	}
	@Override
	public String[] listInputs(Entigrator entigrator) {
	//	System.out.println("TubeHandler:listInputs:locator="+locator$);
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		if(entity$==null)
		   entity$=entigrator.getLabel(operatorKey$);
		ArrayList<String>sl=new ArrayList<String>();
		if(entity$==null) {
			System.out.println("TubeHandler:listInputs:no entity label in locator="+locator$);
			return null;
		}
		try {
			Sack entity=entigrator.getEntityAtLabel(entity$);
			Core[] ca=entity.elementGet("ray.name");
			if(ca!=null) {
				for(Core c:ca) {
					if("t".equals(c.value))
							continue;
					sl.add(c.value);
				}
			}
			String[] sa=new String[sl.size()];
			sl.toArray(sa);
			if(sa.length>1)
				Arrays.sort(sa);
		//	System.out.println("TubeHandler:listInputs:sa="+sa.length);
			return sa;
		}catch(Exception e) {
			System.out.println("TubeHandler:listInputs:"+e.toString());
		}
		System.out.println("TubeHandler:listInputs:no inputs");
		return null;
	}
	@Override
	public void step(Entigrator entigrator, String locator$) {
	}
	@Override
	public void reset(Entigrator entigrator, String locator$) {
	}
	@Override
	public void reinit(Entigrator entigrator, String locator$) {
	}
	@Override
	public TubePanel getInstrument() {
         return new TubePanel(entigrator,locator$);		
	}
	@Override
	public String getInstrumentType() {
		return TUBE;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return null;
	}
	}


