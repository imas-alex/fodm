package _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import gdt.base.store.Entigrator;

public interface RhythmHandler {
    public void modifyRhythm(Entigrator entigrator,String locator$);
}
