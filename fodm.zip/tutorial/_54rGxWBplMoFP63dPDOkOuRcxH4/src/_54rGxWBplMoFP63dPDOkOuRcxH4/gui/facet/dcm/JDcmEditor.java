package _54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.dcm;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Properties;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DcmHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.JContext;
public class JDcmEditor extends JContext{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_7N63m9gLPQLrN5ZMmhPAA3uB5Ew";
	JTextField txtP;
	JTextField txtU;
	JTextField txtN;
	JTextField txtR;
	JTextField txtL;
	JTextField txtJ;
	JTextField txtEta;
	JTextField txtKtg;
	Sack entity;
	DcmHandler dcmHandler;
	public JDcmEditor(JMainConsole console,String locator$) {
		super(console,locator$);
		String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		if(entityLabel$!=null)
			entity=console.getEntigrator().getEntityAtLabel(entityLabel$);
		if(entity==null) {
			System.out.println("DcmEditor:cannot get entity at label="+entityLabel$);
			return;
		}
		dcmHandler=new DcmHandler(console.getEntigrator(),locator$);
		dcmHandler.setEntigrator(console.getEntigrator());
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0,0,1};
		gridBagLayout.rowHeights = new int[]{0, 0,0,0,0,0,0,0,1};
		gridBagLayout.columnWeights = new double[]{0.0,0.0,1.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0,0.0,0.0,0.0,0.0,0.0,0.0,Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel lblP = new JLabel("Power(Wt)");
		GridBagConstraints gbc_lblP = new GridBagConstraints();
		gbc_lblP.anchor = GridBagConstraints.LINE_START;
		gbc_lblP.insets = new Insets(5, 5, 5, 5);
		gbc_lblP.gridx = 0;
		gbc_lblP.gridy = 0;
		add(lblP, gbc_lblP);
		
		txtP = new JTextField();
		txtP.setColumns(10);
		txtP.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String p$=txtP.getText();
		    	if(!entity.existsElement("dcm"))
		    		entity.createElement("dcm");
	    		entity.putElementItem("dcm", new Core(null,"P",p$));	
				console.getEntigrator().putEntity(entity);
				dcmHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtP = new GridBagConstraints();
		gbc_txtP.insets = new Insets(5, 5, 5, 5);
		gbc_txtP.gridx = 1;
		gbc_txtP.gridy = 0;
		add(txtP, gbc_txtP);
		
		JLabel lblU = new JLabel("Voltage(V)");
		GridBagConstraints gbc_lblU = new GridBagConstraints();
		gbc_lblU.anchor = GridBagConstraints.LINE_START;
		gbc_lblU.insets = new Insets(5, 5, 5, 5);
		gbc_lblU.gridx = 0;
		gbc_lblU.gridy = 1;
		add(lblU, gbc_lblU);
		txtU = new JTextField();
		txtU.setColumns(10);
		txtU.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String u$=txtU.getText();
		    	if(!entity.existsElement("dcm"))
		    		entity.createElement("dcm");
	    		entity.putElementItem("dcm", new Core(null,"U",u$));	
				console.getEntigrator().putEntity(entity);
				dcmHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtU = new GridBagConstraints();
		gbc_txtU.insets = new Insets(5, 5, 5, 5);
		gbc_txtU.gridx = 1;
		gbc_txtU.gridy = 1;
		add(txtU, gbc_txtU);
		
		JLabel lblN = new JLabel("Speed(rpm)");
		GridBagConstraints gbc_lblN = new GridBagConstraints();
		gbc_lblN.anchor = GridBagConstraints.LINE_START;
		gbc_lblN.insets = new Insets(5, 5, 5, 5);
		gbc_lblN.gridx = 0;
		gbc_lblN.gridy = 2;
		add(lblN, gbc_lblN);
		txtN = new JTextField();
		txtN.setColumns(10);
		txtN.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String n$=txtN.getText();
		    	if(!entity.existsElement("dcm"))
		    		entity.createElement("dcm");
	    		entity.putElementItem("dcm", new Core(null,"N",n$));	
				console.getEntigrator().putEntity(entity);
				dcmHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtN = new GridBagConstraints();
		gbc_txtN.insets = new Insets(5, 5, 5, 5);
		gbc_txtN.gridx = 1;
		gbc_txtN.gridy = 2;
		add(txtN, gbc_txtN);
		
		JLabel lblR = new JLabel("Resistance(Ohm)");
		GridBagConstraints gbc_lblR = new GridBagConstraints();
		gbc_lblR.anchor = GridBagConstraints.LINE_START;
		gbc_lblR.insets = new Insets(5, 5, 5, 5);
		gbc_lblR.gridx = 0;
		gbc_lblR.gridy = 3;
		add(lblR, gbc_lblR);
		txtR = new JTextField();
		txtR.setColumns(10);
		txtR.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String r$=txtR.getText();
		    	if(!entity.existsElement("dcm"))
		    		entity.createElement("dcm");
	    		entity.putElementItem("dcm", new Core(null,"R",r$));	
				console.getEntigrator().putEntity(entity);
				dcmHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtR = new GridBagConstraints();
		gbc_txtR.insets = new Insets(5, 5, 5, 5);
		gbc_txtR.gridx = 1;
		gbc_txtR.gridy = 3;
		add(txtR, gbc_txtR);
		
		JLabel lblL = new JLabel("Inductance(H)");
		GridBagConstraints gbc_lblL = new GridBagConstraints();
		gbc_lblL.anchor = GridBagConstraints.LINE_START;
		gbc_lblL.insets = new Insets(5, 5, 5, 5);
		gbc_lblL.gridx = 0;
		gbc_lblL.gridy = 4;
		add(lblL, gbc_lblL);
		txtL = new JTextField();
		txtL.setColumns(10);
		txtL.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String l$=txtL.getText();
		    	if(!entity.existsElement("dcm"))
		    		entity.createElement("dcm");
	    		entity.putElementItem("dcm", new Core(null,"L",l$));	
				console.getEntigrator().putEntity(entity);
				dcmHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtL = new GridBagConstraints();
		gbc_txtL.insets = new Insets(5, 5, 5, 5);
		gbc_txtL.gridx = 1;
		gbc_txtL.gridy = 4;
		add(txtL, gbc_txtL);
		
		JLabel lblJ= new JLabel("Inertia(kg*m²)");
		GridBagConstraints gbc_lblJ = new GridBagConstraints();
		gbc_lblJ.anchor = GridBagConstraints.LINE_START;
		gbc_lblJ.insets = new Insets(5, 5, 5, 5);
		gbc_lblJ.gridx = 0;
		gbc_lblJ.gridy = 5;
		add(lblJ, gbc_lblJ);
		txtJ = new JTextField();
		txtJ.setColumns(10);
		txtJ.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String j$=txtJ.getText();
		    	if(!entity.existsElement("dcm"))
		    		entity.createElement("dcm");
	    		entity.putElementItem("dcm", new Core(null,"J",j$));	
				console.getEntigrator().putEntity(entity);
				dcmHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtJ = new GridBagConstraints();
		gbc_txtJ.insets = new Insets(5, 5, 5, 5);
		gbc_txtJ.gridx = 1;
		gbc_txtJ.gridy = 5;
		add(txtJ, gbc_txtJ);
		
		JLabel lblE= new JLabel("Efficiency(%)");
		GridBagConstraints gbc_lblE = new GridBagConstraints();
		gbc_lblE.anchor = GridBagConstraints.LINE_START;
		gbc_lblE.insets = new Insets(5, 5, 5, 5);
		gbc_lblE.gridx = 0;
		gbc_lblE.gridy = 6;
		add(lblE, gbc_lblE);
		txtEta = new JTextField();
		txtEta.setColumns(10);
		txtEta.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
		    	String eta$=txtEta.getText();
		    	if(!entity.existsElement("dcm"))
		    		entity.createElement("dcm");
	    		entity.putElementItem("dcm", new Core(null,"Eta",eta$));	
				console.getEntigrator().putEntity(entity);
				dcmHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtEta = new GridBagConstraints();
		gbc_txtEta.insets = new Insets(5, 5, 5, 5);
		gbc_txtEta.gridx = 1;
		gbc_txtEta.gridy = 6;
		add(txtEta, gbc_txtEta);
		
		JLabel lblKtg= new JLabel("Speed factor(V/rpm)");
		GridBagConstraints gbc_lblKtg = new GridBagConstraints();
		gbc_lblKtg.anchor = GridBagConstraints.LINE_START;
		gbc_lblKtg.insets = new Insets(5, 5, 5, 5);
		gbc_lblKtg.gridx = 0;
		gbc_lblKtg.gridy = 7;
		add(lblKtg, gbc_lblKtg);
		txtKtg = new JTextField();
		txtKtg.setColumns(10);
		txtKtg.addCaretListener(new CaretListener() {
			@Override
			public void caretUpdate(CaretEvent e) {
			   	String ktg$=txtKtg.getText();
		    	if(!entity.existsElement("dcm"))
		    		entity.createElement("dcm");
	    		entity.putElementItem("dcm", new Core(null,"Ktg",ktg$));	
				console.getEntigrator().putEntity(entity);
				dcmHandler.reset();
				 }
	      });
		GridBagConstraints gbc_txtKtg = new GridBagConstraints();
		gbc_txtKtg.insets = new Insets(5, 5, 5, 5);
		gbc_txtKtg.gridx = 1;
		gbc_txtKtg.gridy = 7;
		add(txtKtg, gbc_txtKtg);
		initParameters();
	}
	private void initParameters() {
		if(entity==null)
			return;
		txtP.setText(entity.getElementItemAt("dcm","P"));
		txtU.setText(entity.getElementItemAt("dcm","U"));
		txtN.setText(entity.getElementItemAt("dcm","N"));
		txtR.setText(entity.getElementItemAt("dcm","R"));
		txtL.setText(entity.getElementItemAt("dcm","L"));
		txtJ.setText(entity.getElementItemAt("dcm","J"));
		txtEta.setText(entity.getElementItemAt("dcm","Eta"));
		txtKtg.setText(entity.getElementItemAt("dcm","Ktg"));
	}
	private void saveParameters() {
		if(entity==null)
			return;
		entity.putElementItem("dcm",new Core(null,"P",txtP.getText()));
		entity.putElementItem("dcm",new Core(null,"U",txtU.getText()));
		entity.putElementItem("dcm",new Core(null,"N",txtN.getText()));
		entity.putElementItem("dcm",new Core(null,"R",txtR.getText()));
		entity.putElementItem("dcm",new Core(null,"L",txtL.getText()));
		entity.putElementItem("dcm",new Core(null,"J",txtJ.getText()));
		entity.putElementItem("dcm",new Core(null,"Eta",txtEta.getText()));
		entity.putElementItem("dcm",new Core(null,"Ktg",txtKtg.getText()));
		console.getEntigrator().putEntity(entity);
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_KEY,KEY);
		locator.put(FacetHandler.FACET_NAME,"Dcm");
		locator.put(FacetHandler.FACET_TYPE,"dcm");
		locator.put(FacetHandler.FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FacetHandler.FACET_MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.DcmMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
		locator.put(JContext.CONTEXT_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.dcm.JDcmEditor");
		return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public boolean handleDone() {
		
		saveParameters();
		String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
		if(parentLocator$==null) {
			//System.out.println("JDcmEditor:handleDone:parent is null:locator="+locator$);
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String facetList$=JEntityFacetList.classLocator();
			facetList$=Locator.append(facetList$, Entigrator.ENTITY_LABEL, entity$);
			JEntityFacetList facetList=new JEntityFacetList(console,facetList$);
		    replace(console, facetList);
		    return true;
		}
		JContext.displayInstance(console, parent$);
		return true;
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
}
