package _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Hashtable;
import java.util.Properties;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public class DriveHandler extends FacetHandler implements SegueController{
	public static final String KEY="__S19HZ5MS1v01JFZnG_pSLKFwnkY";
	public static final String LOOP="loop";
	public static final double LOOP_SPEED=0;
	public static final double LOOP_CURRENT=1;
	Sack entity;
	Ac3dcHandler ac3dcHandler;
	DcmHandler dcmHandler;
	//values and parameters
		//motor
			//parameters
	double Kt=0;
	double Ke=0;
	double J=0;
	double Tap=0;
			//values
	double i=0;
	double w=0;
	double m=0;
		//rectifier
			//parameters
	double Tr=0;
	double Ku=0;
	double Udm=0;
			//values
	double ud=0;
	double preferredClock=0;
		//controller
			//current regulator
				//parameters
	double Tar=0;
	double Kar=0;
	double Kap=0;
	double a=0;
	double b=0;
	double c=0;	
	double g=0;
				//values
	double zap=0;
	double iap=0;
	double zar=0;
	double uc=0;
			//speed regulator
				//parameters
	double Tsrd=0;
	double Tsri=0;
	double zsr=0;
				//values
	double ig=0;
			//drive
	double Umax=0;
	double Imax=0;
			//model
	double clock=0;
	public DriveHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
		String entity$=Locator.getProperty(alocator$,Entigrator.ENTITY_LABEL);
		entity=entigrator.getEntityAtLabel(entity$);
		System.out.println("DriveHandler:entity ="+entity$);
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,"drive");
		locator.put(FACET_TYPE,"Drive");
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_MASTER_CLASS,"_54rGxWBplMoFP63dPDOkOuRcxH4.gui.facet.DriveMaster");
		locator.put(ModuleHandler.FACET_MODULE,"_54rGxWBplMoFP63dPDOkOuRcxH4");
		locator.put( IconLoader.ICON_FILE, "drive.png");
		locator.put( IconLoader.ICON_CONTAINER,"_54rGxWBplMoFP63dPDOkOuRcxH4 ");
		return Locator.toString(locator);
	}
	@Override
	public String getLocator() {
		return Locator.merge(locator$, classLocator());
	}
	@Override
	public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
		Hashtable<String, Double> outs=new Hashtable<String, Double> ();
		try {
			//clock
			clock=Tr/100;
			try {clock=ins.get("clock");}catch(Exception ee){}
			double time=0;
			try {time=ins.get("time");}catch(Exception eee){}
			//speed regulator
			double wg=0;
				try{ wg=ins.get("wg");}catch(Exception ee) {}
				double mc=0;	
				try{ mc=ins.get("mc");}catch(Exception ee) {}
				double dw=wg-w;
				double dzsr=dw*clock;
				if(Math.abs(dw)>10)
					zsr=0;
				zsr=zsr+dzsr;
				ig=zsr+dw*Tsrd/Tsri;
			//loop mode
				double loop=0;
				try {loop=ins.get(LOOP);}catch(Exception e) {}
				if(LOOP_CURRENT==loop) {
					ig=0;
					try {ig=ins.get("ig");}catch(Exception e) {}
				}
				if(ig>Imax)
					ig=Imax;
				if(ig<-Imax)
					ig=-Imax;
			//current loop	
				//summator
				double di=ig-i;
				zar=zar+di*clock;
				//double uc=Kar*di;
				double uc=Kar*di+zar/Tar;
				//rectifier
				Hashtable<String, Double> rectifierIns=new Hashtable<String, Double>();
				rectifierIns.put("time", time);
				rectifierIns.put("clock",clock);
				rectifierIns.put("uc", uc);
				Hashtable<String, Double> rectifierOuts=ac3dcHandler.stride(rectifierIns);
				ud=0;
				try{ud=rectifierOuts.get("ud");}catch(Exception e) {}
				outs.put("ud", ud);
				//plant
				double dzap=(-b*zap-c*i+ud/Ku-Ke*w/Ku)*clock/a;
				zap=zap+dzap;
				double dzi=zap*clock;
				i=i+dzi;
				outs.put("i", i);
			//speed plant
				 mc=0;
				try {mc=ins.get("mc");}catch(Exception ee) {}
				m=i*Kt;
				double dwp=(m-mc)*clock/J;
				w=w+dwp;
				outs.put("w", w);
				outs.put("m", m);
				outs.put("i", i);
			return outs;
			}catch(Exception e) {
				System.out.println("DriveHandler:stride:"+e.toString());
				return null;
			}
	}
	@Override
	public void reset() {
		try {
		if(entigrator==null) {
			System.out.println("DriveHandler:reset:entigrator is null");
			return;
		}
		if(entity==null) {
			System.out.println("DriveHandler:reset:entity is null");
			return;
		}
		zap=0;
		ig=0;
		iap=0;
		uc=0;
		zsr=0;
		//speed
		zsr=0;
		w=0;
		//drive
		String Umax$=entity.getElementItemAt("drive", "Ucmax");
		Umax=Double.parseDouble(Umax$);
		String Imax$=entity.getElementItemAt("drive", "Iamax");
		Imax=Double.parseDouble(Imax$);
		String ac3dc$=entity.getElementItemAt("drive", "rectifier");
		String dcm$=entity.getElementItemAt("drive", "motor");
		String dcmHandler$=DcmHandler.classLocator();
		dcmHandler$=Locator.append(dcmHandler$,Entigrator.ENTITY_LABEL, dcm$);
		dcmHandler=new DcmHandler(entigrator,dcmHandler$);
		dcmHandler.reset();
		Hashtable<String,Double>dcmSettings=dcmHandler.getSettings();
		try{Ke=dcmSettings.get("Ke");}catch(Exception ee) {}
		try{Kt=dcmSettings.get("Kt");}catch(Exception ee) {}
		String ac3dcHandler$=Ac3dcHandler.classLocator();
		ac3dcHandler$=Locator.append(ac3dcHandler$, Entigrator.ENTITY_LABEL, ac3dc$);
		ac3dcHandler=new Ac3dcHandler(entigrator,ac3dcHandler$);
		ac3dcHandler.reset();
		Hashtable<String,Double>ac3dcSettings=ac3dcHandler.getSettings();
		Tr=ac3dcSettings.get("Tr");
		Ku=ac3dcSettings.get("Ku");
		Udm=ac3dcSettings.get("Udm");
		clock=ac3dcSettings.get("preferredClock");
		double La=0;
		try{La=	dcmSettings.get("L");}catch(Exception ee) {}
		double Ra=0;
		try{Ra=	dcmSettings.get("R");}catch(Exception ee) {}
		Tap=La/Ra;
		double Ktg=0;
		try{Ktg=dcmSettings.get("Ktg");}catch(Exception ee) {}
		J=0;
		try{J=dcmSettings.get("J");}catch(Exception ee) {}
		//current regulator
		Tar=2*Tr*Ku/Ra;
		Kar=Ra*Tap/(2*Tr*Ku);
		a=Ra*Tap*Tr/Ku;
		b=Ra*(Tap+Tr)/Ku;
		c=Ra/Ku;	
		g=1/Tar;;
		//speed regulator
		//T_srd=4T_r
		Tsrd=8*Tr;
		Tsri=32*Tr*Tr*Kt/J;
		clock=Tr/100;
		entity.putElementItem("operator",new Core("out","w","0"));	
	    entity.putElementItem("operator",new Core("out","i","0"));
	    entity.putElementItem("operator",new Core("out","m","0"));
	    entity.putElementItem("operator",new Core("out","ud","0"));
	    entity.putElementItem("operator",new Core("in","wg","0"));
	    entity.putElementItem("operator",new Core("in","mc","0"));	
	    entity.putElementItem("operator",new Core("in","ig","0"));	
		//parameters
	    if(!entity.existsElement("drive"))
	    	entity.createElement("drive");
	    entity.putElementItem("drive",new Core(null,"Tsrd",String.valueOf(Tsrd)));	
	    entity.putElementItem("drive",new Core(null,"Tsri",String.valueOf(Tsri)));	
	    entity.putElementItem("drive",new Core(null,"Tar",String.valueOf(Tar)));	
	    entity.putElementItem("drive",new Core(null,"Kar",String.valueOf(Kar)));
		entigrator.putEntity(entity);
		entity.printElement("drive");
		}catch(Exception e) {
			System.out.println("DriveHandler:reset:"+e.toString());
		}
	}
	@Override
	public Hashtable<String, Double> getSettings() {
		Hashtable<String, Double> settings=new Hashtable<String, Double> ();
		settings.put("Tr", Tr);
		settings.put("Kar",Kar);
		settings.put("Tar",Tar);
		settings.put("Tsrd",Tsrd);
		settings.put("Tsri",Tsri);
		return settings;
	}
	@Override
	public void putSettings(Hashtable<String, Double> settings) {
			}
	@Override
	public Hashtable<String, Double> getOuts() {
		Hashtable<String, Double> outs=new Hashtable<String, Double> ();
		outs.put("w",w);
		outs.put("m",m);
		outs.put("i",i);
		outs.put("ud",ud);
		return outs;
	}
	@Override
	public double getClock() {
		return Tr/100;
	}
	@Override
	public void setClock(double clock) {
		this.clock=clock;
	}
	@Override
	public String[] listInputs() {
		String[] sa=new String[] {
				"wg",
				"mc",
				"ig"
		};
		return sa;
	}
	@Override
	public String[] listOutputs() {
		String[] sa=new String[] {
				"w",
				"m",
				"i",
				"ud",
				"ig"
		};
		return sa;
	}
	@Override
	public void setEntigrator(Entigrator entigrator) {
		this.entigrator=entigrator;
	}
	
	@Override
	public String getName() {
		return "drive";
	}
	@Override
	public String getType() {
		return "Drive";
	}
	@Override
	public String getFacetClass() {
		return classLocator();
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return null;
	}
	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return null;
	}
}
