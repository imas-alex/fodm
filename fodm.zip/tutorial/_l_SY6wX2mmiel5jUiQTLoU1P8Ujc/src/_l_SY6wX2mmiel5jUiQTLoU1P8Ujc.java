import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import java.util.Hashtable;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _l_SY6wX2mmiel5jUiQTLoU1P8Ujc  implements SegueController {
//sosPlant
private final static String ENTITY_KEY="_l_SY6wX2mmiel5jUiQTLoU1P8Ujc";
//pars
double K=10; //коэффициент усиления
double T=1;	 //постоянная времени
double L=0.5;	 //показатель колебательности
double preferredClock=0.01;
double clock=preferredClock;
//vars
double y=0;
double z=0;
//inner pars
double a= K/((T*T)+Double.MIN_VALUE);
double b=L/(T+Double.MIN_VALUE);
double c=1/((T*T)+Double.MIN_VALUE);
Entigrator entigrator;
boolean closed=false;
@Override
public void reset() {
	y=0;
	z=0;
	if(entigrator==null) {
		System.out.println(ENTITY_KEY+":reset:entigrator is null");
		return;
	}
	Sack entity=entigrator.getEntity(ENTITY_KEY);
	if(!entity.existsElement(OperatorHandler.OPERATOR))
    	entity.createElement(OperatorHandler.OPERATOR);
entity.putElementItem(OperatorHandler.OPERATOR, new Core("in","x","0"));
entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","y","0"));
entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","z","0"));
entigrator.putEntity(entity);
}
@Override
public Hashtable<String, Double> getSettings()  {
	Hashtable<String,Double> set=new Hashtable<String,Double> ();
	set.put("K", K);
	set.put("T", T);
	set.put("L", L);
	return set;
	}

@Override
public String[] listInputs(){
	return new String[] {"x"};
	}
@Override
public String[] listOutputs(){
	return new String[] {"y"};
	}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins){

//	System.out.println(ENTITY_KEY+" y="+y+"  z="+z);	
	boolean closed=false;
	 double open=1;
  try {open= ins.get("open");}catch(Exception e) {}
  try {clock= ins.get("clock");}catch(Exception e) {}
  if(open<0)
  	closed=true;
  double x=0;
  try {x= ins.get("x");}catch(Exception e) {}
 
 // System.out.println(ENTITY_KEY+" x="+x);
 
  double dz=0;
	if(!closed)
		dz=(a*x-b*z-c*y)*clock;
	else
		dz=(a*(x-y)-b*z-c*y)*clock;	
	z=z+dz; 
	double dy=z*clock;
  	y=y+dy;
  	//System.out.println(ENTITY_KEY+" y="+y);	
	//System.out.println(ENTITY_KEY+" z="+z);	
	Hashtable<String,Double> outs=new Hashtable<String,Double>();
	outs.put("y", y);
//	System.out.println(ENTITY_KEY+" x="+x+"  y="+y+"  z="+z);
	return outs;

} 
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double>outs=new Hashtable<String, Double>();
	outs.put("y",y);
	outs.put("z",z);
	return outs;
}
@Override
public double getClock() {
	return preferredClock;
}
@Override
public void setClock(double clock) {
		this.clock=clock;
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
	
}
@Override
public void putSettings(Hashtable<String, Double> settings) {
	// TODO Auto-generated method stub
	
}
}
