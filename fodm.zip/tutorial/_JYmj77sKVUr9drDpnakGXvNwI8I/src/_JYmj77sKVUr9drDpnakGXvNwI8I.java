import java.util.Hashtable;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import gdt.base.store.Entigrator;

public class _JYmj77sKVUr9drDpnakGXvNwI8I  implements SegueController {
//lpf
	private final static String ENTITY_KEY="_JYmj77sKVUr9drDpnakGXvNwI8I";
double K=10;
double T=1;
double defaultClock=0.1;
double clock=defaultClock;
double y=0;
double dy;
double a=K/(T+Double.MIN_VALUE);
double b=1/(T+Double.MIN_VALUE);
double b2=(K+1)/(T+Double.MIN_VALUE);
Entigrator entigrator;
@Override
public void reset() {
	y=0;
	System.out.println(ENTITY_KEY+":RESET:y="+y);
}
@Override
public  Hashtable<String,Double>  stride(Hashtable<String,Double> ins) {
	
	boolean closed=false;
	 double open=1;
    try {open= ins.get("open");}catch(Exception e) {}
    if(open<0)
    	closed=true;
    double x=0;
    clock=ins.get("clock");
    try {x= ins.get("x");}catch(Exception e) {}
    if(!closed)	{
    	dy=(a*x-b*y)*clock;
    }else
		dy=(a*x-b2*y)*clock;
	 y=y+dy;
	 Hashtable<String,Double> outs=new Hashtable<String,Double>();
	 outs.put("y", y);
	// System.out.println(ENTITY_KEY+" x="+x+"  y="+y+"  clock="+clock);
	 return outs;
}
@Override
public Hashtable <String,Double> getSettings() {
	Hashtable<String,Double> set=new Hashtable<String,Double> ();
	set.put("K", K);
	set.put("T", T);
	return set;
}

@Override
public String[] listInputs() {
	return new String[] {"x"};
}
public String[] listOutputs() {
	return new String[] {"y"};
}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double>outs=new Hashtable<String, Double>();
	outs.put("y",y);
	return outs;
}
@Override
public double getClock() {
	return defaultClock;
}
@Override
public void setClock(double clock) {
	if(clock<defaultClock)
		this.clock=clock;
	else
		this.clock=defaultClock;
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
	
}
@Override
public void putSettings(Hashtable<String, Double> settings) {
	// TODO Auto-generated method stub
	
}
}
