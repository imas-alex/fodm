import gdt.base.store.Entigrator;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.EduHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DriveHandler;
import java.util.Hashtable;
import java.util.Properties;
import gdt.base.generic.Locator;
public class _DXD8umx6nCCUJhGNMUssTLlbhjg implements SegueController{
private final static String ENTITY_KEY="_DXD8umx6nCCUJhGNMUssTLlbhjg";
private _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DriveHandler driveHandler;
public _DXD8umx6nCCUJhGNMUssTLlbhjg(){}
public Hashtable<String,Double>  stride(Hashtable<String,Double>  ins){ 
	//ins.put(DriveHandler.LOOP,DriveHandler.LOOP_CURRENT);
	//ins.put("ig",10.0);
//EduHandler.printHashtableDouble(ENTITY_KEY+":stride:ins", ins);
Hashtable<String,Double>outs=driveHandler. stride(ins);
//EduHandler.printHashtableDouble(ENTITY_KEY+":stride:outs", outs);
return outs;
} 
public void reset(){ 
driveHandler.reset();
Hashtable<String,Double>settings=getSettings();
EduHandler.printHashtableDouble(ENTITY_KEY+"settings", settings);
} 
public Hashtable<String,Double> getSettings(){ 
return driveHandler.getSettings();
} 
public void putSettings(Hashtable<String,Double> settings){ 
driveHandler.putSettings(settings); 
} 
public Hashtable<String,Double> getOuts(){ 
return driveHandler.getOuts();
}
public double getClock(){
return driveHandler.getClock();
}
public void setClock(double clock){ 
driveHandler.setClock(clock); 
} 
public String[] listInputs(){ 
return driveHandler.listInputs(); 
}
public String[] listOutputs(){ 
return driveHandler.listOutputs(); 
}
public void setEntigrator(Entigrator entigrator){ 
 String entity$=entigrator.getLabel(ENTITY_KEY);
 Properties props=new Properties();
 props.put(Entigrator.ENTITY_LABEL, entity$);
 String locator$=Locator.toString(props);
driveHandler=new DriveHandler(entigrator,locator$);
driveHandler.setEntigrator(entigrator);
} 
}
