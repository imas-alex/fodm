import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JEditorPane;

import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.procedure.Procedure;
public class _YKAnRdWtfFpAEgma84sWT546GGo  implements Procedure {
private final static String ENTITY_KEY="_YKAnRdWtfFpAEgma84sWT546GGo";
public _YKAnRdWtfFpAEgma84sWT546GGo (){} 
@Override
public void exec(JMainConsole console, String locator$, JEditorPane reportPanel) {
	String[] sa=console.getEntigrator().listEntities();
	String label$;
	
	ArrayList<String>sl=new ArrayList<String>();
	for(String s:sa) {
		label$=console.getEntigrator().getLabel(s);
		if(label$!=null)
			sl.add(label$);
			//out.append(label$+"\n");
	}
	Collections.sort(sl);
	StringBuffer out=new StringBuffer();
	for(String s:sl) {
		out.append(s+"\n");
	}
	reportPanel.setText(out.toString());
/*	
	
	String target$="/home/alexander/knorus/fodm";
String source$="/home/alexander/fomdmaster/tutorial";

Entigrator target=console.getEntigrator();	
Entigrator source=new Entigrator(source$);
String[] sa=source.listEntities();
Sack entity;
if(sa!=null)
	for(String s:sa) {
	entity=null;	
	 // System.out.println(ENTITY_KEY+" "+s);
	entity=target.getEntity(s);
	//}catch(Exception ee) {}
	if(entity!=null)
		continue;
	entity=source.getEntity(s);
	if(entity==null)
		continue;
	System.out.println(ENTITY_KEY+" "+s);
	String targetPath$=target$+"/_xXsnV5R_SGxkuH_SpLJDeXCglybwsOld/data/"+s;
	System.out.println(targetPath$);
	try {
	target.putEntity(entity);
	target.reindexEntity(entity);
	}catch(Exception ee) {System.out.println(ee.toString());}
	}
*/
}
}
