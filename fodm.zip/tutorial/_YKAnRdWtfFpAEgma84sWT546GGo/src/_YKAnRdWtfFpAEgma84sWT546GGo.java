import java.io.File;

import javax.swing.JEditorPane;

import gdt.base.store.Entigrator;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.procedure.Procedure;
public class _YKAnRdWtfFpAEgma84sWT546GGo  implements Procedure {
private final static String ENTITY_KEY="_YKAnRdWtfFpAEgma84sWT546GGo";
public _YKAnRdWtfFpAEgma84sWT546GGo (){} 
@Override
public void exec(JMainConsole console, String locator$, JEditorPane reportPanel) {
Entigrator entigrator=console.getEntigrator();
String[] sa=entigrator.listEntities("folder", "true");
if(sa!=null) {
	String entihome$=entigrator.getEntihome();
	String folder$;
	for(String s:sa) {
		//System.out.println(s);
		folder$=entihome$+"/"+s;
		
		File folder=new File(folder$);
		//String[] fa=folder.list();
		File [] fa=folder.listFiles();
		if(fa!=null) {
			for(File f:fa) {
				System.out.println(f.getName()+"="+f.length());
			
		}
		
	}
	}
}}}

