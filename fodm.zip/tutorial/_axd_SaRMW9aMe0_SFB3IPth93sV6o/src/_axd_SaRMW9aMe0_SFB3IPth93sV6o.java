import gdt.base.store.Entigrator;
public class _axd_SaRMW9aMe0_SFB3IPth93sV6o implements StepHandler{
private final static String ENTITY_KEY="_axd_SaRMW9aMe0_SFB3IPth93sV6o";
public _axd_SaRMW9aMe0_SFB3IPth93sV6o(){} 
public void step(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reset(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reinit(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
}
