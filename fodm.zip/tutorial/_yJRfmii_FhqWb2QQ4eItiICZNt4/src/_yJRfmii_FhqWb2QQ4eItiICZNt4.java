import java.util.Hashtable;

import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _yJRfmii_FhqWb2QQ4eItiICZNt4  implements SegueController {
private final static String ENTITY_KEY="_yJRfmii_FhqWb2QQ4eItiICZNt4";
//currentLoopSummator
Hashtable<String, Double>settings=new Hashtable<String, Double>();
double Kig=1;
double Ki=-1;
double ig=0;
double i=0;
double di=0;
Sack entity;
Entigrator entigrator;
@Override
public void reset() {
	try {
        if(!entity.existsElement(OperatorHandler.OPERATOR))
	        	entity.createElement(OperatorHandler.OPERATOR);
    	entity.putElementItem(OperatorHandler.OPERATOR, new Core("in","ig","0"));
	    entity.putElementItem(OperatorHandler.OPERATOR, new Core("i","i","0"));
	    entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","di","0"));
	    entigrator.putEntity(entity);
	    di=0;
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+":reset:"+e.toString());
	}
}
@Override
public Hashtable<String, Double> getSettings()  {
	Hashtable<String, Double>settings=new Hashtable<String, Double>();
	settings.put("Kig", Kig);
	settings.put("Ti",Ki);
	return settings;
	}

@Override
public void putSettings(Hashtable<String, Double> set)  {}
@Override
public String[] listInputs(){
	String[] sa=new String[] {
			"ig",
			"i"
	};
	return sa;
	}
@Override
public String[] listOutputs(){
	String[] sa=new String[] {
			"di"
	};
	return sa;
	}

@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
	Hashtable<String, Double> outs=new Hashtable<String, Double>();
	//EduHandler.printHashtableDouble(ENTITY_KEY+":stride:ins", ins);
	try {
	ig=ins.get("ig");
	i=ins.get("i");
	di=Kig*ig+Ki*i;
	outs.put("di", di);
	//EduHandler.printHashtableDouble(ENTITY_KEY+":stride:outs", outs);
	return outs;
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+"stride:"+e.toString());
		return null;
	}
}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double> outs=new Hashtable<String, Double>();
	outs.put("di", di);
	return outs;
}
@Override
public double getClock() {
	// TODO Auto-generated method stub
	return 0;
}
@Override
public void setClock(double clock) {
	// TODO Auto-generated method stub
	
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
	entity=entigrator.getEntity(ENTITY_KEY);
	
}
}
