import java.util.Hashtable;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _MKNH_WxilXvhLw0cLAbr4uDEozA  implements SegueController {
	//currentLoopItem
private final static String ENTITY_KEY="_MKNH_WxilXvhLw0cLAbr4uDEozA";
Entigrator entigrator;
Hashtable<String, Double>settings=new Hashtable<String, Double>();
double Ta=0.011;
double Tr=0.00333;
//double Tar=83.5;
double Tar=0.15;
double Ku=513;
double Ra=3.72;
double Kar=0.041;
double a=Ra*Ta*Tr/Ku;
double b=Ra*(Ta+Tr)/Ku;
double c=Ra/Ku;	
double g=1/Tar;
double preferredClock=Ta/1000;
double clock=preferredClock;
double z=0;
double i=0;
double zr=0;
double yr=0;
double di=0;
@Override
public void reset() {
	z=0;
	zr=0;
	i=0;
	yr=0;
	di=0;
	if(entigrator!=null) {
		Sack entity=entigrator.getEntity(ENTITY_KEY);
		if(entity!=null) {
			if(!entity.existsElement("operator"))
				entity.createElement("operator");
		    entity.putElementItem("operator",new Core("out","z","0"));	
		    entity.putElementItem("operator",new Core("out","zr","0"));
		    entity.putElementItem("operator",new Core("out","i","0"));
		    entity.putElementItem("operator",new Core("out","yr","0"));
		    entity.putElementItem("operator",new Core("out","di","0"));
		    entigrator.putEntity(entity);
		}
	}
}
@Override
public Hashtable<String, Double> getSettings()  {
	Hashtable<String, Double>settings=new Hashtable<String, Double>();
	settings.put("Ta",Ta);
	settings.put("Tr",Tr);
	settings.put("Tar",Tar);
	settings.put("Ku",Ku);
	settings.put("Ra",Ra);
	settings.put("Kar",Kar);
	return settings;
	}

@Override
public String[] listOutputs(){
	return new String[] {
			"i",
			"z",
			"zr",
			"yr",
			"di"
			};
	}
@Override
public String[] listInputs(){
	return new String[] {
			"ig"
			};
}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double>outs=new Hashtable<String, Double>();
	outs.put("z", z);
	outs.put("i", i);
	outs.put("zr", zr);
	outs.put("yr", yr);
	return outs;
}
@Override
public double getClock() {
    return clock;

}
@Override
public void setClock(double clock) {
	this.clock=clock;
	
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
	
}

@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
//	EduHandler.printHashtableDouble(ENTITY_KEY+": stride:ins", ins);

//	EduHandler.printHashtableDouble(ENTITY_KEY+": stride:outs", outs);
	Hashtable<String, Double> outs=new Hashtable<String, Double>();
	try {
	clock=ins.get("clock");
	double ig=ins.get("ig");
	//summator
	di=ig-i;
	//regulator
	zr=zr+di*clock;
	yr=zr/Tar+Kar*di;
	//yr=Kar*di;
	//plant
	double dy=z*clock;
	double dz=(-b*z-c*i+yr)*clock/a;
	i=i+dy;
	z=z+dz;
	outs.put("i", i);
	outs.put("di", di);
	outs.put("zr", zr);
	outs.put("yr", yr);
	return outs;
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+":stride:"+e.toString());
		return null;
	}
}
@Override
public void putSettings(Hashtable<String, Double> settings) {
	
}
}
