import java.util.Hashtable;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.OperatorHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _fOEFnYktrm_Wh0pqldLaeepjACc  implements SegueController {
private final static String ENTITY_KEY="_fOEFnYktrm_Wh0pqldLaeepjACc";
//sosItem
//pars
double Kp=10; //коэффициент усиления
double Tp=1;	 //постоянная времени
double Lp=2;	 //показатель колебательности

//vars
double yp=0;
double zp=0;
//inner pars
double a= Kp/((Tp*Tp)+Double.MIN_VALUE);
double b=Lp/(Tp+Double.MIN_VALUE);
double c=1/((Tp*Tp)+Double.MIN_VALUE);

////sosRegulator
double yr=0;
double Tr=24;

////sosSummator
double Kx=1;
double Kxo=-1;
double x=0;
double xo=0;
double dx=0;
////common
double preferredClock=0.01;
double clock=preferredClock;
Entigrator entigrator;
boolean closed=false;
@Override
public void reset() {
	yp=0;
	zp=0;
	yr=0;
	x=0;
	xo=0;
	dx=0;
	if(entigrator==null) {
		System.out.println(ENTITY_KEY+":reset:entigrator is null");
		return;
	}
	Sack entity=entigrator.getEntity(ENTITY_KEY);
	if(!entity.existsElement(OperatorHandler.OPERATOR))
    	entity.createElement(OperatorHandler.OPERATOR);
entity.putElementItem(OperatorHandler.OPERATOR, new Core("in","x","0"));
entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","xo","0"));
entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","zp","0"));
entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","yr","0"));
entity.putElementItem(OperatorHandler.OPERATOR, new Core("out","yp","0"));
   String clock$=entity.getElementItemAt(OperatorHandler.OPERATOR, "takt");
   try {clock=Double.parseDouble(clock$);}catch(Exception e) {}
entigrator.putEntity(entity);
	
}
@Override
public Hashtable<String, Double> getSettings()  {
	
	Hashtable<String, Double> settings=new Hashtable<String, Double>();
	
	settings.put("Kp", Kp);
	settings.put("Tp", Tp);
	settings.put("Lp", Lp);
	settings.put("Tr", Tr);
	settings.put("Kx", Kx);
	settings.put("Kxo", Kxo);
	
	return settings;
	}

@Override
public void putSettings(Hashtable<String, Double> set)  {}
@Override
public String[] listInputs(){
	return new String[] {
			"x"
	};
	
}
@Override
public String[] listOutputs(){
	return new String[] {
		"yp",
		"yr",
		"dx"
	};
			}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
	//System.out.println(ENTITY_KEY+":stride:BEGIN");
	double x=0;
	try{x =ins.get("x");}catch(Exception ee) {}
	double open=1;
	try{open =ins.get("open");}catch(Exception ee) {}
	//EduHandler.printHashtableDouble(ENTITY_KEY, ins);
	if(open<0) 
   		x=x-yp;
	//summator
	dx=Kx*x+Kxo*yp;
	//regulator
	double dyr=dx*clock/Tr;
	yr=yr+dyr;
	//plant
	double dzp=(a*yr-b*zp-c*yp)*clock;
	zp=zp+dzp; 
	double dyp=zp*clock;
  	yp=yp+dyp;
  	Hashtable<String, Double>outs=new Hashtable<String, Double>();
  	outs.put("yp", yp);
  	outs.put("yr", yr);
  	outs.put("dx", dx);
	return outs;
}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double> outs=new Hashtable<String, Double>();
	outs.put("yp", yp);
	outs.put("yr", yr);
	return outs;
}
@Override
public double getClock() {
		return preferredClock;
}
@Override
public void setClock(double clock) {
	this.clock=clock;
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
}
}
