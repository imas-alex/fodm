import java.util.Hashtable;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _6_SQJwxEwRFivs_Sm06j9kiA8XnJU  implements SegueController {
private final static String ENTITY_KEY="_6_SQJwxEwRFivs_Sm06j9kiA8XnJU";
Entigrator entigrator;
Hashtable<String, Double>settings=new Hashtable<String, Double>();
//current loop
double Tap=0.0113;
double Tr=0.00333;
double Tar=0.919;
double Kar=0.0121;
double Kap=138;
double a=Tap*Tr/Kap;
double b=(Tap+Tr)/Kap;
double c=1/Kap;	
double g=1/Tap;
double preferredClock=Tr/1000;
double clock=preferredClock;
double zap=0;
double iap=0;
double zar=0;
double uc=0;

// speed
	//primary parameters
double Kt=2.214;
double J=0.038;
	//secondary parameres
double Tsrd=8*Tr;
double Tsri=32*Tr*Tr*Kt/J;
	//variables
double zsr=0;
double ig=0;
double w=0;
@Override
public void reset() {
	//current
	zap=0;
	ig=0;
	//speed
	zsr=0;
	ig=0;
	w=0;
	if(entigrator!=null) {
		Sack entity=entigrator.getEntity(ENTITY_KEY);
		if(entity!=null) {
			if(!entity.existsElement("operator"))
				entity.createElement("operator");
		   //current
			entity.putElementItem("operator",new Core("out","zap","0"));
		    entity.putElementItem("operator",new Core("out","ig","0"));
		    //speed
		    entity.putElementItem("operator",new Core("out","zsr","0"));
		    entity.putElementItem("operator",new Core("out","w","0"));
		    entigrator.putEntity(entity);
		    System.out.println(ENTITY_KEY+":reset:Tsrd="+Tsrd+" Tsri="+Tsri);
		}
	}
	
}
@Override
public Hashtable<String, Double> getSettings()  {
	Hashtable<String, Double>settings=new Hashtable<String, Double>();
	settings.put("Tsrd",Tsrd);
	settings.put("Tsri",Tsri);
	settings.put("Tr",Tr);
	settings.put("Kt",Kt);
	settings.put("J",J);
	settings.put("Tar",Tar);
	settings.put("Kar",Kar);
	settings.put("Kap",Kap);
	return settings;
	}

public void putSettings(Hashtable<String, Double> set)  {}
@Override
public String[] listInputs(){
	return new String[] {
			"mc",
			"wg"
			};
}
@Override
public String[] listOutputs(){
	return new String[] {
		"i",
		"w"
		};
	}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
//	System.out.println(ENTITY_KEY+":stride:BEGIN");
	if(ins==null||ins.isEmpty()) {
		System.out.println(ENTITY_KEY+":stride:empty ins");
	}
//	EduHandler.printHashtableDouble(ENTITY_KEY+": stride:ins", ins);
//	EduHandler.printHashtableDouble(ENTITY_KEY+": stride:outs", outs);
	Hashtable<String, Double> outs=new Hashtable<String, Double>();
	try {
	//current
	clock=ins.get("clock");
	//speed regulator
	double wg=0;
		try{ wg=ins.get("wg");}catch(Exception ee) {}
		double dw=wg-w;
		double dzsr=dw*clock/Tsri;
		zsr=zsr+dzsr;
		ig=zsr+dw*Tsrd/Tsri;
	//current loop
		//summator
		//summator
		double di=ig-iap;
		//regulator
		zar=zar+di*clock;
		uc=zar/Tar+Kar*di;
		//plant
		double dzap=(-b*zap-c*iap+uc)*clock/a;
		zap=zap+dzap;
		double diap= zap*clock;
		iap=iap+diap;
		
	//speed plant
		double mc=0;
		try {mc=ins.get("mc");}catch(Exception ee) {}
	//	System.out.println(ENTITY_KEY+":stride:mc="+mc);
		double dwp=(iap*Kt-mc)*clock/J;
		w=w+dwp;
		outs.put("w", w);
		outs.put("i", iap);
	return outs;
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+":stride:"+e.toString());
		return null;
	}
}
@Override
public Hashtable<String, Double> getOuts() {
	Hashtable<String, Double>outs=new Hashtable<String, Double>();
	outs.put("i", iap);
	outs.put("w", w);
	return outs;
}
@Override
public double getClock() {
	return clock;
}
@Override
public void setClock(double clock) {
	this.clock=clock;
	
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
}
}
