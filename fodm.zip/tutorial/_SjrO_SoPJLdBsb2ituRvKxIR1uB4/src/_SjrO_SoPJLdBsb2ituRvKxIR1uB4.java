import gdt.base.store.Entigrator;
public class _SjrO_SoPJLdBsb2ituRvKxIR1uB4 implements StepHandler{
private final static String ENTITY_KEY="_SjrO_SoPJLdBsb2ituRvKxIR1uB4";
public _SjrO_SoPJLdBsb2ituRvKxIR1uB4(){} 
public void step(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reset(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reinit(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
}
