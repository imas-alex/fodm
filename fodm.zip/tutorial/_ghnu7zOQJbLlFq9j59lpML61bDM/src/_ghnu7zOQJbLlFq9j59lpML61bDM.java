import gdt.base.store.Entigrator;
public class _ghnu7zOQJbLlFq9j59lpML61bDM implements StepHandler{
private final static String ENTITY_KEY="_ghnu7zOQJbLlFq9j59lpML61bDM";
public _ghnu7zOQJbLlFq9j59lpML61bDM(){} 
public void step(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reset(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
public void reinit(Entigrator entigrator, String locator$) {
System.out.println(ENTITY_KEY+":"+locator$);
	}
}
