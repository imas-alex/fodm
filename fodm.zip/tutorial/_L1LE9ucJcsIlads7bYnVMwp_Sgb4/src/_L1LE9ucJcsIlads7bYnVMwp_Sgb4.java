import java.util.Hashtable;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.PackHandler;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
public class _L1LE9ucJcsIlads7bYnVMwp_Sgb4  implements SegueController {
//sosPack
	private final static String ENTITY_KEY="_L1LE9ucJcsIlads7bYnVMwp_Sgb4";
PackHandler packHandler;
Entigrator entigrator;
String pack$="currentLoopPack";

@Override
public void reset() {
	if(entigrator==null) {
		System.out.println(ENTITY_KEY+":reset:entigrator is null");
		return;
	}
	try {
		String packHandler$=PackHandler.classLocator();
		packHandler$=Locator.append(packHandler$, Entigrator.ENTITY_LABEL, pack$);
		Sack pack=entigrator.getEntityAtLabel(pack$);
		if(pack==null) {
			System.out.println(ENTITY_KEY+":reset:cannot get entity="+pack$);
		}
		packHandler=new PackHandler(entigrator,packHandler$);
		packHandler.reset();
	}catch(Exception e) {
		System.out.println(ENTITY_KEY+":reset:"+e.toString());
	}
}
@Override
public Hashtable<String, Double> getSettings()  {
	return packHandler.getSettings();
	}
@Override
public void putSettings(Hashtable<String, Double> set)  {}
@Override
public String[] listInputs(){
	 if(packHandler==null) {
	    	System.out.println(ENTITY_KEY+":listInputs:pack handler is null");
	    	/*
	    	if(entigrator==null)
	    		System.out.println(ENTITY_KEY+":listInputs:entigrator is null");
	    	return null;
	    	*/
	    	String packHandler$=PackHandler.classLocator();
			packHandler$=Locator.append(packHandler$, Entigrator.ENTITY_LABEL, pack$);
			packHandler=new PackHandler(entigrator,packHandler$);
			packHandler.reset();
	    }
	String[]sa=packHandler.listInputs();
	for(String s:sa)
		System.out.println(ENTITY_KEY+":listInputs:s="+s);	
	return packHandler.listInputs();
}
@Override
public String[] listOutputs(){
    if(packHandler==null) {
    	String packHandler$=PackHandler.classLocator();
    	packHandler$=Locator.append(packHandler$, Entigrator.ENTITY_LABEL, pack$);
		packHandler=new PackHandler(entigrator,packHandler$);
		packHandler.reset();
    }
    	
	return packHandler.listOutputs();
	}
@Override
public Hashtable<String, Double> stride(Hashtable<String, Double> ins) {
	Hashtable<String, Double>outs=packHandler.stride(ins);
	if(outs==null) {
		System.out.println(ENTITY_KEY+":stride:outs is null");
	}
	return packHandler.stride(ins);
}
@Override
public Hashtable<String, Double> getOuts() {
	return packHandler.getOuts();
}
@Override
public double getClock() {
	return packHandler.getClock();
}
@Override
public void setClock(double clock) {
	packHandler.setClock(clock);
}
@Override
public void setEntigrator(Entigrator entigrator) {
	this.entigrator=entigrator;
}
}
