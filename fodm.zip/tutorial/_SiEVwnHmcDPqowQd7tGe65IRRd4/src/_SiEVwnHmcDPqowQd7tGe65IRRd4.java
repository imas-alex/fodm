import gdt.base.store.Entigrator;
import _TZ34ntGtza4ryheSV3Xo_JOLOIU.base.facet.SegueController;
import _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DcmHandler;
import java.util.Hashtable;
import java.util.Properties;
import gdt.base.generic.Locator;
public class _SiEVwnHmcDPqowQd7tGe65IRRd4 implements SegueController{
private final static String ENTITY_KEY="_SiEVwnHmcDPqowQd7tGe65IRRd4";
private _54rGxWBplMoFP63dPDOkOuRcxH4.base.facet.DcmHandler dcmHandler;
public _SiEVwnHmcDPqowQd7tGe65IRRd4(){}
public Hashtable<String,Double>  stride(Hashtable<String,Double>  ins){ 
return dcmHandler. stride(ins);
} 
public void reset(){ 
dcmHandler.reset();
} 
public Hashtable<String,Double> getSettings(){ 
return dcmHandler.getSettings();
} 
public void putSettings(Hashtable<String,Double> settings){ 
dcmHandler.putSettings(settings); 
} 
public Hashtable<String,Double> getOuts(){ 
return dcmHandler.getOuts();
}
public double getClock(){
return dcmHandler.getClock();
}
public void setClock(double clock){ 
dcmHandler.setClock(clock); 
} 
public String[] listInputs(){ 
return dcmHandler.listInputs(); 
}
public String[] listOutputs(){ 
return dcmHandler.listOutputs(); 
}
public void setEntigrator(Entigrator entigrator){ 
 String entity$=entigrator.getLabel(ENTITY_KEY);
 Properties props=new Properties();
 props.put(Entigrator.ENTITY_LABEL, entity$);
 String locator$=Locator.toString(props);
 dcmHandler=new DcmHandler(entigrator,locator$);
 dcmHandler.setEntigrator(entigrator);
} 
}
