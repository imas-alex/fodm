import javax.swing.JEditorPane;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.procedure.Procedure;
public class _1I3P9ZAbkIqanLk6TfqtHmeppAc  implements Procedure {
private final static String ENTITY_KEY="_1I3P9ZAbkIqanLk6TfqtHmeppAc";
public _1I3P9ZAbkIqanLk6TfqtHmeppAc (){} 
@Override
public void exec(JMainConsole console, String locator$, JEditorPane reportPanel) {
System.out.println(ENTITY_KEY+":"+locator$);
reportPanel.setText(locator$);
	}
}
