package gdt.gui.facet.module;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.Properties;

import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.ModuleMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;

public class JModuleServicesList extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_3WusUV8kxhoBn48ONj5ntFxhN_Q";
	public JModuleServicesList(JMainConsole console, String locator$) {
		super(console, locator$);
//		 System.out.println("ModuleServicesList:locator="+locator$);
		JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);	
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.facet.module.JModuleServicesList");
	    locator.put(Locator.LOCATOR_TITLE,"Module services");
		locator.put(INSTANCE, KEY);
		locator.put(IconLoader.ICON_FILE,"module.png");
	 	 locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(PARENT, JEntityFacetList.KEY);
		locator.put(DEFAULT_PARENT, JEntityFacetList.KEY);
		 return Locator.toString(locator);
	} 
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Select all");
		menu=removeItem(menu,"Unselect all");
		menu=removeItem(menu,"Delete");
		return menu;
		}
	private JItemPanel getRebuildItem(JMainConsole console, String alocator$) {
		Properties locator=new Properties();
		locator.put(Locator.LOCATOR_TITLE,"Rebuld");
		locator.put(IconLoader.ICON_FILE,"rebuild.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		String itemLocator$=Locator.toString(locator);
		String entity$=Locator.getProperty(alocator$,Entigrator.ENTITY_LABEL);
		itemLocator$=Locator.append(itemLocator$, Entigrator.ENTITY_LABEL, entity$);
		return new JRebuildItem(console,itemLocator$);
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		JItemPanel[] ipa=new JItemPanel[1];
		ipa[0]=getRebuildItem(console,locator$);
		return sortItems(ipa);
	}
	private class JRebuildItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JRebuildItem(JMainConsole console, String locator$) {
			super(console, locator$);
		}
		@Override
		public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
		}
		@Override
		public void onClick(JMainConsole console, String locator$){
		  String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL );
//		  System.out.println("ModuleServicesList:rebuildModule:entity="+entity$);
		  String moduleKey$=console.getEntigrator().getKey(entity$);
		  ModuleMaster.rebuildModule(console, moduleKey$);
		}
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean handleDone() {
		JContext.displayInstance(console, parent$);
		return true;
	}
}

