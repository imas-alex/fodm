package gdt.gui.facet.perspective;

import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JPopupMenu;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;

public class JPerspectiveList extends JItemsListPanel {
	public JPerspectiveList(JMainConsole console) {
		super(console);
		JItemPanel[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa) {
				addItem(ip);
			}
	}
	public JPerspectiveList(JMainConsole console,String locator$) {
		super(console,locator$);
		JItemPanel[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa) {
				addItem(ip);
			}
	}
	private static final long serialVersionUID = 1L;
	public static final String KEY="_eJKFKY86XDcpBdGxTq4_ZE9bZiU";
	
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.facet.perspective.JDisplayList");
	    locator.put(Locator.LOCATOR_TITLE,"DisplayList");
		//locator.put(INSTANCE, KEY);
		locator.put(IconLoader.ICON_FILE,"perspective.png");
	 	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(DEFAULT_PARENT, JAdminPanel.KEY);
		 return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}

	@Override
	public String reply(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean handleDone() {
		JDisplay display=getDisplay();
		if(display!=null) {
			display.dispose();
			return true;
		}
		String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
		if(parentLocator$==null) {
			System.out.println("JPerspectiveList:handleDone:parent is null:locator="+locator$);
			String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			String facetList$=JEntityFacetList.classLocator();
			facetList$=Locator.append(facetList$, Entigrator.ENTITY_LABEL, entity$);
			JEntityFacetList facetList=new JEntityFacetList(console,facetList$);
		    replace(console, facetList);
		    return true;
		}
		//JContext.displayInstance(console, parent$);
		JContext.displayInstance(console, parent$,getDisplay());
		return true;
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		JDisplay[] displays=console.getDisplays();
		if(displays==null||displays.length<1)
			return null;
		System.out.println("JPerspectiveList:getItems:displays="+displays.length);
		JItemPanel ip;
		Properties props=new Properties();
		props.put(JItemPanel.ITEM_CHECKABLE,Locator.LOCATOR_TRUE);
		props.put(JItemPanel.ITEM_CHECKED,Locator.LOCATOR_FALSE);
		String itemLocator$=Locator.toString(props);
		JContext context;
		String context$;
		ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
		String title$;
		String entity$;
		for(JDisplay display:displays) {
			context=display.getContext();
			if(context==null) {
				System.out.println("JPerspectiveList:getItems:no context");
				continue;
			}
			
			String contextLocator$=context.getLocator();
			System.out.println("JPerspectiveList:getItems:context locator="+contextLocator$);
			context$=Locator.getProperty(contextLocator$, Locator.LOCATOR_TITLE);
			entity$=Locator.getProperty(contextLocator$, Entigrator.ENTITY_LABEL);
			title$=context$+"("+entity$+")";
					System.out.println("JPerspectiveList:getItems:title="+title$);
			itemLocator$=Locator.append(itemLocator$, Locator.LOCATOR_TITLE, title$);
			ip=new JDisplayItem(console,itemLocator$);	
			ipl.add(ip);
		}
		JItemPanel[] ipa=new JItemPanel[ipl.size()];
		ipl.toArray(ipa);
		return sortItems(ipa);
	}
	private   class JDisplayItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JDisplayItem(JMainConsole console, String locator$) {
			super(console, locator$);
		}
		@Override
		public JPopupMenu getPopup(JMainConsole console, String locator$) {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public void onClick(JMainConsole console, String locator$) {
			// TODO Auto-generated method stub
			
		}}
}
