package gdt.gui.facet;

import java.util.Properties;
import javax.swing.JPopupMenu;
import gdt.base.facet.ModuleHandler;
import gdt.base.facet.PerspectiveHandler;
import gdt.base.facet.ProjectHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;

import gdt.gui.console.JMainConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JItemPanel;
import gdt.gui.facet.perspective.JPerspectiveList;

public class PerspectiveMaster extends  FacetMaster{
	public static final String KEY="_XM_bihnEJWzNpcPrkPyt_HwF5ZY";
	public static final String NAME="Perspective";
	public static final String FACET_HANDLER_KEY="_47co139EsVtLoZMSwjsCJ0AcumQ";	
	String entity$;
	
	public PerspectiveMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
		entity$=Locator.getProperty(alocator$,Entigrator.ENTITY_LABEL);
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	     locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
	     locator.put(MASTER_CLASS,"gdt.gui.facet.PerspectiveMaster");
	     locator.put(FacetHandler.FACET_HANDLER_CLASS,PerspectiveHandler.PERSPECTIVE_FACET_CLASS);
	     locator.put(Locator.LOCATOR_TITLE,"Perspective");
	     locator.put(MASTER_KEY,KEY);
	     locator.put(JContext.PARENT,ALL_FACETS_KEY);
	     locator.put( IconLoader.ICON_FILE, "perspective.png");
	     locator.put( IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	     locator.put(FacetHandler.FACET_TYPE,PerspectiveHandler.PERSPECTIVE_FACET_TYPE);
	     return Locator.toString(locator);
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "perspective.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Perspectives");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		String entityLabel$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		  if(entityLabel$!=null)
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL,entityLabel$);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,itemLocator$);
		return itemPanel;
	}

	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "perspective.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Perspective");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL,Locator.getProperty(locator$,Entigrator.ENTITY_LABEL));
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,itemLocator$);
		return itemPanel;
	}

	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String perspectiveHandler$=ProjectHandler.classLocator();
			perspectiveHandler$=Locator.append(perspectiveHandler$, Entigrator.ENTITY_LABEL, entity$);
	
			PerspectiveHandler perspectiveHandler =new PerspectiveHandler(console.getEntigrator(),perspectiveHandler$);
			return perspectiveHandler;
		}catch(Exception e) {
			System.out.println("PerspectiveMaster:getFacetHandler:"+e.toString());
		}
		return null;
	}

	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public String getName() {
		return "Perspective";
	}

	@Override
	public String getType() {
		return "perspective";
	}

	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
	/*
		String perspectiveList$= JPerspectiveList.classLocator();
		String parent$=console.saveContext();
		String entity$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
		perspectiveList$=Locator.append(perspectiveList$,Entigrator.ENTITY_LABEL, entity$);
		perspectiveList$=Locator.append(perspectiveList$,JContext.PARENT, parent$);
//		System.out.println("ModuleMaster:entityFacetsItemOnClick:parent="+parent$);
		JPerspectiveList perspectiveList=new JPerspectiveList(console,perspectiveList$);
		 console.replaceContext(peString entity$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);rspectiveList);
		 */
		try {
		String entity$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
		Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		Core[] ca=entity.elementGet("perspective");
		if(ca!=null)
			for(Core c:ca) {
				System.out.println("PerspectiveMaster:entityFacetsItemOnClick:display="+c.value);
				JDisplay.putToScreen(console, c.value);
			}
		}catch(Exception e) {
			System.out.println("PerspectiveMaster:entityFacetsItemOnClick:"+e.toString());
			
		}
		
	}

	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLocator() {
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String thisLocator$=classLocator();
		if(entity$!=null)
		   thisLocator$=Locator.append(thisLocator$,Entigrator.ENTITY_LABEL, entity$);
		return thisLocator$;
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		 Sack session=getSession(console,locator$);
	     Core masterEntry=new Core(ModuleHandler.SYSTEM,KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core(ModuleHandler.SYSTEM,PerspectiveHandler.KEY,PerspectiveHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("PerspectiveMaster:addToSession:"+e.toString());
	    }
	}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}

	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity.putElementItem("facet", new Core(ModuleHandler.SYSTEM,getType(),classLocator()));
		entity.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","perspective.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		return entity;
	}

}
