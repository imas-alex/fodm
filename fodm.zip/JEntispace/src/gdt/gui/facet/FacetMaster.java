package gdt.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 * last modified 25.02.2023 06:31
 */

import java.lang.reflect.Constructor;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;
import java.util.logging.Logger;
import javax.swing.JPopupMenu;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Sack;
import gdt.gui.console.JAddFacetsList;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JAllFacetsList;
import gdt.gui.console.JDesignPanel;
import gdt.gui.console.JHistoryPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JListEntities;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JItemPanel;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;

public abstract class FacetMaster {
	public static final String ALL_FACETS_KEY=JAllFacetsList.KEY;
	public static final String HANDLER_KEY="handler key";
	public static final String MASTER_KEY="master key";
	public static final String MASTER_ELEMENT="facet.master";
	public static final String ICON_ELEMENT="icon";
	public static final String MASTER_CLASS="master class";
	public JMainConsole console;
	protected String locator$;
	public String display$;
	public  FacetMaster() {}
	public  FacetMaster(JMainConsole console,String alocator$) {
    	 this.console=console;
    	 this.locator$=alocator$;
	}
     public  abstract JItemPanel getJAllFacetsItem(JMainConsole console,String handlerLocator$);
     public  abstract JItemPanel getJAddFacetsItem(JMainConsole console,String handlerLocator$);
     public  abstract JItemPanel getJEntityFacetsItem(JMainConsole console,String handlerLocator$);
     public  abstract void removeFacet(JMainConsole console,String handlerLocator$);
     public abstract FacetHandler  getFacetHandler(JMainConsole console,String locator$);
     
     public JItemPanel getJFacetAddItem() {
    	 JItemPanel item=new JEntityAddFacetItem( console, locator$) ;
    	 return item; 
     }
public abstract String getKey();    
public abstract String getName();  
public abstract String getType();  
public  void  allFacetsItemOnClick(JMainConsole console,String locator$) {
	//System.out.println("FacetMaster:allFacetsItemOnClick:display="+display$);
	locator$=getLocator();
	if(display$!=null)
	   locator$=Locator.append(locator$, JContext.DISPLAY,display$);
	listFacetMembers(console,locator$);	
}

public abstract void  entityFacetsItemOnClick(JMainConsole console,String locator$);
public abstract void  addFacetItemOnClick(JMainConsole console,String locator$);

public abstract JPopupMenu  allFacetsItemPopup(JMainConsole console,String locator$);
public abstract JPopupMenu  entityFacetsItemPopup(JMainConsole console,String locator$);
public abstract JPopupMenu  addFacetItemPopup(JMainConsole console,String locator$);
public abstract  String getLocator();
public abstract  void addToSession(JMainConsole console, String locator$);
public class  JAllFacetsItem extends JItemPanel{
	private static final long serialVersionUID = 1L;
	public JAllFacetsItem(JMainConsole console, String locator$) {
		super(console, locator$);
	}
	
	@Override
	public JPopupMenu getPopup(JMainConsole console, String locator$) {
		return  allFacetsItemPopup(console,locator$);
	}
	@Override
	public void onClick(JMainConsole console, String locator$) {
		allFacetsItemOnClick(console, locator$);
	}
  }
public class  JEntityFacetsItem extends JItemPanel {
	private static final long serialVersionUID = 1L;
	public JEntityFacetsItem(JMainConsole console, String locator$) {
		super(console, locator$);
	}
	@Override
	public JPopupMenu getPopup(JMainConsole console, String locator$) {
		return entityFacetsItemPopup( console, locator$);
	}
	@Override
	public void onClick(JMainConsole console, String locator$) {
		entityFacetsItemOnClick(console,locator$);
	}
}
public class  JEntityAddFacetItem extends JItemPanel{
	private static final long serialVersionUID = 1L;
	public JEntityAddFacetItem(JMainConsole console, String locator$) {
		super(console, locator$);
	}
	@Override
	public JPopupMenu getPopup(JMainConsole console, String locator$) {
		return addFacetItemPopup(console, locator$);
	}
	@Override
	public void onClick(JMainConsole console, String locator$) {
		addFacetItemOnClick( console,locator$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String addFacets$=JAddFacetsList.classLocator();
		addFacets$=Locator.append(addFacets$, Entigrator.ENTITY_LABEL, entity$);
		JAddFacetsList addFacetsList=new  JAddFacetsList(console,addFacets$);
		console.refreshContext(addFacetsList);
	}
  }
public static FacetMaster build(JMainConsole console,String locator$) {
	try {
   	//System.out.println("FacetMaster:build:START:locator="+locator$);
	String className$=Locator.getProperty(locator$, MASTER_CLASS);
	String display$=Locator.getProperty(locator$,JContext.DISPLAY);
    //System.out.println("FacetMaster:build:display="+display$+"  class="+className$);
    //if(display$==null)
    //	System.out.println("FacetMaster:build:class="+Locator.getProperty(locator$,MASTER_CLASS));
	if(className$==null) {
		System.out.println("FacetMaster:build:master class is null. Locator="+locator$);
		return null;
	}
	//System.out.println("FacetMaster:build:class name="+className$+"   locator="+locator$);
	Class<?> cls=console.getEntigrator().getClass(className$);
	if(cls==null) {
	System.out.println("FacetMaster:build:cannot load class="+className$);
	return null;
	}
	Object  obj=null; 
	try {	
	Constructor<?> cns=cls.getConstructor(console.getClass(),cls.getName().getClass());
		if(cns==null) {
			System.out.println("FacetMaster:build:2:cannot get default constructor class="+className$);
			return null;
		}
		cns.setAccessible(true);
		 obj= cns.newInstance(console,locator$);
 	    }catch(Exception ee) {
 	    	System.out.println("FacetMaster:build:3:"+ee.toString()+"  locator="+locator$);
 	    	return null;
 	    }
 	   ((FacetMaster)obj).display$=display$;
 	   
 	    return (FacetMaster)obj;
	}catch(Exception e) {
		//
		URL[] urla=console.getEntigrator().listURLs();
		if(urla!=null)
			for(URL url:urla) {
				System.out.println("FacetMaster:build:url="+url.getPath());
			}
	//	System.out.println("FacetMaster:build:0:"+e.toString());
	}
	return null;
}
public static void setDefaultFacets(JMainConsole console) {
	BlankMaster.putToSession(console,null);
	FolderMaster.putToSession(console,null);
	ModuleMaster.putToSession(console, null);
	ProcedureMaster.putToSession(console, null);
	ProjectMaster.putToSession(console, null);
	BaseMaster.putToSession(console, null);
	PerspectiveMaster.putToSession(console, null);
}
public static void setDefaultContexts(JMainConsole console) {
	String locator$=JAdminPanel.classLocator();
	SessionHandler.putLocator(console.getEntigrator(), locator$);
	locator$=JAllFacetsList.classLocator();
	SessionHandler.putLocator(console.getEntigrator(), locator$);
	locator$=JDesignPanel.classLocator();
	SessionHandler.putLocator(console.getEntigrator(), locator$);
	locator$=JHistoryPanel.classLocator();
	SessionHandler.putLocator(console.getEntigrator(), locator$);
}
public static void listFacetMembers(JMainConsole console,String locator$) {
	try {
		System.out.println("FacetMaster:listFacetMembers:locator="+locator$);
		String facetMaster$=Locator.getProperty(locator$, FacetMaster.MASTER_CLASS);
		FacetMaster fm=FacetMaster.build(console, locator$);
		String facetType$=fm.getType();
		Entigrator entigrator=console.getEntigrator();
		String[] sa=entigrator.listEntities(facetType$,Locator.LOCATOR_TRUE);
		String listEntities$=JListEntities.classLocator();
		listEntities$=Locator.append(listEntities$,JContext.PARENT, JAllFacetsList.KEY);
		listEntities$=Locator.append(listEntities$,JContext.DEFAULT_PARENT, JAllFacetsList.KEY);
		listEntities$=Locator.append(listEntities$,MASTER_CLASS, facetMaster$);
		//System.out.println("FacetMaster:listFacetMembers:listEntities="+listEntities$);
	if(sa!=null&&sa.length>0) {	
		ArrayList<String>sl=new ArrayList<String>();
		String entityLabel$;
		for(int i=0;i<sa.length;i++) {
			entityLabel$=entigrator.getLabel(sa[i]);
			if(entityLabel$==null) {
				System.out.println("FacetMaster:listMembers:cannot find label at key="+sa[i]);
				continue;
			}else
				sl.add(entityLabel$);
		
		}
		if(sl.size()<1) {
			System.out.println("FacetMaster:listMembers:no entities at type="+facetType$);
			return;
		}
        Collections.sort(sl);		
        sa=new String[sl.size()];
        sl.toArray(sa);
		String ea$=Locator.toString(sa);
	//	System.out.println("FacetMaster:listMembers:facet type="+facetType$);
	    listEntities$=Locator.append(listEntities$,JDesignPanel.ENTITIES, ea$);
		}
	//System.out.println("FacetMaster:listFacetMembers::listEntities="+listEntities$);
	    JListEntities listEntities=new JListEntities(console,listEntities$);
	   
	    JDisplay display=null;
	    String display$=Locator.getProperty(locator$, JContext.DISPLAY);
	   // System.out.println("FacetMaster:listFacetMembers:display="+display$);
	    if(display$!=null)
	    	display=console.getDisplay(display$);
	    if(display==null) {
	      console.replaceContext(listEntities);
	      System.out.println("FacetMaster:listFacetMembers:cannot get display="+display$);
	    }
	    else
	       display.putContext(listEntities);	
	}catch(Exception e) {
		System.out.println("FacetMaster:listFacetMembers:"+e.toString());
	}
}

public static void setModuleFacets(JMainConsole console) {
	//System.out.println("FacetMaster:setModuleFacets:BEGIN");
	try {
	 Entigrator entigrator=console.getEntigrator();
	 String[] sa=entigrator.listEntities(Entigrator.ENTITY, "module");
	 //System.out.println("FacetMaster:setModuleFacets:sa"+sa.length);
	 if(sa==null||sa.length<1)
		 return;
	 Sack module;
	 Core[] ha;
	 FacetMaster fm;
	 for(String s:sa) {
	  module=entigrator.getEntity(s);
	  if(module!=null) {
		ha=module.elementGet("handler");
		if(ha!=null)
			for(Core h:ha) {
				try {
					System.out.println("FacetMaster:setModuleFacets:facet="+h.type+"  locator="+h.value);	
				    fm=FacetMaster.build(console, h.value);
				if(fm!=null) {
					System.out.println("FacetMaster:setModuleFacets:facet master="+fm.getName());
					fm.addToSession(console, null);
				}else {
					System.out.println("FacetMaster:setModuleFacets:cannot get facet master:module="+module.getProperty("label")+"  facet="+h.type+"  locator="+h.value);
				}
				}catch(Exception  ee) {System.out.println("FacetMaster:setModuleFacets:"+ee.toString());}
			}
	  }
	 }
//	 System.out.println("FacetMaster:setModuleFacets:FINISH");		 
	}catch(Exception e) {
		System.out.println("FacetMaster:setModuleFacets:"+e.toString());
	}
}	
private static Sack addFacet(Sack session,String facetMaster$) {
	//System.out.println("FacetMaster:addFacet:facetMaster="+facetMaster$);
	if(!session.existsElement(MASTER_ELEMENT))
		session.createElement(MASTER_ELEMENT);
	String key$=Locator.getProperty(facetMaster$,JContext.INSTANCE);
	//System.out.println("FacetMaster:addFacet:key="+key$);
	session.putElementItem(MASTER_ELEMENT, new Core(ModuleHandler.SYSTEM,key$,facetMaster$));
	if(!session.existsElement(ICON_ELEMENT))
		session.createElement(ICON_ELEMENT);
	String iconModule$=Locator.getProperty(facetMaster$, ModuleHandler.FACET_MODULE);
	String iconContainer$=Locator.getProperty(facetMaster$, IconLoader.ICON_CONTAINER);
	String iconFile$=Locator.getProperty(facetMaster$, IconLoader.ICON_FILE);
	String entityType$=Locator.getProperty(facetMaster$, FacetHandler.FACET_TYPE);
	Properties iconLocator= new Properties ();
	iconLocator.put(ModuleHandler.FACET_MODULE, iconModule$);
	iconLocator.put(IconLoader.ICON_CONTAINER,iconContainer$);
	iconLocator.put(IconLoader.ICON_FILE,iconFile$);
	String iconLocator$=Locator.toString(iconLocator);
	Core core =new Core(iconModule$,entityType$,iconLocator$);
	//System.out.println("FacetMaster:addFacet:core type="+core.type+"  name="+core.name+" value="+core.value);
	session.putElementItem(ICON_ELEMENT,core);
	//System.out.println("FacetMaster:addFacet:end");
return session;
}
public abstract Sack createEntity(Entigrator entigrator,String entitylabel$);

public static  Sack  getSession(JMainConsole console,String locator$) {
	//System.out.println("FacetMaster:getSession");
	Sack session=SessionHandler.getSession(console.getEntigrator());
	if(!session.existsElement(MASTER_ELEMENT))
		session.createElement(MASTER_ELEMENT);
	if(!session.existsElement(FacetHandler.HANDLER_ELEMENT))
		session.createElement(FacetHandler.HANDLER_ELEMENT);
	return session;
}

public static void loadModule(JMainConsole console,String moduleKey$) {
	try{
		Sack module=console.getEntigrator().getEntity(moduleKey$);
//		System.out.println("FacetMaster:loadModule:module="+module.getProperty("label"));
		if(console.getEntigrator().getEntihome()==null) {
			System.out.println("FacetMaster:loadModule:entihome is null");
			return;
		}
		String jar$="jar:file:" +console.getEntigrator().getEntihome()+"/"+moduleKey$+"/lib/"+moduleKey$+".jar!/";
		//System.out.println("FacetMaster:loadModule:jar="+console.getEntigrator().getEntihome());
		ArrayList <URL> urll=new ArrayList<URL>();
		urll.add(new URL(jar$));
		URL[] urls=urll.toArray(new URL[0]);
		URLClassLoader moduleClassLoader=new URLClassLoader(urls);
		//handlers
		Core[] ca=module.elementGet("module.master");
//		System.out.println("FacetMaster:loadModule:ca="+ca.length);
		FacetMaster facetMaster=null;
		Class<?> cls;
		Constructor<?>cns;
		String masterClass$=null;
		if(ca!=null)
			for(Core c:ca) {
			   masterClass$=Locator.getProperty(c.value, MASTER_CLASS);
			   cls = moduleClassLoader.loadClass(masterClass$);
			   cns=cls.getDeclaredConstructor(JMainConsole.class,String.class);
			   facetMaster=(FacetMaster)cns.newInstance(console,c.value);
//			   System.out.println("FacetMaster:loadModule: facet master="+facetMaster.getName());
			}
		moduleClassLoader.close();	
	}catch(Exception e){
		Logger.getLogger(FacetMaster.class.getName()).severe(e.toString());
	}
}
public static Core handlerToMacter(JMainConsole console,String locator$) {
	try {
		String masterClass$=Locator.getProperty(locator$,"master class");
		if(masterClass$==null) {
		String handlerClass$=Locator.getProperty(locator$,"facet class");
		if(handlerClass$==null)
			return null;
		 masterClass$=handlerClass$.replace("base", "gui");
		masterClass$=masterClass$.replace("Handler", "Master");
		}
		String module$=Locator.getProperty(locator$,"module");
		Properties masterLocator=new Properties();
		masterLocator.put(MASTER_CLASS,masterClass$);
		if(module$!=null)
			masterLocator.put("module",module$);
		else
			masterLocator.put("module","system");
		String masterLocator$=Locator.toString(masterLocator);
		FacetMaster fm=FacetMaster.build(console, masterLocator$);
		if(fm!=null) {
		//	System.out.println("FacetMaster:handlerToMacter:master="+fm.getName());
			Core entry= new Core(fm.getName(),fm.getKey(),fm.getLocator());
		//	System.out.println("FacetMaster:handlerToMacter:entry type="+entry.type+" name="+entry.name+"  value="+entry.value);
		    return entry;
		}
	}catch(Exception e) {
		System.out.println("FacetMaster:handlerToMacter:"+e.toString()+"  locator="+locator$);	
	}
	return null;
}
}
