package gdt.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Properties;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JAddFacetsList;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;

public class FolderMaster extends FacetMaster{
public static final String KEY="_zBcC5wq6JxzX2cdexv_kn60T92M";
public static final String NAME="Folder";
public static final String FACET_HANDLER_KEY="_EPLKJlQuhun7QAL0_JMK_SUyRYDQ";

	public FolderMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
		}
	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		try{
		//	System.out.println("FolderMaster:entityFacetsItemOnClick:locator="+locator$);
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			Entigrator entigrator=console.getEntigrator();
			String entityKey$=entigrator.getKey(entityLabel$);
			File folder=new File(entigrator.getEntihome()+"/"+entityKey$);
			Desktop.getDesktop().open(folder);
			}catch(Exception ee){
				System.out.println("FolderMaster:entityFacetsItemOnClick:"+ee.toString());
			}
		
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String alocator$) {
		//System.out.println("FolderMaster:addFacetItemOnClick:locator="+alocator$);
		String entityLabel$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
		Sack entity=console.getEntigrator().getEntityAtLabel(entityLabel$);
		entity=FolderHandler.add(console.getEntigrator(), entity);
		console.getEntigrator().putEntity(entity);
		String addFacetsList$=JAddFacetsList.classLocator();
		JAddFacetsList addFacetsList=new JAddFacetsList(console,addFacetsList$); 
		console.replaceContext(addFacetsList);
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		final String itemLocator$=alocator$;
		JPopupMenu popup=new JPopupMenu();
		JMenuItem newItem=new JMenuItem("New entity");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("FolderMaster:entityFacetsItemPopup:new entity:locator="+itemLocator$);
				popup.setVisible(false);
				String textEditor$=JTextEditor.classLocator();
				textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New label");
				String facetList$=JEntityFacetList.classLocator();
				facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
				facetList$=Locator.append(facetList$,MASTER_CLASS,"gdt.gui.facet.FolderMaster");
				facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
				textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
				JTextEditor textEditor=new JTextEditor(console,textEditor$);
				console.replaceContext(textEditor);
			}
		} );
		popup.add(newItem);
		return popup;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String alocator$) {
		//System.out.println("FolderMaster:entityFacetsItemPopup:locator="+locator$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		alocator$=Locator.append(alocator$, Entigrator.ENTITY_LABEL, entity$);
		final String removeLocator$=alocator$;
		JPopupMenu popup=new JPopupMenu();
		JMenuItem removeItem=new JMenuItem("Remove from entity");
		removeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("FolderMaster:entityFacetsItemPopup:remove:locator="+removeLocator$);
				popup.setVisible(false);
				removeFacet(console,removeLocator$);
				JEntityFacetList facetList=new JEntityFacetList(console,locator$);
				console.replaceContext(facetList);
			}
		} );
		popup.add(removeItem);
		return popup;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
	//	System.out.println("FolderMaster:getJAllFacetsItem:locator="+handlerLocator$);
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "folder.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Folders");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,MASTER_CLASS,"gdt.gui.facet.FolderMaster" );
	//	System.out.println("FolderMaster:getJAllFacetsItem:item locator="+itemLocator$);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
	//	System.out.println("FolderMaster:getJAllFacetsItem:locator="+handlerLocator$);
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "folder.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Folder");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,itemLocator$);
		return itemPanel;
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	     locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
	     locator.put(MASTER_CLASS,"gdt.gui.facet.FolderMaster");
	     locator.put(FacetHandler.FACET_HANDLER_CLASS,FolderHandler.FOLDER_FACET_CLASS);
	     locator.put(MASTER_KEY,KEY);
	     locator.put(Locator.LOCATOR_TITLE,"Folder");
	     locator.put(JContext.INSTANCE,KEY);
	     locator.put(JContext.PARENT,ALL_FACETS_KEY);
	     locator.put( IconLoader.ICON_FILE, "folder.png");
	     locator.put( IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	     locator.put(FacetHandler.FACET_TYPE,"folder");
	     return Locator.toString(locator);
	}
	@Override
	public void removeFacet(JMainConsole console, String locator$) {
		//System.out.println("FolderMaster:remove facet:locator="+locator$);
		try {
			String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			Sack entity=console.getEntigrator().getEntityAtLabel(entityLabel$);
			entity=FolderHandler.delete(console.getEntigrator(), entity);
			console.getEntigrator().putEntity(entity);
			}catch(Exception e) {
				System.out.println("FolderMaster:removeFacet:"+e.toString());
			}
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String folderHandler$=FolderHandler.classLocator();
			folderHandler$=Locator.append(folderHandler$, Entigrator.ENTITY_LABEL, entity$);
			//System.out.println("FolderMaster:getFacetHandler:locator="+folderHandler$);
			FolderHandler folderHandler =new FolderHandler(console.getEntigrator(),folderHandler$);
			return folderHandler;
		}catch(Exception e) {
			System.out.println("FolderMaster:getFacetHandler:"+e.toString());
		}
		return null;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String locator$) {
		//System.out.println("FolderMaster:getJAddFacetsItem:locator="+locator$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "folder");
		itemLocator$=Locator.append(itemLocator$,IconLoader.ICON_FILE,"folder.png");
		JEntityAddFacetItem itemPanel=new JEntityAddFacetItem(console,itemLocator$);
			return itemPanel;
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core(ModuleHandler.SYSTEM,KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core(ModuleHandler.SYSTEM,FolderHandler.KEY,FolderHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("FolderMaster:addToSession:"+e.toString());
	    }
	}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
	public String getName() {
		return NAME;
	}		
	@Override
	public String getLocator() {
		return classLocator();
	}
	@Override
	public String getType() {
		return "folder";
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(console.getEntigrator(), entity);
		entity.createElement("facet");
		entity.putElementItem("facet", new Core(ModuleHandler.SYSTEM,getType(),classLocator()));
		entity.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","folder.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		return entity;
	}	
}
