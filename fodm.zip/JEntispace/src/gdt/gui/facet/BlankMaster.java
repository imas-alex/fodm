package gdt.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import gdt.base.facet.BlankHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;

public class BlankMaster extends FacetMaster{
	public static final String KEY="_cBJb_DvRuDjLK0EB3K_vZrKQe1g";
	public static final String NAME="Blank";
	public static final String FACET_HANDLER_KEY="_umTtTS25W6Xq_SW3GizYuhmnhtiw";
	public BlankMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "box.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Blanks");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String handlerLocator$) {
			return null;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
		return null;
	}
	@Override
	public void removeFacet(JMainConsole console, String handlerLocator$) {
	}
	@Override
	public BlankHandler getFacetHandler(JMainConsole console, String locator$) {
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String blankHandler$=BlankHandler.classLocator();
			blankHandler$=Locator.append(blankHandler$, Entigrator.ENTITY_LABEL, entity$);
			//System.out.println("FolderMaster:getFacetHandler:locator="+folderHandler$);
			BlankHandler blankHandler =new BlankHandler(console.getEntigrator(),blankHandler$);
			return blankHandler;
		}catch(Exception e) {
			System.out.println("BlankMaster:getFacetHandler:"+e.toString());
		}
		return null;
	}
	@Override
	public void allFacetsItemOnClick(JMainConsole console, String locator$) {
		listFacetMembers(console,classLocator());
	}
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String locator$) {

	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String locator$) {
		
	}

	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		JPopupMenu popup=new JPopupMenu();
		JMenuItem newItem=new JMenuItem("New entity");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			//	System.out.println("BlankMaster:entityFacetsItemPopup:new entity:locator="+itemLocator$);
				popup.setVisible(false);
				String textEditor$=JTextEditor.classLocator();
				textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New blank");
				String facetList$=JEntityFacetList.classLocator();
				facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
				facetList$=Locator.append(facetList$,MASTER_CLASS,"gdt.gui.facet.BlankMaster");
				facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
				textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
				JTextEditor textEditor=new JTextEditor(console,textEditor$);
				console.replaceContext(textEditor);
			}
		} );
		popup.add(newItem);
		return popup;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	     locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
	     locator.put(MASTER_CLASS,"gdt.gui.facet.BlankMaster");
	     locator.put(FacetHandler.FACET_HANDLER_CLASS,BlankHandler.BLANK_FACET_CLASS);
	     locator.put(Locator.LOCATOR_TITLE,"Blank");
	     locator.put(JContext.INSTANCE,KEY);
	     locator.put(JContext.PARENT,ALL_FACETS_KEY);
	     locator.put( IconLoader.ICON_FILE, "box.png");
	     locator.put( IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	     locator.put(FacetHandler.FACET_TYPE,BlankHandler.BLANK_FACET_TYPE);
	     return Locator.toString(locator);
	}
	public  static void putToSession(JMainConsole console, String locator$) {
		  try { 
				Sack session=getSession(console,locator$);
			     Core masterEntry=new Core(ModuleHandler.SYSTEM,KEY,classLocator()); 
			     session.putElementItem(MASTER_ELEMENT, masterEntry);
			     Core handlerEntry=new Core(ModuleHandler.SYSTEM,BlankHandler.KEY,BlankHandler.classLocator());
			     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
			     console.getEntigrator().putEntity(session);
			    }catch(Exception e) {
			    	System.out.println("BlankMaster:putToSession:"+e.toString());
			    }
	}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
	  putToSession( console, locator$);
	}
	@Override
	public String getName() {
		return NAME;
	}
	@Override
	public String getLocator() {
		return classLocator();
	}
	@Override
	public String getType() {
		return "blank";
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity.createElement("facet");
		entity.putElementItem("facet", new Core(ModuleHandler.SYSTEM,getType(),classLocator()));
		entity.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","box.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		return entity;
	}	
}
