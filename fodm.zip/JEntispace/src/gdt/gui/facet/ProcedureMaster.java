package gdt.gui.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.facet.ProcedureHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JAddFacetsList;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;

import gdt.gui.facet.procedure.JProcedureConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JTextEditor;

public class ProcedureMaster extends FacetMaster{
public static final String KEY="_TnmndN9la7ABVfiVoGLacqlwkyk";
public static final String NAME="Procedure";
public static final String FACET_HANDLER_KEY="_HSnkzcw2CkCMTClofdTMPri17zQ";	
	public ProcedureMaster(JMainConsole console, String alocator$) {
		super(console, alocator$);
	}
	@Override
	public String getKey() {
		return KEY;
	}
	@Override
	public String getName() {
		return NAME;
	}
	@Override
	public void allFacetsItemOnClick(JMainConsole console, String locator$) {
		listFacetMembers(console,classLocator());
	}
	@Override
	public void entityFacetsItemOnClick(JMainConsole console, String alocator$) {
		String procedureConsole$=JProcedureConsole.classLocator();
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		procedureConsole$=Locator.append(procedureConsole$,Entigrator.ENTITY_LABEL, entity$);
		Entigrator entigrator=console.getEntigrator();
		String entityKey$=entigrator.getKey(entity$);
		String path$=entigrator.getEntihome()+"/"+entityKey$;
		String parent$=console.saveContext();
		procedureConsole$=Locator.append(procedureConsole$,JContext.PARENT, parent$);
		JProcedureConsole procedureConsole=new JProcedureConsole(console,procedureConsole$);
		console.replaceContext(procedureConsole);
	}
	@Override
	public void addFacetItemOnClick(JMainConsole console, String alocator$) {
	//	System.out.println("ProcedurMaster:addFacetItemOnClick:locator="+alocator$);
		String entityLabel$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
		Sack entity=console.getEntigrator().getEntityAtLabel(entityLabel$);
		entity=ProcedureHandler.add(console.getEntigrator(), entity);
		String addFacetsList$=JAddFacetsList.classLocator();
		addFacetsList$=Locator.append(addFacetsList$,Entigrator.ENTITY_LABEL , entityLabel$);
		JAddFacetsList addFacetsList=new JAddFacetsList(console,addFacetsList$); 
		console.saveContext();
		console.replaceContext(addFacetsList);
	}
	@Override
	public JPopupMenu allFacetsItemPopup(JMainConsole console, String alocator$) {
		final String itemLocator$=alocator$;
		JPopupMenu popup=new JPopupMenu();
		JMenuItem newItem=new JMenuItem("New entity");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			//	System.out.println("ProcedureMaster:entityFacetsItemPopup:new entity:locator="+itemLocator$);
				popup.setVisible(false);
				String textEditor$=JTextEditor.classLocator();
				textEditor$=Locator.append(textEditor$, JTextEditor.IN_TEXT, "New label");
				String facetList$=JEntityFacetList.classLocator();
				facetList$=Locator.append(facetList$, JContext.REPLY, Locator.LOCATOR_TRUE);
				facetList$=Locator.append(facetList$,MASTER_CLASS,"gdt.gui.facet.ProcedureMaster");
				facetList$=Locator.append(facetList$,ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
				//SessionHandler.putLocator(console.getEntigrator(),facetList$);
				textEditor$=Locator.append(textEditor$, JContext.PARENT, JEntityFacetList.KEY);
				JTextEditor textEditor=new JTextEditor(console,textEditor$);
				console.saveContext();
				console.replaceContext(textEditor);
			}
		} );
		popup.add(newItem);
		return popup;
	}
	@Override
	public JPopupMenu entityFacetsItemPopup(JMainConsole console, String alocator$) {
		//System.out.println("FProcedureMaster:entityFacetsItemPopup:locator="+locator$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		alocator$=Locator.append(alocator$, Entigrator.ENTITY_LABEL, entity$);
		final String removeLocator$=alocator$;
		JPopupMenu popup=new JPopupMenu();
		JMenuItem removeItem=new JMenuItem("Remove from entity");
		removeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			//	System.out.println("ProcedureMaster:entityFacetsItemPopup:remove:locator="+removeLocator$);
				popup.setVisible(false);
				removeFacet(console,removeLocator$);
				JEntityFacetList facetList=new JEntityFacetList(console,locator$);
				console.saveContext();
				console.replaceContext(facetList);
			}
		} );
		popup.add(removeItem);
		return popup;
	}
	@Override
	public JPopupMenu addFacetItemPopup(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public JItemPanel getJAllFacetsItem(JMainConsole console, String handlerLocator$) {
	//	System.out.println("ProcedureMaster:getJAllFacetsItem:locator="+handlerLocator$);
		String itemLocator$=JItemPanel.classLocator();
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "procedure.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Procedures");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		JAllFacetsItem itemPanel=new JAllFacetsItem(console,itemLocator$);
		return itemPanel;
	}
	@Override
	public JItemPanel getJEntityFacetsItem(JMainConsole console, String handlerLocator$) {
	//	System.out.println("ProcedureMaster:getJAllFacetsItem:locator="+handlerLocator$);
		String entity$=Locator.getProperty(handlerLocator$, Entigrator.ENTITY_LABEL);
		String parent$=Locator.getProperty(handlerLocator$, JContext.PARENT);
		String itemLocator$=JItemPanel.classLocator();
		if(entity$!=null)
		  itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
			  itemLocator$=Locator.append(itemLocator$,JContext.PARENT, parent$);
		itemLocator$=Locator.append(itemLocator$, IconLoader.ICON_FILE, "procedure.png");
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "Procedure");
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,MASTER_CLASS,"gdt.gui.facet.ProcedureMaster");
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_HANDLER_CLASS,ProcedureHandler.PROCEDURE_FACET_CLASS);
		JEntityFacetsItem itemPanel=new JEntityFacetsItem(console,itemLocator$);
		return itemPanel;
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	     locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
	     locator.put(MASTER_CLASS,"gdt.gui.facet.ProcedureMaster");
	     locator.put(FacetHandler.FACET_HANDLER_CLASS,ProcedureHandler.PROCEDURE_FACET_CLASS);
	     locator.put(Locator.LOCATOR_TITLE,"Procedure");
	     locator.put(MASTER_KEY,KEY);
	     locator.put(JContext.PARENT,ALL_FACETS_KEY);
	     locator.put( IconLoader.ICON_FILE, "procedure.png");
	     locator.put( IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	     locator.put(FacetHandler.FACET_TYPE,ProcedureHandler.PROCEDURE_FACET_TYPE);
	     return Locator.toString(locator);
	}
	@Override
	public void removeFacet(JMainConsole console, String locator$) {
		//System.out.println("ProcedureMaster:remove facet:locator="+locator$);
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			entity=ProcedureHandler.delete(console.getEntigrator(), entity);
			console.getEntigrator().putEntity(entity);
			}catch(Exception e) {
				System.out.println("ProcedureMaster:removeFacet:"+e.toString());
			}
	}
	@Override
	public FacetHandler getFacetHandler(JMainConsole console, String locator$) {
		try {
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String procedureHandler$=ProcedureHandler.classLocator();
			procedureHandler$=Locator.append(procedureHandler$, Entigrator.ENTITY_LABEL, entity$);
			//System.out.println("ProcedureMaster:getFacetHandler:locator="+folderHandler$);
			ProcedureHandler procedureHandler =new ProcedureHandler(console.getEntigrator(),procedureHandler$);
			return procedureHandler;
		}catch(Exception e) {
			System.out.println("ProcedureMaster:getFacetHandler:"+e.toString());
		}
		return null;
	}

	@Override
	public JItemPanel getJAddFacetsItem(JMainConsole console, String locator$) {
		//System.out.println("ProcedureMaster:getJAddFacetsItem:locator="+locator$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String parent$=Locator.getProperty(locator$, JContext.PARENT);
		String itemLocator$=JItemPanel.classLocator();
		if(entity$!=null)
		  itemLocator$=Locator.append(itemLocator$,Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
			  itemLocator$=Locator.append(itemLocator$,JContext.PARENT, parent$);
		itemLocator$=Locator.append(itemLocator$,JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_FALSE);
		itemLocator$=Locator.append(itemLocator$,Locator.LOCATOR_TITLE, "procedure");
		itemLocator$=Locator.append(itemLocator$,IconLoader.ICON_FILE,"procedure.png");
		itemLocator$=Locator.append(itemLocator$,MASTER_CLASS,"gdt.gui.facet.ProcedureMaster");
		itemLocator$=Locator.append(itemLocator$,FacetHandler.FACET_HANDLER_CLASS,ProcedureHandler.PROCEDURE_FACET_CLASS);
		JEntityAddFacetItem itemPanel=new JEntityAddFacetItem(console,itemLocator$);
		return itemPanel;
	}
	public static void putToSession(JMainConsole console, String locator$) {
	    try { 
		Sack session=getSession(console,locator$);
	     Core masterEntry=new Core(ModuleHandler.SYSTEM,KEY,classLocator()); 
	     session.putElementItem(MASTER_ELEMENT, masterEntry);
	     Core handlerEntry=new Core(ModuleHandler.SYSTEM,ProcedureHandler.KEY,ProcedureHandler.classLocator());
	     session.putElementItem(FacetHandler.HANDLER_ELEMENT, handlerEntry);
	     console.getEntigrator().putEntity(session);
	    }catch(Exception e) {
	    	System.out.println("ProcedureMaster:addToSession:"+e.toString());
	    }
	}
	@Override
	public  void addToSession(JMainConsole console, String locator$) {
		putToSession( console, locator$); 
	}
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String getLocator() {
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		String parent$=Locator.getProperty(locator$,JContext.PARENT);
		String thisLocator$=getClassLocator();
		if(entity$!=null)
		   thisLocator$=Locator.append(thisLocator$,Entigrator.ENTITY_LABEL, entity$);
		if(parent$!=null)
			   thisLocator$=Locator.append(thisLocator$,JContext.PARENT, parent$);
		return thisLocator$;
	}
	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return "procedure";
	}
	@Override
	public Sack createEntity(Entigrator entigrator, String entityLabel$) {
		String entityKey$=entigrator.getKey(entityLabel$);
		if(entityKey$!=null)
				entityLabel$=entityLabel$+Identity.key().substring(0,4);
		Sack entity=entigrator.createEntity(entityLabel$, getType());
		entity=FolderHandler.add(entigrator, entity);
		entity.putElementItem("facet", new Core(ModuleHandler.SYSTEM,getType(),classLocator()));
		entity.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","procedure.png"));
		entigrator.putEntity(entity);
		entity=entigrator.assignProperty("entity", getType(), entity.getKey());
		return entity;
	}	
}
