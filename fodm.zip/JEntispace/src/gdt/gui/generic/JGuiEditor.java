package gdt.gui.generic;

import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.gui.console.JMainConsole;
import gdt.gui.entity.JEntityFacetList;

public abstract class JGuiEditor extends JContext{
	public   JGuiEditor () {
		super();
	}
	public JGuiEditor(JMainConsole console) {
		super(console);
		
	}
	public  JGuiEditor (JMainConsole console,String alocator$) {
		super(console,alocator$);
	}
	
	@Override
	public boolean handleDone() {
		/*
		System.out.println("JGuiEditor:handleDone;locator="+locator$);
		JDisplay display=getDisplay();
		System.out.println("JGuiEditor:handleDone:display is null");
		String displayKey$=Locator.getProperty(locator$,DISPLAY);
		if(displayKey$!=null)
			display=console.getDisplay(displayKey$);
		System.out.println("JGuiEditor:handleDone:display is null"+ "  by key="+displayKey$);
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String facetList$=JEntityFacetList.classLocator();
		facetList$=Locator.append(facetList$, Entigrator.ENTITY_LABEL, entity$);
		JEntityFacetList facetList=new JEntityFacetList(console,facetList$);
		if(display==null)
	    	replace(console, facetList);
	    else
	    	display.putContext(facetList);
		return true;
		*/
		if(parent$==null||SessionHandler.getInstanceLocator(console.getEntigrator(),parent$)==null) {
			String facetList$=JEntityFacetList.classLocator();
			JEntityFacetList facetList=new JEntityFacetList(console,facetList$);
			JDisplay display=getDisplay();
			if(display==null)
		    	replace(console, facetList);
		    else
		    	display.putContext(facetList);
			return true;
		}
		JContext.displayInstance(console, parent$,getDisplay());
		return true;
	}
}
