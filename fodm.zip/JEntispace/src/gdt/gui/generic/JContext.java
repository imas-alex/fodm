package gdt.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Constructor;
import java.util.Properties;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.EntigratorListener;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;

public  abstract class JContext extends JPanel implements EntigratorListener {
private static final long serialVersionUID = 1L;
public static final String PARENT="parent";

public static final String DEFAULT_PARENT="default parent";
public final static String REPLY="reply";
public final static String ACTION="action";
public final static String DONE="done";
public final static String NO_DONE="no done";
public final static String ROOT="root";
public final static String INSTANCE="instance";
public final static String NON_REMOVABLE="non removable";
public final static String DISPLAY="display";
public final static String CONTEXT_CLASS="context class";
public final static String INVALID="invalid";
final static int NOP=0;
final static int DISPLAY_DISPOSE=1;
final static int CONTEXT_REPLACE=2;
final static int CONSOLE_REPLACE=3;
protected JMainConsole console;
protected String locator$;
protected String instance$;
protected String parent$;
protected String display$;
protected String reply$;
protected String status$;
protected boolean nomenu=false;
JMenuItem viewItem;
public   JContext () {
	super();
	setLayout(new BorderLayout(0, 0));
}
public JContext(JMainConsole console) {
	super();
	this.console=console;
	locator$=getClassLocator();
	instance$=getInstance();
}
public  JContext (JMainConsole console,String alocator$){
	super();
	//System.out.println("JContext:alocator="+alocator$);
	locator$=Locator.merge( getClassLocator(),alocator$);
	
	//System.out.println("JContext:0:locator="+locator$);
	if(console!=null&&console.getEntigrator()!=null)
	          console.getEntigrator().addListener(this);
	this.console=console;
	display$=Locator.getProperty(alocator$, DISPLAY);
	instance$=getInstance();
	locator$=Locator.append(locator$, INSTANCE, instance$);
	parent$=Locator.getProperty(alocator$, PARENT);
	if(parent$==null) 
		System.out.println("JContext:parent is null:locator="+alocator$);
//	System.out.println("JContext:locator="+locator$);
  }
public abstract String getClassLocator();
public abstract String reply(JMainConsole console,String locator$);
public abstract boolean handleDone();
public void refreshDisplay() {
	Component root=SwingUtilities.getRoot(this);
	if(root==null) {
		System.out.println("JContext:refreshDisplay:root is null: context="+getLocator());
		return;
	}
	if(root instanceof JDisplay) {
		display$=console.getDisplayKey(this);
		if(display$==null)
			display$=console.putDisplay((JDisplay)root);
		//System.out.println("JContext:refreshDisplay:root is JDisplay="+display$);
	}
}
public void rebuild(JMainConsole console) {}
public void setSubtitle(String subtitle$) {
	Component root=SwingUtilities.getRoot(this);
    if(root instanceof JDisplay) {
		int cnt=((JDisplay)root).getComponentCount();
		if(cnt>0) {
			Component cmp;
			for(int i=0;i<cnt;i++ ) {
				cmp=((JDisplay)root).getComponent(i);
				if(cmp instanceof JLabel) {
					((JLabel)cmp).setText(subtitle$);
					return;
				}
		}
		}
	}else
		console.setSubtitle(subtitle$);
	
}
public void setTitle(String title$) {
	if(display$!=null){
		JDisplay display=console.getDisplay(display$);
		if(display!=null) {
			display.setTitle(title$);
			return;
		}
	}
	Component root=SwingUtilities.getRoot(this);
    if(root==null)
    	return;
	if(root instanceof JDisplay) {
		((JDisplay)root).setTitle(title$);
		return;
	}else
    	console.setTitle(title$);
	
}
public  void append( String property$,String  value$) {
	if(property$!=null&&value$!=null)
	 locator$=Locator.append(locator$, property$, value$);
}
public  JMenu getContextMenu() {
	// System.out.println("JContext:getContextMenu:this="+getClass().getName());
	  JMenu menu=new JMenu("Context");
	  menu.addMenuListener(new MenuListener(){
		     @Override
		     public void menuCanceled(MenuEvent e) {
		     		     }
		     @Override
		     public void menuDeselected(MenuEvent e) {
		     		     }
			@Override
			public void menuSelected(MenuEvent arg0) {
				JDisplay [] da=console.getDisplays();
				if(da==null) { 
					viewItem.setEnabled(false);
					return;
				}
				else {
				//	System.out.println("JContext:menu:da="+da.length);
					if(da.length>0)
						viewItem.setEnabled(true);
					else
						viewItem.setEnabled(false);
				}
			}
	  });
		JMenuItem doneItem = new JMenuItem("Done");
		doneItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handleDone();
					}
				});
		menu.add(doneItem);
		JMenuItem displayItem = new JMenuItem("Display");
		displayItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JDisplay display=JContext.this.getDisplay();
				
				if(display==null)
				   display=new JDisplay(console,JContext.this);
					display.toFront();
				console.putDisplay(display);
				//System.out.println("JContext:display="+display.getClass().getName());
				transfer(console,display);
			}
		});
		menu.add(displayItem);
		viewItem = new JMenuItem("All displays");
		viewItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JDisplay [] da=console.getDisplays();
				for(JDisplay d:da) {
					d.setVisible(true);
					d.toFront();
				}
			}
		});
		menu.add(viewItem);
		return menu;
  };
 public static JMenu removeItem(JMenu menu,String item$) {
	 if(menu==null||item$==null)
		 return menu;
	 int cnt=menu.getItemCount();
		if(cnt>0)
			for(int i=0;i<cnt;i++) {
				JMenuItem item=menu.getItem(i);
				if(item==null)
					continue;
				if(item$.equals(item.getText())) {
					menu.remove(i);
					return menu;
				}
			}
	 return menu;	
 }
 public static JMenuItem getMenuItem(JMenu menu,String item$) {
	 if(menu==null||item$==null)
		 return menu;
	 int cnt=menu.getItemCount();
		if(cnt>0)
			for(int i=0;i<cnt;i++) {
				JMenuItem item=menu.getItem(i);
				if(item==null)
					continue;
				if(item$.equals(item.getText())) {
					return item;
				}
			}
	 return null;	
 }
 public void setLocator(String locator$) {
	this.locator$=locator$;
}
public void setParent(String parentInstance$) {
  if(parentInstance$!=null)
	locator$=Locator.append(locator$, PARENT, parentInstance$);
}
public void replace(JMainConsole console,JContext context) {
        try {
        	String actualCurrentInstance$=getInstance();
   //     	System.out.println("JContext:replace:current locator="+actualCurrentLocator$);
        	String contextLocator$=context.getLocator();
       		contextLocator$=Locator.append(contextLocator$, PARENT, actualCurrentInstance$);
       		//context.setLocator(contextLocator$);
       		context.setParent(actualCurrentInstance$);
            String display$=Locator.getProperty(locator$, DISPLAY);
        	Component root=SwingUtilities.getRoot(this);
        	if(display$!=null) {
        		JDisplay display=console.getDisplay(display$);
        		if(display!=null)
        			root=display;
        	}
        	if(root instanceof JDisplay) {
        		//System.out.println("JContext:replaceContext:root is dialog");
        		try {
        		SessionHandler.putLocator(console.getEntigrator(), context.getLocator());
        		
        		 ((JDisplay)root).setJMenuBar(null);
        		 ((JDisplay)root).getContentPane().removeAll();
        		 JMenuBar menuBar = new JMenuBar();
        		 ((JDisplay)root).setJMenuBar(menuBar);
        		 ((JDisplay)root).setTitle(Locator.getProperty(context.getLocator(), Locator.LOCATOR_TITLE));
        		 JMenu contextMenu=context.getContextMenu();
        		 contextMenu=JContext.removeItem(contextMenu, "Display");
        		 menuBar.add(contextMenu);
        		 ((JDisplay)root).getContentPane().add(context,BorderLayout.CENTER);
        		 JLabel subtitle = new JLabel("");
        		 subtitle.setText(Locator.getProperty(locator$, Entigrator.ENTITY_LABEL));
				 subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
				 subtitle.setOpaque(true);
				 subtitle.setBackground(Color.BLACK);
				 subtitle.setForeground(Color.WHITE);
				 ((JDisplay)root).getContentPane().add(subtitle,BorderLayout.SOUTH);
        		}catch(Exception ee) {
        			((JDisplay) root).dispose();
        		}
        	}
        	else {
        		console.replaceContext(context);
        	}
        	if(root!=null) {
        	root.revalidate();
    	    root.repaint();
        	}
        }catch(Exception e) {
        	 System.out.println("JContext:replace:"+e.toString());
        }
}

private static  JContext restoreParent(JMainConsole console, JContext context) {
    try {
 //   	 System.out.println("JContext:restoreParent:BEGIN");	 
    	String locator$=context.getLocator();
         String parent$=Locator.getProperty(locator$, PARENT);
  //       System.out.println("JContext:restoreParent:parent$="+parent$);
         JContext parent=new JAdminPanel(console,null);
         if(parent$!=null) {
        	 String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(), parent$);
     //   	 System.out.println("JContext:restoreParent:parentLocator$="+parentLocator$);
        	 if(parentLocator$!=null) {
        		 parent=build(console,parentLocator$);
        		 if(parent==null)
        			 parent=new JAdminPanel(console,null);	 
        	 }
         }
  //      System.out.println("JContext:restoreParent:parent="+parent.getClass().getName());
        String display$=Locator.getProperty(locator$, DISPLAY);
    	Component root=SwingUtilities.getRoot(context);
    	if(display$!=null) {
    		JDisplay display=console.getDisplay(display$);
    		if(display!=null)
    			root=display;
    	}
    	if(root instanceof JDisplay) {
    		//System.out.println("JContext:replaceContext:root is dialog");
    		try {
    		 ((JDisplay)root).setJMenuBar(null);
    		 ((JDisplay)root).getContentPane().removeAll();
    		 JMenuBar menuBar = new JMenuBar();
    		 ((JDisplay)root).setJMenuBar(menuBar);
    		 ((JDisplay)root).setTitle(Locator.getProperty(parent.getLocator(), Locator.LOCATOR_TITLE));
    		 JMenu contextMenu=parent.getContextMenu();
    		 contextMenu=JContext.removeItem(contextMenu, "Display");
    		 menuBar.add(contextMenu);
    		 ((JDisplay)root).getContentPane().add(parent,BorderLayout.CENTER);
    		 JLabel subtitle = new JLabel("");
    		 subtitle.setText(Locator.getProperty(locator$, Entigrator.ENTITY_LABEL));
			 subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
			 subtitle.setOpaque(true);
			 subtitle.setBackground(Color.BLACK);
			 subtitle.setForeground(Color.WHITE);
			 ((JDisplay)root).getContentPane().add(subtitle,BorderLayout.SOUTH);
    		}catch(Exception ee) {
    			((JDisplay) root).dispose();
    		}
    	}
    	else {
    		console.replaceContext(parent);
    	}
    	if(root!=null) {
    	root.revalidate();
	    root.repaint();
    	}
    	return parent;
    }catch(Exception e) {
    	 System.out.println("JContext:restore Parent:"+e.toString());
    	 return new JAdminPanel(console,null);
    }
}
public  static  void displayInstance(JMainConsole console, String instance$) {
    try {
    	// System.out.println("JContext:displayContext:instance="+instance$);
    	 if(instance$==null) {
    		 System.out.println("JContext:displayContext:instance is null");
    		 return ;
    	 }
        String locator$=SessionHandler.getInstanceLocator(console.getEntigrator(), instance$);
        //System.out.println("JContext:displayContext:locator="+locator$);
        if(locator$==null) {
        	System.out.println("JContext:displayContext:cannot get locator for instance="+instance$);
        	return ;
        }
        	String contextClass$=Locator.getProperty(locator$, CONTEXT_CLASS);
        //	System.out.println("JContext:displayContext:context class="+contextClass$);
        	if(contextClass$==null) {
        		System.out.println("JContext:displayContext:no CONTEXT_CLASS in parent locator ="+locator$);
        		return;
        	}
   			Class <?>contextClass=console.getEntigrator().getClass(contextClass$);
   			Constructor<?> cns=contextClass.getConstructor(JMainConsole.class,String.class);
        	if(cns==null) {
        		System.out.println("JContext:displayContext::cannot get constructor for context class="+contextClass$);
        			return;
        	}
      		cns.setAccessible(true);
      		Object obj=  cns.newInstance(console,locator$);
      		String display$=Locator.getProperty(locator$, DISPLAY);
      		if(display$!=null) {
      			//System.out.println("JContext:displayContext:dislay is null:locator="+locator$);
        		JDisplay display=console.getDisplay(display$);
        		if(display==null) {
        			System.out.println("JContext:displayContext:no display="+display$);
        			return;
        		}
        		Component root=display;
        		((JDisplay)root).setJMenuBar(null);
       		 ((JDisplay)root).getContentPane().removeAll();
       		 JMenuBar menuBar = new JMenuBar();
       		 ((JDisplay)root).setJMenuBar(menuBar);
       		 ((JDisplay)root).setTitle(Locator.getProperty(locator$, Locator.LOCATOR_TITLE));
       		 JMenu contextMenu=((JContext)obj).getContextMenu();
       		 contextMenu=JContext.removeItem(contextMenu, "Display");
       		 menuBar.add(contextMenu);
       		 ((JDisplay)root).getContentPane().add((JContext)obj,BorderLayout.CENTER);
       		 JLabel subtitle = new JLabel("");
       		 subtitle.setText(Locator.getProperty(locator$, Entigrator.ENTITY_LABEL));
   			 subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
   			 subtitle.setOpaque(true);
   			 subtitle.setBackground(Color.BLACK);
   			 subtitle.setForeground(Color.WHITE);
   			 ((JDisplay)root).getContentPane().add(subtitle,BorderLayout.SOUTH);
   			root.revalidate();
   		    root.repaint();
      		}else {
      			console.replaceContext((JContext)obj);
      		}
        }catch(Exception e) {
        	System.out.println("JContext:displayInstance:"+e.toString());
        	return ;
        }
       	}
public  static  void displayInstance(JMainConsole console, String instance$,String display$) {
    try {
    	// System.out.println("JContext:displayContext:instance="+instance$);
    	 if(instance$==null) {
    		 System.out.println("JContext:displayContext:instance is null");
    		 return ;
    	 }
        String locator$=SessionHandler.getInstanceLocator(console.getEntigrator(), instance$);
        //System.out.println("JContext:displayContext:locator="+locator$);
        if(locator$==null) {
        	System.out.println("JContext:displayContext:cannot get locator for instance="+instance$);
        	return ;
        }
        	String contextClass$=Locator.getProperty(locator$, CONTEXT_CLASS);
        //	System.out.println("JContext:displayContext:context class="+contextClass$);
        	if(contextClass$==null) {
        		System.out.println("JContext:displayContext:no CONTEXT_CLASS in parent locator ="+locator$);
        		return;
        	}
   			Class <?>contextClass=console.getEntigrator().getClass(contextClass$);
   			Constructor<?> cns=contextClass.getConstructor(JMainConsole.class,String.class);
        	if(cns==null) {
        		System.out.println("JContext:displayContext::cannot get constructor for context class="+contextClass$);
        			return;
        	}
      		cns.setAccessible(true);
      		Object obj=  cns.newInstance(console,locator$);
      		((JContext)obj).setDisplay(display$);
      	//	String display$=Locator.getProperty(locator$, DISPLAY);
      		if(display$!=null) {
      			//System.out.println("JContext:displayContext:display is null:locator="+locator$);
        		JDisplay display=console.getDisplay(display$);
        		if(display==null) {
        			System.out.println("JContext:displayContext:no display="+display$);
        			return;
        		}
        		Component root=display;
        		((JDisplay)root).setJMenuBar(null);
       		 ((JDisplay)root).getContentPane().removeAll();
       		 JMenuBar menuBar = new JMenuBar();
       		 ((JDisplay)root).setJMenuBar(menuBar);
       		 ((JDisplay)root).setTitle(Locator.getProperty(locator$, Locator.LOCATOR_TITLE));
       		 JMenu contextMenu=((JContext)obj).getContextMenu();
       		 contextMenu=JContext.removeItem(contextMenu, "Display");
       		 menuBar.add(contextMenu);
       		 ((JDisplay)root).getContentPane().add((JContext)obj,BorderLayout.CENTER);
       		 JLabel subtitle = new JLabel("");
       		 subtitle.setText(Locator.getProperty(locator$, Entigrator.ENTITY_LABEL));
   			 subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
   			 subtitle.setOpaque(true);
   			 subtitle.setBackground(Color.BLACK);
   			 subtitle.setForeground(Color.WHITE);
   			 ((JDisplay)root).getContentPane().add(subtitle,BorderLayout.SOUTH);
   			root.revalidate();
   		    root.repaint();
      		}else {
      			console.replaceContext((JContext)obj);
      		}
        
        }catch(Exception e) {
        	System.out.println("JContext:displayInstance:"+e.toString());
        	return ;
        }
       	}
public  static  void replyInstance(JMainConsole console, String instance$) {
	int breakPoint=0;
	try {
    	// System.out.println("JContext:replyInstance:instance="+instance$);
    	if(instance$==null) {
    		 System.out.println("JContext:replyInstance:instance is null");
    		 return ;
    	 }
        String locator$=SessionHandler.getInstanceLocator(console.getEntigrator(), instance$);
        breakPoint=1;
        System.out.println("JContext:replyInstance:locator="+locator$);
        if(locator$==null) {
        	System.out.println("JContext:replyInstance:cannot get locator for instance="+instance$);
        	return ;
        }
        	String contextClass$=Locator.getProperty(locator$, CONTEXT_CLASS);
        	 breakPoint=2;
        	//	System.out.println("JContext:displayContext:context class="+contextClass$);
        	if(contextClass$==null) {
        		System.out.println("JContext:replyInstance:no CONTEXT_CLASS in parent locator ="+locator$);
        		return;
        	}
        //	System.out.println("JContext:replyInstance:context="+contextClass$);
   			Class <?>contextClass=console.getEntigrator().getClass(contextClass$);
   		 breakPoint=3;
   			Constructor<?> cns=contextClass.getConstructor(JMainConsole.class,String.class);
        	if(cns==null) {
        		System.out.println("JContext:replyInstance::cannot get constructor for context class="+contextClass$);
        			return;
        	}
        	 breakPoint=4;
      		cns.setAccessible(true);
      		Object obj=  cns.newInstance(console,locator$);
      		if(obj==null) {
      			System.out.println("JContext:replyInstance::cannot get object for context class="+contextClass$);
      			return;
      		}
      		 breakPoint=5;
      	//	System.out.println("JContext:replyInstance:object="+obj.getClass().getName());
      		locator$=((JContext)obj).reply(console,locator$);
      		 breakPoint=6;
      		SessionHandler.putLocator(console.getEntigrator(), locator$);
      		
        }catch(Exception e) {
        	System.out.println("JContext:replyInstance:"+e.toString()+"  break point="+breakPoint+" instance="+instance$);
        	return ;
        }
    
    	}  
public void transfer(JMainConsole console,JDisplay display) {
	String parent$=Locator.getProperty(locator$,PARENT);
//	System.out.println("JContext:transfer:parent="+parent$);
	String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(), parent$);
//	System.out.println("JContext:transfer:parent locator="+parentLocator$);
//	System.out.println("JContext:transfer:this locator="+locator$);
	JContext parent=build(console,parentLocator$);
	console.replaceContext(parent);
	JMenuBar menuBar = new JMenuBar();
	display.setJMenuBar(menuBar);
	display.setTitle(getTitle());
    display.setSize(console.frmEntigrator.getSize());   
  //  System.out.println("JContext:transfer:locator="+this.locator$);
	String display$=display.getKey();
	locator$=Locator.append(locator$, DISPLAY, display$);
    SessionHandler.putLocator(console.getEntigrator(), locator$);
	JMenu menu=getContextMenu();
	menu=removeItem(menu,"Display");
	menuBar.add(menu);
	display.putContext(this);
	display.setSize(console.frmEntigrator.getSize());
	display.revalidate();
	display.repaint();
	display.setVisible(true);
	display.setTitle(getTitle());
	display.setSubtitle(Locator.getProperty(this.getLocator(), Entigrator.ENTITY_LABEL));
//	System.out.println("JContext:transfer.FINISH:subtitle="+Locator.getProperty(this.getLocator(), Entigrator.ENTITY_LABEL)+" title="+getTitle());
}
  public void setDisplay(String display$) {
	  this.display$=display$;
	  if(display$!=null)
		  locator$=Locator.append(locator$, DISPLAY, display$);
  }
  public JDisplay getDisplay() {
	  if(display$==null)
		  return null;
	  return console.getDisplay(display$);
  }
  public String getLocator() {
	  if(locator$==null)
		return null;
	  String instance$=getInstance();
	  locator$=Locator.append(locator$, INSTANCE, instance$);
	  return locator$;
  }
  public String getInstance() {
	  if(locator$==null)
		  return null;
	  String instance$= Locator.getProperty(locator$, INSTANCE);
	  if(instance$!=null)
		  return instance$;
	  instance$=Identity.key();
	  locator$=Locator.append(locator$, INSTANCE, instance$);
	  return instance$;
  }
  public String getParentInstance() {
	  if(locator$==null)
		  return null;
	  return Locator.getProperty(locator$, PARENT);
  }
  public  void close() {
	  console.getEntigrator().removeListener(this);
	  if(Locator.LOCATOR_TRUE.equals(display$))
		  return;
	  try {
		Sack session=console.getEntigrator().getEntityAtLabel("current");
		session.putAttribute(new Core("runtime","current",getLocator()));
		console.getEntigrator().putEntity(session);
	  }catch(Exception e) {
		  System.out.println("JContext:close:"+e.toString());
	  }
  }
  public String getTitle() {
	  return Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
  }
  public String getSubtitle() {
	  return Locator.getProperty(locator$, Locator.LOCATOR_SUBTITLE);
  }
public static JContext build(JMainConsole console,String locator$) {
	String className$="";
	StringBuffer sb=new StringBuffer("JContext:build:log::");
	try {
	//System.out.println("JContext:build:locator="+locator$);
	Properties locator=Locator.toProperties(locator$);
	String containerType$=locator.getProperty(FacetHandler.FACET_CONTAINER_TYPE);
	className$=locator.getProperty(CONTEXT_CLASS);
	sb.append("class name="+className$+"\n");	
	//System.out.println("JContext:build:className="+className$+" module="+module$);
	Class<?> cls=null;
	if(FacetHandler.FACET_CONTAINER_INTERNAL.equals(containerType$)) {
		ClassLoader cl=Thread.currentThread().getContextClassLoader();
		
		try {
		cls=cl.loadClass(className$);
		}catch(ClassNotFoundException ee) {
			System.out.println("JContext:build::cannot load class:"+ee);
			return null;
		}
        sb.append("internal class loaded\n");
		}else{
			cls=console.getEntigrator().getClassLoader().loadClass(className$);
			sb.append("module class loaded\n");
		}
		if(cls==null) {
			System.out.println("JContext:build:2:class is null");
		  return null;
		}
		Constructor <?>ctr= cls.getDeclaredConstructor(JMainConsole.class, String.class);
		if(ctr==null) {
			System.out.println("JContext:build:3:cannot get default constructor:class="+className$);
			return null;
		}
		sb.append("constructor found\n");
		Object  obj= ctr.newInstance(console,locator$);
		if(obj==null) {
			System.out.println("JContext:build:4:cannot instantiate calss="+className$);
			return null;
		}
		sb.append("instance created\n");
		//System.out.println("JContext:build:return context="+obj.getClass().getName()+ "  locator="+((JContext)obj).getLocator());
		return (JContext)obj;
	}catch(Exception e) {
		System.out.println("JContext:build::"+e.toString()+"  class name="+className$+ "  locator="+locator$);
		System.out.print(sb.toString());
	}
	return null;
}
public String getStatus() {
	return status$;
}
@Override
public void onEntigratorEvent(String locator$) {
	//System.out.println("JContext:onEntigratorEvent:locator="+locator$);
	}
public static void selectCombo(JComboBox combo, String selection$){
	try{
	DefaultComboBoxModel<String> model=(DefaultComboBoxModel<String>) combo.getModel();
   int size=model.getSize();
   int sel=0;
 for(int i=0;i<size;i++) {
	 if(selection$.equalsIgnoreCase((String)combo.getItemAt(i))) {
		 sel=i;
	 }
 }
try{combo.setSelectedIndex(sel);}catch(Exception e) {}
}catch(Exception e){
	System.out.println("JContext:selectCombo:"+e.toString());
	}
	
}
public static  void updateInstanceLocator(JMainConsole console,String locator$) {
	try {
	//	System.out.println("JContext:updateInstanceLocator:locator="+locator$);
		if(locator$==null) {
			System.out.println("JContext:updateInstanceLocator:locator is null");
			return;
		}
			String contextClass$=Locator.getProperty(locator$, CONTEXT_CLASS);
		//	System.out.println("JContext:updateInstanceLocator:context class="+contextClass$);
			if(contextClass$==null) {
				System.out.println("JContext:updateInstanceLocator:no CONTEXT_CLASS in locator ="+locator$);
				return;
			}
			
			Class <?>contextClass=console.getEntigrator().getClass(contextClass$);
			Constructor<?> cns=contextClass.getConstructor(JMainConsole.class,String.class);
			if(cns==null) {
				System.out.println("JContext:updateInstanceLocator:cannot get constructor");
				return;
			}
			cns.setAccessible(true);
			JContext  context=(JContext)cns.newInstance(console,locator$);
		//	System.out.println("JContext:updateInstanceLocator:context="+context.getClass().getName());
			locator$=context.reply(console, locator$); 
			
		//	SessionHandler.putLocator(console.getEntigrator(), locator$);
			System.out.println("JContext:updateInstanceLocator:OK locator="+locator$);
	}catch(Exception e) {
		System.out.println("JContext:updateInstanceLocator:"+e.toString());
	}
}
}
	


