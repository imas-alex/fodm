package gdt.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.border.BevelBorder;

import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
import javax.swing.JPanel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class JDisplay extends JDialog {
private static final long serialVersionUID = 1L;
public static final String DISPLAY_KEY="display key";    
 public static final String DISPLAY_WIDTH="display width";  
 public static final String DISPLAY_HEIGHT="display width";
 public static final String DISPLAY_WPOS="display wpos"; 
 public static final String DISPLAY_HPOS="display hpos";  
	JContext context;
    JMainConsole console;
    JMenu menu;
    JLabel subtitle;
    String key$;
    String locator$;
    JPanel contextPanel;
    public JDisplay(JMainConsole console,JContext context) {
    	super();
    	addWindowListener(new WindowAdapter() {
    		@Override
    		public void windowClosing(WindowEvent e) {
    			//System.out.println("JDisplay:window closing: locator="+context.getLocator());
    			if(key$!=null)
    				console.removeDisplay(key$);
    	      }
    	});
    	this.console=console;
    	this.context=context;
    	key$=console.getDisplayKey(context);
    	if(key$==null)
    		key$=console.putDisplay(this);
    	context.setDisplay(key$);
    	String contextLocator$=context.getLocator();
    	SessionHandler.putLocator(console.getEntigrator(), contextLocator$);
    	locator$=context.getLocator();
    	String key$=Locator.getProperty(contextLocator$, DISPLAY_KEY);
    	if(key$==null)
    	  key$=Identity.key();
    	locator$=Locator.append(locator$, DISPLAY_KEY, key$);
    	console.putDisplay(this);
    	SessionHandler.putLocator(console.getEntigrator(), locator$);
    	JMenuBar menuBar = new JMenuBar();
    	setJMenuBar(menuBar);
    	menu=context.getContextMenu();
    	menu=JContext.removeItem(menu,"Display");
    	menu.addSeparator();
        JMenuItem deleteItem = new JMenuItem("Dispose");
		deleteItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				int response = JOptionPane.showConfirmDialog( JDisplay.this, "Finally delete display ?", "Confirm",JOptionPane.YES_NO_CANCEL_OPTION);
			   if (response == JOptionPane.YES_OPTION) { 
				  console.removeDisplay(JDisplay.this.key$); 
				  dispose();
			   }
			}
				});
		menu.add(deleteItem);
		menuBar.add(menu);
    	getContentPane().add(context,BorderLayout.NORTH);
    	subtitle = new JLabel();
    	subtitle.setPreferredSize(new Dimension(30,20));
    	subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
    	subtitle.setOpaque(true);
    	subtitle.setBackground(Color.BLACK);
    	subtitle.setForeground(Color.WHITE);
    	getContentPane().add(subtitle,BorderLayout.SOUTH);
    	String subtitle$=Locator.getProperty(context.getLocator(), Locator.LOCATOR_SUBTITLE);
    	if(subtitle$!=null)
    		subtitle.setText(subtitle$);
    	String title$=Locator.getProperty(context.getLocator(), Locator.LOCATOR_TITLE);
    	if(title$!=null)
    		setTitle(title$);
    	pack();
		invalidate();
		validate();
		repaint();
		context.refreshDisplay();
		setLocationRelativeTo(context);
//		System.out.println("JDisplay:context locator="+context.getLocator());
    }
    public JDisplay(JMainConsole console,String locator$) {
    	super();
    	this.console=console;
    	this.locator$=locator$;
      	//System.out.println("JDisplay:locator="+locator$);
    	try {
    	String title$=Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
    	if(title$!=null)
    		setTitle(title$);
    	JMenuBar menuBar = new JMenuBar();
    	setJMenuBar(menuBar);
    	subtitle = new JLabel();
    	subtitle.setPreferredSize(new Dimension(30,20));
    	subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
    	subtitle.setOpaque(true);
    	subtitle.setBackground(Color.BLACK);
    	subtitle.setForeground(Color.WHITE);
    	getContentPane().add(subtitle,BorderLayout.SOUTH);
    	String subtitle$=Locator.getProperty(locator$, Locator.LOCATOR_SUBTITLE);
    	if(subtitle$!=null)
    		subtitle.setText(subtitle$);
    	JContext context=JContext.build(console, locator$);
    	key$=console.putDisplay(this);
    	context.setDisplay(key$);	
    	menu=context.getContextMenu();
    	menu=JContext.removeItem(menu,"Display");
    	menu.addSeparator();
    	JMenuItem deleteItem = new JMenuItem("Dispose");
 		deleteItem.addActionListener(new ActionListener() {
 			@Override
 			public void actionPerformed(ActionEvent arg0) {
 				int response = JOptionPane.showConfirmDialog( JDisplay.this, "Finally delete display ?", "Confirm",JOptionPane.YES_NO_CANCEL_OPTION);
 			   if (response == JOptionPane.YES_OPTION) { 
 				  console.removeDisplay(key$); 
 				  dispose();
 			   }
 			}
			});
 		menu.add(deleteItem);
    	menuBar.add(menu);
    	getContentPane().add(context,BorderLayout.CENTER);
    	String width$=Locator.getProperty(locator$, DISPLAY_WIDTH);
    	String height$=Locator.getProperty(locator$, DISPLAY_HEIGHT);
    	try{ 
    		int width=Integer.parseInt(width$);
    		int height=Integer.parseInt(height$);
    		setSize(width, height);
    	}catch(Exception e) {
    		System.out.println("JDisplay:size="+e.toString());
    	}
    	String wpos$=Locator.getProperty(locator$, DISPLAY_WPOS);
    	String hpos$=Locator.getProperty(locator$, DISPLAY_HPOS);
    	try{ 
    		int wpos=Integer.parseInt(wpos$);
    		int hpos=Integer.parseInt(hpos$);
    		setLocation(wpos, hpos);
    	}catch(Exception e) {
    		System.out.println("JDisplay:size="+e.toString());
    	}
    	}catch(Exception ee) {
    		System.out.println("JDisplay:"+ee.toString());
    	}
    	pack();
		invalidate();
		validate();
		repaint();
		setVisible(true);
		//System.out.println("JDisplay:context locator="+context.getLocator());
    }
    public void putContext(JContext context ) {
   	getContentPane().removeAll();
    	getContentPane().add(context,BorderLayout.CENTER);	
   		subtitle.setText(context.getSubtitle());
    	getContentPane().add(subtitle,BorderLayout.SOUTH);	
    	setTitle(context.getTitle());
    	pack();
		invalidate();
		validate();
		repaint();
  }
  public String getKey() {
	  return key$;
  }
  public void setKey(String key$) {
	  this.key$= key$;
  }
  public void setSubtitle(String subtitle$) {
	  subtitle.setText(subtitle$);
  }
  public String getLocator() {
	  locator$=Locator.append(locator$, DISPLAY_KEY, key$);
	  Dimension dim=getSize();
	  locator$=Locator.append(locator$, DISPLAY_WIDTH, String.valueOf(dim.width));
	  locator$=Locator.append(locator$, DISPLAY_HEIGHT, String.valueOf(dim.height));
	  Point p=getLocation();
	  locator$=Locator.append(locator$, DISPLAY_WPOS, String.valueOf(p.x));
	  locator$=Locator.append(locator$, DISPLAY_HPOS, String.valueOf(p.y));
	  return locator$;
  }
  public JContext getContext() {
	  return context;
  }
  public void replaceContext(JContext context) {
	  if(context==null) {
		  JAdminPanel adminPanel=new JAdminPanel(console,JAdminPanel.classLocator());
		  console.replaceContext(adminPanel); 
		  return;
	  }	
	  try {
		 String contextLocator$=context.getLocator();
		 String displayKey$=Locator.getProperty(contextLocator$, DISPLAY_KEY);
		 if(key$.equals(displayKey$))
			 return;
//		System.out.println("JDisplay:replaceContext:locator="+getLocator()); 
	     getContentPane().removeAll();
		 JMenuBar menuBar = new JMenuBar();
		 setJMenuBar(menuBar);
		 setTitle(Locator.getProperty(context.getLocator(), Locator.LOCATOR_TITLE));
		 JMenu contextMenu=context.getContextMenu();
		 contextMenu=JContext.removeItem(contextMenu, "Display");
		 menuBar.add(contextMenu);
		 getContentPane().add(context,BorderLayout.CENTER);
		 JLabel subtitle = new JLabel("");
		 subtitle.setText(Locator.getProperty(locator$, Entigrator.ENTITY_LABEL));
		 subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
		 subtitle.setOpaque(true);
		 subtitle.setBackground(Color.BLACK);
		 subtitle.setForeground(Color.WHITE);
		 getContentPane().add(subtitle,BorderLayout.SOUTH);
		 pack();
		 revalidate();
		 repaint();
		 context.refreshDisplay();
	  }catch(Exception e) {
		  console.replaceContext(context);
		  System.out.println("JDisplay:replaceContext:"+e.toString());
	  }
  }
 }
