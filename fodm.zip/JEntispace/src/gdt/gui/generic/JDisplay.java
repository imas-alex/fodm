package gdt.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.border.BevelBorder;

import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import javax.swing.JPanel;

public class JDisplay extends JDialog {
private static final long serialVersionUID = 1L;
public static final String DISPLAY_KEY="display key";    
 public static final String DISPLAY_WIDTH="display width";  
 public static final String DISPLAY_HEIGHT="display height";
 public static final String DISPLAY_WPOS="display wpos"; 
 public static final String DISPLAY_HPOS="display hpos"; 
 public static final String DISPLAY_LOCATOR="display locator"; 
 public static final String CONTEXT_INSTANCE="context instance"; 
	JContext context;
    JMainConsole console;
    JMenu menu;
    JLabel subtitle;
    String key$;
    String locator$;
    JPanel contextPanel;
     public JDisplay(JMainConsole console) {
    	super();
    	this.console=console;
    	JMenuBar menuBar = new JMenuBar();
    	setJMenuBar(menuBar);
    	subtitle = new JLabel();
    	subtitle.setPreferredSize(new Dimension(30,20));
    	subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
    	subtitle.setOpaque(true);
    	subtitle.setBackground(Color.BLACK);
    	subtitle.setForeground(Color.WHITE);
    	getContentPane().add(subtitle,BorderLayout.SOUTH);
    	key$=console.putDisplay(this);
   		setSize(console.frmEntigrator.getSize());
   		setLocationRelativeTo(console.frmEntigrator);
		setVisible(true);
		
		JContext context=JContext.build(console, locator$);
		if(context!=null)
			putContext(context);
    }
    public void putContext(JContext context ) {
   	this.context=context;
    	getContentPane().removeAll();
   	getContentPane().add(context,BorderLayout.CENTER);	
   		subtitle.setText(context.getSubtitle());
    	getContentPane().add(subtitle,BorderLayout.SOUTH);	
    	JMenu menu=context.getContextMenu();
    	if(menu!=null) {
    	menu=JContext.removeItem(menu,"Display");
    	menu.addSeparator();
    	}else {
    		 menu=new JMenu("Context");
    	}
        JMenuItem deleteItem = new JMenuItem("Dispose");
		deleteItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				int response = JOptionPane.showConfirmDialog( JDisplay.this, "Finally delete display ?", "Confirm",JOptionPane.YES_NO_CANCEL_OPTION);
			   if (response == JOptionPane.YES_OPTION) { 
				  console.removeDisplay(JDisplay.this.key$); 
				  dispose();
			   }
			}
				});
		menu.add(deleteItem);
		JMenuBar menuBar = new JMenuBar();
    	setJMenuBar(menuBar);
		menuBar.add(menu);
		setTitle(context.getTitle());
    	context.setDisplay(this);
    	pack();		
		invalidate();
		validate();
		repaint();
		Sack session=SessionHandler.getSession(console.getEntigrator());
			console.getEntigrator().putEntity(session);
  }
  public String getKey() {
	  return key$;
  }
  public void setKey(String key$) {
	  this.key$= key$;
  }
  public void setSubtitle(String subtitle$) {
	 if(subtitle!=null) 
	    subtitle.setText(subtitle$);
  }
  public String getLocator() {
	  String contextLocator$=null;
	  Properties locator=new Properties();
	  locator.put(DISPLAY_KEY, getKey());
	  Dimension dim=getSize();
	  locator.put(DISPLAY_WIDTH,  String.valueOf(dim.width));
	  locator.put(DISPLAY_HEIGHT, String.valueOf(dim.height));
	  Point p=getLocation();
	  locator.put(DISPLAY_WPOS, String.valueOf(p.x));
	  locator.put(DISPLAY_HPOS, String.valueOf(p.y));
	  JContext context=getContext();
	  if(context!=null) {
		  locator.put(CONTEXT_INSTANCE, context.getInstance());
		  System.out.println("JDisplay:getLocator:context name="+context.getName()+" instance="+context.getInstance());
	      contextLocator$=context.getLocator();
	    	  
	  }else
		  System.out.println("JDisplay:getLocator:context is null"); 
	  
	  String displayLocator$=Locator.toString(locator);
	  if(contextLocator$!=null)
		  displayLocator$=Locator.merge(displayLocator$, contextLocator$);
	  return displayLocator$;
  }
  public JContext getContext() {
	  return context;
  }
  public static void putToScreen(JMainConsole console,String locator$) {
	  try {
		  String width$=Locator.getProperty(locator$,DISPLAY_WIDTH);
		  String height$=Locator.getProperty(locator$,DISPLAY_HEIGHT);
		  String wpos$=Locator.getProperty(locator$,DISPLAY_WPOS);
		  String hpos$=Locator.getProperty(locator$,DISPLAY_HPOS);
		  int width=Integer.parseInt(width$);
		  int height=Integer.parseInt(height$);
		  int wpos=Integer.parseInt(wpos$);
		  int hpos=Integer.parseInt(hpos$);
		  Dimension size =new Dimension(width,height);
		  JDisplay display=new JDisplay(console); 
		  display.setSize(size);
		  Point point=new Point(wpos,hpos);
	   	  display.setLocation(point);
	   	  JContext context=JContext.build(console, locator$);
	   	  if(context!=null)
	   		  display.putContext(context);
          display.setVisible(true);
	  }catch(Exception e) {
		  System.out.println("JDisplay:putToScreen:"+e.toString()); 
	  }
  }
 }
