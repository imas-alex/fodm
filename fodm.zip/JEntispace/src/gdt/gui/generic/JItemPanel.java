package gdt.gui.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Properties;
import java.util.logging.Logger;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
public abstract class JItemPanel extends JPanel {
	 public static final String ITEM_CHECKABLE="item checkable";
	 public static final String ITEM_CHECKED="item checked";
	 public static final String ITEM_ACTION="item action";
	private static final long serialVersionUID = 1L;
	private Logger LOGGER=Logger.getLogger(JItemPanel.class.getName());
	protected String locator$;
	protected String title$;
	protected String parent$;
	protected String instance$;
	protected String display$;
	protected ImageIcon  icon;
	protected JMainConsole console;
	protected JCheckBox checkbox=null;
	protected JLabel title ;
	protected JPopupMenu popup;
	protected Entigrator entigrator;
	boolean debug=false;
	public abstract JPopupMenu getPopup(JMainConsole console,String locator$) ;
	public abstract void onClick(JMainConsole console,String locator$) ;
	public JItemPanel(JMainConsole console,String locator$){
		this.console=console;
		this.locator$=locator$;
		instance$=Locator.getProperty(locator$, JContext.INSTANCE);
		parent$=Locator.getProperty(locator$,JContext.PARENT);
		if(instance$==null) { 
			instance$=Identity.key();
			locator$=Locator.append(locator$, JContext.INSTANCE, instance$);
		}
		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		setAlignmentX(Component.LEFT_ALIGNMENT);
		try{
			this.console=console;
			this.locator$=locator$;
	        Properties locator=Locator.toProperties(locator$);
	        
	        if(Locator.LOCATOR_TRUE.equals(locator.getProperty(ITEM_CHECKABLE))){
	        	  checkbox = new JCheckBox();
	      		  add(checkbox);
	      	  if(Locator.LOCATOR_TRUE.equals(locator.getProperty(ITEM_CHECKED)))
	      			if(checkbox!=null)
	      			checkbox.setSelected(true);
	          }
	          title$=locator.getProperty(Locator.LOCATOR_TITLE);
	          if(title$==null)
	        	  title$="Action";
	        	 title = new JLabel(title$, JLabel.LEFT);
	        	 title.setText(title$);
	        	 title.setOpaque(true);
	        	 title.addMouseListener(new MouseAdapter() { 
	        		 public void mousePressed(MouseEvent me) { 
	        			 Border border = BorderFactory.createLineBorder(Color.BLUE, 5);
	        			 title.setBorder(border);
		            	// System.out.println("JItemPanel:mouse click:me="+me.toString());
		            	  if(me.getButton() == MouseEvent.BUTTON1) 
		                              onClick(console,JItemPanel.this.locator$);
		            	  if(me.getButton() == MouseEvent.BUTTON3) {
		            		   popup=getPopup(console,JItemPanel.this.locator$);
		            		  if(popup==null)
                                  onClick(console,JItemPanel.this.locator$);
		            		  else {
		            			  Point p=me.getLocationOnScreen();
		            			  popup.setLocation(p.x+10,p.y+10);
		            			  popup.setVisible(true);
		            		  }
		            	  }
		              } 
		          	@Override
		          	public void mouseClicked(MouseEvent e) {
		          	}
		          	@Override
		          	public void mouseReleased(MouseEvent e) {
		          		title.setBorder(new EmptyBorder(1, 1, 1, 1));
		          	}
		            }); 
	      		 title.setAlignmentX(Component.LEFT_ALIGNMENT);
	      		add(title,BorderLayout.WEST );
	            String iconFile$=locator.getProperty(IconLoader.ICON_FILE);
	      		if(iconFile$!=null){
	        	  icon =IconLoader.getImageIcon(console,locator$);
	        	if(icon!=null)
	        	     title.setIcon(icon); 
	          }
	      		
	          popup=getPopup(console,locator$);
	          
		}catch(Exception e){
			LOGGER.severe(e.toString());
			
		}
	}
	public String getInstance() {
		  if(locator$==null)
			  return null;
		  return Locator.getProperty(locator$, JContext.INSTANCE);
	  }
	public String getLocator(){
	if(locator$==null)
		return null;
	if(checkbox!=null)
		if(checkbox.isSelected())
		   locator$=Locator.append(locator$,Locator.LOCATOR_CHECKED , Locator.LOCATOR_TRUE);
		else
			locator$=Locator.append(locator$,Locator.LOCATOR_CHECKED , Locator.LOCATOR_FALSE);
	if(display$!=null)
		locator$=Locator.append(locator$,JContext.DISPLAY ,display$);
	return locator$;
}
public void setLocator(String locator$){
	this.locator$=locator$;
}
public String getTitle(){
	title.setText(title$);
	return title$;
}
boolean isCheckable(){
	if(checkbox!=null)
		return true;
	else
		return false;
}
public boolean isChecked(){
	if(checkbox==null)
		return false;
	return checkbox.isSelected();
}
public void setChecked(boolean checked){
	if(checkbox!=null)
		checkbox.setSelected(checked);
}
public void hidePopup() {
	if(popup!=null) 
		popup.setVisible(false);
}
public String  getDisplay() {
	return console.getDisplayKey(this);
}
public void  setDisplay(String display$) {
	this.display$=display$;
}
public static String classLocator() {
	Properties locator=new Properties();
	locator.put(Locator.LOCATOR_TITLE, "Item");
	locator.put(JContext.PARENT,JAdminPanel.KEY);
	locator.put(JContext.DEFAULT_PARENT,JAdminPanel.KEY);
	locator.put(ITEM_CHECKABLE,Locator.LOCATOR_TRUE);
	locator.put(ITEM_CHECKED,Locator.LOCATOR_FALSE);
	locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
	locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	locator.put(IconLoader.ICON_FILE,"item.png");
	String locator$=Locator.toString(locator);
	return locator$;
}
}
