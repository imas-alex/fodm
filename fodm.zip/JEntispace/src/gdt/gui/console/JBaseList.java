package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

//import gdt.base.generic.BaseHandler;
import gdt.base.facet.BaseHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

import gdt.gui.generic.FileTool;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
import gdt.gui.generic.JTextEditor;

public class JBaseList extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String BASES="bases";
	public static final String NEW_BASE="new base";
	public static final String KEY="_BXQqfdsL1aRE5K0dHximPrEqbHc";
	public static final String MODE="mode";
	public static final String MODE_ADD="add";
	public static final String MODE_MERGE="merge";
	public static final String MODE_REPLACE="replace";
	public static final String CLEAR_CLOPBOARD="clear";
	//public static final String SHOW_ADMIN="show admin";
	public static final String DIRECTORY="directory";
	String directory$;
	public JBaseList(JMainConsole console,String locator$) {
		super(console,locator$);
		//System.out.println("JBaseList:locator="+locator$);
		reply$=Locator.getProperty(locator$, REPLY);
		directory$=Locator.getProperty(locator$,DIRECTORY);
		//System.out.println("JBaseList:directory="+directory$);
		if(console.getEntigrator()==null)
			console.setSubtitle(directory$);
		else
			console.setSubtitle(console.getEntigrator().getEntihome());
		if(reply$!=null) {
			String instanceLocator$=locator$;
			instanceLocator$=Locator.remove(instanceLocator$, REPLY);
			reply(console,instanceLocator$);
			return;
		}
		JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);	
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		String directory$=Locator.getProperty(locator$,DIRECTORY);
		Properties locatorItem=new Properties();
		locatorItem.put(JItemPanel.ITEM_CHECKABLE, false);
		locatorItem.put(JItemPanel.ITEM_CHECKED, false);
		locatorItem.put(IconLoader.ICON_FILE,"base.png");
	 	locatorItem.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locatorItem.put(PARENT, JAdminPanel.KEY);
		String locatorItem$;
		if(directory$ !=null) {
    		String  [] ba= BaseHandler.listDatabases(new File(directory$));
    		if(ba==null||ba.length<1) {
    			System.out.println("JBaseList:getItems: no bases in directory="+directory$);
    			return null;
    		}
    		//System.out.println("JBaseList:getItems: ba="+ba.length);
    		ArrayList<JBaseItem>ipl=new ArrayList<JBaseItem>();
    		for(String b:ba) {
    			//System.out.println("JBaseList:getItems: b="+b);
    			if(b==null)
    				continue;
    			locatorItem.put(Locator.LOCATOR_TITLE,b);
    			locatorItem$=Locator.toString(locatorItem);
    			ipl.add(new JBaseItem(console,locatorItem$));
    		}
    		JBaseItem[] bia=new JBaseItem[ipl.size()];
    		ipl.toArray(bia);
    		return sortItems(bia);
    		
	   }else {
		   Sack settings=console.getEntigrator().getSettings();
		   String[] ba=settings.elementListNames("base");
		   if(ba==null||ba.length<1)
			   return null;
		   ArrayList<JBaseItem>ipl=new ArrayList<JBaseItem>();
		   for(String b:ba) {
   			if(b==null)
   				continue;
   			locatorItem.put(Locator.LOCATOR_TITLE,b);
   			locatorItem$=Locator.toString(locatorItem);
   			ipl.add(new JBaseItem(console,locatorItem$));
   		}
   		JBaseItem[] bia=new JBaseItem[ipl.size()];
   		ipl.toArray(bia);
   		return sortItems(bia);
	   }
	}
	@Override
	public String getClassLocator() {
	     return classLocator();
	}
	public static String classLocator() {
		 Properties locator=new Properties();
	     locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	     locator.put(CONTEXT_CLASS,"gdt.gui.console.JBaseList");
	     locator.put(Locator.LOCATOR_TITLE,"Bases");
	     locator.put(IconLoader.ICON_FILE,"base.png");
	 	 locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
	      locator.put(NON_REMOVABLE,Locator.LOCATOR_TRUE);
	      locator.put(PARENT,JAdminPanel.KEY);
	      locator.put(INSTANCE,KEY);
	  return Locator.toString(locator);
	}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Select all");
		menu=removeItem(menu,"Unselect all");
		menu=removeItem(menu,"Delete");
		JMenuItem newItem = new JMenuItem("New");
		newItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String editorLocator$=JTextEditor.classLocator();
				editorLocator$=Locator.append(editorLocator$,JTextEditor.IN_TEXT,"NewBase");
				String thisLocator$=getLocator();
				thisLocator$=Locator.append(thisLocator$, ACTION,NEW_BASE);
				thisLocator$=Locator.append(thisLocator$,REPLY,Locator.LOCATOR_TRUE);
				thisLocator$=Locator.append(thisLocator$,DIRECTORY,directory$);
				editorLocator$=Locator.append(editorLocator$,PARENT,getInstance());
				Entigrator entigrator=console.getEntigrator();
				SessionHandler.putLocator(entigrator, thisLocator$);
				JTextEditor  textEditor=new JTextEditor (console,editorLocator$);
				replace(console,textEditor);
			}
				});
		menu.add(newItem);
		if(directory$==null)
			newItem.setEnabled(false);
		return menu;
		}
	public static Entigrator setDefaultBase() {
		Entigrator defaultEntigrator=null;
		File defaultHome=new File(System.getProperty("user.home")+"/.entigrator/default");
		if(!defaultHome.exists()) 
			defaultEntigrator=BaseHandler.createBlankDatabase(System.getProperty("user.home")+"/.entigrator/default");
			defaultEntigrator=new Entigrator(defaultHome.getPath());
			defaultEntigrator.rebuildIndex();
			return defaultEntigrator;
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		Properties locator=Locator.toProperties(locator$);
		String action$=locator.getProperty(ACTION);
		if(NEW_BASE.equals(action$)) {
			String newBase$=locator.getProperty(JTextEditor.OUT_TEXT);
			String directory$=locator.getProperty(DIRECTORY);
//			System.out.println("JBaseList:reply:new base="+newBase$+"  directory="+directory$);
			if(directory$==null) {
				System.out.println("JBaseList:reply:directory is null");
				return locator$;
			}
			  Entigrator entigrator=console.getEntigrator();
			  if(entigrator!=null)
				  entigrator.close();
	    	  Entigrator newEntigrator=BaseHandler.createBlankDatabase(directory$+"/"+newBase$);
	    	  console.setEntigrator(directory$+"/"+newBase$);
	    	  String adminLocator$= JAdminPanel.classLocator();
			  adminLocator$=Locator.append(adminLocator$, Locator.LOCATOR_SUBTITLE, newEntigrator.getEntihome());
			  SessionHandler.putLocator(entigrator, adminLocator$);
			  return adminLocator$;
	    	}
		return locator$;
	}
private   class JBaseItem extends JItemPanel{
	private static final long serialVersionUID = 1L;
	public JBaseItem(JMainConsole console, String locator$) {
		super(console, locator$);
	}
	public JPopupMenu getPopup(JMainConsole console,String locator$) {
		//System.out.println("JCustomerListList:getPopup:locator="+getLocator()); 
		popup=new JPopupMenu();
			JMenuItem deleteItem=new JMenuItem("Delete");
			 deleteItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						//System.out.println("JLinkList:popup:delete:locator="+locator$);
						popup.setVisible(false);	
						int response = JOptionPane.showConfirmDialog(JBaseList.this, "Delete database ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
						if (response == JOptionPane.YES_OPTION) {
						try {
							String base$=Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
							System.out.println("JBaseList:popup:delete:base="+base$);
							FileTool.delete(base$);
							JBaseList.this.rebuild(console);
						}catch(Exception ee) {
							System.out.println("JCustomerList:popup:delete:"+ee.toString());	
						}
			  		    }
					}
					});
				popup.add(deleteItem);
				JMenuItem settingsItem=new JMenuItem("Settings");
				settingsItem.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							//System.out.println("JLinkList:popup:delete:locator="+locator$);
							popup.setVisible(false);	
						try {
								String base$=Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
								Properties baseLocator=new Properties();
								baseLocator.put(Entigrator.ENTIHOME,base$);
								String baseLocator$=Locator.toString(baseLocator);
								JSettingsDialog settingsDialog=new JSettingsDialog(console,baseLocator$);
								//settingsDialog.setPreferredSize(new Dimension(200,300));
								settingsDialog.setLocationRelativeTo(JBaseList.this);
								settingsDialog.setVisible(true);
							}catch(Exception ee) {
								System.out.println("JCustomerList:popup:settingse:"+ee.toString());	
							}
						}
						});
					popup.add(settingsItem);	
				JMenuItem rememberItem=new JMenuItem("Remember");
				 rememberItem.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							//System.out.println("JLinkList:popup:delete:locator="+locator$);
							popup.setVisible(false);
							Sack settings=console.getEntigrator().getSettings();
						//	System.out.println("JBaseList:remember:instance="+settings.getProperty("label"));
							
							try {
							//	System.out.println("JBaseList::remember:locator="+locator$);
								String base$=Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
								if(!settings.existsElement("base"))
									settings.createElement("base");
								String[]sa=base$.split("/");
								String name$=sa[sa.length-1];
								settings.putElementItem("base", new Core(null,base$,name$));
								console.getEntigrator().putEntity(settings);
							}catch(Exception ee) {
								System.out.println("JBaseList:remember:"+ee.toString());	
							}
						}
						});
					popup.add(rememberItem);
				    if(directory$==null)
				    	rememberItem.setEnabled(false);
				    JMenuItem forgetItem=new JMenuItem("Forget");
					forgetItem.addActionListener(new ActionListener() {
					@Override
							public void actionPerformed(ActionEvent e) {
								//System.out.println("JLinkList:popup:delete:locator="+locator$);
								popup.setVisible(false);	
								int response = JOptionPane.showConfirmDialog(JBaseList.this, "Forget database ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
								if (response == JOptionPane.YES_OPTION) {
								try {
									Sack settings=console.getEntigrator().getSettings();
								//	System.out.println("JBaseList:popup:forget:locator="+locator$);
									String base$=Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
								//	System.out.println("JBaseList:popup:forget:base="+base$);
									settings.removeElementItem("base", base$);
									JBaseList.this.rebuild(console);
								}catch(Exception ee) {
									System.out.println("JCustomerList:popup:delete:"+ee.toString());	
								}
					  		    }
							}
							});
						Sack settings=console.getEntigrator().getSettings();
						if(settings!=null) {
							String base$=Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
							if(settings.getElementItem("base", base$)!=null)
									popup.add(forgetItem);
						}
			if(SessionHandler.hasCopy(console.getEntigrator())) {
				JMenuItem pasteItem=new JMenuItem("Paste");
				 pasteItem.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							//System.out.println("JLinkList:popup:delete:locator="+locator$);
							popup.setVisible(false);	
							System.out.println("JBaseList:popup:paste");
							JPasteDialog pasteDialog=new JPasteDialog(console,locator$);
							pasteDialog.setPreferredSize(new Dimension(200,300));
							pasteDialog.setLocationRelativeTo(JBaseList.this);
							pasteDialog.setVisible(true);
						}
						});
				 popup.add(pasteItem);
				 if(directory$==null)
				    	pasteItem.setEnabled(false);
			}
		 return popup;
	}
	@Override
	public void onClick(JMainConsole console, String locator$) {
		//System.out.println("JBaseList:baseitem click:locator="+locator$);
		if(console.getEntigrator()!=null) {
			//System.out.println("JBaseList:baseitem click:0");
			console.getEntigrator().close();
		}
		
		String path$=Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
		System.out.println("JBaseList:baseitem click:path="+path$);
		console.setEntigrator(path$);
		SessionHandler.getSession(console.getEntigrator());			
		console.replaceContext(new JAdminPanel(console,null));
	}
}
public static void pasteEntities(JMainConsole console,String locator$) {
//	System.out.println("JBaseList:paste entities:locator="+locator$);
	String targetBase$=Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
	String mode$=Locator.getProperty(locator$, MODE);
	Entigrator targetEntigrator=new Entigrator(targetBase$);
	Entigrator sourceEntigrator=console.getEntigrator();
	String[] ea=SessionHandler.listCopiedEntities(console.getEntigrator());
	ArrayList<String>el=new ArrayList<String>();
	if(ea==null)
		return;
	String[]la;
	for(String e:ea) {
		el.add(e);
		la=BaseHandler.allLinks(sourceEntigrator, e);
		if(la!=null)
			for(String l:la)
				el.add(l);
	}
	for(String e:el) {
			pasteEntity(sourceEntigrator, targetEntigrator, e,mode$);
		}
}
private static void pasteEntity(Entigrator sourceEntigrator,Entigrator targetEntigrator, String entityKey$,String mode$) {
//	System.out.println("JBaseList:paste entity:key="+entityKey$);
	if(targetEntigrator.getLabel(entityKey$)!=null) {
		if(MODE_ADD.equals(mode$))
			return;
		String sourceFolder$=sourceEntigrator.getEntihome()+"/"+entityKey$;
		File sourceFolder=new File(sourceFolder$);
		if(sourceFolder.exists()) {
			String targetFolder$=targetEntigrator.getEntihome()+"/"+entityKey$;
			File targetFolder=new File(targetFolder$);
			if(targetFolder.exists()) {
				if(MODE_REPLACE.equals(mode$))
					FileTool.clear(targetFolder$);
				try {
					FileTool.copyAll(sourceFolder$, targetFolder$);
				}catch(Exception e) {
					System.out.println("JBaseList:paste entity:"+e.toString());
				}
			}else {
				try {
					//System.out.println("JBaseList:paste entity:target folder="+targetFolder.getPath());
					targetFolder.mkdir();
					FileTool.copyAll(sourceFolder$, targetFolder$);
				}catch(Exception e) {
					System.out.println("JBaseList:paste entity:"+e.toString());
				}
			}
		}
	}else {
		Sack entity=sourceEntigrator.getEntity(entityKey$);
		targetEntigrator.putEntity(entity);
		String targetFolder$=targetEntigrator.getEntihome()+"/"+entityKey$;
	//	System.out.println("JBaseList:paste entity:add:target folder="+targetFolder$);
		File targetFolder=new File(targetFolder$);
		String sourceFolder$=sourceEntigrator.getEntihome()+"/"+entityKey$;
//		System.out.println("JBaseList:paste entity:add:source folder="+sourceFolder$);
		try {
			File sourceFolder=new File(sourceFolder$);
			if(sourceFolder.exists()) {
			if(!targetFolder.exists()) {
				targetFolder.mkdir();
			}
			FileTool.copyAll(sourceFolder$, targetFolder$);
			}
		}catch(Exception e) {
			System.out.println("JBaseList:paste entity:"+e.toString());
		}
	}
}

@Override
public boolean handleDone() {
	JContext.displayInstance(console, parent$);
	return true;
}
}
