package gdt.gui.console;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Instant;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.facet.PerspectiveMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;

public class JDisplayList extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	JMenuItem disposeItem;
	JMenuItem toFrontItem;
	public JDisplayList(JMainConsole console) {
		super(console);
		JItemPanel[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa) {
				addItem(ip);
			}					    	  //   sl.add(di$);
	}
	public JDisplayList(JMainConsole console,String locator$) {
		super(console,locator$);
		JItemPanel[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa) {
				addItem(ip);
			}
	}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		
		menu=removeItem(menu,"Display");
		//menu=removeItem(menu,"Select all");
		//menu=removeItem(menu,"Unselect all");
		menu=removeItem(menu,"Delete");
		menu.addMenuListener(new MenuListener(){
		     @Override
		     public void menuCanceled(MenuEvent e) {
		     		     }
		     @Override
		     public void menuDeselected(MenuEvent e) {
		    	 
		    	 //disposeItem.setEnabled(false);		    
		     }
			@Override
			public void menuSelected(MenuEvent arg0) {
			//	System.out.println("JDisplayList:menu selected");
				if(hasChecked()) {
					disposeItem.setEnabled(true);
					toFrontItem.setEnabled(true);
				}
				else {
					disposeItem.setEnabled(false);
					toFrontItem.setEnabled(false);
				}
				}
			});
		JMenuItem saveItem = new JMenuItem("Save");
		saveItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("JDisplayList:save:il="+il.size());
			    if(il!=null&&il.size()>0) {
			    //	String contextKey$;
			    	ArrayList<String>sl=new ArrayList<String>();
			    	for(JItemPanel ip:il) {
			    		String di$=((JDisplayItem)ip).getLocator();
			    		if(!ip.isChecked())
			    			continue;
			    		   System.out.println("JDisplayList:save:display locator="+di$);
			    	     sl.add(di$);
			    	}
			    if(sl!=null&&sl.size()>0) {	
			      String[] sa=new String[sl.size()];
			      sl.toArray(sa);					    	  //   sl.add(di$);
			      save(sa);
			    }
			    
			    }
			}
			});
		menu.add(saveItem);
		disposeItem = new JMenuItem("Dispose");
		disposeItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
                	int response = JOptionPane.showConfirmDialog(JDisplayList.this, "Dispose selected displays  ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		  		    if (response == JOptionPane.NO_OPTION)
		  		    	return;
				if(il!=null&&il.size()>0) {
					    //	String contextKey$;
					    	ArrayList<String>sl=new ArrayList<String>();
					    	for(JItemPanel ip:il) {
					    		String di$=((JDisplayItem)ip).getLocator();
					    		if(!ip.isChecked())
					    		continue;
					    		   System.out.println("JDisplayList:dispose:display locator="+di$);
					    		   String displayKey$=Locator.getProperty(di$, DISPLAY);
					    		   if(displayKey$==null)
					    			   continue;
					    		   JDisplay display=console.getDisplay(displayKey$);
					    		   if(display!=null)
					    			   display.dispose();
					    		   console.removeDisplay(displayKey$);
					    	}
				 
			}}
		});
		menu.add(disposeItem);
		toFrontItem = new JMenuItem("To front");
		toFrontItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(il!=null&&il.size()>0) {
				    	ArrayList<String>sl=new ArrayList<String>();
				    	for(JItemPanel ip:il) {
				    		String di$=((JDisplayItem)ip).getLocator();
				    		if(!ip.isChecked())
				    		continue;
				    		String displayKey$=Locator.getProperty(di$, DISPLAY);
				    		if(displayKey$==null)
				    			   continue;
				    		JDisplay display=console.getDisplay(displayKey$);
				    		   if(display!=null) {
				    			   display.setVisible(true);
				    			   display.toFront();
				    		   }
				    		 
				    	}
			 
		}
			}
		});
		menu.add(toFrontItem);
		return menu;
	}
	private void save(String[] da) {
		try {
		//String perspectiveLocator$=PerspectiveHandler.classLocator();
		Calendar cal = Calendar.getInstance();
	    cal.setTime(Date.from(Instant.now()));
	    String perspective$ = String.format(
	             "%1$tY-%1$tm-%1$td-%1$tk-%1$tS-%1$tp", cal);
	    PerspectiveMaster perspectiveMaster=new PerspectiveMaster(console,null);
	    Sack perspective=perspectiveMaster.createEntity(console.getEntigrator(), perspective$);
	    perspective.createElement("perspective");
	    for(String d$:da) {
	    	System.out.println("JDisplayList:save:d="+d$);
	    	String displayKey$=Locator.getProperty(d$,JDisplay.DISPLAY_KEY);
	    	System.out.println("JDisplayList:display key="+displayKey$);
	    	JDisplay display=console.getDisplay(displayKey$);
	    	if(display!=null) {
	    	String displayLocator$=display.getLocator();
	        if(displayLocator$!=null)
	        	perspective.putElementItem("perspective", new Core(null,displayKey$,displayLocator$));
	    	}
	    }
	    console.getEntigrator().putEntity(perspective);
		}catch(Exception e) {
			System.out.println("JDisplayList:save:"+e.toString());	
		}
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		JDisplay[] displays=console.getDisplays();
		if(displays==null||displays.length<1)
			return null;
		System.out.println("JPerspectiveList:getItems:displays="+displays.length);
		JItemPanel ip;
		Properties props=new Properties();
		props.put(JItemPanel.ITEM_CHECKABLE,Locator.LOCATOR_TRUE);
		props.put(JItemPanel.ITEM_CHECKED,Locator.LOCATOR_FALSE);
		String itemLocator$=Locator.toString(props);
		JContext context;
		String context$;
		ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
		String title$;
		String entity$;
		for(JDisplay display:displays) {
			context=display.getContext();
			if(context==null) {
				System.out.println("JPerspectiveList:getItems:no context");
				continue;
			}
			
			String contextLocator$=context.getLocator();
			System.out.println("JPerspectiveList:getItems:context locator="+contextLocator$);
			context$=Locator.getProperty(contextLocator$, Locator.LOCATOR_TITLE);
			entity$=Locator.getProperty(contextLocator$, Entigrator.ENTITY_LABEL);
			title$=context$+"("+entity$+")";
					System.out.println("JPerspectiveList:getItems:title="+title$);
			itemLocator$=Locator.append(itemLocator$, Locator.LOCATOR_TITLE, title$);
			itemLocator$=Locator.append(itemLocator$, JDisplay.DISPLAY_KEY, display.getKey());
			ip=new JDisplayItem(console,itemLocator$);	
			ipl.add(ip);
		}
		JItemPanel[] ipa=new JItemPanel[ipl.size()];
		ipl.toArray(ipa);
		return sortItems(ipa);

	}
	@Override
	protected void handleDelete(JItemPanel item) {
		String displayKey$=Locator.getProperty(item.getLocator(), JDisplay.DISPLAY_KEY);
		console.removeDisplay(displayKey$);
		rebuild(console);
	};
public static String classLocator() {
	 Properties locator=new Properties();
     locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
     locator.put(CONTEXT_CLASS,"gdt.gui.console.JDisplayList");
     locator.put(Locator.LOCATOR_TITLE,"Display");
     locator.put(IconLoader.ICON_FILE,"display.png");
 	 locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
      locator.put(NON_REMOVABLE,Locator.LOCATOR_TRUE);
      locator.put(PARENT,JAdminPanel.KEY);
  return Locator.toString(locator);
}
	@Override
	public String getClassLocator() {
	  return classLocator();
	}
	private   class JDisplayItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JDisplayItem(JMainConsole console, String locator$) {
			super(console, locator$);
		}
		@Override
		public String getLocator(){
			String itemLocator$=super.getLocator();
			String displayKey$=Locator.getProperty(itemLocator$, JDisplay.DISPLAY_KEY);
			if(displayKey$!=null) {
				JDisplay display=console.getDisplay(displayKey$);
				if(display!=null) {
					String displayLocator$=display.getLocator();
					itemLocator$=Locator.merge(itemLocator$, displayLocator$);
					JContext context=display.getContext();
					if(context!=null) {
						String contextLocator$=context.getLocator();
						itemLocator$=Locator.merge(itemLocator$, contextLocator$);
					}
				}
			}
			return itemLocator$;
		}
		@Override
		public JPopupMenu getPopup(JMainConsole console, String locator$) {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public void onClick(JMainConsole console, String locator$) {
			// TODO Auto-generated method stub
			
		}}

@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public boolean handleDone() {
		String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
		if(parentLocator$==null) {
			parent$=Locator.getProperty(locator$, JAllFacetsList.KEY);
		}
		//JContext.displayInstance(console, parent$);
		JContext.displayInstance(console, parent$,getDisplay());
		return true;
	}
	
}
