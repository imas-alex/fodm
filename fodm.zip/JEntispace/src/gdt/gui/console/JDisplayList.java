package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.JPopupMenu;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;

public class JDisplayList extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public JDisplayList(JMainConsole console) {
		super(console);
		JItemPanel[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa) {
				addItem(ip);
			}
	}
	public JDisplayList(JMainConsole console,String locator$) {
		super(console,locator$);
		JItemPanel[] ipa=getItems(console, locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa) {
				addItem(ip);
			}
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		try {
			Entigrator entigrator=console.getEntigrator();
			Sack session=SessionHandler.getSession(entigrator);
			Core [] ca=session.elementGet("display");
			ArrayList<JDisplayItem>dil=new ArrayList<JDisplayItem>();
			String itemLocator$;
			boolean exists;
			String diLocator$;
			if(ca!=null)
				for(Core c:ca) {
					exists=false;
					//System.out.println("JDisplayList:getItems::locator="+c.value);
					String title$=Locator.getProperty(c.value,Locator.LOCATOR_TITLE);
		            String entity$=Locator.getProperty(c.value,Entigrator.ENTITY_LABEL);
					if(entity$!=null)
						if(!title$.contains(entity$))
						  title$=title$+"("+entity$+")";
					for(JDisplayItem di:dil) {
						diLocator$=di.getLocator();Locator.getProperty(diLocator$, Locator.LOCATOR_TITLE );
						if(title$.equals(Locator.getProperty(diLocator$, Locator.LOCATOR_TITLE ))) {
							exists=true;
							break;
						}
					}
					itemLocator$=Locator.append(c.value, Locator.LOCATOR_TITLE, title$);
					itemLocator$=Locator.append(itemLocator$, JItemPanel.ITEM_CHECKABLE, Locator.LOCATOR_TRUE);
					if(!exists)
					   dil.add(new JDisplayItem( console, itemLocator$));
				}
			JDisplayItem [] dia=new JDisplayItem [dil.size()];
			dil.toArray(dia);
			return dia;
		}catch(Exception e) {
			System.out.println("JDisplayList:getItems:"+e.toString());
		}
	 return null;
	}
	@Override
	protected void handleDelete(JItemPanel item) {
		String displayKey$=Locator.getProperty(item.getLocator(), JDisplay.DISPLAY_KEY);
		console.removeDisplay(displayKey$);
		rebuild(console);
	};
public static String classLocator() {
	 Properties locator=new Properties();
     locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
     locator.put(CONTEXT_CLASS,"gdt.gui.console.JDisplayList");
     locator.put(Locator.LOCATOR_TITLE,"Display");
     locator.put(IconLoader.ICON_FILE,"display.png");
 	 locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
      locator.put(NON_REMOVABLE,Locator.LOCATOR_TRUE);
      locator.put(PARENT,JAdminPanel.KEY);
  return Locator.toString(locator);
}
	@Override
	public String getClassLocator() {
	  return classLocator();
	}
private   class JDisplayItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JDisplayItem(JMainConsole console, String locator$) {
			super(console, locator$);
		}
		public JPopupMenu getPopup(JMainConsole console,String locator$) {
		return null;	
		}
		@Override
		public void onClick(JMainConsole console, String locator$) {
		//	System.out.println("JDisplayItem:onClick:locator="+locator$);
			try {
				JContext context=JContext.build(console, locator$);
				if(context==null) {
						System.out.println("JDisplayItem:onClick:cannot create context for locator="+locator$);
						return;
				}
				JDisplay display=new JDisplay (console,context);
				display.setVisible(true);
			}catch(Exception e) {
				System.out.println("JDisplayItem:onClick:locator="+locator$+"  error="+e.toString());
			}
		}
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public boolean handleDone() {
		JContext.displayInstance(console, parent$);
		return true;
	}
	
}
