package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.HashMap;
import java.util.Properties;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import java.util.ArrayList;

import gdt.base.facet.ProjectHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JDisplay;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JMainConsole {
    public final static String ACTION_NEW_BASE="action new base";
	public JFrame frmEntigrator;
	private JMenu contextMenu;
	private JMenuBar menuBar;
	JLabel subtitle;
	JMenu adminMenu;
	Entigrator entigrator=null;;
	static boolean debug=false;
	HashMap<String,JDisplay> displays=new HashMap<String,JDisplay>();
	public JMainConsole() {
		frmEntigrator = new JFrame();
		frmEntigrator.setLayout(new BorderLayout());
		frmEntigrator.setTitle("Entigrator");
		frmEntigrator.setBounds(100, 100, 450, 300);
		frmEntigrator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		subtitle = new JLabel("");
		subtitle.setAlignmentX(Component.RIGHT_ALIGNMENT);
		subtitle.setLabelFor(subtitle);
		subtitle.setBorder(new BevelBorder(BevelBorder.RAISED));
		subtitle.setOpaque(true);
		 subtitle.setBackground(Color.BLACK);
		 subtitle.setForeground(Color.WHITE);
		menuBar = new JMenuBar();
		frmEntigrator.setJMenuBar(menuBar);
		JMenu mainMenu = new JMenu("Main");
		menuBar.add(mainMenu);
		JMenuItem basesItem = new JMenuItem("Bases");
		basesItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			//	System.out.println("MainConsole:open");  
				JFileChooser chooser = new JFileChooser(); 
			    chooser.setCurrentDirectory(new java.io.File(System.getProperty("user.home")));
			    chooser.setDialogTitle("Bases directory");
			    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			    chooser.setAcceptAllFileFilterUsed(false);
			    
			    if (chooser.showOpenDialog(frmEntigrator) == JFileChooser.APPROVE_OPTION) { 
			    	File selection=chooser.getSelectedFile();
			    	String basesLocator$=JBaseList.classLocator();
			    	//System.out.println("JMainConsole:bases:base locaotr="+JBaseList.classLocator()+" selection="+selection.getPath());
			    	basesLocator$=Locator.append(basesLocator$, JBaseList.DIRECTORY, selection.getPath());
			    	JBaseList baseList=new JBaseList(JMainConsole.this,basesLocator$);
			    	JMainConsole.this.replaceContext(baseList);
			      }
			}
		} );
		mainMenu.add(basesItem);
		JMenuItem console= new JMenuItem("Console");
		console.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String adminLocator$= JAdminPanel.classLocator();
				adminLocator$=Locator.append(adminLocator$, Locator.LOCATOR_SUBTITLE, getEntigrator().getEntihome());
				//System.out.println("JMainConsole:Admin:adminLocator="+adminLocator$);
				JAdminPanel adminPanel=new JAdminPanel(JMainConsole.this,adminLocator$);
				SessionHandler.putLocator(entigrator,adminLocator$);
				replaceContext(adminPanel);
			}
		} );
		mainMenu.add(console);
		JMenuItem rebuild= new JMenuItem("Rebuild");
		rebuild.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int response = JOptionPane.showConfirmDialog(frmEntigrator, "Rebuild index ?", "Confirm",
				        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			   if (response == JOptionPane.YES_OPTION) { 
			   if(entigrator!=null) {
				  Sack session=SessionHandler.getSession(entigrator);
				  if(session!=null)
					  entigrator.deleteEntity(session.getKey());
				  SessionHandler.forgetOld(getEntigrator(),0);
				  entigrator.rebuildIndex();
			   }
			   }
			}
		} );
		mainMenu.add(rebuild);
		mainMenu.addSeparator();  
   	   JMenuItem importItem = new JMenuItem("Import");
  		   importItem.addActionListener(new ActionListener() {
  			@Override
  			public void actionPerformed(ActionEvent e) {
  			  System.out.println("JMainConsole:import");
  			JFileChooser chooser = new JFileChooser(); 
  		    chooser.setCurrentDirectory(new java.io.File(System.getProperty("user.home")));
  		    chooser.setDialogTitle("Bases directory");
  		    chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
  		    chooser.addChoosableFileFilter(new ProjectHandler.ZipFilter());
  		    chooser.setAcceptAllFileFilterUsed(true);
  		    if (chooser.showOpenDialog(frmEntigrator) == JFileChooser.APPROVE_OPTION) { 
  		    	File selection=chooser.getSelectedFile();
  		    	String zip$=selection.getPath();
  		    	ProjectHandler.unzip(zip$, entigrator);
  		      }	
  			}
  		} );
  		mainMenu.add(importItem);
  		JMenuItem exportItem = new JMenuItem("Export");
		   exportItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JExportDialog exportDialog=new JExportDialog(JMainConsole.this);
				exportDialog.setLocationRelativeTo(JMainConsole.this.frmEntigrator);
				exportDialog.setVisible(true);
			}
	  		} );
		mainMenu.add(exportItem);
		mainMenu.addSeparator();
		
		JMenuItem settings = new JMenuItem("Settings");
		settings.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  
				Properties baseLocator=new Properties();
				baseLocator.put(Entigrator.ENTIHOME,entigrator.getEntihome());
				String baseLocator$=Locator.toString(baseLocator);
				JSettingsDialog settingsDialog=new JSettingsDialog(JMainConsole.this,baseLocator$);
				settingsDialog.setLocationRelativeTo(frmEntigrator);
				settingsDialog.setVisible(true);
			}
		} );
		mainMenu.add(settings);
		JMenuItem exit = new JMenuItem("Exit");
		exit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			  //System.out.println("JMainConsole:exit");
				if(entigrator!=null) {
		    	    JContext context=getContext();
		    	    if(context!=null)
		    	    	 SessionHandler.saveLocator(context.getLocator());
		    	     SessionHandler.store(entigrator);
		    	     entigrator.close();
				}
				 JDisplay [] da=getDisplays();
	    	     //System.out.println("JMainConsole:exit:da="+da.length);
					for(JDisplay d:da) {
						d.dispose();
					}   
			   frmEntigrator.dispose();
			}
		} );
		mainMenu.add(exit);
   		mainMenu.addMenuListener(new MenuListener(){
		     @Override
		     public void menuCanceled(MenuEvent e) {
		     		     }
		     @Override
		     public void menuDeselected(MenuEvent e) {
		     		     }
			@Override
			public void menuSelected(MenuEvent arg0) {
				if(JMainConsole.this.entigrator==null) {
					rebuild.setEnabled(false);
					importItem.setEnabled(false);
					console.setEnabled(false);
					exportItem.setEnabled(false);
					settings.setEnabled(false);
				}else {
					importItem.setEnabled(true);
					rebuild.setEnabled(true);
					console.setEnabled(true);
					exportItem.setEnabled(true);
					settings.setEnabled(true);
				}
			}
		 });
	}
	public Entigrator getEntigrator() {
		return entigrator;
	}
	public void setSubtitle(String subtitle$) {
		subtitle.setText(subtitle$);
	}
	public void setTitle(String title$) {
		frmEntigrator.setTitle(title$);
	}
	public int getFootSize() {
		return subtitle.getHeight();
	}
	public void setTitle(JContext context) {
		try {
			String locator$= context.getLocator();
//			System.out.println("JMainConsole:setTitle:context locator="+locator$);
			String title$=Locator.getProperty(locator$, Locator.LOCATOR_TITLE);
			if(title$==null)
				return;
			String display$=getDisplayKey(context);
			if(display$==null) {
				setTitle(title$);
				return;
			}
			JDisplay display=getDisplay(display$);
			if(display!=null) {
	//			System.out.println("JMainConsole:setTitle:found display="+display$);
				display.setTitle(title$);
			}
			
		}catch(Exception e) {
			System.out.println("JMainConsole:setTitle:"+e.toString());
		}
	}
	
	public void setEntigrator(String basePath$) {
		//System.out.println("JMainConsole:setEntigrator:base path="+basePath$);
		try {
		if(basePath$==null) {
			return;
		}
		//System.out.println("JMainConsole:setEntigrator:0"); 
		entigrator=new Entigrator(basePath$);
		if(entigrator==null)
			System.out.println("JMainConsole:setEntigrator:cannot set entitgrator path="+basePath$); 
		else {
			SessionHandler.clearFacets(entigrator);
			FacetMaster.setDefaultFacets(this);
			FacetMaster.setDefaultContexts(this);
			//System.out.println("JMainConsole:setEntigrator:default facets finished"); 
			try{FacetMaster.setModuleFacets(this);}catch(Exception ee) {
				System.out.println("JMainConsole:setEntigrator:cannot set module facets=  "+ee.toString()); 
			}
		//	System.out.println("JMainConsole:setEntigrator:module facets finished"); 
			entigrator.getEntityAtLabel("actual");
		}
		}catch(Exception e) {
			System.out.println("JMainConsole:setEntigrator:"+e.toString());	
		}
	}
    public static void main( String[] args) {
		EventQueue.invokeLater(new Runnable() {
		public void run() {
				try {
					final JMainConsole console = new JMainConsole();
					console.frmEntigrator.setVisible(true);
					console.frmEntigrator.addWindowListener(new java.awt.event.WindowAdapter() {
					    public void windowClosing(WindowEvent winEvt) {
			//		    	System.out.println("JMainConsole:closing");
					    	  Entigrator entigrator=console.getEntigrator();
					    	  if(entigrator!=null) { 
					    		  SessionHandler.clearInstances(console.getEntigrator());
					    	     JContext context=console.getContext();
					    	     if(context!=null)
						    	     SessionHandler.saveLocator(context.getLocator());
						    	     SessionHandler.store(entigrator);
					    	     entigrator.close();
					    	     JDisplay [] da=console.getDisplays();
					    	     System.out.println("JMainConsole:closing:da="+da.length);
									for(JDisplay d:da) {
										d.dispose();
									}   
					    	  console.frmEntigrator.dispose();
					    	  }else
					    		  System.out.println("JMainConsole:closing:entigrator is null"); 
					        System.exit(0);
					    }
					    public void windowActivated(WindowEvent e) {
					    
					    }
					    public void windowDeactivated(WindowEvent e){
					    
					    }
					});
					String path$=System.getProperty("user.home")+"/.entigrator/session";
					Sack session=null;
					File file=new File(path$);
					if(file.exists()) 
					     session=Sack.readXml(path$);
				   String currentLocator$=null;
				   if(session!=null) {
					   String entihome$=session.getAttributeAt("entihome");
					   File entihome=new File(entihome$);
					   if(entihome$!=null&&entihome.exists()) {
						  console.setEntigrator(entihome$);
						  currentLocator$=SessionHandler.getCurrentLocator(console.getEntigrator());
						  currentLocator$=SessionHandler.restoreLocator();
						 // System.out.println("JMainConsole:run;current locator="+currentLocator$);
					   }
						  if(currentLocator$!=null) {
						 //  System.out.println("JMainConsole:run:current locator="+currentLocator$);
						JContext currentContext=JContext.build(console, currentLocator$);
							if(currentContext!=null)
								console.replaceContext(currentContext);
							else
								console.replaceContext(new JAdminPanel(console,null));
					   }
				   }else {
					  Entigrator entigrator=JBaseList.setDefaultBase();
					  String default$=entigrator.getEntihome();
					  entigrator.close();
				      console.setEntigrator(default$);
				      JAdminPanel adminPanel=new JAdminPanel(console,null);
				      console.replaceContext(adminPanel);
				   }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void clearContextMenu(){
	int cnt=menuBar.getComponentCount();
	ArrayList<JComponent>cl=new ArrayList<JComponent>();
	for(int i=0;i<cnt;i++){
		String menuTitle$=((JMenu)menuBar.getComponent(i)).getText();
        if("Context".equals(menuTitle$))
         	cl.add((JComponent)menuBar.getComponent(i));	
	}
	JComponent[] ca=cl.toArray(new JComponent[0]);
	if(ca!=null)
		for(JComponent jc:ca)
			menuBar.remove(jc);
}
public void clearContext() {
	frmEntigrator.getContentPane().removeAll();
	clearContextMenu();
}
public JContext getContext() {
	int cnt=frmEntigrator.getContentPane().getComponentCount();
	if(cnt>1)
		return (JContext)frmEntigrator.getContentPane().getComponent(0);
	else
		return null;
}
public void replaceContext(JContext context) {
	
	if(context==null) {
		//System.out.println("JMainConsole:replaceContext:context is null");
		JHistoryPanel historyPanel=new JHistoryPanel(this,null);
		replaceContext(historyPanel);
		return;
	}
	//else
	//	System.out.println("JMainConsole:replaceContext:new  context="+context.getLocator());
	if(JContext.INVALID.equals(context.getStatus()))
			return;
	//System.out.println("JMainConsole:replaceContext:BEGIN:context="+context.getClass().getName()+ "  locator="+context.getLocator());
	String display$=Locator.getProperty(context.getLocator(), JContext.DISPLAY);
	//System.out.println("JMainConsole:replaceContext:display="+display$);
	if(display$!=null&&display$.length()>26) {
	  JDisplay display=getDisplay(display$);
	  
	  if(display!=null) {
	//	System.out.println("JMainConsole:replaceContext:found display="+display$);
	    display.putContext(context);
		display.setVisible(true);
		return;
	}
	}
	frmEntigrator.getContentPane().removeAll();
	frmEntigrator.getContentPane().add(context);
	String title$=context.getTitle();
	if(title$!=null)
	   frmEntigrator.setTitle(title$);
//	System.out.println("JMainConsole:replaceContext:title="+title$);
	String subtitle$=context.getSubtitle();
	if(subtitle$!=null)
		subtitle.setText(subtitle$);
	//System.out.println("JMainConsole:replaceContext:subtitle="+subtitle$);
	clearContextMenu();
	try{contextMenu=context.getContextMenu();}catch(Exception ee) { 
		System.out.println("JMainConsole:replaceContext:cannot get ContextMenu="+ee.toString());
	}
	if(contextMenu!=null){
		menuBar.add(contextMenu);
		contextMenu.setVisible(true);
	}
	frmEntigrator.getContentPane().add(subtitle,BorderLayout.SOUTH );
	menuBar.revalidate();
	menuBar.repaint();
	frmEntigrator.getContentPane().revalidate();
	frmEntigrator.getContentPane().repaint();
	context.refreshDisplay();
	//System.out.println("JMainConsole:replaceContext:FINISH");
	}

public void replaceContext(JContext context,JDisplay display) {
	//
	if(frmEntigrator.getContentPane().getComponentCount()>0) {
	Component currentContext=frmEntigrator.getContentPane().getComponent(0);
	/*
	if(currentContext!=null&&currentContext instanceof JContext) {
	System.out.println("JMainConsole:replaceContext:current context="+((JContext)currentContext).getLocator());
	}
	*/
	}
	//
	if(context==null) {
		//System.out.println("JMainConsole:replaceContext:context is null");
		JHistoryPanel historyPanel=new JHistoryPanel(this,null);
		context=historyPanel;
	}
	//System.out.println("JMainConsole:replaceContext:new  context="+context.getLocator());
	//System.out.println("JMainConsole:replaceContext:BEGIN:context="+context.getClass().getName()+ "  locator="+context.getLocator());
	  if(display!=null) {
	//	System.out.println("JMainConsole:replaceContext:found display="+display$);
		display.putContext(context);
	    return;	
	}
	frmEntigrator.getContentPane().removeAll();
	frmEntigrator.getContentPane().add(context);
	String title$=context.getTitle();
	if(title$!=null)
	   frmEntigrator.setTitle(title$);
//	System.out.println("JMainConsole:replaceContext:title="+title$);
	String subtitle$=context.getSubtitle();
	if(subtitle$!=null)
		subtitle.setText(subtitle$);
	//System.out.println("JMainConsole:replaceContext:subtitle="+subtitle$);
	clearContextMenu();
	try {contextMenu=context.getContextMenu();}catch(Exception ee) {
		System.out.println("JMainConsole:replaceContext:cannot get ContextMenu="+ee.toString());
	}
	if(contextMenu!=null){
		menuBar.add(contextMenu);
		contextMenu.setVisible(true);
	}
	frmEntigrator.getContentPane().add(subtitle,BorderLayout.SOUTH );
	menuBar.revalidate();
	menuBar.repaint();
	frmEntigrator.getContentPane().revalidate();
	frmEntigrator.getContentPane().repaint();
	context.refreshDisplay();
		}

public void refreshContext(JContext context){
    if(context==null)
    	return;
	try{
	frmEntigrator.getContentPane().removeAll();
		String title$=context.getTitle();
		//System.out.println("JMainConsole:refreshContext: title="+context.getTitle()+" instance="+context.getInstance());	
	frmEntigrator.getContentPane().add(context,BorderLayout.CENTER);
	clearContextMenu();
	if(title$!=null)
	   frmEntigrator.setTitle(title$);
	String subtitle$=context.getSubtitle();
	if(subtitle$!=null)
		subtitle.setText(subtitle$);
	try {contextMenu=context.getContextMenu();}catch(Exception ee) {
		System.out.println("JMainConsole:refreshContext:cannot get ContextMenu="+ee.toString());
	}
	if(contextMenu!=null){
		menuBar.add(contextMenu);
		contextMenu.setVisible(true);
	}
	frmEntigrator.getContentPane().add(subtitle,BorderLayout.SOUTH );
	menuBar.revalidate();
	menuBar.repaint();
	frmEntigrator.getContentPane().revalidate();
	frmEntigrator.getContentPane().repaint();
	}catch(Exception e) {
		System.out.println("JMainConsole:replaceContext:"+e.toString());
	}
}

public String putDisplay(JDisplay display) {
	String displayKey$=display.getKey();
	//System.out.println("JMainConsole:putDisplay:key="+displayKey$);
	if(displays==null)
		 displays=new HashMap<String,JDisplay>();
	if(displayKey$==null) {
		displayKey$=Identity.key();
		display.setKey(displayKey$);
	}
	displays.put(displayKey$, display);
	Entigrator entigrator=getEntigrator();
	Sack session=SessionHandler.getSession(entigrator);
	//System.out.println("JMainConsole:putDisplay:1");
	//System.out.println("JMainConsole:putDisplay:locator="+display.getLocator());
	//System.out.println("JMainConsole:putDisplay:3");
	entigrator.putEntity(session);
	Component component=frmEntigrator.getContentPane().getComponent(0);
	if(component!=null) {
	//System.out.println("JMainConsole:removeDisplays:component="+component.getClass().getName());
	if(JDisplayList.class.getName().equals(component.getClass().getName())) {
		((JDisplayList)component).rebuild(this);  
	}
	}
	return displayKey$;
}
public JDisplay getDisplay(String displayKey$) {
	if(displays==null)
		return null;
	return displays.get(displayKey$);
}
public JDisplay[] getDisplays() {
	if(displays==null)
		return null;
	ArrayList<JDisplay> dl=new ArrayList<JDisplay>();
	JDisplay display;
	for (HashMap.Entry<String, JDisplay> entry: displays.entrySet())
    {
       display=displays.get(entry.getKey());
       if(display!=null)
    	   dl.add(display);
    }
	JDisplay[] da=new JDisplay[dl.size()];
	dl.toArray(da);
	//System.out.println("JMainConsole:getDisplays:da="+da.length);
	return da;
}
public String getDisplayKey(Component context) {
	if(context==null) {
		System.out.println("JMainConsole:getDisplayKey:context is null.Return");
		return null;
	}
	try {
	Component root=SwingUtilities.getRoot(context);
	if(root==null) {
		//System.out.println("JMainConsole:getDisplayKey:cannot get root for context="+context.getTitle());
		return null;
	}
	if(root.equals(frmEntigrator))
		return null;
    for (HashMap.Entry<String, JDisplay> entry: displays.entrySet())
       {
    if (root.equals(entry.getValue())) {
        return entry.getKey();
    }
       }
	}catch(Exception e) {
		System.out.println("JMainConsole:getDisplayKey:"+e.toString());
	}
return null;
}

public void removeDisplay(String displayKey$) {
	if(displays==null)
		return ;
	displays.remove(displayKey$);
	if(getEntigrator()==null) {
		System.out.println("JMainConsole:removeDisplays:entigrator is null");
		return;
	}
	Sack session=SessionHandler.getSession(getEntigrator());
	getEntigrator().putEntity(session);
	Component component=frmEntigrator.getContentPane().getComponent(0);
	if(component!=null) {
	//System.out.println("JMainConsole:removeDisplays:component="+component.getClass().getName());
	if(JDisplayList.class.getName().equals(component.getClass().getName())) {
		((JDisplayList)component).rebuild(this);  
		replaceContext((JDisplayList)component);
	}
	}
}

public String saveContext() {
	try {
		String currentLocator$=getContext().getLocator();
		if(currentLocator$!=null) {
			SessionHandler.putLocator(getEntigrator(), currentLocator$);
			return Locator.getProperty(currentLocator$, JContext.INSTANCE);
		}
	}catch(Exception e) {
		System.out.println("JMainConsole:saveContext:"+e.toString());
	}
	return null;
}
}

