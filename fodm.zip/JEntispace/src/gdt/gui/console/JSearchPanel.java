package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;
import java.util.logging.Logger;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.gui.entity.JEntityEditor;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import javax.swing.ComboBoxEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicComboBoxEditor;
import javax.swing.border.EtchedBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class JSearchPanel extends JContext{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_SwI24_9kMUMOTOCFLTmB2Indas4";
	boolean debug=false;
	AutoCompleteComboBox labelComboBox;
	AutoCompleteComboBox keyComboBox;
	protected JMenu menu;
	String display$;
private Logger LOGGER=Logger.getLogger(JSearchPanel.class.getName());
	boolean keep=true;
	public JSearchPanel(JMainConsole console,String locator$) {
		super(console,locator$);
		//System.out.println("JSearchPanel:locator="+locator$ );
		display$=Locator.getProperty(locator$,DISPLAY);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{100, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0};
		setLayout(gridBagLayout);
		 ArrayList<String>sl=new ArrayList<String>();
		 Entigrator entigrator=console.getEntigrator();
		 String[] ka =entigrator.listEntities();
		 if(ka!=null) {
			 Arrays.sort(ka);
		 for(String k:ka) {
			// System.out.println("JSearchPanel:entityKey="+k);
			 sl.add(entigrator.getLabel(k));
		 }
		 }else
			 System.out.println("JSearchPanel:cannot list entities");
		Collections.sort(sl);
		JLabel lblLabel = new JLabel("Label");
		GridBagConstraints gbc_lblLabel = new GridBagConstraints();
		gbc_lblLabel.insets = new Insets(5, 5, 5, 5);
		gbc_lblLabel.gridx = 0;
		gbc_lblLabel.gridy = 0;
		gbc_lblLabel.anchor=GridBagConstraints.FIRST_LINE_START;
		add(lblLabel, gbc_lblLabel);
		labelComboBox = new AutoCompleteComboBox(sl.toArray(new String[0]));
		labelComboBox.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		labelComboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				try{
					String label$=(String)labelComboBox.getSelectedItem();
					String labelKey$=console.getEntigrator().getKey(label$);
					String previousKey$=(String)keyComboBox.getSelectedItem();
					if(!labelKey$.equals(previousKey$))
						selectCombo(keyComboBox,labelKey$);
					String locator$=classLocator();
					if(label$!=null)
					   locator$=Locator.append(locator$,Entigrator.ENTITY_LABEL, label$);
					 //SessionHandler.putLocator( console.getEntigrator(),getLocator());
				}catch(Exception ee){
					LOGGER.severe(ee.toString());
				}
			}
		 });
		GridBagConstraints gbc_lblComboBox = new GridBagConstraints();
		gbc_lblComboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_lblComboBox.insets = new Insets(5, 5, 5, 5);
		gbc_lblComboBox.gridx = 1;
		gbc_lblComboBox.gridy = 0;
		gbc_lblComboBox.anchor=GridBagConstraints.FIRST_LINE_START;
		add(labelComboBox, gbc_lblComboBox);
		
		JLabel lblKey = new JLabel("Key");
		lblKey.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
				String entityKey$=(String)keyComboBox.getSelectedItem();
//				System.out.println("JSearchPanel:key click:key="+entityKey$);
				String editorLocator$=JEntityEditor.classLocator();
				editorLocator$=Locator.append(editorLocator$,Entigrator.ENTITY_KEY,entityKey$);
				editorLocator$=Locator.append(editorLocator$,PARENT,getInstance());
				SessionHandler.putLocator(console.getEntigrator(), getLocator());
				JEntityEditor editor=new JEntityEditor(console,editorLocator$);
				replace(console, editor);
				}catch(Exception ee) {
					System.out.println("JSearchPanel:key click:"+ee.toString());
				}
			}
		});
		GridBagConstraints gbc_lblKey = new GridBagConstraints();
		gbc_lblKey.insets = new Insets(5, 5, 5, 5);
		gbc_lblKey.gridx = 0;
		gbc_lblKey.gridy = 1;
		gbc_lblKey.anchor=GridBagConstraints.FIRST_LINE_START;
		add(lblKey, gbc_lblKey);
		keyComboBox = new AutoCompleteComboBox(ka);
		keyComboBox.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		keyComboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				try{
					String key$=(String)keyComboBox.getSelectedItem();
					System.out.println("JSearchPanel:key state changed:key="+key$);
					String keyLabel$=console.getEntigrator().getLabel(key$);
					if(keyLabel$==null) {
						DefaultComboBoxModel<String> model=new DefaultComboBoxModel<String>();
						labelComboBox.setModel(model);
						return;
					}
					String previousLabel$=(String)labelComboBox.getSelectedItem();
					if(!keyLabel$.equals(previousLabel$))
						selectCombo(labelComboBox,keyLabel$);
				}catch(Exception ee){
					LOGGER.severe(ee.toString());
				}
			}
		 });
		GridBagConstraints gbc_keyComboBox = new GridBagConstraints();
		gbc_keyComboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_keyComboBox.insets = new Insets(5, 5, 5, 5);
		gbc_keyComboBox.gridx = 1;
		gbc_keyComboBox.gridy = 1;
		gbc_keyComboBox.anchor=GridBagConstraints.FIRST_LINE_START;
		add(keyComboBox, gbc_keyComboBox);
		JPanel panel = new JPanel();
		
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 2;
		gbc_panel.weighty=1;
		add(panel, gbc_panel); 
		String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		if(entity$!=null)
			selectCombo(labelComboBox,entity$);
		String label$=(String)labelComboBox.getSelectedItem();
		if(label$!=null) {
		String key$=console.getEntigrator().getKey(label$);	
		   selectCombo(keyComboBox,key$);
		}
	}
	@Override
	public JMenu getContextMenu() {
		menu=super.getContextMenu();
		JMenuItem openItem = new JMenuItem("Open");
		openItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("JSearchPanel:open:editor locator="+locator$);
				JEntityFacetList entityFacetList=new JEntityFacetList(console);
				entityFacetList.append(Entigrator.ENTITY_LABEL,(String)labelComboBox.getSelectedItem());
				entityFacetList.rebuild(console);
				//System.out.println("JSearchPanel:open:entityFacetList locator="+entityFacetList.getLocator());
				replace(console,entityFacetList);
			}
		} );
		menu.add(openItem);
		return menu;
	}
	@Override
	public String getTitle() {
	return "Search";
	}
	
	@Override
	public void close() {
	}
	@Override
	public String getSubtitle() {
		return null;
	}
	class AutoCompleteComboBox extends JComboBox<String> {
		 private static final long serialVersionUID = 1L;
		public int caretPos = 0;
		   public JTextField tfield = null;
		   public AutoCompleteComboBox(final String[] strings) {
		      super(strings);
		      setEditor(new BasicComboBoxEditor());
		      setEditable(true);
		   }
		   public void setSelectedIndex(int index) {
		      super.setSelectedIndex(index);
		      tfield.setText(getItemAt(index).toString());
		      tfield.setSelectionEnd(caretPos + tfield.getText().length());
		      tfield.moveCaretPosition(caretPos);
		   }
		   public void setEditor(ComboBoxEditor editor) {
		      super.setEditor(editor);
		      if(editor.getEditorComponent() instanceof JTextField) {
		         tfield = (JTextField) editor.getEditorComponent();
		         tfield.addKeyListener(new KeyAdapter() {
		            public void keyReleased(KeyEvent ke) {
		               char key = ke.getKeyChar();
		               if (!(Character.isLetterOrDigit(key) || Character.isSpaceChar(key) )) return;
		               caretPos = tfield.getCaretPosition();
		               String text="";
		               try {
		                  text = tfield.getText(0, caretPos);
		               } catch (javax.swing.text.BadLocationException e) {
		                  e.printStackTrace();
		               }
		               for (int i=0; i < getItemCount(); i++) {
		                  String element = (String) getItemAt(i);
		                  if (element.startsWith(text)) {
		                     setSelectedIndex(i);
		                     return;
		                  }
		               }
		            }
		         });
		      }
		   }
		}
	public static  String classLocator() {
		     Properties locator=new Properties();
		     locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
		     locator.put(CONTEXT_CLASS,"gdt.gui.console.JSearchPanel");
		     locator.put(Locator.LOCATOR_TITLE,"Search");
		     locator.put(IconLoader.ICON_FILE,"search.png");
		 	 locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		 	 locator.put(INSTANCE,KEY);
		 	 locator.put(NON_REMOVABLE,Locator.LOCATOR_TRUE);
			 locator.put(PARENT,JAdminPanel.KEY);
		  return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public boolean handleDone() {
		String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
		if(parentLocator$==null) {
			parent$=Locator.getProperty(locator$, JAllFacetsList.KEY);
		}
		//JContext.displayInstance(console, parent$);
		JContext.displayInstance(console, parent$,getDisplay());
		return true;
	}
}
