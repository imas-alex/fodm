package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JMenu;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
public class JAllFacetsList extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_e7rnZiO2kimhgiNYquRriWhfwkM";
	public JAllFacetsList(JMainConsole console, String alocator$) {
		super(console, alocator$);
		//System.out.println("JAllFacetrsList::locator="+locator$);
		JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);	
	locator$=Locator.append(locator$, INSTANCE,KEY);	
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String alocator$) {
		//System.out.println("JAllFacetrsList:getItems:locator="+locator$);
		Sack session=SessionHandler.getSession(console.getEntigrator());
		if(session==null) {
			System.out.println("JAllFacetrsList:getItems:cannot create session");
			return null;
		}
		String[] sa=session.elementListNames(FacetMaster.MASTER_ELEMENT);
		 
		if(sa==null||sa.length<1) {
				System.out.println("JAllFacetrsList:getItems:no facets in session");
				return null;
			}else
		{
		//	System.out.println("JAllFacetrsList:getItems:put facets into session");
			FacetMaster.setDefaultFacets(console);
			FacetMaster.setModuleFacets(console);
			session=SessionHandler.getSession(console.getEntigrator());
			sa=session.elementListNames(FacetMaster.MASTER_ELEMENT);
			}
		SessionHandler.putLocator(console.getEntigrator(), getLocator());
		//System.out.println("JAllFacetrsList:getItems:instance="+instance$);
		ArrayList<JItemPanel>ipal=new  ArrayList<JItemPanel>();		
		JItemPanel allFacetsItem;
    	 if(sa!=null) {
    	    String facetLocator$;
    	    FacetMaster facetMaster=null; 
    	    for(int i=0;i<sa.length;i++) {
    	    	facetLocator$=session.getElementItemAt(FacetMaster.MASTER_ELEMENT, sa[i]);
    	    	facetLocator$=Locator.append(facetLocator$, INSTANCE, instance$);
    		//	System.out.println("JAllFacetrsList:getItems:facet locator="+facetLocator$);
    			facetMaster=FacetMaster.build(console,facetLocator$);
    			try {
    			allFacetsItem=facetMaster.getJAllFacetsItem(console, facetLocator$);
    			ipal.add(allFacetsItem);
    			}catch(Exception ee) {
    				System.out.println("JAllFacetrsList:getItems::cannot get item="+sa[i]);
    			}
    	    }
    	    JItemPanel[] mipa= getModuleItems( console);
    	    if(mipa!=null) {
    	    	for(JItemPanel ip:mipa)
    	    		ipal.add(ip);
    	    }
    	    JItemPanel[] ipa=new JItemPanel[ipal.size()];
    	    ipal.toArray(ipa);
    	    return sortItems(ipa);
    	 }
		return null;
	}
	public static  JItemPanel[] getModuleItems(JMainConsole console) {
	try { 
	String[] sa=console.getEntigrator().listEntities("entity","module");
	  if(sa==null)
		  return null;
	  Sack module;
	  Core[]ca;
	  ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
	  FacetMaster facetMaster=null;
	  JItemPanel allFacetsItem;
	  for(String s:sa) {
		 // System.out.println("JAllFacetsList:getModuleItems:s="+s);
		  module=console.getEntigrator().getEntity(s);
		  ca=module.elementGet("handler");
		  if(ca==null)
			  continue;
		  for(Core c:ca) {
			 // System.out.println("JAllFacetsList:getModuleItems:c.value="+c.value);
			 try {
			  facetMaster=FacetMaster.build(console,c.value);
			  //System.out.println("JAllFacetsList:getModuleItems:facet master="+facetMaster.getName());
			  allFacetsItem=facetMaster.getJAllFacetsItem(console, c.value);
			  ipl.add(allFacetsItem);
			 }catch(Exception ee) {
				 System.out.println("JAllFacetsList:getModuleItems:type="+c.type+"  error="+ee.toString());
			 }
		  }
	  }
	  JItemPanel[] ipa=new  JItemPanel[ipl.size()];
	  ipl.toArray(ipa);
//	  System.out.println("JAllFacetsList:getModuleItems:ipa="+ipa.length);
	  return ipa;
	}catch(Exception e) {
		System.out.println("JAllFacetsList:getModuleItems:"+e.toString());	
	}
	return null;
}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Select all");
		menu=removeItem(menu,"Unselect all");
		menu=removeItem(menu,"Delete");
		return menu;
	}
	public static String classLocator() {
		String locator$=JItemsListPanel.classLocator();
		locator$=Locator.append(locator$, CONTEXT_CLASS,"gdt.gui.console.JAllFacetsList");
		locator$=Locator.append(locator$,FacetHandler.FACET_HANDLER_CLASS,"gdt.gui.console.JAllFacetsList");
		locator$=Locator.append(locator$,Locator.LOCATOR_TITLE,"Facets");
		locator$=Locator.append(locator$,IconLoader.ICON_FILE,"facets.png");
		locator$=Locator.append(locator$,INSTANCE, KEY); 
		locator$=Locator.append(locator$,PARENT, JAdminPanel.KEY); 
		locator$=Locator.append(locator$,DEFAULT_PARENT, JAdminPanel.KEY); 
		locator$=Locator.append(locator$,IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator$=Locator.append(locator$,IconLoader.ICON_FILE,"facets.png");
		//System.out.println("JDesignActions:classLocator:locator="+Locator.toString(locator));
		 return locator$;
	}
	public static void main(String[] args) throws IOException {
		String entihome$="/home/alexander/AC 1122021";
		JMainConsole console=new JMainConsole();
		console.setEntigrator(entihome$);
	    JAllFacetsList.getModuleItems(console);
		console.getEntigrator().close();
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public boolean handleDone() {
		JAdminPanel adminPanel=new JAdminPanel(console,null);
		replace(console,adminPanel);
		return true;
	}
}
