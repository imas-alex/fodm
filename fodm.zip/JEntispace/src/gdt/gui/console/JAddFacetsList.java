package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.entity.JEntityFacetList;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
public class JAddFacetsList extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_eeJZ_TCm_S_0KsIFl2MF6Pnd9Xp4";
	public JAddFacetsList(JMainConsole console, String locator$) {
		super(console, locator$);
		String classLocator$=classLocator();
		locator$=Locator.merge(locator$, classLocator$);
		JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);	
	//	System.out.println("JAddFacetrsList:locator="+locator$);
		}
	@Override
	public  JMenu getContextMenu() {
		// System.out.println("JAddFacetrsList:getContextMenu");
		  JMenu menu=new JMenu("Context");
			JMenuItem doneItem = new JMenuItem("Done");
			doneItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					//String locator$=JContext.this.getLocator();
					if(locator$!=null)
						//done(console,JAddFacetsList.this);
						handleDone();
						}
					});
			menu.add(doneItem);
			return menu;
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
        String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
        if(entity$==null) {
        	handleDone();
         	System.out.println("JAddFacetsList:getItems:entity is null.Return");
        	 return null;
        }
        Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
        if(entity==null) {
        	handleDone();
        	System.out.println("JAddFacetsList:getItems:cannot get entity="+entity$);
       	 return null;
       }
        if(!entity.existsElement(FacetHandler.FACET)) {
        	entity.createElement(FacetHandler.FACET);
        }
        Sack session=SessionHandler.getSession(console.getEntigrator());
        String[] sa=session.elementListNames(FacetMaster.MASTER_ELEMENT);
        ArrayList<JItemPanel> efi=new ArrayList<JItemPanel>();
    	 if(sa!=null) {
    	    String facetLocator$;
    	    FacetMaster facetMaster=null; 
    	    FacetHandler facetHandler=null; 
    	    JItemPanel item;
    	    for(int i=0;i<sa.length;i++) {
    	    	try {
  	        	facetLocator$=session.getElementItemAt(FacetMaster.MASTER_ELEMENT, sa[i]);
    	    	//System.out.println("JAddFacetsList:getItems:facet locator="+facetLocator$);	
    	    	facetLocator$=Locator.append(facetLocator$,Entigrator.ENTITY_LABEL, entity$);
    			facetMaster=FacetMaster.build(console,facetLocator$);
    			//System.out.println("JAddFacetrsList:getItems:facet master="+facetMaster.getClass().getName());
    			facetHandler=facetMaster.getFacetHandler(console, facetLocator$);
    			locator$=Locator.append(locator$, FacetHandler.FACET_TYPE, facetHandler.getType());
    			if(!facetHandler.isAddable(console.getEntigrator(), locator$)) {
    				System.out.println("JAddFacetrsList:getItems:not addable facet="+facetMaster.getClass().getName());
    				continue;
    			}
    			if(facetHandler.isAdded(console.getEntigrator(), locator$)) {
    				System.out.println("JAddFacetrsList:getItems:already added facet="+facetMaster.getClass().getName());
    				continue;
    			}
       			item= facetMaster.getJAddFacetsItem( console, facetLocator$);
    			if(item==null) {
    				System.out.println("JAddFacetrsList:getItems: add facet item is null in facet master="+facetMaster.getClass().getName());
    			    continue;
    			}
       			efi.add(item);
    			//System.out.println("JAddFacetrsList:getItems:facet handler="+facetHandler.getClass().getName());
    	    	}catch(Exception ee) {
    				System.out.println("JAllFacetrsList:getItems::cannot get item="+sa[i]);
    			}
    	    }	
    		JItemPanel[] ipa=new JItemPanel[efi.size()];
    		efi.toArray(ipa);
    	    return sortItems(ipa);
    	 }else {
    		 System.out.println("JAddFacetrsList:getItems:no 'facet.master' in session"); 
    	 }
		return null;
	}
	public static String classLocator() {
		String locator$=JItemsListPanel.classLocator();
		locator$=Locator.append(locator$, CONTEXT_CLASS,"gdt.gui.facet.JAddFacetsList");
		locator$=Locator.append(locator$,Locator.LOCATOR_TITLE,"Add facets");
		locator$=Locator.append(locator$,IconLoader.ICON_FILE,"facets.png");
		locator$=Locator.append(locator$,INSTANCE, KEY); 
		locator$=Locator.append(locator$,DEFAULT_PARENT, JEntityFacetList.KEY); 
		locator$=Locator.append(locator$,PARENT,JEntityFacetList.KEY); 
		locator$=Locator.append(locator$,IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		 return locator$;
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public boolean handleDone() {
		String parentLocator$=SessionHandler.getInstanceLocator(console.getEntigrator(),parent$);
		if(parentLocator$==null) {
			parent$=Locator.getProperty(locator$, DEFAULT_PARENT);
		}
		//JContext.displayInstance(console, parent$);
		JContext.displayInstance(console, parent$,getDisplay());
		return true;

	}
}
