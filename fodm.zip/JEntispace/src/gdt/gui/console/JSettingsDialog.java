package gdt.gui.console;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JSettingsDialog extends JDialog{
	private static final long serialVersionUID = 1L;
	String locator$;
	String entihome$;
	Entigrator baseEntigrator;
	JMainConsole console;
	JTextField txtDelay;
	JTextField txtKeep;
	JButton btnSave;
	JButton btnCancel;
	
	public JSettingsDialog(JMainConsole console,String locator$) {
		this.console=console;
		this.locator$=locator$;
		entihome$=Locator.getProperty(locator$, Entigrator.ENTIHOME);
		Entigrator entigrator=console.getEntigrator();
		if(entigrator.getEntihome().equals(entihome$))
			baseEntigrator=entigrator;
		else
		    baseEntigrator=new Entigrator(entihome$);
		this.setTitle(entihome$);
		setTitle("Settings :"+console.getEntigrator().getEntihome());
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0,0,1};
		gridBagLayout.rowHeights = new int[]{0,0,0,1};
		gridBagLayout.columnWeights = new double[]{0.0,0.0,Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0,0.0,0.0,Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel lblDelay = new JLabel("Delay");
		GridBagConstraints gbc_lblDelay = new GridBagConstraints();
		gbc_lblDelay.anchor = GridBagConstraints.LINE_START;
		gbc_lblDelay.insets = new Insets(5, 5, 5, 5);
		gbc_lblDelay.gridx = 0;
		gbc_lblDelay.gridy = 0;
		add(lblDelay, gbc_lblDelay);
		txtDelay = new JTextField();
	    
		txtDelay.setColumns(10);
		GridBagConstraints gbc_txtDelay = new GridBagConstraints();
		gbc_txtDelay.insets = new Insets(5, 5, 5, 5);
		gbc_txtDelay.gridx = 1;
		gbc_txtDelay.gridy = 0;
		add(txtDelay, gbc_txtDelay);
		
		JLabel lblKeep = new JLabel("Keep");
		GridBagConstraints gbc_lblKeep = new GridBagConstraints();
		gbc_lblKeep.anchor = GridBagConstraints.LINE_START;
		gbc_lblKeep.insets = new Insets(5, 5, 5, 5);
		gbc_lblKeep.gridx = 0;
		gbc_lblKeep.gridy = 1;
		add(lblKeep, gbc_lblKeep);
		txtKeep = new JTextField();
			    
		txtKeep.setColumns(10);
		GridBagConstraints gbc_txtKeep = new GridBagConstraints();
		gbc_txtKeep.insets = new Insets(5, 5, 5, 5);
		gbc_txtKeep.gridx = 1;
		gbc_txtKeep.gridy = 1;
		add(txtKeep, gbc_txtKeep);
		 
		btnCancel=new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			    dispose();
			}
		});
		GridBagConstraints gbc_btnCancel = new GridBagConstraints();
		gbc_btnCancel.insets = new Insets(10, 10, 5, 0);
		gbc_btnCancel.anchor=GridBagConstraints.LINE_END; 
		gbc_btnCancel.gridx = 0;
		gbc_btnCancel.gridy = 2;
		add(btnCancel, gbc_btnCancel);
		
		btnSave=new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			    saveSettings();
			    if(!entigrator.getEntihome().equals(baseEntigrator.getEntihome()))
			    	baseEntigrator.close();
				dispose();
			}
		});
		GridBagConstraints gbc_btnSave = new GridBagConstraints();
		gbc_btnSave.insets = new Insets(10, 0, 5, 0);
		gbc_btnSave.anchor=GridBagConstraints.LINE_START; 
		gbc_btnSave.gridx = 1;
		gbc_btnSave.gridy = 2;
		add(btnSave, gbc_btnSave);
		initSettings();
		pack();
		revalidate();
		repaint();
	}
	private void initSettings() {
		try {
			Sack settings=baseEntigrator.getSettings();
			if(settings==null) {
				System.out.println("JSettingsDialog:initSettings:no settings in base="+entihome$);
				dispose();
			}
			txtDelay.setText(settings.getElementItemAt("base", "_delay"));
			txtKeep.setText(settings.getElementItemAt("base", "_keep"));
		}catch(Exception e) {
			System.out.println("JSettingsDialog:initSettings:"+e.toString());
		}
	}
	private void saveSettings() {
		try {
			int delay=15000;
			int keep=50;
			Sack settings=baseEntigrator.getSettings();
			if(settings==null) {
				System.out.println("JSettingsDialog:initSettings:no settings in base="+entihome$);
				dispose();
			}
			String delay$=txtDelay.getText();
			try{delay=Integer.parseInt(delay$);}catch(Exception ee ) {
				System.out.println("JSettingsDialog:initSettings:delay:"+ee.toString());
			}
			String keep$=txtKeep.getText();
			try{keep=Integer.parseInt(keep$);}catch(Exception ee ) {
				System.out.println("JSettingsDialog:initSettings:keep:"+ee.toString());
			}
			settings.putElementItem("base", new Core(null,"_delay",String.valueOf(delay)));
			settings.putElementItem("base", new Core(null,"_keep",String.valueOf(keep)));
			baseEntigrator.putEntity(settings);
		}catch(Exception e) {
			System.out.println("JSettingsDialog:initSettings:"+e.toString());
		}
	}
}
