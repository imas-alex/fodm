package gdt.gui.entity;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JDesignPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
import javax.swing.JComboBox;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import javax.swing.DefaultComboBoxModel;

public class JAddLinks extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_FXZ6DPIF4iWnWWv2a1f3FzK6pxA";
	JComboBox<String>selector;
    boolean noInit=false;
	public JAddLinks(JMainConsole console ,String locator$) {
		super(console,locator$);
		selector = new JComboBox<String>();
		selector.setMaximumSize(new Dimension(1400, 24));
		add(selector);
		selector.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				initList();
			}
		});
		initSelector();
		initList();
	}
	public JAddLinks(JMainConsole console ) {
		super(console);
		selector = new JComboBox<String>();
		selector.setMaximumSize(new Dimension(1400, 24));
		add(selector);
		selector.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				initList();
			}
		});
	}
	public static String classLocator() {
		Properties locator=new Properties();
		 locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.entity.JAddLinks");
	    locator.put(Locator.LOCATOR_TITLE,"Add links");
		locator.put(IconLoader.ICON_FILE,"link.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(INSTANCE, KEY); 
		locator.put(PARENT, JLinkList.KEY);
		locator.put(DEFAULT_PARENT, JDesignPanel.KEY);
		 return Locator.toString(locator);
	}
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Delete");
		JMenuItem addItem = new JMenuItem("Add");
		addItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JItemPanel []ipa=JAddLinks.this.getChecked();
				for(JItemPanel ip:ipa)
					((JAddLinkItem)ip).addLink();
				initList();
			}
			});
		menu.add(addItem);
		menu.addMenuListener(new MenuListener(){
		     @Override
		     public void menuCanceled(MenuEvent e) {
			     }

		     @Override
		     public void menuDeselected(MenuEvent e) {
			     }
			@Override
			public void menuSelected(MenuEvent arg0) {
				if(hasChecked()) 
					addItem.setEnabled(true);
				else 	
					addItem.setEnabled(false);
			}	
		 });
		return menu;
		}
	private void initList() {
		try {
			//System.out.println("JAddLinks:initList:BEGIN");
			container.removeAll();
			il.clear();
			String entityType$=(String)selector.getSelectedItem();
			String[] sa=console.getEntigrator().listEntities("entity", entityType$);
			il.clear();
			String entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			String entityKey$=console.getEntigrator().getKey(entity$);
			Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
			String []la=entity.elementListNames("link");
		//	System.out.println("JAddLinks:initList:sa="+sa.length+" la="+la.length);
			ArrayList<String>sl=new ArrayList<String>();
			boolean found=false;
			if(sa!=null) {
			  for(String s:sa) {
				  if(s.equals(entityKey$))
					  continue;
				found=false;
				if(la!=null) 
				for(String l:la) {
				//	System.out.println("JAddLinks:initList:s="+s+" l="+l);
					if(l.equals(s)) {
					found=true;
					break;
					}
				}
				if(!found) {
					//System.out.println("JAddLinks:initList:add sl:s="+s);
				   sl.add(s);
				}
			  }
			}
			//System.out.println("JAddLinks:initList:sl="+sl.size());
			JAddLinkItem ip;
			for(String s:sl) {
				ip=getItem( s);
				addItem(ip);
			}
			container.revalidate();
			container.repaint();	
		}catch(Exception e) {
			System.out.println("JAddLinks:initList:"+e.toString());
		}
	}
	private void initSelector() {
		try {
			String[] sa=console.getEntigrator().listValues("entity");
			if(sa!=null&&sa.length>1)
				Arrays.sort(sa);
			DefaultComboBoxModel<String> selectorModel=new DefaultComboBoxModel<String>(sa);
			selector.setModel(selectorModel);
		}catch(Exception e) {
			System.out.println("JAddLinks:initSelector:"+e.toString());
		}
	}
	
	private   JAddLinkItem getItem( String entityKey$) {
		String customer$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL );
		Properties itemLocator=new Properties();
		 String entity$=console.getEntigrator().getLabel(entityKey$);
		 itemLocator.put(Entigrator.CUSTOMER, customer$);
         itemLocator.put(Locator.LOCATOR_TITLE, entity$);
         itemLocator.put(JItemPanel.ITEM_CHECKABLE,Locator.LOCATOR_TRUE);
         itemLocator.put(JItemPanel.ITEM_CHECKED,Locator.LOCATOR_FALSE);
         Sack entity=console.getEntigrator().getEntity(entityKey$);
         Core icon=entity.getAttribute("icon");
         if(icon!=null) {
        	 itemLocator.put(IconLoader.ICON_FILE,icon.value);
        	 itemLocator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
      	   if(icon.type!=null&& icon.type.length()>0) {
      		 itemLocator.put(ModuleHandler.FACET_MODULE,icon.type);
      		itemLocator.remove(IconLoader.ICON_CONTAINER);
      	   }
         }else {	   
        	 itemLocator.put(IconLoader.ICON_FILE,"box.png");
        	 itemLocator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
         }
          itemLocator.put(Entigrator.ENTITY_LABEL,entity$);
          itemLocator.put(SessionHandler.INSTANCE,entityKey$);
          itemLocator.put(JContext.PARENT,JAddLinks.KEY);
          itemLocator.put(JContext.DEFAULT_PARENT,KEY);
          String itemLocator$=Locator.toString(itemLocator);
          return new JAddLinkItem(console,itemLocator$);
	}
	private   class JAddLinkItem extends JItemPanel{
		private static final long serialVersionUID = 1L;
		public JAddLinkItem(JMainConsole console, String locator$) {
			super(console, locator$);
			//System.out.println("JHistoryItem::locator="+locator$);
		}
		public JPopupMenu getPopup(JMainConsole console,String locator$) {
		return null;	
		}
		public void addLink() {
			try {
				String customer$=Locator.getProperty(locator$, Entigrator.CUSTOMER);
				String link$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
				if(link$.equals(customer$))
					return;
				Entigrator entigrator=console.getEntigrator();
				String customerKey$=entigrator.getKey(customer$);
				String linkKey$=entigrator.getKey(link$);
				Sack customer=entigrator.getEntity(customerKey$);
				Sack link=entigrator.getEntity(linkKey$);
				if(!customer.existsElement(Entigrator.LINK))
					customer.createElement(Entigrator.LINK);
				if(!link.existsElement(Entigrator.CUSTOMER))
					link.createElement(Entigrator.CUSTOMER);
				customer.putElementItem(Entigrator.LINK, new Core(null,linkKey$,link$));
				link.putElementItem(Entigrator.CUSTOMER, new Core(null,customerKey$,customer$));
				entigrator.putEntity(link);
				entigrator.putEntity(customer);
			}catch(Exception e) {
				System.out.println("JAddLinks:addLink:"+e.toString());
			}
		}
		@Override
		public void onClick(JMainConsole console, String locator$) {
			//System.out.println("JAddLinks:onClick:locator="+locator$);
			addLink();
			initList();
		}
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
			return null;
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public boolean handleDone() {
		JContext.displayInstance(console, parent$);
		return true;
	}
}
