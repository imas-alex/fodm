package gdt.gui.entity;
//version 2023-0
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JAddFacetsList;
import gdt.gui.console.JDesignPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
import gdt.gui.generic.JTextEditor;

public class JEntityFacetList extends JItemsListPanel{
	public static final String KEY="_7fwHv_SFQ3PgntP_CPCScrFfNSm0";
	public final String DEFAULT_TITLE="Default";
	public final String DELETE_ACTION="delete";
	public final String LIST_ACTION="list";

	String entity$;
	String[] ea=null;
	private static final long serialVersionUID = 1L;
	public JEntityFacetList(JMainConsole console, String alocator$) {
		super(console, alocator$);
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		//System.out.println("JEntityFacetList:locator="+locator$);
		instance$=getInstance();
		parent$=Locator.getProperty(alocator$, PARENT);
		display$=Locator.getProperty(locator$, DISPLAY);
		if(display$==null)
			display$=console.getDisplayKey(this);
		if(parent$!=null)
		 locator$=Locator.append(alocator$, PARENT, parent$);
		System.out.println("JEntityFacetList:instance="+instance$+"  parent="+parent$+" display="+display$);
		setTitle("Entity facet list");
		setSubtitle(entity$);
		refreshDisplay();
	    JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);
		console.setSubtitle(entity$);
	}
	@Override
	public void rebuild(JMainConsole console) {
		//System.out.println("JEntityFacetList:rebuild");
		display$=console.getDisplayKey(this);
		container.removeAll();
		entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	    il=new ArrayList<JItemPanel>();
	    //System.out.println("JEntityFacetList:rebuild:locator="+locator$);
	    JItemPanel[] ipa=getItems(console,  locator$);
			//System.out.println("JDesignActions:items="+ipa.length);
			if(ipa!=null)
				for(JItemPanel ip:ipa)
				  if(ip!=null)	
					addItem(ip);
			revalidate();
			repaint();
			refreshDisplay();
			//System.out.println("JEntityFacetList:rebuild:FINISH display="+display$);	
	}
	
	public JEntityFacetList(JMainConsole console) {
		super(console);
	}
	@Override
	public String getTitle() {
		return "Entity facet list";
	}
	@Override
	 public String getSubtitle() {
		  return entity$;
	  }
	
	public  JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Select all");
		menu=removeItem(menu,"Unselect all");
		menu=removeItem(menu,"Delete");
		JMenuItem addItem = new JMenuItem("Add facet");
		addItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
				String addFacets$=JAddFacetsList.classLocator();
				addFacets$=Locator.append(addFacets$, Entigrator.ENTITY_LABEL, entity$);
				JAddFacetsList addFacetsList=new  JAddFacetsList(console,addFacets$);
				replace(console,addFacetsList);
			}
			});
		menu.addSeparator();
		menu.add(addItem);
		return menu;
	}
	 public static String classLocator() {
			Properties locator=new Properties();
			 locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
		    locator.put(CONTEXT_CLASS,"gdt.gui.entity.JEntityFacetList");
		    locator.put(Locator.LOCATOR_TITLE,"Entity facets");
			locator.put(IconLoader.ICON_FILE,"facet.png");
			locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
			locator.put(DEFAULT_PARENT, JDesignPanel.KEY);
			 return Locator.toString(locator);
		} 
	private class JDefaultFacetItem extends JItemPanel{
		private static final long serialVersionUID = -8596195035443603689L;
		String action$;
		String entity$;
		public JDefaultFacetItem( JMainConsole console, String locator$) {
			super(console, locator$);
			action$=Locator.getProperty(locator$, JItemPanel.ITEM_ACTION);
			entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
		}
		@Override
		public JPopupMenu getPopup(JMainConsole console, String locator$) {
			return null;
		}
		@Override
		public void onClick(JMainConsole console, String alocator$) {
			String entityLabel$=Locator.getProperty(alocator$, Entigrator.ENTITY_LABEL);
			String listLocator$=JEntityFacetList.this.getLocator();
			//String listInstance$=Locator.getProperty(listLocator$, INSTANCE);
			String listInstance$=JEntityFacetList.this.getInstance();
			SessionHandler.putLocator(console.getEntigrator(), listLocator$);
			String defaultLocator$=JDefaultServicesList.classLocator();
			defaultLocator$=Locator.append(defaultLocator$, Entigrator.ENTITY_LABEL,entityLabel$);
			defaultLocator$=Locator.append(defaultLocator$,JContext.PARENT,listInstance$ );
			display$=getDisplay();
			//System.out.println("JEntityFacetList:onclick:display key="+display$);
			if(display$!=null)
				defaultLocator$=Locator.append(defaultLocator$,DISPLAY,display$);
			JDefaultServicesList defaultServicesList=new JDefaultServicesList (console,defaultLocator$);
			replace(console,defaultServicesList);
		}
	}
	JDefaultFacetItem  getDefaultItem(JMainConsole console) {
		String defaultItemLocator$=JDefaultServicesList.classLocator();
		defaultItemLocator$=Locator.append(defaultItemLocator$, Entigrator.ENTITY_LABEL, entity$);
		defaultItemLocator$=Locator.append(defaultItemLocator$, PARENT, instance$);
		JDefaultFacetItem  defaultItem= new JDefaultFacetItem (console, defaultItemLocator$);
	return defaultItem;	  
	}
	
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		//System.out.println("JEntityFacetList:getItems:locator="+locator$);
		try {
		String parentInstance$=getInstance();
		String thisLocator$=getLocator();
		
		SessionHandler.putLocator(console.getEntigrator(), thisLocator$);
		System.out.println("JEntityFacetList:getItems:this locator="+thisLocator$);
		Properties locator=Locator.toProperties(locator$);
		entity$=locator.getProperty(Entigrator.ENTITY_LABEL);
		display$=console.getDisplayKey(this);
		if(display$==null)
			display$=Locator.getProperty(getLocator(), JContext.DISPLAY);
		//System.out.println("JEntityFacetList:getItems:display="+display$);
		if(entity$==null)
			return null;
		Sack entity=console.getEntigrator().getEntityAtLabel(entity$);
		//entity.print();
		FacetMaster fm=null;
		JItemPanel item;
		String itemLocator$;
		JDefaultFacetItem defaultItem=getDefaultItem( console);
		ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
		ipl.add(defaultItem);
		String[] sa=entity.elementListNames("facet");
		if(sa!=null) {
			//System.out.println("JEntityFacetList:getItems:sa="+sa.length);
		for(String s:sa) {
			try {
			itemLocator$= entity.getElementItemAt("facet", s);
			//System.out.println("JEntityFacetList:getItems:item locator="+itemLocator$);
			itemLocator$=Locator.append(itemLocator$, Entigrator.ENTITY_LABEL, entity$);
			if(display$!=null)
				itemLocator$=Locator.append(itemLocator$,DISPLAY,display$);
			if(parentInstance$!=null)
			itemLocator$=Locator.append(itemLocator$,JContext.PARENT, parentInstance$);
			fm=FacetMaster.build(console,itemLocator$);
			if(fm==null) {
				System.out.println("JEntityFacetList:getItems:cannot get facet master:locator="+itemLocator$);
			    continue;
			}
		//	System.out.println("JEntityFacetList:getItems:item locator="+itemLocator$);
			item=fm.getJEntityFacetsItem(console, itemLocator$);
			item.setDisplay(display$);
			
			if(item!=null)
			   ipl.add(item);
			else
				System.out.println("JEntityFacetList:getItems:cannot get item panel for locator=="+itemLocator$);
			}catch(Exception ee) {
				System.out.println("JEntityFacetList:getItems:s="+s+"   "+ee.toString());	
			}
		}
		}
		JItemPanel[]ipa=new JItemPanel[ipl.size()];
		ipl.toArray(ipa);
		if(ipa==null||ipa.length<1)
			return null;
		//System.out.println("JEntityFacetList:getItems:ipa="+ipa.length);
		return sortItems(ipa);
		}catch(Exception e) {
			System.out.println("JEntityFacetList:getItems:"+e.toString());	
		}
		return null;
	}
	
	@Override
	public String reply(JMainConsole console,String locator$) {
		System.out.println("JEntityFacetList:reply:locator="+locator$);
		try {
			String entityLabel$=Locator.getProperty(locator$,JTextEditor.OUT_TEXT);
			//Entigrator entigrator=console.getEntigrator();
			String masterClass$=Locator.getProperty(locator$, FacetMaster.MASTER_CLASS);
			FacetMaster fm=FacetMaster.build(console, locator$);
		    Sack entity=fm.createEntity(console.getEntigrator(), entityLabel$);
		    String entityFacetList$ =JEntityFacetList.classLocator();
		    entityFacetList$=Locator.append(entityFacetList$,Entigrator.ENTITY_LABEL, entity.getProperty(Entigrator.LABEL));
		    entityFacetList$=Locator.append(entityFacetList$,FacetMaster.MASTER_CLASS,masterClass$);
		    entityFacetList$=Locator.remove(entityFacetList$, REPLY);
		    JEntityFacetList entityFacetList= new JEntityFacetList(console,entityFacetList$);
		    entityFacetList.setSubtitle(entityLabel$);
		    status$=INVALID;
		    return entityFacetList$;
	}catch(Exception e) {
		System.out.println("JEntityFacetList:reply:"+e.toString()+" locator="+locator$);
		return getLocator();
	}
	}
	
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public boolean handleDone() {
		JContext.displayInstance(console, parent$);
		return true;
	}
	
}
