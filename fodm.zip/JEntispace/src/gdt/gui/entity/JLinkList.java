package gdt.gui.entity;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JDesignPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;
public class JLinkList extends JItemsListPanel{
	private static final long serialVersionUID = 1L;
	public static final String KEY="_jxSGAFRyrpDyN54VrQdlcselynI";
	public JLinkList(JMainConsole console, String locator$) {
		super(console, locator$);
		rebuild(console);
	}
	public JLinkList(JMainConsole console) {
		super(console);
	}

	public static String classLocator() {
		Properties locator=new Properties();
		 locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.entity.JLinkList");
	    locator.put(Locator.LOCATOR_TITLE,"Links");
		locator.put(IconLoader.ICON_FILE,"link.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(INSTANCE, KEY); 
		locator.put(PARENT, JEntityFacetList.KEY);
		locator.put(DEFAULT_PARENT, JDesignPanel.KEY);
		 return Locator.toString(locator);
	} 
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		Sack customer=console.getEntigrator().getEntityAtLabel(entity$);
		Core[] ca=customer.elementGet("link");
		if(ca==null||ca.length<1) {
			System.out.println("JLinkList:getItems: no links in entity="+entity$);
			return null;
		}
//		System.out.println("JLinkList:getItems: "+ca.length+"  links in entity="+entity$);
		Properties entityLocator;
		ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
		 {
			 Sack entity;
			String entityLocator$;
			JLinkItem entityItem;
			String parentKey$=Locator.getProperty(locator$,JContext.INSTANCE);
			for(Core c:ca) {
		       entity=console.getEntigrator().getEntity(c.name);
		       if(entity!=null) {
		    	   entityLocator=new Properties();
		           entityLocator.put(Locator.LOCATOR_TITLE, c.value);
		           entityLocator.put(JItemPanel.ITEM_CHECKABLE,Locator.LOCATOR_TRUE);
		           entityLocator.put(JItemPanel.ITEM_CHECKED,Locator.LOCATOR_FALSE);
		           Core icon=entity.getAttribute("icon");
		           if(icon!=null) {
		        	   entityLocator.put(IconLoader.ICON_FILE,icon.value);
		        	   entityLocator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		        	   if(icon.type!=null&& icon.type.length()>0) {
		        	      entityLocator.put(ModuleHandler.FACET_MODULE,icon.type);
		        	      entityLocator.remove(IconLoader.ICON_CONTAINER);
		        	   }
		           }else {	   
		        	   entityLocator.put(IconLoader.ICON_FILE,"box.png");
		               entityLocator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		           }
		           entityLocator.put(Entigrator.ENTITY_LABEL,c.value);
		           entityLocator.put(SessionHandler.INSTANCE,c.name);
		           entityLocator.put(JContext.PARENT,parentKey$);
		           entityLocator.put(JContext.DEFAULT_PARENT,KEY);
		           entityLocator.put(Entigrator.CUSTOMER,entity$);
		           String entityType$=entity.getProperty("entity");
		           entityLocator$=Locator.toString(entityLocator);
		           if(entityType$!=null) {
		        	   Sack session=SessionHandler.getSession(console.getEntigrator());
		        	   String iconLocator$=session.getElementItemAt(FacetMaster.ICON_ELEMENT, entityType$);
		        	   entityLocator$=Locator.merge(entityLocator$, iconLocator$);
		           }
		           entityItem=new JLinkItem(console,entityLocator$);
		            ipl.add(entityItem);
		       }else
		    	   System.out.println("JLinkList:getItems:cannot get entity at key="+c.name);  
			}
		}
		JItemPanel[] ipa=new JItemPanel[ipl.size()]; 
		ipl.toArray(ipa);
		return sortItems(ipa);
	}
@Override
public JMenu getContextMenu() {
	JMenu menu=super.getContextMenu();
	menu=removeItem(menu,"Display");
	menu.addSeparator();
	JMenuItem addItem = new JMenuItem("Add");
	addItem.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
	      System.out.println("JLinkList:add");
	      JAddLinks addLinks=new JAddLinks(console);
	      JLinkList.this.replace(console, addLinks);
		}
	} );
	menu.add(addItem);
	if(SessionHandler.hasCopy(console.getEntigrator())){
		menu.addSeparator();
		JMenuItem paste = new JMenuItem("Paste");
		paste.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				container.removeAll();
				il.clear();
				String [] ea=SessionHandler.listCopiedEntities(console.getEntigrator());
				if(ea!=null)
				   for(String e$:ea){
					try {
						String customer$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
						if(e$.equals(customer$))
							return;
						Entigrator entigrator=console.getEntigrator();
						String customerKey$=entigrator.getKey(customer$);
						Sack customer=entigrator.getEntity(customerKey$);
						Sack link=entigrator.getEntity(e$);
						String linkLabel$=console.getEntigrator().getLabel(e$);
						if(!customer.existsElement(Entigrator.LINK))
							customer.createElement(Entigrator.LINK);
						if(!link.existsElement(Entigrator.CUSTOMER))
							link.createElement(Entigrator.CUSTOMER);
						customer.putElementItem(Entigrator.LINK, new Core(null,e$,linkLabel$));
						link.putElementItem(Entigrator.CUSTOMER, new Core(null,customerKey$,customer$));
						entigrator.putEntity(link);
						entigrator.putEntity(customer);
						}catch(Exception ee) {
						System.out.println("JLinksList:paste:"+ee.toString());
					}	
				}
    			rebuild(console);
			}
		} );
		menu.add(paste);
	}
	return menu;
	}
@Override
protected void handleDelete(JItemPanel item) {
			try {
			String link$=item.getTitle();
			String customer$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
			Entigrator entigrator=console.getEntigrator();
			Sack link=entigrator.getEntityAtLabel(link$);
			Sack customer=entigrator.getEntityAtLabel(customer$);
			link.removeElementItem(Entigrator.CUSTOMER, customer.getKey());
			customer.removeElementItem(Entigrator.LINK, link.getKey());
			entigrator.putEntity(customer);
			entigrator.putEntity(link);
			}catch(Exception e) {
				System.out.println("JLinkList:handleDelete:"+e.toString()); 
			}
}
private class JLinkItem extends JItemPanel {
	private static final long serialVersionUID = 1L;
	public JLinkItem(JMainConsole console, java.lang.String locator$) {
		super(console, locator$);
	}
@Override
public JPopupMenu getPopup(JMainConsole console, String locator$) {
	//System.out.println("JLinkList:getPopup:locator="+locator$); 
	popup=new JPopupMenu();
	JMenuItem openItem=new JMenuItem("Open");
	 openItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("JLinkList:popup:open:locator="+locator$);
				String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
				String facetsLocator$=JEntityFacetList.classLocator();
				facetsLocator$=Locator.append(facetsLocator$,Entigrator.ENTITY_LABEL, entityLabel$);
				facetsLocator$=Locator.append(facetsLocator$, PARENT, KEY);
				JEntityFacetList facetList=new JEntityFacetList(console,facetsLocator$);
				JLinkList.this.replace(console, facetList);
				popup.setVisible(false);
			}
			});
		popup.add(openItem);
		JMenuItem removeItem=new JMenuItem("Remove");
		removeItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					//System.out.println("JLinkList:popup:delete:locator="+locator$);
					popup.setVisible(false);	
					int response = JOptionPane.showConfirmDialog(JLinkList.this, "Delete link ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (response == JOptionPane.YES_OPTION) {
						deleteItem(JLinkItem.this);
		  		    }
				}
				});
			popup.add(removeItem);
	 return popup;
}
@Override
public void onClick(JMainConsole console, String locator$) {
	//System.out.println("JLinkList:on item click:locator="+locator$);
	String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	String facetsLocator$=JEntityFacetList.classLocator();
	facetsLocator$=Locator.append(facetsLocator$,Entigrator.ENTITY_LABEL, entityLabel$);
	facetsLocator$=Locator.append(facetsLocator$, PARENT, KEY);
	JEntityFacetList facetList=new JEntityFacetList(console,facetsLocator$);
	replace(console, facetList);
}
}
@Override
public String getClassLocator() {
	return classLocator();
}
@Override
public String reply(JMainConsole console, String locator$) {
	return null;
}
@Override
public boolean handleDone() {
	JContext.displayInstance(console, parent$);
	return true;
}
}
