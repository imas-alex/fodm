package gdt.gui.entity;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.ListSelectionModel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.util.logging.Logger;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.console.JAdminPanel;
import gdt.gui.console.JMainConsole;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JTextEditor;
import java.awt.FlowLayout;
public class JEntityEditor extends  JContext{
	private static final long serialVersionUID = 1L;
	private static final String ACTION_RENAME_ELEMENT="action rename element";
	private static final String ACTION_ADD_ELEMENT="action add element";
	private Logger LOGGER=Logger.getLogger(JEntityEditor.class.getName());
	public final static String SELECTED_ELEMENT="selected element";
	private String entityKey$;
	private String entity$;
	JTabbedPane tabbedPane;
	JMenu menu;
	JMenuItem deleteItemsItem;
	JMenuItem editCellItem;
	JMenuItem copyItem;
	JMenuItem cutItem; 
	
	JMenuItem pasteItem;
	String message$;
	Sack entity;
	boolean debug=false;
	Dimension selectionInterval;
	String selectedElement$;
	int selectedIndex=0;
	JTable selectedTable;
	boolean blockChangeEvent=false;
	boolean blockTableListeners=false;
	String action$;
	String outtext$;
	String intext$;
	String display$;
	public JEntityEditor(JMainConsole console) {
		super(console);
	}
	public JEntityEditor(JMainConsole console,String alocator$) {
		super(console,alocator$);
		System.out.println("JEntityEditor:locator="+locator$);
		setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		display$=Locator.getProperty(locator$, DISPLAY);
		if(locator$!=null) {
		Properties locator=Locator.toProperties(locator$);
		selectedElement$=locator.getProperty(SELECTED_ELEMENT);
		entity$=locator.getProperty(Entigrator.ENTITY_LABEL);
		if(entity$!=null)
			entityKey$=console.getEntigrator().getKey(entity$);
		else
			entityKey$=locator.getProperty(Entigrator.ENTITY_KEY);
		if(entityKey$==null) {
			System.out.println("JEntityEditor:entity key is null:locator="+locator$);
			return;
		}
		entity=console.getEntigrator().getEntity(entityKey$);
		selectedElement$=Sack.ATTRIBUTES;
		refresh();
		}
	}

private JTable getTable(String element$) {
	int cnt=tabbedPane.getComponentCount();
	for(int i=0;i<cnt;i++){
		if(element$.equals(tabbedPane.getTitleAt(i))){
			try {
			JScrollPane scrollPane=(JScrollPane)tabbedPane.getComponent(i);
			JTable table=(JTable)scrollPane.getViewport().getComponent(0);
			return table;
			}catch(Exception e) {
				System.out.println("JEntityEditor:getTable:element=" +element$+" erroe="+e.toString());
			}
		}	
		}
	return null;
}
private void showElement(Sack entity,String element$){
	if(entity==null)
		System.out.println("EntityEditor:showElement:entity is null");
	blockTableListeners=true;
	try{
	Core[] ca=null;
	if("attributes".equals(element$)) {
		ca=entity.attributesGet();
	}else
	   ca=entity.elementGet(element$);
	  final JTable table = new JTable();
	  DefaultTableModel model=new DefaultTableModel(
			  null
			  ,
				new String[] {
					"type", "name", "value"
				}
			);
	  table.setName(element$);
	  table.setModel(model);
	  table.getTableHeader().setDefaultRenderer(new SimpleHeaderRenderer());
	  table.getTableHeader().addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		       try {
		    	 if(blockTableListeners)
		    		 return;
		    	table.clearSelection();
		        selectionInterval=null;
		    	int col = table.columnAtPoint(e.getPoint());
		        String name = table.getColumnName(col);
		        //System.out.println("Column index selected " + col + " " + name);
		        sort(table,name);
		       }catch(Exception ee) {
		    	   System.out.println("JEntityEditor:showElement:header clicked:"+ee.toString());   
		       }
		    }
		});
	  table.getModel().addTableModelListener(new TableModelListener() {
		@Override
		public void tableChanged(TableModelEvent model) {
			 if(blockTableListeners)
	    		 return;
			Core[] ca=getContent(false);
			entity.elementReplace(selectedElement$, ca);
			console.getEntigrator().putEntity(entity);
		    refresh();
		}
	    });
	  table.setCellSelectionEnabled(true);
	  table.setColumnSelectionInterval(0, 2);
	  ListSelectionModel cellSelectionModel = table.getSelectionModel();
	  cellSelectionModel.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
	  cellSelectionModel.addListSelectionListener(new ListSelectionListener() {
	      public void valueChanged(ListSelectionEvent e) {
	    	  if(blockTableListeners)
		    		 return;
	    	  table.setColumnSelectionInterval(0, 2);
	    	  int[] selectedRow = table.getSelectedRows();
	    	  if(selectedRow.length>0)
	          selectionInterval=new Dimension(selectedRow[0],selectedRow[selectedRow.length-1]);
	    	  else
	    		selectionInterval=null; 
	       // System.out.println("JEntityEditor:showElement:row selection:element="+element$+"; row interval: begin=" + selectedRow[0]+"  end="+selectedRow[selectedRow.length-1]);
	      }

	    });
	  JScrollPane scrollPane = new JScrollPane();
	  tabbedPane.add(element$,scrollPane);
	  scrollPane.setViewportView(table); 
	if(ca!=null) {	
		//System.out.println("JEntityEditor:showElement:ca="+ca.length);
	  for(Core aCa:ca){
		  model.addRow(new String[]{aCa.type,aCa.name,aCa.value});
	  }
	  blockTableListeners=false;
	}
	}catch(Exception e ){
		System.out.println("JEntityEditor:showElement:element="+element$);
		LOGGER.severe(e.toString());
	}
	//System.out.println("EntityEditor: showElement:size="+getSize());
	//System.out.println("JEntityEditor:selectElement="+selectedElement$+" tab size="+tabbedPane.getSize());
}
private Core[] getContent(boolean selected){
	try{
		JScrollPane scrollPane=(JScrollPane)tabbedPane.getSelectedComponent();
		JTable table=(JTable)scrollPane.getViewport().getView();
		DefaultTableModel model=(DefaultTableModel)table.getModel();
		ListSelectionModel listModel=table.getSelectionModel();
		int cnt=model.getRowCount();
		if(cnt<1)
			return null;
		ArrayList<Core>cl=new ArrayList<Core>();
		for(int i=0;i<cnt;i++){
			if(selected)
				if(!listModel.isSelectedIndex(i))
					continue;
			cl.add(new Core((String)model.getValueAt(i, 0),(String)model.getValueAt(i, 1),(String)model.getValueAt(i, 2)));
		}
        return cl.toArray(new Core[0]);		
	}catch(Exception e){
		LOGGER.severe(e.toString());
	}
	return null;
}
private void replaceTable( JTable table,Core[] ca){
	try{
		if(ca==null||ca.length<1)
			return;
	//	System.out.println("JEntityEditor:replaceTable:ca="+ca.length+" selected index="+selectedIndex);
	//	System.out.println("JEntityEditor:replaceTable:table="+table.getName());
		DefaultTableModel model=(DefaultTableModel)table.getModel();
		while(model.getRowCount()>0)
			    model.removeRow(0);
		int cnt=ca.length;
		if(cnt<1)
			return;
//		System.out.println("JEntityEditor:replaceTable:model cnt="+model.getRowCount());
		for(int i=0;i<cnt;i++)
			model.addRow(new String[]{ca[i].type,ca[i].name,ca[i].value});
	}catch(Exception e){
		LOGGER.severe(e.toString());
	}
}
private JTable sort(JTable table,String header$){
	try{
//		System.out.println("EntityEditor.sort:header="+header$);
		blockTableListeners=true;
		DefaultTableModel model=(DefaultTableModel)table.getModel();
		int cnt=model.getRowCount();
		if(cnt<1)
			return table ;
		ArrayList<Core>cl=new ArrayList<Core>();
		for(int i=0;i<cnt;i++){
			cl.add(new Core((String)model.getValueAt(i, 0),(String)model.getValueAt(i, 1),(String)model.getValueAt(i, 2)));
		}
	   Core[] ca=new Core [cl.size()];
	   cl.toArray(ca);
		if("type".equals(header$))
			ca=Core.sortAtType(ca);
		else if ("name".equals(header$))
			ca=Core.sortAtName(ca);
		else if ("value".equals(header$))
			ca=Core.sortAtValue(ca);
		replaceTable(table,ca);
		blockTableListeners=false;
	}catch(Exception e){
		LOGGER.severe(e.toString());
	}
	return table;
}
	
	@Override
	public JMenu getContextMenu() {
		
		menu=super.getContextMenu();
		menu.addSeparator();
		menu.addMenuListener(new MenuListener(){
			@Override
			public void menuCanceled(MenuEvent arg0) {
			}
			@Override
			public void menuDeselected(MenuEvent arg0) {
			}
			@Override
			public void menuSelected(MenuEvent arg0) {
				//System.out.println("JEntityEditor:getContextMenu:getContextMenu:selected:selection interval="+selectionInterval+" requester="+requester$);
				if(deleteItemsItem!=null)
					menu.remove(deleteItemsItem);
				if(copyItem!=null)
					menu.remove(copyItem);
				if(pasteItem!=null)
					menu.remove(pasteItem);
				if(cutItem!=null)
					menu.remove(cutItem);
				if(SessionHandler.hasCores(console.getEntigrator())){
					pasteItem = new JMenuItem("Paste items");
						pasteItem.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							Core[] ca=SessionHandler.getCores(console.getEntigrator());
							for(Core c:ca)
							   entity.putElementItem(selectedElement$, c);
							console.getEntigrator().putEntity(entity);
							refresh();
						}
					} );
					menu.add(pasteItem);
					}
				if(selectionInterval!=null){
					//System.out.println("JEntityEditor:getContextMenu:has selected rows");
					deleteItemsItem = new JMenuItem("Delete items");
					deleteItemsItem.addActionListener(new ActionListener() { 
						@Override
						public void actionPerformed(ActionEvent e) {
							int response = JOptionPane.showConfirmDialog(JEntityEditor.this, "Delete selected items ?", "Confirm",
							        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
						   if (response == JOptionPane.YES_OPTION) {
							   blockTableListeners=true;
								   deleteRows();
						   }
						}
					   });
					menu.add(deleteItemsItem);
				copyItem = new JMenuItem("Copy items");
				copyItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						SessionHandler.putCores(console.getEntigrator(),getContent(true));
					}
				} );
				menu.add(copyItem);
				cutItem = new JMenuItem("Cut items");
				cutItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						SessionHandler.putCores(console.getEntigrator(),getContent(true));
						   deleteRows();
					}
				} );
				menu.add(cutItem);
				}
			}
		});
		JMenuItem refreshItem = new JMenuItem("Refresh");
		refreshItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
		        refresh();
			}
		} );
		menu.add(refreshItem);
		JMenuItem addItemItem = new JMenuItem("Add item");
		addItemItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Core entry=new Core(null,Identity.key().substring(0, 4),null);
				entity.putElementItem(selectedElement$, entry);
		        //System.out.println("JEntityEditor:addItem:element="+selectedElement$);
		        console.getEntigrator().putEntity(entity);
		        refresh();
			}
		} );
		menu.add(addItemItem);
		JMenuItem addElementItem = new JMenuItem("Add element");
		addElementItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String textEditorLocator$=JTextEditor.classLocator();
				textEditorLocator$=Locator.append(textEditorLocator$,JTextEditor.IN_TEXT,"new element");
				textEditorLocator$=Locator.append(textEditorLocator$,PARENT,getInstance());
				locator$=getLocator();
				locator$=Locator.append(locator$,REPLY, Locator.LOCATOR_TRUE);
				locator$=Locator.append(locator$,FacetHandler.FACET_ACTION,ACTION_ADD_ELEMENT);
				String parent$=getInstance();
				if(parent$==null) {
					locator$=Locator.append(locator$, PARENT, JAdminPanel.KEY);
				}
				System.out.println("JEntityEditor:addElement:locator="+locator$);
				SessionHandler.putLocator(console.getEntigrator(), locator$);
				textEditorLocator$=Locator.append(textEditorLocator$,PARENT,getInstance());
				JTextEditor textEditor=new JTextEditor(console,textEditorLocator$);
				JEntityEditor.this.replace(console,textEditor);
			}
		} );
		menu.add(addElementItem);
		menu.addSeparator();		
		JMenuItem deleteElementItem = new JMenuItem("Delete element");
		deleteElementItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				 int response = JOptionPane.showConfirmDialog(JEntityEditor.this, "Delete element="+selectedElement$+ " ?", "Confirm",
					        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				   if (response == JOptionPane.YES_OPTION) {
					   //   System.out.println("JEntityEditor:Delete element="+selectedElement$);
						  entity.removeElement(selectedElement$);
						  console.getEntigrator().putEntity(entity);
						  refresh();
					    } 
			}
		} );
		menu.add(deleteElementItem);
		JMenuItem renameElementItem = new JMenuItem("Rename element");
		renameElementItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//System.out.println("JEntityEditor:renameElement:this locator="+JEntityEditor.this.getLocator());
				String textEditorLocator$=JTextEditor.classLocator();
				textEditorLocator$=Locator.append(textEditorLocator$,JTextEditor.IN_TEXT,selectedElement$);
				String textEditorInstance$=Identity.key();
				textEditorLocator$=Locator.append(textEditorLocator$,INSTANCE,textEditorInstance$);
				
				String thisLocator$=getLocator();
				thisLocator$=Locator.append(thisLocator$,REPLY, Locator.LOCATOR_TRUE);
				thisLocator$=Locator.append(thisLocator$,FacetHandler.FACET_ACTION,ACTION_RENAME_ELEMENT);
				thisLocator$=Locator.append(thisLocator$,JTextEditor.IN_TEXT,selectedElement$);
				display$=console.getDisplayKey(JEntityEditor.this);
				if(display$!=null) {
					textEditorLocator$=Locator.append(textEditorLocator$,DISPLAY,display$);
					thisLocator$=Locator.append(thisLocator$,DISPLAY,display$);
				}
				textEditorLocator$=Locator.append(textEditorLocator$,PARENT,getInstance());
				SessionHandler.putLocator(console.getEntigrator(),thisLocator$);
				JTextEditor textEditor=new JTextEditor(console,textEditorLocator$);
				JEntityEditor.this.replace(console,textEditor);
				return;
			}
		} );
		menu.add(renameElementItem);
		return menu;
	}

	public String getLocator() {
		locator$=Locator.append(locator$,Locator.LOCATOR_TITLE, getTitle());
	    if(entityKey$!=null)
			locator$=Locator.append(locator$,Entigrator.ENTITY_KEY,entityKey$);
	    if(entity$!=null)
	    	locator$=Locator.append(locator$,Entigrator.ENTITY_LABEL,entity$);
		 if(selectedElement$!=null)
			 locator$=Locator.append(locator$,SELECTED_ELEMENT,selectedElement$);
	   return locator$;
	}
	private void refresh() {
		entity=console.getEntigrator().getEntity(entityKey$);
		if(entity==null) {
        	System.out.println("JEntityEditor: refresh:cannot get entity="+entityKey$);
        	return;
		}
		try{
        	//System.out.println("JEntityEditor: refresh:entity="+entity.getProperty("label"));
			blockChangeEvent=true;
			if(tabbedPane!=null) {
				remove(tabbedPane);
			tabbedPane.removeAll();
			}
				tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			    setLayout(new BorderLayout());
				add(tabbedPane);
				ChangeListener changeListener = new ChangeListener() {
				@Override
					public void stateChanged(ChangeEvent changeEvent) {
					if(blockChangeEvent)
						return;	 
					JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
					        int index = sourceTabbedPane.getSelectedIndex();
					        selectedIndex=index;
					        selectedElement$=sourceTabbedPane.getTitleAt(index);
					        selectedTable=getTable(selectedElement$);
					        String locator$=getLocator();
					    	locator$=Locator.append(locator$, SELECTED_ELEMENT, selectedElement$);
					        revalidate();
					        repaint();
					}
				    };
				    tabbedPane.addChangeListener(changeListener);
			showElement(entity,Sack.ATTRIBUTES);
			String[]sa=entity.elementsListNoSorted();
			if(sa==null) {
				System.out.println("JEntityEditor: refresh:sa is null");
				return;
			}
			Arrays.sort(sa);
			for(String aSa:sa)
				showElement(entity,aSa);
			if(selectedElement$!=null)
				if(entity.elementGet(selectedElement$)!=null)
				   selectElement(selectedElement$);
			//System.out.println("EntityEditor: refresh:FINISH");
			blockChangeEvent=false;
			}catch(Exception e){
				LOGGER.severe(e.toString());
			}
		
	}
@Override
	public String getTitle() {
		return "Entity editor";
	}
@Override
public String getSubtitle() {
	return "Label="+entity$+"; Key="+entityKey$;
}
private void selectElement(String element$){
		int cnt=tabbedPane.getComponentCount();
		for(int i=0;i<cnt;i++)
		     if(element$.equals(tabbedPane.getTitleAt(i))){
		    	 tabbedPane.setSelectedIndex(i);
		    	 selectedIndex=i;
		    	 return;
		     }
		//System.out.println("JEntityEditor:selectElement="+selectedElement$+" tab size="+tabbedPane.getSize());	
	}
private void deleteRows(){
		try{
			 blockTableListeners=true;
			JScrollPane scrollPane=(JScrollPane)tabbedPane.getSelectedComponent();
			JTable table=(JTable)scrollPane.getViewport().getView();
			DefaultTableModel tableModel=(DefaultTableModel)table.getModel();
			ListSelectionModel listModel=table.getSelectionModel();
			int rCnt=table.getRowCount();
			ArrayList<Integer>srl=new ArrayList<Integer>();
			for(int i=0;i<rCnt;i++)
				if(listModel.isSelectedIndex(i)){
					srl.add( Integer.valueOf(i));
				}
			Integer[] sra=srl.toArray(new Integer[0]);
			ArrayList<Core> ol=new ArrayList<Core>();
			Core row;
			boolean skip;
			for(int i=0;i<rCnt;i++){
				skip=false;
				for(int aSra:sra){
					if(i==aSra){
						skip=true;
						break;
					}
				}
				if(!skip){
					row =new Core((String)tableModel.getValueAt(i, 0),(String)tableModel.getValueAt(i, 1),(String)tableModel.getValueAt(i, 2));
					ol.add(row);
				}
			}
			Core[] ra=ol.toArray(new Core[0]);
			while(tableModel.getRowCount()>0)
				tableModel.removeRow(0);
			for(Core aRa:ra){
				 tableModel.addRow(new String[]{aRa.type,aRa.name,aRa.value});
			}
			 Core[] ca=getContent(false);
			 if(Sack.ATTRIBUTES.equals(selectedElement$)) {
				 System.out.println("JEntityEditor:deleteRows:ca="+ca.length);
				 entity.attributesReplace(ca);
			 }else
			     entity.elementReplace(selectedElement$, ca);
			 console.getEntigrator().putEntity(entity);
			 refresh();
			 blockTableListeners=false;
		}catch(Exception e){
			LOGGER.severe(e.toString());
		}
	}
	private class SimpleHeaderRenderer extends JLabel implements TableCellRenderer {
		private static final long serialVersionUID = 1L;
		public SimpleHeaderRenderer() {
	        setFont(new Font("Consolas", Font.BOLD, 14));
	        setForeground(Color.BLUE);
	        setBorder(BorderFactory.createEtchedBorder());
	        setHorizontalAlignment( JLabel.CENTER );
	    }
	    @Override
	    public Component getTableCellRendererComponent(JTable table, Object value,
	            boolean isSelected, boolean hasFocus, int row, int column) {
	        setText(value.toString());
	        return this;
	    }
	}
	@Override
	public  void close() {
	  }
	
@Override
	public void onEntigratorEvent(String eventLocator$) {
		String entityLabel$=Locator.getProperty(eventLocator$, Entigrator.ENTITY_LABEL);
		//System.out.println("JEntityEditor:onEntigratorEvent:entity="+entity$+"  label="+entityLabel$);
		if(entity$.equals(entityLabel$))
			refresh();
}
	@Override
	public String reply(JMainConsole console,String locator$) {
//		System.out.println("JEntityEditor:reply:locator="+locator$);
		String action$=Locator.getProperty(locator$, FacetHandler.FACET_ACTION);
		String outtext$=Locator.getProperty(locator$, JTextEditor.OUT_TEXT);
		String intext$=Locator.getProperty(locator$, JTextEditor.IN_TEXT);
		
		//System.out.println("JEntityEditor:reply:action="+action$+" outtext="+outtext$);
		if(ACTION_ADD_ELEMENT.equals(action$)) {
			if(outtext$!=null) {
			//	System.out.println("JEntityEditor:reply:add element="+outtext$);	
			entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
			entityKey$=console.getEntigrator().getKey(entity$);
			entity=console.getEntigrator().getEntity(entityKey$);	
			entity.createElement(outtext$);
			entity.putElementItem(outtext$, new Core(null,"null", null));
			console.getEntigrator().putEntity(entity);
			locator$=Locator.append(locator$,SELECTED_ELEMENT ,outtext$);
			locator$=Locator.remove(locator$, REPLY);
			return locator$;
			}
		}
		if(ACTION_RENAME_ELEMENT.equals(action$)) {
			System.out.println("JEntityEditor:reply:rename element: from old="+intext$+" to  new="+outtext$+" selectedElement="+selectedElement$);		
			if(outtext$!=null&&intext$!=null) {
				entity$=Locator.getProperty(locator$,Entigrator.ENTITY_LABEL);
				entityKey$=console.getEntigrator().getKey(entity$);
				entity=console.getEntigrator().getEntity(entityKey$);
				entity.elementRename(intext$, outtext$);
				console.getEntigrator().putEntity(entity);
				locator$=Locator.append(locator$,SELECTED_ELEMENT ,outtext$);
				locator$=Locator.remove(locator$, REPLY);
				locator$=Locator.merge(locator$, getLocator());
				SessionHandler.putLocator(console.getEntigrator(), locator$);
				return locator$;
			}	
		}
		return locator$;
		
	}
	public static String classLocator() {
		Properties locator=new Properties();
		 locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.entity.JEntityEditor");
	    locator.put(Locator.LOCATOR_TITLE,"Entity editor");
		 locator.put(IconLoader.ICON_FILE,"edit.png");
		 locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		 return Locator.toString(locator);
	}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public boolean handleDone() {
	//	System.out.println("JEntityEditor:handleDone:parent="+parent$);
		JContext.displayInstance(console, parent$);
		return true;
	}
}
