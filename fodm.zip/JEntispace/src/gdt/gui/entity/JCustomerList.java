package gdt.gui.entity;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import gdt.base.facet.ModuleHandler;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;

import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.IconLoader;
import gdt.gui.generic.JContext;
import gdt.gui.generic.JItemPanel;
import gdt.gui.generic.JItemsListPanel;

public class JCustomerList extends JItemsListPanel{

	private static final long serialVersionUID = 1L;
	public  static final String KEY="_JIAvlan7i_S2vdV6_hVBKiffJ8EM";
	public JCustomerList(JMainConsole console, String locator$) {
		super(console, locator$);
		JItemPanel[] ipa=getItems(console,  locator$);
		if(ipa!=null)
			for(JItemPanel ip:ipa)
			  if(ip!=null)	
				addItem(ip);	
	}
	public static String classLocator() {
		Properties locator=new Properties();
		 locator.put(FacetHandler.FACET_CONTAINER_TYPE,FacetHandler.FACET_CONTAINER_INTERNAL);
	    locator.put(CONTEXT_CLASS,"gdt.gui.entity.JCustomerList");
	    locator.put(Locator.LOCATOR_TITLE,"Customers");
		locator.put(IconLoader.ICON_FILE,"include.png");
		locator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		locator.put(INSTANCE, KEY); 
		locator.put(PARENT, JEntityFacetList.KEY);
		locator.put(DEFAULT_PARENT,JEntityFacetList.KEY);
		 return Locator.toString(locator);
	} 
	@Override
	public JMenu getContextMenu() {
		JMenu menu=super.getContextMenu();
		menu=removeItem(menu,"Display");
		menu=removeItem(menu,"Select all");
		menu=removeItem(menu,"Unselect all");
		menu=removeItem(menu,"Delete");
		return menu;
		}
	@Override
	public JItemPanel[] getItems(JMainConsole console, String locator$) {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		Sack customer=console.getEntigrator().getEntityAtLabel(entity$);
		Core[] ca=customer.elementGet(Entigrator.CUSTOMER);
		if(ca==null||ca.length<1)
			return null;
		//System.out.println("JListEntities:add items:ea="+ea.length);
		Properties entityLocator;
		ArrayList<JItemPanel>ipl=new ArrayList<JItemPanel>();
		 {
			 Sack entity;
			String entityLocator$;
			JCustomerItem entityItem;
			String parentKey$=Locator.getProperty(locator$,JContext.INSTANCE);
			for(Core c:ca) {
		       entity=console.getEntigrator().getEntity(c.name);
		       if(entity!=null) {
		    	   entityLocator=new Properties();
		           entityLocator.put(Locator.LOCATOR_TITLE, c.value);
		           entityLocator.put(JItemPanel.ITEM_CHECKABLE,Locator.LOCATOR_FALSE);
		           entityLocator.put(JItemPanel.ITEM_CHECKED,Locator.LOCATOR_FALSE);
		           Core icon=entity.getAttribute("icon");
		           if(icon!=null) {
		        	   entityLocator.put(IconLoader.ICON_FILE,icon.value);
		        	   entityLocator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		        	   if(icon.type!=null&& icon.type.length()>0) {
		        	      entityLocator.put(ModuleHandler.FACET_MODULE,icon.type);
		        	      entityLocator.remove(IconLoader.ICON_CONTAINER);
		        	   }
		           }else {	   
		        	   entityLocator.put(IconLoader.ICON_FILE,"box.png");
		               entityLocator.put(IconLoader.ICON_CONTAINER,IconLoader.ICON_CONTAINER_GENERIC);
		           }
		           entityLocator.put(Entigrator.ENTITY_LABEL,entity$);
		           entityLocator.put(SessionHandler.INSTANCE,c.name);
		           entityLocator.put(JContext.PARENT,parentKey$);
		           entityLocator.put(JContext.DEFAULT_PARENT,KEY);
		           entityLocator.put(Entigrator.CUSTOMER,c.value);
		           String entityType$=entity.getProperty("entity");
		           entityLocator$=Locator.toString(entityLocator);
		           if(entityType$!=null) {
		        	   Sack session=SessionHandler.getSession(console.getEntigrator());
		        	   String iconLocator$=session.getElementItemAt(FacetMaster.ICON_ELEMENT, entityType$);
		        	   entityLocator$=Locator.merge(entityLocator$, iconLocator$);
		           }
		           entityItem=new JCustomerItem(console,entityLocator$);
		            ipl.add(entityItem);
		       }
			}
		}
		JItemPanel[] ipa=new JItemPanel[ipl.size()]; 
		ipl.toArray(ipa);
		return sortItems(ipa);

	}
	private class JCustomerItem extends JItemPanel {
		private static final long serialVersionUID = 1L;
		public JCustomerItem(JMainConsole console, java.lang.String locator$) {
			super(console, locator$);
		}
	@Override
	public JPopupMenu getPopup(JMainConsole console, String locator$) {
		//System.out.println("JCustomerListList:getPopup:locator="+locator$); 
		popup=new JPopupMenu();
		JMenuItem deleteItem=new JMenuItem("Delete");
			 deleteItem.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						//System.out.println("JLinkList:popup:delete:locator="+locator$);
						popup.setVisible(false);	
						int response = JOptionPane.showConfirmDialog(JCustomerList.this, "Delete link ?", "Confirm",	    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
						if (response == JOptionPane.YES_OPTION) {
						try {
						String link$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
						String customer$=Locator.getProperty(locator$, Entigrator.CUSTOMER);
						Entigrator entigrator=console.getEntigrator();
						Sack link=entigrator.getEntityAtLabel(link$);
						Sack customer=entigrator.getEntityAtLabel(customer$);
						link.removeElementItem(Entigrator.CUSTOMER, customer.getKey());
						customer.removeElementItem(Entigrator.LINK, link.getKey());
						entigrator.putEntity(customer);
						entigrator.putEntity(link);
						deleteItem(JCustomerItem.this);
						}catch(Exception ee) {
							System.out.println("JCustomerList:popup:delete:"+ee.toString());	
						}
			  		    }
					}
					});
				popup.add(deleteItem);
		 return popup;
	}
	@Override
	public void onClick(JMainConsole console, String locator$) {
		//System.out.println("JCustomerList:on item click:locator="+locator$);
		String entityLabel$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
		String customer$=Locator.getProperty(locator$, Entigrator.CUSTOMER);
		String facetsLocator$=JEntityFacetList.classLocator();
		facetsLocator$=Locator.append(facetsLocator$,Entigrator.ENTITY_LABEL, customer$);
		facetsLocator$=Locator.append(facetsLocator$, PARENT, KEY);
		JEntityFacetList facetList=new JEntityFacetList(console,facetsLocator$);
		String thisLocator$=JCustomerList.classLocator();
		thisLocator$=Locator.append(thisLocator$, Entigrator.ENTITY_LABEL, entityLabel$);
	//	System.out.println("JCustomerList:on item click:this locator="+thisLocator$);
		JCustomerList.this.replace(console, facetList);
	}
}
	@Override
	public String getClassLocator() {
		return classLocator();
	}
	@Override
	public String reply(JMainConsole console, String locator$) {
		return null;
	}
	@Override
	public boolean handleDone() {
		JContext.displayInstance(console, parent$);
		return true;
	}
}
