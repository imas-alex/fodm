
package gdt.base.btree;
/*
 * Copyright 2016-2023 Alexander Imas
 */

public class BValue {
    public String key;
    public Object value;
    public BNode parent;
    private boolean leaf = true;
    public BValue(String key, Object value) {
        this.key = key;
        this.value = value;
    }
    public boolean containsNode() {
        return !leaf;
    }
    public String toString() {
        return key;
    }
    public void noLeaf() {
        leaf = false;
    }
}
