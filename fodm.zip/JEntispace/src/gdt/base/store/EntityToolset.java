package gdt.base.store;
/*
 * Copyright 2016-2023 Alexander Imas
 */

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

import gdt.base.generic.Locator;
import gdt.gui.generic.FileTool;

public class EntityToolset {
	public static Sack getEntity(IndexHandler indexHandler, String entityKey$){
			return indexHandler.getEntity(entityKey$);
	}
	
	public static Sack getEntityAtLabel( IndexHandler indexHandler, String entityLabel$){
			String entityKey$=indexHandler.getKey(entityLabel$);
			if(entityKey$==null)
				return null;
			return indexHandler.getEntity(entityKey$);
	}
	public static Sack newEntity(IndexHandler indexHandler, String entityLabel$,String entityType$){
		if(indexHandler.labelExists(entityLabel$)) {
			Sack entity=getEntityAtLabel(indexHandler,entityLabel$);
			if(entity!=null) {
			System.out.println("EntityToolset:newEntiy: already exists label="+entityLabel$);
			return null;
		}
		}
		Sack newEntity= new Sack();
		newEntity.createElement("property");
		indexHandler.putEntity(newEntity);
		newEntity=indexHandler.assignLabel(entityLabel$, newEntity.getKey());
		newEntity=indexHandler.assignProperty("entity", entityType$, newEntity.getKey());
		newEntity=indexHandler.assignProperty(entityType$, Locator.LOCATOR_TRUE, newEntity.getKey());
		indexHandler.reindexEntity(newEntity);
		return indexHandler.getEntity(newEntity.getKey());
}
	public static Sack cloneEntity(IndexHandler indexHandler, Sack origin) {
		try {
		String cloneLabel$=origin.getProperty("label")+Identity.key().substring(0,4);
		String cloneType$=origin.getProperty("entity");
		Sack clone=	 newEntity( indexHandler, cloneLabel$,cloneType$);
		
		Core[] ca=origin.attributesGet();
		for(Core c:ca)
			if(c.name.equals("icon"))
			    clone.putAttribute(c);
		String[] ea=origin.elementsListNoSorted();
		for(String e:ea) {
			//System.out.println("EntityToolset:cloneEntiy:element="+e);
			clone.createElement(e);
			ca=origin.elementGet(e);
			for(Core c:ca) {
				if("label".equals(c.type)||"entity".equals(c.type))
					continue;
				clone.putElementItem(e, c);
			}
		}
		File originFolder=new File(indexHandler.entihome$+"/"+origin.getKey());
		if(originFolder.exists()&&originFolder.isDirectory()) {
			File cloneFolder=new File(indexHandler.entihome$+"/"+clone.getKey());
			cloneFolder.mkdir();
			FileTool.copyAll(indexHandler.entihome$+"/"+origin.getKey(), indexHandler.entihome$+"/"+clone.getKey(), FileTool.ADD);
		}
		indexHandler.reindexEntity(clone);
		
		return clone;
		}catch(Exception e) {
			System.out.println("EntityToolset:cloneEntiy:"+e.toString() );
		}
		return null;
	}
	public static Sack newEntity(IndexHandler indexHandler, String entityLabel$,String entityType$,String key$){
		if(indexHandler.labelExists(entityLabel$)) {
			System.out.println("EntityToolset:newEntiy: already exists label="+entityLabel$);
			return null;
		}
		System.out.println("EntityToolset:newEntiy:label="+entityLabel$+"  type="+entityType$+" key="+key$);
		Sack newEntity= new Sack();
		newEntity.setKey(key$);
		newEntity.setPath(key$);
		newEntity.createElement("property");
		indexHandler.putEntity(newEntity);
		newEntity=indexHandler.getEntity(key$);
		indexHandler.assignLabel(entityLabel$, newEntity.getKey());
		indexHandler.assignProperty("entity", entityType$, key$);
		indexHandler.reindexEntity(newEntity);
		return indexHandler.getEntity(key$);
}
	public static boolean deleteEntity(IndexHandler indexHandler, String entityKey$){
      	try {
		folderDelete(indexHandler, entityKey$);
		return indexHandler.deleteEntity(entityKey$);
      	}catch(Exception e) {
      		System.out.println("EntityHandler:deleteEntity:"+e.toString());
      		return false;
      	}
}
	public static boolean exportEntity(IndexHandler sourceHandler,IndexHandler targetHandler, String entityKey$){
      	try {
		Sack entity=sourceHandler.getEntity(entityKey$);
		targetHandler.putEntity(entity);
		
		if(folderExists(sourceHandler,entityKey$)) {
			String targetDirectory$=folderCreate(targetHandler,entityKey$);
			String sourceDirectory$=sourceHandler.getEntihome()+"/"+entityKey$;
			copyDirectory(sourceDirectory$, targetDirectory$); 
		}
		return true;
      	}catch(Exception e) {
      		System.out.println("EntityHandler:exportEntity:"+e.toString());
      	}
      	return false;
		}
	public static String[] listProperties(Sack entity) {
		if(entity==null)
			return null;
		Core[] ca=entity.elementGet("property");
		if(ca==null)
			return null;
		String[]sa =new String[ca.length];
		for(int i=0;i<ca.length;i++)
			sa[i]=ca[i].type;
		return sa;
	}
	
	public static Sack reindex(IndexHandler indexHandler,Sack entity) {
		if(entity==null)
			return entity;
		return indexHandler.reindexEntity(entity);
	}
	public static String getPropertyValue(Sack entity,String property$) {
		if(entity==null)
			return null;
		if(property$==null)
			return null;
		Core[] ca=entity.elementGet("property");
		if(ca==null)
			return null;
		String[]sa =new String[ca.length];
		for(int i=0;i<ca.length;i++)
			if(property$.equals(ca[i].type))
					return ca[i].value;
			return null;
	}
	public static String getLocator( IndexHandler indexHandler, String entityKey$){
		Core entry=indexHandler.getEntityEntry(entityKey$);
		if(entry==null) {
			System.out.println("EntityHandler:getLocator:cannot get entity entry for key="+entityKey$);
	    	return null;
		}
		String entihome$=indexHandler.getEntihome();
		Properties locator=new Properties();
	    locator.setProperty(Entigrator.ENTIHOME,entihome$);
	    locator.setProperty(Entigrator.ENTITY_TYPE,entry.type);
	    locator.setProperty(Entigrator.ENTITY_KEY,entityKey$);
	    locator.setProperty(Entigrator.ENTITY_LABEL,entry.value);
		return Locator.toString(locator);
}
	public static String folderCreate( IndexHandler indexHandler, String entityKey$){
		String entihome$=indexHandler.getEntihome();
		File folder=new File(entihome$+"/"+entityKey$);
		if(folder.exists())
			if(folder.isFile())
			  return null;
			else
			  return folder.getPath();
		else {
			folder.mkdir();
			 return folder.getPath();
		}
	}
	public static boolean folderExists( IndexHandler indexHandler, String entityKey$){
		String entihome$=indexHandler.getEntihome();
		File folder=new File(entihome$+"/"+entityKey$);
		if(folder.exists()&&folder.isDirectory())
			return true;
		else 
			return false;
	}
	public static File folderFile( IndexHandler indexHandler, String entityKey$){
		String entihome$=indexHandler.getEntihome();
		return new File(entihome$+"/"+entityKey$);
	}
	public static boolean folderDelete( IndexHandler indexHandler, String entityKey$){
		String entihome$=indexHandler.getEntihome();
		File folder=new File(entihome$+"/"+entityKey$);
		if(folder.exists())
			return deleteDirectory(folder);
		return true;
	}
	
	public static void copyDirectory(String sourceDirectoryLocation, String destinationDirectoryLocation) 
   throws IOException {
    Files.walk(Paths.get(sourceDirectoryLocation))
      .forEach(source -> {
          Path destination = Paths.get(destinationDirectoryLocation, source.toString()
            .substring(sourceDirectoryLocation.length()));
          try {
                Files.copy(source, destination,StandardCopyOption.REPLACE_EXISTING);
          } catch (IOException e) {
              e.printStackTrace();
          }
      });
}
	public static boolean deleteDirectory(File directoryToBeDeleted) {
	    File[] allContents = directoryToBeDeleted.listFiles();
	    if (allContents != null) {
	        for (File file : allContents) {
	        	if(file.isFile())
	        		file.delete();
	        	else
	        		deleteDirectory(file);
	        }
	    }
	    return directoryToBeDeleted.delete();
	}
}
