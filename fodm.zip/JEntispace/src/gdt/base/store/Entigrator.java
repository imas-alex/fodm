package gdt.base.store;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.jar.JarFile;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import javax.swing.ImageIcon;
import gdt.base.facet.ModuleHandler;
import gdt.base.generic.Locator;
import gdt.base.generic.SessionHandler;


public class Entigrator implements IndexListener{
	public static final String ENTIHOME="entihome";
	public static final String ENTITY_TYPE="entity type";
	public static final String ENTITY_KEY="entity key";
	public static final String ENTITY_LABEL="entity label";
	public static final String ENTITY_CHANGED="entity changed";
	public static final String ENTITY="entity";
	public static final String LABEL="label";
	public static final String CUSTOMER="customer";
	public static final String LINK="link";
	IndexHandler indexHandler;
	EntigratorListener entigratorListener;
	EntigratorClassLoader entigratorClassLoader;
	private ArrayList<EntigratorListener> listeners=new ArrayList<EntigratorListener>();
	//public String SESSION_KEY;
	public boolean isValid=false;
	public Entigrator(String entihome$) {
		try {
		//System.out.println("Entigrator:BEGIN entihome="+entihome$);
		indexHandler=new IndexHandler(entihome$,false);
		indexHandler.setIndexListener(this);
	    entigratorClassLoader=new EntigratorClassLoader(new URL[0],ClassLoader.getSystemClassLoader());
		attachModules();
	    isValid=true;
	    initSettings();
		}catch(Exception e) {
			System.out.println("Entigrator:"+e.toString()); 
		}
		
		}
	public Entigrator(String entihome$, boolean rebuild) {
		indexHandler=new IndexHandler(entihome$,rebuild);
		indexHandler.setIndexListener(this);
	    entigratorClassLoader=new EntigratorClassLoader(new URL[0],ClassLoader.getSystemClassLoader());
	    attachModules();
	    isValid=true;
	    initSettings();
		}
	private void initSettings() {
		int delay=15000;
		int keep=10;
		Sack settings=getSettings();
		if(settings==null) {
			System.out.println("Entigrator:no settings");
			return;
		}
		try {delay=Integer.parseInt(settings.getElementItemAt("base", "_delay"));}catch(Exception ee) {}
		try {keep=Integer.parseInt(settings.getElementItemAt("base", "_keep"));}catch(Exception ee) {}
		setDelay(delay);
		SessionHandler.forgetOld(this, keep);
	}
	public URLClassLoader getClassLoader() {
		return entigratorClassLoader;
	}
	
	public Class<?> getClass( String className$) {
		if(className$==null) {
			System.out.println("Entigrator:getClass:class name is null");
			return null;
		}
		try{
			 return entigratorClassLoader.loadClass(className$);
			 
		}catch(Exception e) {
				System.out.println("Entigrator:getClass:class="+className$+"   error="+e.toString());
				e.printStackTrace();
			}
		return null;
	}
	
	public void addURL(String urlFile$) {
		File urlFile=new File(urlFile$);
		try {
		URL url=urlFile.toURI().toURL();
		entigratorClassLoader.addUrl(url);
		}catch(Exception e) {
			System.out.println("Entigrator:addURL:"+e.toString());
		}
	}
	
	public void attachModules() {
		try {
		String[] sa=listEntities("module","true");
		ArrayList<URL> urll=new ArrayList<URL>();
		String[] fl;
		File lib;
		//System.out.println("Entigrator:attachModules:sa="+sa.length);
		if(sa!=null)
			for(String s:sa) {
				try {
				lib=new File(getEntihome()+"/"+s+"/lib");
				if(!lib.exists())
					continue;
				fl=lib.list();
				boolean found=false;
				if(fl!=null&&fl.length>0) {
					for(String f$:fl) {
						found=false;
						//System.out.println("Entigrator:attachModules:f="+f$);
					  if(f$.endsWith(".jar")) {
						File f=new File(getEntihome()+"/"+s+"/lib/"+f$);
						URL url=f.toURI().toURL();
						//System.out.println("Entigrator:attachModules:url="+url.toString());
						urll.add(url);
						found=true;
					  }
					  if(!found) {
							System.out.println("Entigrator:attachModules:no library in module="+f$);
						}  
					}
				}
				
				} catch (MalformedURLException e) {
					System.out.println("Entigrator:attachModules:0:"+e.toString());
				}
			}
		if(urll.size()>0) {
			URL [] urla=new URL[urll.size()];
			urll.toArray(urla);
			for(URL url:urla)
			   entigratorClassLoader.addUrl(url);
		}
		}catch(Exception e) {
			System.out.println("Entigrator:attachModules:"+e.toString());	
		}
	}
	
	public void clone(String newhome$) {
		IndexHandler newHandler=new  IndexHandler( newhome$,false);
		newHandler.makeNewIndex(newhome$);
		String[] ea=indexHandler.listEntities(null, null);
		if(ea!=null)
			for(String e:ea) {
				EntityToolset.exportEntity(indexHandler ,newHandler, e);
			}
	}
	public String getEntihome() {
		return indexHandler.getEntihome();
	}
	
	// entity 
	public String getLabel(String entityKey$) {
		 return indexHandler.getLabel( entityKey$);
	}
	public String getKey(String entityLabel$) {
		 return indexHandler.getKey(entityLabel$);
	}
	public Sack getEntity(String entityKey$) {
		 Sack entity= EntityToolset.getEntity(indexHandler,entityKey$);
		 if(entity==null)
			 return null;
		 return entity;
	}
	public Sack getEntityAtLabel(String entityLabel$) {
		if(indexHandler==null)
			return null;
		 return EntityToolset.getEntityAtLabel(indexHandler,entityLabel$);
	}
	public String[] listProperties(Sack entity) {
		String[] sa=EntityToolset.listProperties(entity);
		Arrays.sort(sa);
		return sa;
	}
	public String getPropertyValue(Sack entity,String property$) {
		return EntityToolset.getPropertyValue(entity, property$);
	}
	public boolean putEntity(Sack entity) {
		      notifyPutEntity(entity.getProperty(LABEL));    
		      entity.setPath(getEntihome()+"/"+IndexHandler.CONTAINER_ENTITIES+"/data/"+entity.getKey());
		      return indexHandler.putEntity(entity);
	}
	public Sack reindexEntity(Sack entity) {
		return indexHandler.reindexEntity(entity);
	}
	public boolean deleteEntityRecursively(String entityKey$) {
		try {
		Sack entity=getEntity(entityKey$);
		String[] sa=entity.elementListNames("customer");
		
		if(sa!=null) {
		   Sack customer;
		   for(String s:sa) {
		   customer=getEntity(s);
		   if(customer!=null)
			   unlink(customer,entity);
		   else
			   entity.removeElementItem("customer", s); 
		   }
		}
        sa=entity.elementListNames("link");
		if(sa!=null) 
			for(String s:sa)
			    deleteEntityRecursively(s);   
		
		return EntityToolset.deleteEntity(indexHandler, entityKey$);
		}catch(Exception e) {
			System.out.println("Entigrator:deleteEntity:"+e.toString());
			return false;
		}
	}
	public boolean deleteEntity(String entityKey$) {
		try {
		Sack entity=getEntity(entityKey$);
		String[] sa=entity.elementListNames("customer");
		
		if(sa!=null) {
		   Sack customer;
		   for(String s:sa) {
		   customer=getEntity(s);
		   if(customer!=null)
			   unlink(customer,entity);
		   else
			   entity.removeElementItem("customer", s); 
		   }
		}
        sa=entity.elementListNames("link");
		if(sa!=null) {
		   Sack link;
		   for(String s:sa) {
		       link=getEntity(s);
		   if(link!=null)
			   unlink(entity,link);
		   else
			   entity.removeElementItem("link", s);
		   }
		}
		}catch(Exception e) {
			System.out.println("Entigrator:deleteEntity:"+e.toString());
		}
		return EntityToolset.deleteEntity(indexHandler, entityKey$);
	}
	public boolean deleteEntities(String property$,String value$) {
		String[]sa=listEntities(property$,value$);
		if(sa!=null)
			for(String s:sa)
				deleteEntity(s);
		return true;
	}
	public Sack createEntity(String entityLabel$,String entityType$) {
		return EntityToolset.newEntity(indexHandler ,entityLabel$,entityType$);
	}
	public String getEntityLocator(String entityKey$) {
		return EntityToolset.getLocator(indexHandler,  entityKey$);
	}
	public  boolean folderExists( String entityKey$) {
		return EntityToolset.folderExists(indexHandler, entityKey$);
	}
	public  File folderFile(String entityKey$) {
		return EntityToolset.folderFile(indexHandler, entityKey$);
	}
	public String folderCreate( String entityKey$) {
		return EntityToolset.folderCreate(indexHandler, entityKey$);
	}
	public boolean folderDelete( String entityKey$) {
		return EntityToolset.folderDelete(indexHandler, entityKey$);
	}
	public  Sack newEntity( String entityLabel$,String entityType$){
		return EntityToolset.newEntity(indexHandler, entityLabel$, entityType$);
	}
	public  Sack newEntity( String entityLabel$,String entityType$,String key$){
		return EntityToolset.newEntity(indexHandler, entityLabel$, entityType$,key$);
	}
	public  Sack cloneEntity(Sack origin){
		return EntityToolset.cloneEntity(indexHandler, origin);
	}
	//property
	public String[] listProperties() {
		String[] pa=indexHandler.listProperties();
		if(pa==null)
			return null;
		Arrays.sort(pa); 
		return pa;
	}
	public String[] listValues(String property$) {
		String[] va=indexHandler.listValues(property$);
		if(va!=null)
		   Arrays.sort(va); 
		return va;
	}
	public String[] listEntities() {
		
		return indexHandler.listEntities();
	}
	public String[] listEntities(String property$) {
		String[] ea=indexHandler.listEntities(property$);
		return ea;
	}
	public String[] listEntities(String property$,String value$) {
		String[] ea=indexHandler.listEntities(property$,value$);
		return ea;
	}
	public boolean addProperty(String property$) {
		return indexHandler.addProperty(property$);
	}
	public boolean addPropertyValue(String property$,String value$) {
		return indexHandler.addPropertyValue(property$,value$) ;
	}
	public Sack assignProperty(String property$,String value$,String entityKey$) {
		return indexHandler.assignProperty(property$,value$, entityKey$);
	}
	public Sack removeProperty(String property$,String entityKey$) {
		return indexHandler.removeProperty(property$, entityKey$);
	}
	 public Sack assignLabel(String label$,String entityKey$) {
		 return indexHandler.assignLabel(label$,entityKey$);
	 }
	public boolean deleteProperty(String property$) {
		return indexHandler.deleteProperty(property$);
	}
	public boolean deleteValue(String property$,String value$) {
		return indexHandler.deleteValue(property$,value$); 
	}
	public boolean editProperty(String property$,String newProperty$) {
		return indexHandler.editProperty(property$,newProperty$);
	}
	 public boolean editValue(String property$,String value$,String newValue$) {
		 return indexHandler.editValue(property$, value$, newValue$); 
	 }
	public boolean deleteUnusedProperty(String property$) {
		return indexHandler.deleteUnusedProperty(property$);
	}
	public boolean deleteUnusedValue(String property$,String value$) {
		return indexHandler.deleteUnusedValue(property$,value$);
	}
	 public boolean deleteUnusedValues(String property$) {
		 return indexHandler.deleteUnusedValues(property$);
	 }
	 public boolean deleteUnusedProperties() {
		 return indexHandler.deleteUnusedProperties();
	 }
	 public Sack makeNewIndex(String entihome$) {
		 return indexHandler.makeNewIndex(entihome$);
	 }
	 public Sack takeOffProperty(String property$,String entityKey$) {
		 return indexHandler.takeOffProperty(property$, entityKey$);
	 }
	public void close() {
		SessionHandler.store(this);
		indexHandler.close();
	}
	public void rebuildIndex() {
			indexHandler.pauseContainerServices(true);
			indexHandler.rebuildIndex();
			indexHandler=new IndexHandler(getEntihome(),true);
		    indexHandler.pauseContainerServices(false);
	}
	public ImageIcon getGenericIcon(String iconFile$){
		try{
			URL imageURL = getClass().getClassLoader().getResource(iconFile$);
			ImageIcon icon = new ImageIcon(imageURL);
			BufferedImage oldImage = new BufferedImage(icon.getIconWidth(), icon.getIconHeight(), BufferedImage.TYPE_INT_RGB);
			BufferedImage newImage = new BufferedImage(24, 24, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = newImage.createGraphics();
			g.setColor(Color.WHITE);
		    g.fillRect(0, 0, 24, 24);
			g.drawImage(oldImage, 0, 0, 24, 24, null);
			g.dispose();
			return new ImageIcon(newImage);
			
		}catch(Exception e){
			 Logger.getLogger(getClass().getName()).severe(e.toString());
			 
		}

		return null;
		}
	
	public void notifyPutEntity(String entity$) {
		if(entity$==null)
			return;
		if("current".equals(entity$))
			return;
		
		String locator$=EntigratorListener.getDefaultLocator();
		locator$=Locator.append(locator$, ENTITY_LABEL, entity$);
		Iterator<EntigratorListener> iter = listeners.iterator();
//		System.out.println("Entigrator:notifyPut:entity="+entity$+" listeners="+listeners.size());
		EntigratorListener listener;
		int cnt=0;
		while (iter.hasNext()) {
			if(cnt++>10)
				break;
			try {
				listener=iter.next();
			if(listener==null)
				continue;
			listener.onEntigratorEvent(locator$);
			}catch(Exception e) {
				System.out.println("Entigrator:notifyPut:"+e.toString());	
			}
		}
	}
	public void addListener(EntigratorListener listener) {
		listeners.add(listener);
	}
	public void removeListener(EntigratorListener listener) {
		listeners.remove(listener);
	}
    public URL[] listURLs() {
    	return entigratorClassLoader.getURLs();
    }
   
	@Override
	public void onIndexEvent(String locator$) {
		// TODO Auto-generated method stub
		
	}
	public InputStream  getResource(String resourcePath$) {
		try {
			String[] sa=resourcePath$.split("/");
			String module$=sa[0];
			String jarfile$=getEntihome()+"/"+module$+"/lib/"+module$+".jar";
			JarFile jarfile=new JarFile(jarfile$);
			 ZipEntry jarEntry =jarfile.getEntry(resourcePath$);
		    return jarfile.getInputStream(jarEntry);
		}catch(Exception e) {
			System.out.println("Entigrator:getResouce:"+e.toString());	
		}
		return null;
	}
	public static boolean isValid(String entihome$) {
		try {
			Entigrator entigrator=new Entigrator(entihome$);
			return entigrator.isValid;
		}catch(Exception e) {
			return false;
		}
	}
	public Sack link(Sack customer,Sack link) {
		try {
		if(!customer.existsElement(LINK))
			customer.createElement(LINK);
		if(!link.existsElement(CUSTOMER))
			link.createElement(CUSTOMER);
		customer.putElementItem(LINK, new Core(null,link.getKey(),link.getProperty("label")));
		link.putElementItem(CUSTOMER, new Core(null,customer.getKey(),customer.getProperty("label")));
		putEntity(link);
		putEntity(customer);
		return customer;
		}catch(Exception e) {
			System.out.println("Entigrator:link:"+e.toString());	
		}
		return customer;
	}
	public Sack unlink(Sack customer,Sack link) {
		try {
		customer.removeElementItem(LINK, link.getKey());
		link.removeElementItem(CUSTOMER, customer.getKey());
		putEntity(link);
		putEntity(customer);
		return customer;
		}catch(Exception e) {
			System.out.println("Entigrator:link:"+e.toString());	
		}
		return customer;
	}
	public String[] listCustomers(Sack link) {
			if(link==null)
				return null;
		return link.elementListNames(CUSTOMER);
	}
	public void setDelay(int delay) {
		indexHandler.setDelay(delay);
	}
	public Sack getSettings() {
		
		Sack settings=getEntityAtLabel("settings");
		if(settings!=null) {
			return settings;
		}
		
		try { settings= createEntity("settings","sysbase");}catch(Exception e) {
			System.out.println("Entigrator:getSettings:failed create new settings:"+e.toString());
		}
		if(settings==null) {
			System.out.println("Entigrator:getSettings::cannot create new session ");
			return null;
		}
    	 settings.putAttribute(new Core(ModuleHandler.SYSTEM,"icon","settings.png"));
		return settings;
	}
class EntigratorClassLoader extends URLClassLoader{
	public EntigratorClassLoader( URL[] urls, ClassLoader parent) {
		super( urls, parent);
	}
	
public void addUrl(URL url) {
	super.addURL(url);
}
 public Class<?> findClass​(String moduleName, String name){
	return super.findClass(moduleName, name);
}
}
}
