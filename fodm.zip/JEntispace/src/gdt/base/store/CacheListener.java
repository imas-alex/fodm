package gdt.base.store;

import java.util.EventListener;

public interface CacheListener extends EventListener{
	void onCacheEvent(String locator$);
}
