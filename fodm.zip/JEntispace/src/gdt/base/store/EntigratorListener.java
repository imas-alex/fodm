package gdt.base.store;

import java.util.EventListener;
import java.util.Properties;

import gdt.base.generic.Locator;

public interface EntigratorListener extends EventListener{
	public final String  EVENT_SOURCE="source";
	public final String  EVENT_ENTIGRATOR="entigrator";
	static  String getDefaultLocator() {
		Properties locator=new Properties();
		locator.put(EVENT_SOURCE,EVENT_ENTIGRATOR );
		return Locator.toString(locator);
	}
	void onEntigratorEvent(String locator$);
}

