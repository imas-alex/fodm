package gdt.base.store;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.util.EventListener;
public interface IndexListener extends EventListener{
	void onIndexEvent(String locator$);
}
