package gdt.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import javax.swing.filechooser.FileFilter;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.IndexHandler;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;
import gdt.gui.generic.FileTool;

public class ProjectHandler extends FacetHandler{
	public static final String KEY="_UhYQQb945G1bf0c9DimVfO_SQKZA";	
	public static final String PROJECT_FACET_NAME="Project";
	public static final String PROJECT_FACET_TYPE="project";
	public static final String PROJECT_FACET_CLASS="gdt.base.facet.ProjectHandler";
	public ProjectHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	
	}
	
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,PROJECT_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_TRUE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_TRUE);
		locator.put(FACET_HANDLER_CLASS,PROJECT_FACET_CLASS);
		locator.put(FACET_TYPE,PROJECT_FACET_TYPE);
		locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.ProjectMaster");
		locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
		return Locator.toString(locator);
	}
	@Override
	public String getName() {
		return PROJECT_FACET_NAME;
	}

	@Override
	public String getType() {
		return PROJECT_FACET_TYPE;
	}

	@Override
	public String getFacetClass() {
		return PROJECT_FACET_CLASS;
	}

	@Override
	public String getKey() {
		return KEY;
	}
	private static void collectEntityFiles(Entigrator entigrator,String entityKey$,ArrayList<String>sl){
		try {
            String entihome$=entigrator.getEntihome();
            String entityPath$=entihome$+"/"+IndexHandler.CONTAINER_ENTITIES+"/data/"+entityKey$;
            sl.add(entityPath$);
            String entityRoot$=entihome$+"/"+entityKey$;
            FileTool.collect(entityRoot$, sl);
		} catch(Exception e) {
			System.out.println("ProjectHandler:collectEntityFiles"+ e.toString()); 
		}
	
		
	}
	public static void  export(String directory$, Entigrator entigrator,String project$) {
       try {
		FileOutputStream fos = new FileOutputStream(directory$+"/"+project$+".zip");
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        ArrayList<String>fl=new ArrayList<String>();
        String projectKey$=entigrator.getKey(project$);
        String[] ea= BaseHandler.allLinks(entigrator,projectKey$);
        for(String e:ea) {
         	try {
        	collectEntityFiles(entigrator,e,fl);
        	}catch(Exception ee) {
        		System.out.println("ProjectHandler:export:e="+"   error:"+ee.toString());	
        	}
        }
        String localPath$;
        for (String f :fl) {
            File fileToZip = new File(f);
            FileInputStream fis = new FileInputStream(fileToZip);
            localPath$=fileToZip.getPath().replace(entigrator.getEntihome(),"");
            ZipEntry zipEntry = new ZipEntry(localPath$);
            zipOut.putNextEntry(zipEntry);
            byte[] bytes = new byte[1024];
            int length;
            while((length = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, length);
            }
            fis.close();
        }
        zipOut.close();
        fos.close();
       }catch(Exception e) {
    	   System.out.println("ProjectHandler:export"+ e.toString());  
       }
    }
	public static void  exportCollection(String directory$, Entigrator entigrator,String collectionName$,String[]ma) {
	       try {
			if(ma==null) {
	        	System.out.println("ProjectHandler:exportCollection:no members in collection");
	        	return;
	        }
			FileOutputStream fos = new FileOutputStream(directory$+"/"+collectionName$+".zip");
	        ZipOutputStream zipOut = new ZipOutputStream(fos);
	        ArrayList<String>fl=new ArrayList<String>();
	        
	        for(String m$:ma) {
	        	String[] ea= BaseHandler.allLinks(entigrator,m$);
	        for(String e:ea) {
	        	//System.out.println("ProjectHandler:exportCollection:e="+e);
	        	try {
	        	collectEntityFiles(entigrator,e,fl);
	        	}catch(Exception ee) {
	        		System.out.println("ProjectHandler:export:e="+"   error:"+ee.toString());	
	        	}
	        }
	        }
	        String localPath$;
	        for (String f :fl) {
	            File fileToZip = new File(f);
	            FileInputStream fis = new FileInputStream(fileToZip);
	            localPath$=fileToZip.getPath().replace(entigrator.getEntihome(),"");
	            ZipEntry zipEntry = new ZipEntry(localPath$);
	            zipOut.putNextEntry(zipEntry);
	            byte[] bytes = new byte[1024];
	            int length;
	            while((length = fis.read(bytes)) >= 0) {
	                zipOut.write(bytes, 0, length);
	            }
	            fis.close();
	        }
	        zipOut.close();
	        fos.close();
	       }catch(Exception e) {
	    	   System.out.println("ProjectHandler:export"+ e.toString());  
	       }
	    }
	public static void unzip(String zip$, Entigrator entigrator) {
	        File destDir = new File(entigrator.getEntihome());
	        byte[] buffer = new byte[1024];
	        File fileZip=new File(zip$);
	       // ZipInputStream zis=null;
			try {
				 ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip));
				 ZipEntry zipEntry = zis.getNextEntry();
				while (zipEntry != null) {
					File newFile = newFile(destDir, zipEntry);
				     if (zipEntry.isDirectory()) {
				         if (!newFile.isDirectory() && !newFile.mkdirs()) {
				        	 zis.close();
				         	 return;
				         }
				     } else {
				         // fix for Windows-created archives
				         File parent = newFile.getParentFile();
				         if (!parent.isDirectory() && !parent.mkdirs()) {
				             zis.close();
				        	 return; 
				         }
				         
				         // write file content
				         FileOutputStream fos = new FileOutputStream(newFile);
				         int len;
				         while ((len = zis.read(buffer)) > 0) {
				             fos.write(buffer, 0, len);
				         }
				         fos.close();
				     }
				     zipEntry = zis.getNextEntry();
				}
				zis.closeEntry();  
				zis.close();
			} catch (IOException e) {
				System.out.println("ProjectHandler:unzip:"+e.toString());
			}
	}
	private static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
	    File destFile = new File(destinationDir, zipEntry.getName());
	    String destDirPath = destinationDir.getCanonicalPath();
	    String destFilePath = destFile.getCanonicalPath();
	    if (!destFilePath.startsWith(destDirPath + File.separator)) {
	        throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
	    }
	    return destFile;
	}
	public static class ZipFilter extends FileFilter{
		@Override
		public boolean accept(File file) {
			 if (file.getName().endsWith(".zip")	||file.getName().endsWith(".ZIP")) 
			      return true;
			  else
				  return false;
		}
		@Override
		public String getDescription() {
				return null;
		}
		}
	public static Sack add(Entigrator entigrator, Sack entity) {
		try { 
	       
	        entity=entigrator.assignProperty(PROJECT_FACET_TYPE,Locator.LOCATOR_TRUE,entity.getKey());
	        if(!entity.existsElement(FACET))
	        	entity.createElement(FACET);
	        entity.putElementItem(FACET, new Core(ModuleHandler.SYSTEM,KEY,classLocator()));
	        entigrator.reindexEntity(entity);
	        entigrator.putEntity(entity);
			return entity;
	        }catch(Exception e) {
	        	System.out.println("ProjectHandler:apply:"+e.toString());
				return null;
	        }
	}
	public static Sack delete(Entigrator entigrator, Sack entity) {	
		if(entity==null)
			return null;
		String entityType$=entity.getProperty("entity");
		if(PROJECT_FACET_TYPE.equals(entityType$))
			return entity;
		try {
		entity=entigrator.takeOffProperty(PROJECT_FACET_TYPE, entity.getKey());
		entity.removeElementItem(FACET, KEY);
		entigrator.putEntity(entity);
	}catch(Exception e) {
	   System.out.println("ProjectHandler:remove:"+e.toString());
	}
	   return entity;
	}
	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
		return add(entigrator, entity);
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
		return delete(entigrator, entity);
	}
}
