package gdt.base.facet;

import java.util.Properties;

import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Entigrator;
import gdt.base.store.Sack;
import gdt.gui.console.JMainConsole;
import gdt.gui.facet.FacetMaster;

public class PerspectiveHandler extends FacetHandler{
	public static final String KEY="_47co139EsVtLoZMSwjsCJ0AcumQ";	
	public static final String PERSPECTIVE_FACET_NAME="Perspective";
	public static final String PERSPECTIVE_FACET_TYPE="perspective";
	public static final String PERSPECTIVE_FACET_CLASS="gdt.base.facet.PerspectiveHandler";
	public PerspectiveHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	
	}
	@Override
	public String getName() {
		return PERSPECTIVE_FACET_NAME;
	}

	@Override
	public String getType() {
		return PERSPECTIVE_FACET_TYPE;
	}

	@Override
	public String getFacetClass() {
		return PERSPECTIVE_FACET_CLASS;
	}
	@Override
	public String getKey() {
		return KEY;
	}

	@Override
	public Sack apply(Entigrator entigrator, Sack entity) {
			return null;
	}

	@Override
	public Sack remove(Entigrator entigrator, Sack entity) {
			return null;
	}
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,PERSPECTIVE_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_FALSE);
		locator.put(FACET_HANDLER_CLASS,PERSPECTIVE_FACET_CLASS);
		locator.put(FACET_TYPE,PERSPECTIVE_FACET_TYPE);
		locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
		locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.PerspectiveMaster");
		return Locator.toString(locator);
	}
   public void putDisplay(Entigrator entigrator,String locator$) {
	   try {
		   String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	   }catch(Exception e) {
		   System.out.println("PerspectiveHandler:putDisplay:"+e.toString());
	   }
   }

}
