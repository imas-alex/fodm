package gdt.base.facet;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.io.File;
import java.util.Properties;
import gdt.base.generic.FacetHandler;
import gdt.base.generic.Locator;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.EntityToolset;
import gdt.base.store.Sack;
import gdt.gui.facet.FacetMaster;

public class FolderHandler extends FacetHandler{
	protected String facetHandlerKey$;
	public FolderHandler(Entigrator entigrator, String alocator$) {
		super(entigrator, alocator$);
	}
	public FolderHandler() {
		super();
	}
	public static final String KEY="_EPLKJlQuhun7QAL0_JMK_SUyRYDQ";	
	public static final String FOLDER_FACET_NAME="Folder";
	public static final String FOLDER_FACET_TYPE="folder";
	public static final String FOLDER_FACET_CLASS="gdt.base.facet.FolderHandler";
	public static String classLocator() {
		Properties locator=new Properties();
		locator.put(FACET_KEY,KEY);
		locator.put(FACET_NAME,FOLDER_FACET_NAME);
		locator.put(FACET_TYPE,FOLDER_FACET_TYPE);
		locator.put(FACET_ADDABLE,Locator.LOCATOR_TRUE);
		locator.put(FACET_REMOVABLE,Locator.LOCATOR_TRUE);
		locator.put(FACET_HANDLER_CLASS,FOLDER_FACET_CLASS);
		locator.put(CONTAINS_FOLDER,Locator.LOCATOR_TRUE);
		locator.put(ModuleHandler.FACET_MODULE,ModuleHandler.SYSTEM);
		locator.put(FacetMaster.MASTER_CLASS,"gdt.gui.facet.FolderMaster");
		return Locator.toString(locator);
	}
	public static Sack assign(Entigrator entigrator, String locator$) {
	//try { 
        String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);	
		if(entity$==null){
			System.out.println("FolderHandler:assign:entity label is null.Return");
        	locator$=Locator.append(locator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_FALSE); 
			return null;
		}
		Sack entity=entigrator.getEntityAtLabel(entity$);
		return add(entigrator,entity);
}
public String clearFolder(Entigrator entigrator,String locator$) {
	 try { 	
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);	
		if(entity$==null) {
				System.out.println("FolderHandler:clearFolder:entity label is null");
				locator$=Locator.append(locator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_FALSE); 
 			return locator$;
		}
	String path$=entigrator.getEntihome()+"/"+entigrator.getKey(entity$);
    File folder=new File(path$);
    if(folder.exists()) 
       EntityToolset.deleteDirectory(folder);
    locator$=Locator.append(locator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_TRUE); 
	return locator$;
	 }catch(Exception e) {
	     	System.out.println("FolderHandler:clearFolder:"+e.toString());
	     	 locator$=Locator.append(locator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_FALSE); 
				return locator$;
	     }
}
@Override
public String getKey() {
	return KEY;
}
@Override
public String getName() {
	return FOLDER_FACET_NAME;
}
@Override
public String getType() {
		return FOLDER_FACET_TYPE;
}
@Override
public String getFacetClass() {
	return FOLDER_FACET_CLASS;
}
@Override
public  Sack apply(Entigrator entigrator, Sack entity) {
	return add(entigrator, entity);
}
public static Sack add(Entigrator entigrator, Sack entity) {
	try { 
        String path$=entigrator.getEntihome()+"/"+entity.getKey();
        File folder=new File(path$);
        if(!folder.exists())
        	if(!folder.mkdir()) {
        		System.out.println("FolderHandler:apply:cannot create folder="+path$);
    			return entity;
        	}
       // System.out.println("FolderHandler:assign:property="+FOLDER_FACET_TYPE+";   value="+Locator.LOCATOR_TRUE+"; entity="+entity.getKey());
        entity=entigrator.assignProperty(FOLDER_FACET_TYPE,Locator.LOCATOR_TRUE,entity.getKey());
        if(!entity.existsElement(FACET))
        	entity.createElement(FACET);
        entity.putElementItem(FACET, new Core(ModuleHandler.SYSTEM,KEY,classLocator()));
        entigrator.reindexEntity(entity);
        entigrator.putEntity(entity);
		return entity;
        }catch(Exception e) {
        	System.out.println("FolderHandler:apply:"+e.toString());
			return null;
        }
}
@Override
public Sack remove(Entigrator entigrator, Sack entity) {
	return delete(entigrator, entity);
}
public static Sack delete(Entigrator entigrator, Sack entity) {	
	if(entity==null)
		return null;
	String entityType$=entity.getProperty("entity");
	if(FOLDER_FACET_TYPE.equals(entityType$))
		return entity;
	try {
	String path$=entigrator.getEntihome()+"/"+entity.getKey();
	//System.out.println("FolderHandler:remove:path="+path$);
	File folder=new File(path$);
	if(folder.exists()) {
		EntityToolset.deleteDirectory(folder);
	}
	entity=entigrator.takeOffProperty(FOLDER_FACET_TYPE, entity.getKey());
	entity.removeElementItem(FACET, KEY);
	entigrator.putEntity(entity);
}catch(Exception e) {
   System.out.println("FolderHandler:remove:"+e.toString());
}
   return entity;
}
}
