package gdt.base.generic;

/*
 * Copyright 2016-2023 Alexander Imas
  */
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.Logger;

public class Locator {
	public static final String PARENT="parent";
	public final static String INSTANCE="instance";
	public static final String VALUE_DELIMITER = "=";
    public static final String ARRAY_DELIMITER ="_;A_";
    public static final String NAME_DELIMITER ="_;N_";
    public static final String LOCATOR_TITLE="title";
    public static final String LOCATOR_SUBTITLE="subtitle";
    public static final String LOCATOR_ENTITY_KEY="entity key";
    public static final String LOCATOR_TYPE="type";
    public static final String LOCATOR_RETURN_VALUE="return value";
    public static final String LOCATOR_SCOPE="scope";
    public static final String LOCATOR_CHECKABLE="locator checkable";
    public static final String LOCATOR_CHECKED="locator checked";
    public static final String LOCATOR_TRUE="true";
    public static final String LOCATOR_FALSE="false";
    public static String toString(Properties props) {
    	if (props == null||props.size()<1) {
    		System.out.println("Locator:toString:empty properties");
            return null;
    	}
       try{
        StringBuffer sb = new StringBuffer();
        Enumeration<?> keys = props.keys();
        if(keys==null)
        	return null;
        String name$;
        String value$;
        while (keys.hasMoreElements()) {
            name$ = (String) keys.nextElement();
            value$ = props.getProperty(name$);
            if (value$ != null)
                sb.append(name$ + VALUE_DELIMITER + value$ + NAME_DELIMITER);
        }
        String locator$ = sb.toString();
        locator$.substring(0, locator$.length() - NAME_DELIMITER.length());
        return sb.toString();
       }catch(Exception e){
    	   Logger.getLogger(Locator.class.getName()).severe(":toString:"+e.toString());
    	   return null;
       }
    }
     public static String getProperty(String locator$,String property$){
    	try {
    	if(locator$==null||property$==null)
    		return null;
    	Properties props=toProperties( locator$);
    	if(props==null)
    		return null;
    	return props.getProperty(property$);
    	}catch(Exception e) {
    		System.out.println("Locator:getProperty:cannot get property="+property$+ "  locator="+locator$);
    		return null;
    	}
    }
     public static Properties toProperties(String locator$) {
       // System.out.println("Locator:toProperties:locator="+locator$);
    	if (locator$ == null){
             return null;
        }
        Properties props = new Properties();
        String[] sa = locator$.split(NAME_DELIMITER);
        if (sa == null){
        	Logger.getLogger(Locator.class.getName()).severe(":toProperties:cannot split fields");
            return null;
        }
        String[] na;
        for (int i = 0; i < sa.length; i++) {
            try {
            	
                na = sa[i].split(VALUE_DELIMITER);
                if (na == null || na.length < 2)
                    continue;
                props.setProperty(na[0], na[1]);
            } catch (Exception e) {
            	Logger.getLogger(Locator.class.getName()).severe(":toProperties:"+e.toString());
            }
        }
        if (props.isEmpty()){
        	Logger.getLogger(Locator.class.getName()).severe(":toProperties:empty");
        	return null;
        }
        return props;
    }
     public static String toString( String[] sa) {
        if(sa==null)
        	return null;
        StringBuffer list = new StringBuffer();
        for (int i = 0; i < sa.length; i++)
            list.append(sa[i] + ARRAY_DELIMITER);
        String list$ = list.toString();
        try{
        list$ = list$.substring(0, list$.length() - ARRAY_DELIMITER.length());
        }catch(Exception e){}
        return list$;
    }
     public static String[] toArray(String list$){
    	if(list$==null)
    		return null;
    	if(list$.indexOf(ARRAY_DELIMITER)<0)
    		return new String[]{list$};
    	return list$.split(ARRAY_DELIMITER);
    }
     public static String append(String locator$, String name$, String value$) {
        if (name$ == null || value$ == null) {
        	LocatorException le= new LocatorException("Wrong argument name="+name$+" value="+value$);
        	le.printStackTrace();
         }
        Properties locator =toProperties(locator$);
       
        if (locator == null)
        	locator = new Properties();
        if(locator.getProperty(name$)!=null)
        	locator.replace(name$, value$);
        else	
           locator.setProperty(name$, value$);
        //System.out.println("Locator:append: name="+name$+"  value="+value$+"   locator="+locator);	
        return toString(locator);
    }
     public static String remove(String locator$,String name$) {
        if (name$ == null )
            return locator$;
        Properties locator =toProperties(locator$);
        if (locator == null)
        	return locator$;
        Enumeration<?> en=locator.keys();
        String key$;
        while(en.hasMoreElements()){
        	key$=(String)en.nextElement();
        	if(name$.equals(key$)){
        		locator.remove(key$);
        		break;
        		}
        }
        return toString(locator);
    }
     public static String merge(String target$,String source$) {
        try{
        Properties locator =toProperties(source$);
        if (locator == null)
        	return target$;
        Enumeration<?> en=locator.keys();
        String key$;
        String value$;
        while(en.hasMoreElements()){
        	key$=(String)en.nextElement();
        	if(INSTANCE.equals(key$))
         			continue;
       		if(PARENT.equals(key$)	)
        				continue;
        	value$=locator.getProperty(key$);
        	target$=Locator.append(target$, key$, value$);
        }
        return target$;
        }catch(Exception e){
        	Logger.getLogger(Locator.class.getName()).severe(e.toString());
        	return null;
        }
    }
    public static class LocatorException extends Exception { 
        public LocatorException(String errorMessage) {
            super(errorMessage);
        }
    }
}
