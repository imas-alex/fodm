package gdt.base.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import gdt.base.store.Entigrator;
import gdt.base.store.IndexHandler;
import gdt.base.store.Sack;

public class EventHandler {
	public static final	String NAME="Events";
	public static final	String TYPE="events";
	public static final	String KEY="_ohFgnS1GWzafxslParpkvqk3XwA";
	public static final	String LOCATOR="locator";
	public static final	String CONSUMED="consumed";	
	public static Sack getEvents(Entigrator entigrator) {
		Sack events=entigrator.getEntity(KEY);
		if(events!=null) {
        	return events;
		}
		events=new Sack();
        events.setKey(KEY);
        events.setPath(entigrator.getEntihome()+"/"+IndexHandler.CONTAINER_ENTITIES+"/data/"+KEY);
        events.createElement("LOCATOR");
        events.createElement("CONSUMED");
        events.store();
		entigrator.reindexEntity(events);
        return events;
	}
}
