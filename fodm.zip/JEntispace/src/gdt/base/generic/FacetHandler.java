package gdt.base.generic;
/*
 * Copyright 2016-2023 Alexander Imas
 */
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Properties;


import gdt.base.facet.FolderHandler;
import gdt.base.facet.ModuleHandler;
import gdt.base.store.Core;
import gdt.base.store.Entigrator;
import gdt.base.store.Identity;
import gdt.base.store.Sack;
import gdt.gui.generic.IconLoader;

public  abstract class FacetHandler {
public static final String FACET="facet";	
public static final String FACET_KEY="facet key";
public static final String FACET_MODULE="module";
public static final String FACET_NAME="facet name";	
public static final String FACET_TYPE="facet type";	
public static final String FACET_HANDLER_CLASS="handler class";
public static final String FACET_MASTER_CLASS="master class";
public static final String FACET_MASTER_KEY="master key";
public static final String FACET_CONTAINER_TYPE="container type";
public static final String FACET_CONTAINER_INTERNAL="container internal";
public static final String FACET_ADDABLE="addable";
public static final String FACET_REMOVABLE="removable";
public static final String FACET_ACTION="action";
public static final String HANDLER_ELEMENT="facet.handler";
public static final String CONTAINS_FOLDER="contains folder";
protected String locator$;
protected String entity$;
protected String key$;
protected String name$;
protected String addable$;
protected String removable$;
protected Entigrator entigrator;
protected FacetHandler() {
}
protected FacetHandler(Entigrator entigrator,String alocator$) {
	if(alocator$==null)
		return;
	locator$=alocator$;
	this.entigrator=entigrator;
	Properties locator=Locator.toProperties(locator$);
	key$=locator.getProperty(FACET_KEY);
	name$=locator.getProperty(FACET_NAME);
	entity$=locator.getProperty(Entigrator.ENTITY_LABEL);
	addable$=locator.getProperty(FACET_ADDABLE);
	removable$=locator.getProperty(FACET_REMOVABLE);
}

public static FacetHandler build(Entigrator entigrator,String className$) {
	try {
	System.out.println("FacetHandler:build:class="+className$);
    Class<?> cls=null;
	cls=entigrator.getClassLoader().loadClass(className$);
		Constructor<?> cns=cls.getConstructor(Entigrator.class,String.class);
		if(cns==null) {
			System.out.println("FacetHandler:build:2:cannot get default constructor");
			return null;
		}
		cns.setAccessible(true);
		Object  obj=null;
 	    try {
		   obj= cns.newInstance(entigrator,null);
 	    }catch(Exception ee) {
 	    	System.out.println("FacetMaster:build:3:"+ee.toString());
 	    	return null;
 	    }
 	  // System.out.println("JContext:build:object="+obj.getClass().getName());
 	    return (FacetHandler)obj;
	}catch(Exception e) {
		System.out.println("FacetMaster:build:0:"+e.toString());
	}
	return null;
}
public static FacetHandler buildOn(Entigrator entigrator,String locator$) {
	try {
	//System.out.println("FacetHandler:buildOn:locator="+locator$);
	String className$=Locator.getProperty(locator$,FACET_HANDLER_CLASS);
	//System.out.println("FacetMaster:buildOn:class="+className$);
	Class<?> cls=null;
			//cls=entigrator.getClassLoader().loadClass(className$);
		cls=entigrator.getClass(className$);
		Constructor<?> cns=cls.getConstructor(Entigrator.class,String.class);
		if(cns==null) {
			System.out.println("FacetHandler:buildOn:2:cannot get default constructor");
			return null;
		}
	//	System.out.println("FacetHandler:buildOn:constructor="+cns.toString());
		cns.setAccessible(true);
		Object  obj=null;
 	    try {
		   obj= cns.newInstance(entigrator,locator$);
 	    }catch(Exception ee) {
 	    	System.out.println("FacetMaster:build:3:"+ee.toString());
 	    	return null;
 	    }
 	    return (FacetHandler)obj;
	}catch(Exception e) {
		System.out.println("FacetMaster:buildOn:0:"+e.toString());
	}
	return null;
}

public static String createEntity(Entigrator entigrator,String locator$) {
	//System.out.println("FacetHandler:new entity:locator:="+locator$);
	String label$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	String entityKey$=entigrator.getKey(label$);
	String module$=Locator.getProperty(locator$,ModuleHandler.FACET_MODULE);
	if(module$==null)
		module$=ModuleHandler.SYSTEM;
	if(entityKey$!=null)
		label$=label$+Identity.key().substring(0,4);
	String facetType$=Locator.getProperty(locator$, FACET_TYPE);
	Sack entity=entigrator.newEntity(label$, facetType$);
	if(entity==null) {
		System.out.println("FacetHandler:newEntity:cannot create entity="+ label$);
		locator$=Locator.append(locator$, Locator.LOCATOR_RETURN_VALUE, Locator.LOCATOR_FALSE); 
		return locator$;
	}
	//entity.print();
	if(!entity.existsElement(FACET))
      	entity.createElement(FACET);
	locator$=Locator.append( locator$, Entigrator.ENTITY_LABEL, entity.getProperty(Entigrator.LABEL));
	 String facetKey$=Locator.getProperty(locator$, FACET_KEY);
    entity.putElementItem(FACET, new Core(module$,facetKey$,locator$));
    entity=entigrator.assignProperty(facetType$,Locator.LOCATOR_TRUE, entity.getKey());
    String iconFile$=Locator.getProperty(locator$,IconLoader.ICON_FILE);
    if(iconFile$!=null)
    	entity.putAttribute(new Core(module$,"icon",iconFile$));
    entigrator.putEntity(entity);
    String containsFolder$=Locator.getProperty(locator$, CONTAINS_FOLDER);
    if(Locator.LOCATOR_TRUE.equals(containsFolder$)) {
       	FolderHandler.assign(entigrator, locator$);
    }  entigrator.reindexEntity(entity);
    entity=entigrator.getEntity(entity.getKey());
    //entity.print();
	return locator$;
}
public String getLocator() {
	return locator$;
	}
public String[] getFacetMethods() {
Method[] methods = getClass().getDeclaredMethods();
ArrayList<String>ml=new ArrayList<String>();
for(int i = 0; i < methods.length; i++) {
   Type[] ta=methods[i].getParameterTypes();
   if(ta.length==2) 
	   if(ta[0].getTypeName().equals(entigrator.getClass().getName())
			   &&ta[1].getTypeName().equals(locator$.getClass().getName())) {
			   ml.add(methods[i].getName());
			   System.out.println("The method is: " + methods[i].toString());
	   }
	}
 String[] ma=new String[ml.size()];
 ml.toArray(ma);
return ma;
}
public void perform (String method$) {
	try {
	Method method=getClass().getMethod(method$, entigrator.getClass(),locator$.getClass());
	method.invoke(this, entigrator,locator$);
	}catch(Exception e) {
		System.out.println("FacetHandler:perform:method="+method$+"; "+e.toString());
	}
}
public abstract String getName();
public abstract String getType();
public abstract String getFacetClass();
public String getFacetKey() {
	return key$;
}
public static boolean isAssigned(FacetHandler facetHandler, Sack entity) {
	if(entity.getElementItem("facet", facetHandler.getType())!=null)
		return true;
	return false;
}
public static boolean isAssignable(Entigrator entigrator,Class facetClass, Sack entity) {
	if(entity==null)
		return false;
	try {
	Core[] ca=entity.elementGet(FACET);
	if(ca==null) {
		System.out.println(" FacetHandler:isAssigned:no facets in entity="+entity.getProperty("label"));
		return false;
	}
	String class$;
	String facetClass$=facetClass.getName();
	Class cls;
		for(Core c:ca) {
	      	class$=Locator.getProperty(c.value, FACET_HANDLER_CLASS);
	      	cls=entigrator.getClass(class$);
	      	if(facetClass.isAssignableFrom(cls))
	      		return true;
		}
	
	}catch(Exception e) {
		System.out.println(" FacetHandler:isAssignable:"+e.toString());
	
	}
	return false;
}
public boolean isAdded(Entigrator entigrator,String locator$ ) {
	String key$=getKey();
	if(key$==null) {
		System.out.println(" FacetHandler:isAdded:facet key is null:locator="+locator$);
		return false;	
	}
	//System.out.println(" FacetHandler:isAdded:check facet key="+ key$);
	try {
		String entity$=Locator.getProperty(locator$, Entigrator.ENTITY_LABEL);
	//	System.out.println(" FacetHandler:isAdded:entity label="+entity$);
		Sack entity=entigrator.getEntityAtLabel(entity$);
		if(entity==null) {
			System.out.println(" FacetHandler:isAdded:cannot get entity="+entity$);
			return false;
		}
		String facetType$=Locator.getProperty(locator$, FACET_TYPE);
		String entityType$=entity.getProperty(Entigrator.ENTITY);
		System.out.println(" FacetHandler:isAdded:check: entity value="+entityType$+"; facet type="+facetType$);  
		if(entityType$.equals(facetType$)) {
			System.out.println(" FacetHandler:is added="+facetType$);
			return true;
		}
		String value$=entity.getProperty(facetType$);
		// System.out.println(" FacetHandler:isAdded:check: entity value="+entityValue$+"; facet type="+facetType$);  
	   if(value$==null||!value$.equals(Locator.LOCATOR_TRUE)) {
		   System.out.println(" FacetHandler:isAdded:facet '"+facetType$+"' not set in entity="+entity.getProperty(Entigrator.LABEL));  
				    return false;	
	   }
	  if(!entity.existsElement(FACET)) {
		System.out.println(" FacetHandler:isAdded:element="+FACET+" not exists. Return false");
		return false;
	}
	//System.out.println(" FacetHandler:isAdded:1");
	if(entity.getElementItem(FACET, key$)==null) {
		System.out.println(" FacetHandler:isAdded:element="+FACET+" doesn't contain key="+key$+". Return false. ");
		return false;
	}else {
		System.out.println(" FacetHandler:is added="+facetType$);
	    return true;
	}
	}catch(Exception e) {
		System.out.println(" FacetHandler:isAdded:"+e.toString());
	}
	return false;
}
public boolean isAddable(Entigrator entigrator,String locator$ ) {
	if(Locator.LOCATOR_TRUE.equals(addable$))
		return true;
	return false;
}
public boolean isRemovable(Entigrator entigrator,String locator$ ) {
	if(Locator.LOCATOR_TRUE.equals(removable$))
		return true;
	return false;
}
public String[] listMembers(Entigrator entigrator, String locator$) {
	String facetName$=Locator.getProperty(locator$, FACET_NAME);
	return entigrator.listEntities(facetName$);
}

public  abstract String getKey();
public  abstract Sack  apply(Entigrator entigrator, Sack entity);
public  abstract Sack  remove(Entigrator entigrator, Sack entity);

public static void putDefaultFacetsIntoSession(Entigrator entigrator) {
	try {
//	System.out.println(" FacetHandler:putDefaultFacetsIntoSession:");
	Sack session=SessionHandler.getSession(entigrator);
	String folderHandler$=FolderHandler.classLocator();
	String folderKey$=Locator.getProperty(folderHandler$, FACET_KEY);
	if(!session.existsElement(HANDLER_ELEMENT))
		session.createElement(HANDLER_ELEMENT);
	session.putElementItem(HANDLER_ELEMENT, new Core(ModuleHandler.SYSTEM,folderKey$,folderHandler$));
    entigrator.putEntity(session);
	}catch(Exception e) {
		System.out.println("FacetHandler:putDefaultFacetsIntoSession:"+e.toString());
	}
		
}
public static FacetHandler[] getHandlers(Entigrator entigrator,Sack entity) {
	try {
		Core[] ca=entity.elementGet("facet");
		if(ca==null)
			return null;
		ArrayList<FacetHandler>fl=new ArrayList<FacetHandler>();
		FacetHandler fh;
		for(Core c:ca) {
			fh=buildOn(entigrator,c.value);
			if(fh!=null)
				fl.add(fh);
		}
		FacetHandler[] fha=new FacetHandler[fl.size()];
		fl.toArray(fha);
		return fha;
	}catch(Exception e) {
		System.out.println("FacetHandler:getHandlers:"+e.toString());
	}
	return null;
	
}
public String getClassLocator() { return null;}

public void appendLocator(String name$,String value$) {
	if(name$==null)
		return;
	if(value$==null)
	System.out.println("FacetHandler:appendLocator:before locator="+locator$+"  name="+name$+" value="+value$);
	locator$=Locator.append(locator$, name$, value$);
	//System.out.println("FacetHandler:appendLocator:after locator="+locator$);
	getLocator();
}
}

